﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MssCorsework
{
    public partial class calculateBillControl : UserControl
    {
        public calculateBillControl()
        {
            InitializeComponent();
        }

        SQLQueries sqlq = new SQLQueries();
        labReportViewer lrv = new labReportViewer();

        private void Button_Search_Click(object sender, EventArgs e)
        {
            string searchNIC = Textbox_SearchNIC.Text;
            DateTime date = Datepicker_aDate.Value;

            if (Textbox_SearchNIC.Text == "")
            {
                label_ESearchNIC.Visible = true;
                label_ESearchNIC.Text = "Patient's NIC or Guardian's NIC is required!";
            }
            else
            {
                SqlDataReader dr = sqlq.InternalPatient(searchNIC, date);
                if (dr.Read())
                {
                    label_ID.Text = dr[0].ToString();
                    Textbox_pName.Text = dr[2].ToString();
                    Textbox_AdmissionNum.Text = dr[5].ToString();
                    Textbox_pres.Text = dr[7].ToString();
                    Textbox_reports.Text = dr[8].ToString();
                }
                else
                {
                    MessageBox.Show("Invalid Patient's or Guardian's NIC", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void Textbox_dFee_KeyPress(object sender, KeyPressEventArgs e)
        {
            //allow only numaric values for contact number
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 32)
            {
                e.Handled = true;
            }
        }

        private void Textbox_hCharge_KeyPress(object sender, KeyPressEventArgs e)
        {
            //allow only numaric values for contact number
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 32)
            {
                e.Handled = true;
            }
        }

        private void Textbox_aTax_KeyPress(object sender, KeyPressEventArgs e)
        {
            //allow only numaric values for contact number
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 32)
            {
                e.Handled = true;
            }
        }

        private void clear()
        {
            Textbox_SearchNIC.Text = "";
            Textbox_pres.Text = "";
            Textbox_reports.Text = "";
            Textbox_pName.Text = "";
            Textbox_AdmissionNum.Text = "";
            Textbox_RCharge.Text = "";
            Textbox_MCharge.Text = "";
            Textbox_RepCharge.Text = "";
            Textbox_charge.Text = "";
        }

        private void Button_SavePayment_Click(object sender, EventArgs e)
        {
            if (Textbox_RCharge.Text == "")
            {
                label_RCharge.Visible = true;
                label_RCharge.Text = "Room Charges is required!";
            }
            else if (Textbox_MCharge.Text == "")
            {
                label_MCharge.Visible = true;
                label_MCharge.Text = "Medicine Charges is required!";
            }
            else if (Textbox_RepCharge.Text == "")
            {
                label_RepCharge.Visible = true;
                label_RepCharge.Text = "Report Charges is required!";
            }
            else
            {
                try
                {
                    string pNIC = Textbox_SearchNIC.Text;
                    DateTime date = Datepicker_aDate.Value;
                    string pName = Textbox_pName.Text;
                    int admNumber = int.Parse(Textbox_AdmissionNum.Text);
                    int RCharge = int.Parse(Textbox_RCharge.Text);
                    int MCharge = int.Parse(Textbox_MCharge.Text);
                    int RepCharge = int.Parse(Textbox_RepCharge.Text);
                    int Total = int.Parse(Textbox_charge.Text);
                    int Id = int.Parse(label_ID.Text);

                    //pass values for internalPatientCharges query which include in SQLQueries class
                    sqlq.internalPatientCharges(RCharge, MCharge, RepCharge, Total, Id);
                    Message1 pr = new Message1();
                    pr.label1.Text = "Payment Details Added Successfully!";
                    pr.label1.Location = new System.Drawing.Point(41, 200);
                    pr.Show();
                    this.clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Please Check The Values" + ex, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void Btn_result_Click(object sender, EventArgs e)
        {
            int value1 = int.Parse(Textbox_RCharge.Text);
            int value2 = int.Parse(Textbox_MCharge.Text);
            int value3 = int.Parse(Textbox_RepCharge.Text);

            //Find Total Charge
            int result = value1 + value2 + value3;
            Textbox_charge.Text = result.ToString();
        }

        private void Button_bill_Click(object sender, EventArgs e)
        {
            string pNIC = Textbox_SearchNIC.Text;
            DateTime date = Datepicker_aDate.Value;

            if (Textbox_SearchNIC.Text == "")
            {
                label_ESearchNIC.Visible = true;
                label_ESearchNIC.Text = "Patient's NIC or Guardian's NIC is required!";
            }
            else
            {
                HospitelBillReport lr = new HospitelBillReport();
                SqlConnection con = new SqlConnection();
                con = MSSDBConnection.MSSConnection();
                string labReport = "SELECT * FROM TableInternalPatients WHERE pNIC = '" + pNIC + "' AND addmittedDate = '" + date + "'";
                DataSet ds = new DataSet();
                SqlDataAdapter sda = new SqlDataAdapter(labReport, con);
                sda.Fill(ds, "TableInternalPatients");

                lr.SetDataSource(ds.Tables["TableInternalPatients"]);
                lrv.crystalReportViewer1.ReportSource = lr;
                lrv.crystalReportViewer1.Refresh();
                lrv.Show();
            }
        }
    }
}
