﻿namespace MssCorsework
{
    partial class PaymentControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PaymentControl));
            this.bunifuGradientPanel1 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.Textbox_dFee = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Textbox_hCharge = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Textbox_aTax = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.btn_result = new Bunifu.Framework.UI.BunifuFlatButton();
            this.label_aeTax = new System.Windows.Forms.Label();
            this.label_heCharge = new System.Windows.Forms.Label();
            this.label_deFee = new System.Windows.Forms.Label();
            this.Textbox_charge = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.lbl_totalCharge = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lbl_aTax = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lbl_hCharge = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_dFee = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuSeparator3 = new Bunifu.Framework.UI.BunifuSeparator();
            this.Textbox_doctorName = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Textbox_appointmentNumber = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.lbl_doctorName = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lbl_appointmentNumber = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Datepicker_aDate = new System.Windows.Forms.DateTimePicker();
            this.label_ID = new System.Windows.Forms.Label();
            this.bunifuSeparator2 = new Bunifu.Framework.UI.BunifuSeparator();
            this.panel_DocType = new System.Windows.Forms.Panel();
            this.btn_Type4 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btn_Type3 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btn_Type1 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btn_Type2 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Button_bill = new Bunifu.Framework.UI.BunifuFlatButton();
            this.label_ESearchNIC = new System.Windows.Forms.Label();
            this.bunifuSeparator1 = new Bunifu.Framework.UI.BunifuSeparator();
            this.Button_Search = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Label_SearchNIC = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Textbox_SearchNIC = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label_Errors = new System.Windows.Forms.Label();
            this.label_EDate = new System.Windows.Forms.Label();
            this.Textbox_NIC = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Textbox_pName = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Button_SavePayment = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Label_Date = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_dNIC = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_Name = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_Title = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuGradientPanel1.SuspendLayout();
            this.panel_DocType.SuspendLayout();
            this.SuspendLayout();
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_dFee);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_hCharge);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_aTax);
            this.bunifuGradientPanel1.Controls.Add(this.btn_result);
            this.bunifuGradientPanel1.Controls.Add(this.label_aeTax);
            this.bunifuGradientPanel1.Controls.Add(this.label_heCharge);
            this.bunifuGradientPanel1.Controls.Add(this.label_deFee);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_charge);
            this.bunifuGradientPanel1.Controls.Add(this.lbl_totalCharge);
            this.bunifuGradientPanel1.Controls.Add(this.lbl_aTax);
            this.bunifuGradientPanel1.Controls.Add(this.lbl_hCharge);
            this.bunifuGradientPanel1.Controls.Add(this.Label_dFee);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuSeparator3);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_doctorName);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_appointmentNumber);
            this.bunifuGradientPanel1.Controls.Add(this.lbl_doctorName);
            this.bunifuGradientPanel1.Controls.Add(this.lbl_appointmentNumber);
            this.bunifuGradientPanel1.Controls.Add(this.Datepicker_aDate);
            this.bunifuGradientPanel1.Controls.Add(this.label_ID);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuSeparator2);
            this.bunifuGradientPanel1.Controls.Add(this.panel_DocType);
            this.bunifuGradientPanel1.Controls.Add(this.label_ESearchNIC);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuSeparator1);
            this.bunifuGradientPanel1.Controls.Add(this.Button_Search);
            this.bunifuGradientPanel1.Controls.Add(this.Label_SearchNIC);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_SearchNIC);
            this.bunifuGradientPanel1.Controls.Add(this.label_Errors);
            this.bunifuGradientPanel1.Controls.Add(this.label_EDate);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_NIC);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_pName);
            this.bunifuGradientPanel1.Controls.Add(this.Button_SavePayment);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Date);
            this.bunifuGradientPanel1.Controls.Add(this.Label_dNIC);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Name);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Title);
            this.bunifuGradientPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.Black;
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.Gray;
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(1140, 816);
            this.bunifuGradientPanel1.TabIndex = 2;
            // 
            // Textbox_dFee
            // 
            this.Textbox_dFee.BackColor = System.Drawing.Color.Silver;
            this.Textbox_dFee.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_dFee.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_dFee.ForeColor = System.Drawing.Color.Black;
            this.Textbox_dFee.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_dFee.HintText = "Doctors Fee";
            this.Textbox_dFee.isPassword = false;
            this.Textbox_dFee.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_dFee.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_dFee.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_dFee.LineThickness = 3;
            this.Textbox_dFee.Location = new System.Drawing.Point(66, 564);
            this.Textbox_dFee.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_dFee.Name = "Textbox_dFee";
            this.Textbox_dFee.Size = new System.Drawing.Size(208, 58);
            this.Textbox_dFee.TabIndex = 122;
            this.Textbox_dFee.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Textbox_dFee.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_dFee_KeyPress);
            // 
            // Textbox_hCharge
            // 
            this.Textbox_hCharge.BackColor = System.Drawing.Color.Silver;
            this.Textbox_hCharge.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_hCharge.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_hCharge.ForeColor = System.Drawing.Color.Black;
            this.Textbox_hCharge.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_hCharge.HintText = "Hospital Charge";
            this.Textbox_hCharge.isPassword = false;
            this.Textbox_hCharge.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_hCharge.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_hCharge.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_hCharge.LineThickness = 3;
            this.Textbox_hCharge.Location = new System.Drawing.Point(320, 564);
            this.Textbox_hCharge.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_hCharge.Name = "Textbox_hCharge";
            this.Textbox_hCharge.Size = new System.Drawing.Size(208, 58);
            this.Textbox_hCharge.TabIndex = 121;
            this.Textbox_hCharge.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Textbox_hCharge.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_dFee_KeyPress);
            // 
            // Textbox_aTax
            // 
            this.Textbox_aTax.BackColor = System.Drawing.Color.Silver;
            this.Textbox_aTax.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_aTax.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_aTax.ForeColor = System.Drawing.Color.Black;
            this.Textbox_aTax.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_aTax.HintText = "Appointment Tax";
            this.Textbox_aTax.isPassword = false;
            this.Textbox_aTax.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_aTax.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_aTax.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_aTax.LineThickness = 3;
            this.Textbox_aTax.Location = new System.Drawing.Point(572, 564);
            this.Textbox_aTax.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_aTax.Name = "Textbox_aTax";
            this.Textbox_aTax.Size = new System.Drawing.Size(208, 58);
            this.Textbox_aTax.TabIndex = 120;
            this.Textbox_aTax.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Textbox_aTax.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_dFee_KeyPress);
            // 
            // btn_result
            // 
            this.btn_result.Activecolor = System.Drawing.Color.RoyalBlue;
            this.btn_result.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn_result.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_result.BorderRadius = 0;
            this.btn_result.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.btn_result.ButtonText = "TOTAL";
            this.btn_result.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_result.DisabledColor = System.Drawing.Color.Gray;
            this.btn_result.ForeColor = System.Drawing.Color.White;
            this.btn_result.Iconcolor = System.Drawing.Color.Transparent;
            this.btn_result.Iconimage = null;
            this.btn_result.Iconimage_right = null;
            this.btn_result.Iconimage_right_Selected = null;
            this.btn_result.Iconimage_Selected = null;
            this.btn_result.IconMarginLeft = 0;
            this.btn_result.IconMarginRight = 0;
            this.btn_result.IconRightVisible = true;
            this.btn_result.IconRightZoom = 0D;
            this.btn_result.IconVisible = true;
            this.btn_result.IconZoom = 90D;
            this.btn_result.IsTab = false;
            this.btn_result.Location = new System.Drawing.Point(823, 637);
            this.btn_result.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_result.Name = "btn_result";
            this.btn_result.Normalcolor = System.Drawing.Color.RoyalBlue;
            this.btn_result.OnHovercolor = System.Drawing.Color.Transparent;
            this.btn_result.OnHoverTextColor = System.Drawing.Color.Black;
            this.btn_result.selected = false;
            this.btn_result.Size = new System.Drawing.Size(253, 52);
            this.btn_result.TabIndex = 118;
            this.btn_result.Text = "TOTAL";
            this.btn_result.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_result.Textcolor = System.Drawing.Color.White;
            this.btn_result.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_result.Click += new System.EventHandler(this.Btn_result_Click);
            // 
            // label_aeTax
            // 
            this.label_aeTax.AutoSize = true;
            this.label_aeTax.BackColor = System.Drawing.Color.Transparent;
            this.label_aeTax.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_aeTax.ForeColor = System.Drawing.Color.Red;
            this.label_aeTax.Location = new System.Drawing.Point(568, 636);
            this.label_aeTax.Name = "label_aeTax";
            this.label_aeTax.Size = new System.Drawing.Size(60, 19);
            this.label_aeTax.TabIndex = 116;
            this.label_aeTax.Text = "label5";
            this.label_aeTax.Visible = false;
            // 
            // label_heCharge
            // 
            this.label_heCharge.AutoSize = true;
            this.label_heCharge.BackColor = System.Drawing.Color.Transparent;
            this.label_heCharge.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_heCharge.ForeColor = System.Drawing.Color.Red;
            this.label_heCharge.Location = new System.Drawing.Point(316, 636);
            this.label_heCharge.Name = "label_heCharge";
            this.label_heCharge.Size = new System.Drawing.Size(60, 19);
            this.label_heCharge.TabIndex = 115;
            this.label_heCharge.Text = "label5";
            this.label_heCharge.Visible = false;
            // 
            // label_deFee
            // 
            this.label_deFee.AutoSize = true;
            this.label_deFee.BackColor = System.Drawing.Color.Transparent;
            this.label_deFee.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_deFee.ForeColor = System.Drawing.Color.Red;
            this.label_deFee.Location = new System.Drawing.Point(62, 636);
            this.label_deFee.Name = "label_deFee";
            this.label_deFee.Size = new System.Drawing.Size(60, 19);
            this.label_deFee.TabIndex = 114;
            this.label_deFee.Text = "label5";
            this.label_deFee.Visible = false;
            // 
            // Textbox_charge
            // 
            this.Textbox_charge.BackColor = System.Drawing.Color.Silver;
            this.Textbox_charge.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_charge.Enabled = false;
            this.Textbox_charge.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_charge.ForeColor = System.Drawing.Color.Black;
            this.Textbox_charge.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_charge.HintText = "Total Charge";
            this.Textbox_charge.isPassword = false;
            this.Textbox_charge.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_charge.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_charge.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_charge.LineThickness = 3;
            this.Textbox_charge.Location = new System.Drawing.Point(823, 564);
            this.Textbox_charge.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_charge.Name = "Textbox_charge";
            this.Textbox_charge.Size = new System.Drawing.Size(253, 58);
            this.Textbox_charge.TabIndex = 113;
            this.Textbox_charge.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // lbl_totalCharge
            // 
            this.lbl_totalCharge.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_totalCharge.AutoSize = true;
            this.lbl_totalCharge.BackColor = System.Drawing.Color.Transparent;
            this.lbl_totalCharge.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_totalCharge.ForeColor = System.Drawing.Color.Black;
            this.lbl_totalCharge.Location = new System.Drawing.Point(817, 527);
            this.lbl_totalCharge.Name = "lbl_totalCharge";
            this.lbl_totalCharge.Size = new System.Drawing.Size(229, 32);
            this.lbl_totalCharge.TabIndex = 112;
            this.lbl_totalCharge.Text = "Total Charge (LKR)";
            // 
            // lbl_aTax
            // 
            this.lbl_aTax.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_aTax.AutoSize = true;
            this.lbl_aTax.BackColor = System.Drawing.Color.Transparent;
            this.lbl_aTax.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_aTax.ForeColor = System.Drawing.Color.Black;
            this.lbl_aTax.Location = new System.Drawing.Point(566, 527);
            this.lbl_aTax.Name = "lbl_aTax";
            this.lbl_aTax.Size = new System.Drawing.Size(214, 32);
            this.lbl_aTax.TabIndex = 109;
            this.lbl_aTax.Text = "Appointment Tax";
            // 
            // lbl_hCharge
            // 
            this.lbl_hCharge.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_hCharge.AutoSize = true;
            this.lbl_hCharge.BackColor = System.Drawing.Color.Transparent;
            this.lbl_hCharge.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_hCharge.ForeColor = System.Drawing.Color.Black;
            this.lbl_hCharge.Location = new System.Drawing.Point(314, 527);
            this.lbl_hCharge.Name = "lbl_hCharge";
            this.lbl_hCharge.Size = new System.Drawing.Size(197, 32);
            this.lbl_hCharge.TabIndex = 106;
            this.lbl_hCharge.Text = "Hospital Charge";
            // 
            // Label_dFee
            // 
            this.Label_dFee.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_dFee.AutoSize = true;
            this.Label_dFee.BackColor = System.Drawing.Color.Transparent;
            this.Label_dFee.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_dFee.ForeColor = System.Drawing.Color.Black;
            this.Label_dFee.Location = new System.Drawing.Point(60, 527);
            this.Label_dFee.Name = "Label_dFee";
            this.Label_dFee.Size = new System.Drawing.Size(157, 32);
            this.Label_dFee.TabIndex = 103;
            this.Label_dFee.Text = "Doctors Fee ";
            // 
            // bunifuSeparator3
            // 
            this.bunifuSeparator3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator3.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator3.LineThickness = 2;
            this.bunifuSeparator3.Location = new System.Drawing.Point(61, 503);
            this.bunifuSeparator3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator3.Name = "bunifuSeparator3";
            this.bunifuSeparator3.Size = new System.Drawing.Size(1018, 10);
            this.bunifuSeparator3.TabIndex = 102;
            this.bunifuSeparator3.Transparency = 255;
            this.bunifuSeparator3.Vertical = false;
            // 
            // Textbox_doctorName
            // 
            this.Textbox_doctorName.BackColor = System.Drawing.Color.Silver;
            this.Textbox_doctorName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_doctorName.Enabled = false;
            this.Textbox_doctorName.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_doctorName.ForeColor = System.Drawing.Color.Black;
            this.Textbox_doctorName.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_doctorName.HintText = "Doctor\'s Name";
            this.Textbox_doctorName.isPassword = false;
            this.Textbox_doctorName.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_doctorName.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_doctorName.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_doctorName.LineThickness = 3;
            this.Textbox_doctorName.Location = new System.Drawing.Point(61, 423);
            this.Textbox_doctorName.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_doctorName.Name = "Textbox_doctorName";
            this.Textbox_doctorName.Size = new System.Drawing.Size(480, 60);
            this.Textbox_doctorName.TabIndex = 101;
            this.Textbox_doctorName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // Textbox_appointmentNumber
            // 
            this.Textbox_appointmentNumber.BackColor = System.Drawing.Color.Silver;
            this.Textbox_appointmentNumber.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_appointmentNumber.Enabled = false;
            this.Textbox_appointmentNumber.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_appointmentNumber.ForeColor = System.Drawing.Color.Black;
            this.Textbox_appointmentNumber.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_appointmentNumber.HintText = "Appointment Number";
            this.Textbox_appointmentNumber.isPassword = false;
            this.Textbox_appointmentNumber.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_appointmentNumber.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_appointmentNumber.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_appointmentNumber.LineThickness = 3;
            this.Textbox_appointmentNumber.Location = new System.Drawing.Point(63, 295);
            this.Textbox_appointmentNumber.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_appointmentNumber.Name = "Textbox_appointmentNumber";
            this.Textbox_appointmentNumber.Size = new System.Drawing.Size(480, 60);
            this.Textbox_appointmentNumber.TabIndex = 100;
            this.Textbox_appointmentNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // lbl_doctorName
            // 
            this.lbl_doctorName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_doctorName.AutoSize = true;
            this.lbl_doctorName.BackColor = System.Drawing.Color.Transparent;
            this.lbl_doctorName.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_doctorName.ForeColor = System.Drawing.Color.Black;
            this.lbl_doctorName.Location = new System.Drawing.Point(55, 375);
            this.lbl_doctorName.Name = "lbl_doctorName";
            this.lbl_doctorName.Size = new System.Drawing.Size(186, 32);
            this.lbl_doctorName.TabIndex = 99;
            this.lbl_doctorName.Text = "Doctor\'s Name";
            // 
            // lbl_appointmentNumber
            // 
            this.lbl_appointmentNumber.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_appointmentNumber.AutoSize = true;
            this.lbl_appointmentNumber.BackColor = System.Drawing.Color.Transparent;
            this.lbl_appointmentNumber.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_appointmentNumber.ForeColor = System.Drawing.Color.Black;
            this.lbl_appointmentNumber.Location = new System.Drawing.Point(60, 247);
            this.lbl_appointmentNumber.Name = "lbl_appointmentNumber";
            this.lbl_appointmentNumber.Size = new System.Drawing.Size(268, 32);
            this.lbl_appointmentNumber.TabIndex = 98;
            this.lbl_appointmentNumber.Text = "Appointment Number";
            // 
            // Datepicker_aDate
            // 
            this.Datepicker_aDate.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Datepicker_aDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Datepicker_aDate.Location = new System.Drawing.Point(496, 142);
            this.Datepicker_aDate.MinimumSize = new System.Drawing.Size(4, 44);
            this.Datepicker_aDate.Name = "Datepicker_aDate";
            this.Datepicker_aDate.Size = new System.Drawing.Size(400, 44);
            this.Datepicker_aDate.TabIndex = 97;
            this.Datepicker_aDate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Datepicker_aDate_KeyPress);
            // 
            // label_ID
            // 
            this.label_ID.AutoSize = true;
            this.label_ID.BackColor = System.Drawing.Color.Transparent;
            this.label_ID.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ID.ForeColor = System.Drawing.Color.Black;
            this.label_ID.Location = new System.Drawing.Point(1053, 27);
            this.label_ID.Name = "label_ID";
            this.label_ID.Size = new System.Drawing.Size(26, 19);
            this.label_ID.TabIndex = 95;
            this.label_ID.Text = "ID";
            this.label_ID.Visible = false;
            // 
            // bunifuSeparator2
            // 
            this.bunifuSeparator2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator2.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuSeparator2.LineThickness = 3;
            this.bunifuSeparator2.Location = new System.Drawing.Point(496, 183);
            this.bunifuSeparator2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator2.Name = "bunifuSeparator2";
            this.bunifuSeparator2.Size = new System.Drawing.Size(400, 10);
            this.bunifuSeparator2.TabIndex = 92;
            this.bunifuSeparator2.Transparency = 255;
            this.bunifuSeparator2.Vertical = false;
            // 
            // panel_DocType
            // 
            this.panel_DocType.BackColor = System.Drawing.Color.Transparent;
            this.panel_DocType.Controls.Add(this.btn_Type4);
            this.panel_DocType.Controls.Add(this.btn_Type3);
            this.panel_DocType.Controls.Add(this.btn_Type1);
            this.panel_DocType.Controls.Add(this.btn_Type2);
            this.panel_DocType.Controls.Add(this.Button_bill);
            this.panel_DocType.Location = new System.Drawing.Point(599, 702);
            this.panel_DocType.MaximumSize = new System.Drawing.Size(480, 242);
            this.panel_DocType.MinimumSize = new System.Drawing.Size(480, 64);
            this.panel_DocType.Name = "panel_DocType";
            this.panel_DocType.Size = new System.Drawing.Size(480, 64);
            this.panel_DocType.TabIndex = 88;
            // 
            // btn_Type4
            // 
            this.btn_Type4.Activecolor = System.Drawing.Color.SteelBlue;
            this.btn_Type4.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_Type4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Type4.BorderRadius = 0;
            this.btn_Type4.ButtonText = "Surgeon";
            this.btn_Type4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Type4.DisabledColor = System.Drawing.Color.Gray;
            this.btn_Type4.Iconcolor = System.Drawing.Color.Transparent;
            this.btn_Type4.Iconimage = null;
            this.btn_Type4.Iconimage_right = null;
            this.btn_Type4.Iconimage_right_Selected = null;
            this.btn_Type4.Iconimage_Selected = null;
            this.btn_Type4.IconMarginLeft = 0;
            this.btn_Type4.IconMarginRight = 0;
            this.btn_Type4.IconRightVisible = true;
            this.btn_Type4.IconRightZoom = 0D;
            this.btn_Type4.IconVisible = true;
            this.btn_Type4.IconZoom = 90D;
            this.btn_Type4.IsTab = false;
            this.btn_Type4.Location = new System.Drawing.Point(0, 199);
            this.btn_Type4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Type4.Name = "btn_Type4";
            this.btn_Type4.Normalcolor = System.Drawing.Color.SteelBlue;
            this.btn_Type4.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.btn_Type4.OnHoverTextColor = System.Drawing.Color.White;
            this.btn_Type4.selected = false;
            this.btn_Type4.Size = new System.Drawing.Size(480, 42);
            this.btn_Type4.TabIndex = 60;
            this.btn_Type4.Text = "Surgeon";
            this.btn_Type4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Type4.Textcolor = System.Drawing.Color.White;
            this.btn_Type4.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btn_Type3
            // 
            this.btn_Type3.Activecolor = System.Drawing.Color.SteelBlue;
            this.btn_Type3.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_Type3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Type3.BorderRadius = 0;
            this.btn_Type3.ButtonText = "Ophthalmologist";
            this.btn_Type3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Type3.DisabledColor = System.Drawing.Color.Gray;
            this.btn_Type3.Iconcolor = System.Drawing.Color.Transparent;
            this.btn_Type3.Iconimage = null;
            this.btn_Type3.Iconimage_right = null;
            this.btn_Type3.Iconimage_right_Selected = null;
            this.btn_Type3.Iconimage_Selected = null;
            this.btn_Type3.IconMarginLeft = 0;
            this.btn_Type3.IconMarginRight = 0;
            this.btn_Type3.IconRightVisible = true;
            this.btn_Type3.IconRightZoom = 0D;
            this.btn_Type3.IconVisible = true;
            this.btn_Type3.IconZoom = 90D;
            this.btn_Type3.IsTab = false;
            this.btn_Type3.Location = new System.Drawing.Point(0, 155);
            this.btn_Type3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Type3.Name = "btn_Type3";
            this.btn_Type3.Normalcolor = System.Drawing.Color.SteelBlue;
            this.btn_Type3.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.btn_Type3.OnHoverTextColor = System.Drawing.Color.White;
            this.btn_Type3.selected = false;
            this.btn_Type3.Size = new System.Drawing.Size(480, 42);
            this.btn_Type3.TabIndex = 59;
            this.btn_Type3.Text = "Ophthalmologist";
            this.btn_Type3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Type3.Textcolor = System.Drawing.Color.White;
            this.btn_Type3.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btn_Type1
            // 
            this.btn_Type1.Activecolor = System.Drawing.Color.SteelBlue;
            this.btn_Type1.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_Type1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Type1.BorderRadius = 0;
            this.btn_Type1.ButtonText = "Cardiologist";
            this.btn_Type1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Type1.DisabledColor = System.Drawing.Color.Gray;
            this.btn_Type1.Iconcolor = System.Drawing.Color.Transparent;
            this.btn_Type1.Iconimage = null;
            this.btn_Type1.Iconimage_right = null;
            this.btn_Type1.Iconimage_right_Selected = null;
            this.btn_Type1.Iconimage_Selected = null;
            this.btn_Type1.IconMarginLeft = 0;
            this.btn_Type1.IconMarginRight = 0;
            this.btn_Type1.IconRightVisible = true;
            this.btn_Type1.IconRightZoom = 0D;
            this.btn_Type1.IconVisible = true;
            this.btn_Type1.IconZoom = 90D;
            this.btn_Type1.IsTab = false;
            this.btn_Type1.Location = new System.Drawing.Point(0, 67);
            this.btn_Type1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Type1.Name = "btn_Type1";
            this.btn_Type1.Normalcolor = System.Drawing.Color.SteelBlue;
            this.btn_Type1.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.btn_Type1.OnHoverTextColor = System.Drawing.Color.White;
            this.btn_Type1.selected = false;
            this.btn_Type1.Size = new System.Drawing.Size(480, 42);
            this.btn_Type1.TabIndex = 25;
            this.btn_Type1.Text = "Cardiologist";
            this.btn_Type1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Type1.Textcolor = System.Drawing.Color.White;
            this.btn_Type1.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btn_Type2
            // 
            this.btn_Type2.Activecolor = System.Drawing.Color.SteelBlue;
            this.btn_Type2.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_Type2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Type2.BorderRadius = 0;
            this.btn_Type2.ButtonText = "Family Physician";
            this.btn_Type2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Type2.DisabledColor = System.Drawing.Color.Gray;
            this.btn_Type2.Iconcolor = System.Drawing.Color.Transparent;
            this.btn_Type2.Iconimage = null;
            this.btn_Type2.Iconimage_right = null;
            this.btn_Type2.Iconimage_right_Selected = null;
            this.btn_Type2.Iconimage_Selected = null;
            this.btn_Type2.IconMarginLeft = 0;
            this.btn_Type2.IconMarginRight = 0;
            this.btn_Type2.IconRightVisible = true;
            this.btn_Type2.IconRightZoom = 0D;
            this.btn_Type2.IconVisible = true;
            this.btn_Type2.IconZoom = 90D;
            this.btn_Type2.IsTab = false;
            this.btn_Type2.Location = new System.Drawing.Point(0, 111);
            this.btn_Type2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Type2.Name = "btn_Type2";
            this.btn_Type2.Normalcolor = System.Drawing.Color.SteelBlue;
            this.btn_Type2.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.btn_Type2.OnHoverTextColor = System.Drawing.Color.White;
            this.btn_Type2.selected = false;
            this.btn_Type2.Size = new System.Drawing.Size(480, 42);
            this.btn_Type2.TabIndex = 26;
            this.btn_Type2.Text = "Family Physician";
            this.btn_Type2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Type2.Textcolor = System.Drawing.Color.White;
            this.btn_Type2.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // Button_bill
            // 
            this.Button_bill.Activecolor = System.Drawing.Color.Crimson;
            this.Button_bill.BackColor = System.Drawing.Color.Crimson;
            this.Button_bill.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_bill.BorderRadius = 0;
            this.Button_bill.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Button_bill.ButtonText = "GENERATE BILL";
            this.Button_bill.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_bill.DisabledColor = System.Drawing.Color.Gray;
            this.Button_bill.ForeColor = System.Drawing.Color.White;
            this.Button_bill.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_bill.Iconimage = null;
            this.Button_bill.Iconimage_right = null;
            this.Button_bill.Iconimage_right_Selected = null;
            this.Button_bill.Iconimage_Selected = null;
            this.Button_bill.IconMarginLeft = 0;
            this.Button_bill.IconMarginRight = 0;
            this.Button_bill.IconRightVisible = true;
            this.Button_bill.IconRightZoom = 0D;
            this.Button_bill.IconVisible = true;
            this.Button_bill.IconZoom = 90D;
            this.Button_bill.IsTab = false;
            this.Button_bill.Location = new System.Drawing.Point(0, 0);
            this.Button_bill.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_bill.Name = "Button_bill";
            this.Button_bill.Normalcolor = System.Drawing.Color.Crimson;
            this.Button_bill.OnHovercolor = System.Drawing.Color.Transparent;
            this.Button_bill.OnHoverTextColor = System.Drawing.Color.Black;
            this.Button_bill.selected = false;
            this.Button_bill.Size = new System.Drawing.Size(480, 64);
            this.Button_bill.TabIndex = 58;
            this.Button_bill.Text = "GENERATE BILL";
            this.Button_bill.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_bill.Textcolor = System.Drawing.Color.White;
            this.Button_bill.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_bill.Click += new System.EventHandler(this.Button_bill_Click);
            // 
            // label_ESearchNIC
            // 
            this.label_ESearchNIC.AutoSize = true;
            this.label_ESearchNIC.BackColor = System.Drawing.Color.Transparent;
            this.label_ESearchNIC.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ESearchNIC.ForeColor = System.Drawing.Color.Red;
            this.label_ESearchNIC.Location = new System.Drawing.Point(60, 200);
            this.label_ESearchNIC.Name = "label_ESearchNIC";
            this.label_ESearchNIC.Size = new System.Drawing.Size(60, 19);
            this.label_ESearchNIC.TabIndex = 85;
            this.label_ESearchNIC.Text = "label5";
            this.label_ESearchNIC.Visible = false;
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator1.LineThickness = 2;
            this.bunifuSeparator1.Location = new System.Drawing.Point(64, 233);
            this.bunifuSeparator1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Size = new System.Drawing.Size(1018, 10);
            this.bunifuSeparator1.TabIndex = 84;
            this.bunifuSeparator1.Transparency = 255;
            this.bunifuSeparator1.Vertical = false;
            // 
            // Button_Search
            // 
            this.Button_Search.Activecolor = System.Drawing.Color.DarkViolet;
            this.Button_Search.BackColor = System.Drawing.Color.DarkViolet;
            this.Button_Search.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_Search.BorderRadius = 0;
            this.Button_Search.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Button_Search.ButtonText = "SEARCH";
            this.Button_Search.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_Search.DisabledColor = System.Drawing.Color.Gray;
            this.Button_Search.ForeColor = System.Drawing.Color.White;
            this.Button_Search.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_Search.Iconimage = null;
            this.Button_Search.Iconimage_right = null;
            this.Button_Search.Iconimage_right_Selected = null;
            this.Button_Search.Iconimage_Selected = null;
            this.Button_Search.IconMarginLeft = 0;
            this.Button_Search.IconMarginRight = 0;
            this.Button_Search.IconRightVisible = true;
            this.Button_Search.IconRightZoom = 0D;
            this.Button_Search.IconVisible = true;
            this.Button_Search.IconZoom = 90D;
            this.Button_Search.IsTab = false;
            this.Button_Search.Location = new System.Drawing.Point(915, 142);
            this.Button_Search.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_Search.Name = "Button_Search";
            this.Button_Search.Normalcolor = System.Drawing.Color.DarkViolet;
            this.Button_Search.OnHovercolor = System.Drawing.Color.Transparent;
            this.Button_Search.OnHoverTextColor = System.Drawing.Color.Black;
            this.Button_Search.selected = false;
            this.Button_Search.Size = new System.Drawing.Size(167, 51);
            this.Button_Search.TabIndex = 83;
            this.Button_Search.Text = "SEARCH";
            this.Button_Search.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_Search.Textcolor = System.Drawing.Color.White;
            this.Button_Search.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Search.Click += new System.EventHandler(this.Button_Search_Click);
            // 
            // Label_SearchNIC
            // 
            this.Label_SearchNIC.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_SearchNIC.AutoSize = true;
            this.Label_SearchNIC.BackColor = System.Drawing.Color.Transparent;
            this.Label_SearchNIC.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SearchNIC.ForeColor = System.Drawing.Color.Black;
            this.Label_SearchNIC.Location = new System.Drawing.Point(58, 104);
            this.Label_SearchNIC.Name = "Label_SearchNIC";
            this.Label_SearchNIC.Size = new System.Drawing.Size(315, 32);
            this.Label_SearchNIC.TabIndex = 82;
            this.Label_SearchNIC.Text = "Patient\'s Or Gurdian\'s NIC";
            // 
            // Textbox_SearchNIC
            // 
            this.Textbox_SearchNIC.BackColor = System.Drawing.Color.Silver;
            this.Textbox_SearchNIC.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_SearchNIC.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_SearchNIC.ForeColor = System.Drawing.Color.Black;
            this.Textbox_SearchNIC.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_SearchNIC.HintText = "Patient\'s Or Gurdian\'s NIC";
            this.Textbox_SearchNIC.isPassword = false;
            this.Textbox_SearchNIC.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_SearchNIC.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_SearchNIC.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_SearchNIC.LineThickness = 3;
            this.Textbox_SearchNIC.Location = new System.Drawing.Point(64, 144);
            this.Textbox_SearchNIC.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_SearchNIC.Name = "Textbox_SearchNIC";
            this.Textbox_SearchNIC.Size = new System.Drawing.Size(400, 45);
            this.Textbox_SearchNIC.TabIndex = 81;
            this.Textbox_SearchNIC.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Textbox_SearchNIC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_SearchNIC_KeyPress);
            // 
            // label_Errors
            // 
            this.label_Errors.AutoSize = true;
            this.label_Errors.BackColor = System.Drawing.Color.Transparent;
            this.label_Errors.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Errors.ForeColor = System.Drawing.Color.Red;
            this.label_Errors.Location = new System.Drawing.Point(59, 669);
            this.label_Errors.Name = "label_Errors";
            this.label_Errors.Size = new System.Drawing.Size(60, 19);
            this.label_Errors.TabIndex = 75;
            this.label_Errors.Text = "label5";
            this.label_Errors.Visible = false;
            // 
            // label_EDate
            // 
            this.label_EDate.AutoSize = true;
            this.label_EDate.BackColor = System.Drawing.Color.Transparent;
            this.label_EDate.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_EDate.ForeColor = System.Drawing.Color.Red;
            this.label_EDate.Location = new System.Drawing.Point(492, 200);
            this.label_EDate.Name = "label_EDate";
            this.label_EDate.Size = new System.Drawing.Size(60, 19);
            this.label_EDate.TabIndex = 71;
            this.label_EDate.Text = "label3";
            this.label_EDate.Visible = false;
            // 
            // Textbox_NIC
            // 
            this.Textbox_NIC.BackColor = System.Drawing.Color.Silver;
            this.Textbox_NIC.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_NIC.Enabled = false;
            this.Textbox_NIC.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_NIC.ForeColor = System.Drawing.Color.Black;
            this.Textbox_NIC.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_NIC.HintText = "Doctor\'s NIC";
            this.Textbox_NIC.isPassword = false;
            this.Textbox_NIC.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_NIC.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_NIC.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_NIC.LineThickness = 3;
            this.Textbox_NIC.Location = new System.Drawing.Point(599, 423);
            this.Textbox_NIC.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_NIC.Name = "Textbox_NIC";
            this.Textbox_NIC.Size = new System.Drawing.Size(480, 60);
            this.Textbox_NIC.TabIndex = 66;
            this.Textbox_NIC.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // Textbox_pName
            // 
            this.Textbox_pName.BackColor = System.Drawing.Color.Silver;
            this.Textbox_pName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_pName.Enabled = false;
            this.Textbox_pName.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_pName.ForeColor = System.Drawing.Color.Black;
            this.Textbox_pName.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_pName.HintText = "Patient\'s Name";
            this.Textbox_pName.isPassword = false;
            this.Textbox_pName.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_pName.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_pName.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_pName.LineThickness = 3;
            this.Textbox_pName.Location = new System.Drawing.Point(596, 295);
            this.Textbox_pName.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_pName.Name = "Textbox_pName";
            this.Textbox_pName.Size = new System.Drawing.Size(480, 60);
            this.Textbox_pName.TabIndex = 61;
            this.Textbox_pName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // Button_SavePayment
            // 
            this.Button_SavePayment.Activecolor = System.Drawing.Color.ForestGreen;
            this.Button_SavePayment.BackColor = System.Drawing.Color.ForestGreen;
            this.Button_SavePayment.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_SavePayment.BorderRadius = 0;
            this.Button_SavePayment.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Button_SavePayment.ButtonText = "SAVE PAYMENT";
            this.Button_SavePayment.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_SavePayment.DisabledColor = System.Drawing.Color.Gray;
            this.Button_SavePayment.ForeColor = System.Drawing.Color.White;
            this.Button_SavePayment.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_SavePayment.Iconimage = null;
            this.Button_SavePayment.Iconimage_right = null;
            this.Button_SavePayment.Iconimage_right_Selected = null;
            this.Button_SavePayment.Iconimage_Selected = null;
            this.Button_SavePayment.IconMarginLeft = 0;
            this.Button_SavePayment.IconMarginRight = 0;
            this.Button_SavePayment.IconRightVisible = true;
            this.Button_SavePayment.IconRightZoom = 0D;
            this.Button_SavePayment.IconVisible = true;
            this.Button_SavePayment.IconZoom = 90D;
            this.Button_SavePayment.IsTab = false;
            this.Button_SavePayment.Location = new System.Drawing.Point(61, 702);
            this.Button_SavePayment.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_SavePayment.Name = "Button_SavePayment";
            this.Button_SavePayment.Normalcolor = System.Drawing.Color.ForestGreen;
            this.Button_SavePayment.OnHovercolor = System.Drawing.Color.Transparent;
            this.Button_SavePayment.OnHoverTextColor = System.Drawing.Color.Black;
            this.Button_SavePayment.selected = false;
            this.Button_SavePayment.Size = new System.Drawing.Size(480, 64);
            this.Button_SavePayment.TabIndex = 57;
            this.Button_SavePayment.Text = "SAVE PAYMENT";
            this.Button_SavePayment.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_SavePayment.Textcolor = System.Drawing.Color.White;
            this.Button_SavePayment.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_SavePayment.Click += new System.EventHandler(this.Button_SavePayment_Click);
            // 
            // Label_Date
            // 
            this.Label_Date.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Date.AutoSize = true;
            this.Label_Date.BackColor = System.Drawing.Color.Transparent;
            this.Label_Date.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Date.ForeColor = System.Drawing.Color.Black;
            this.Label_Date.Location = new System.Drawing.Point(490, 104);
            this.Label_Date.Name = "Label_Date";
            this.Label_Date.Size = new System.Drawing.Size(68, 32);
            this.Label_Date.TabIndex = 25;
            this.Label_Date.Text = "Date";
            // 
            // Label_dNIC
            // 
            this.Label_dNIC.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_dNIC.AutoSize = true;
            this.Label_dNIC.BackColor = System.Drawing.Color.Transparent;
            this.Label_dNIC.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_dNIC.ForeColor = System.Drawing.Color.Black;
            this.Label_dNIC.Location = new System.Drawing.Point(593, 375);
            this.Label_dNIC.Name = "Label_dNIC";
            this.Label_dNIC.Size = new System.Drawing.Size(161, 32);
            this.Label_dNIC.TabIndex = 23;
            this.Label_dNIC.Text = "Doctor\'s NIC";
            // 
            // Label_Name
            // 
            this.Label_Name.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Name.AutoSize = true;
            this.Label_Name.BackColor = System.Drawing.Color.Transparent;
            this.Label_Name.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Name.ForeColor = System.Drawing.Color.Black;
            this.Label_Name.Location = new System.Drawing.Point(593, 247);
            this.Label_Name.Name = "Label_Name";
            this.Label_Name.Size = new System.Drawing.Size(188, 32);
            this.Label_Name.TabIndex = 19;
            this.Label_Name.Text = "Patient\'s Name";
            // 
            // Label_Title
            // 
            this.Label_Title.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Title.AutoSize = true;
            this.Label_Title.BackColor = System.Drawing.Color.Transparent;
            this.Label_Title.Font = new System.Drawing.Font("Felix Titling", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Title.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.Label_Title.Location = new System.Drawing.Point(428, 30);
            this.Label_Title.Name = "Label_Title";
            this.Label_Title.Size = new System.Drawing.Size(296, 35);
            this.Label_Title.TabIndex = 18;
            this.Label_Title.Text = "Payment Details";
            // 
            // PaymentControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.bunifuGradientPanel1);
            this.Name = "PaymentControl";
            this.Size = new System.Drawing.Size(1140, 816);
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            this.panel_DocType.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel1;
        private System.Windows.Forms.DateTimePicker Datepicker_aDate;
        private System.Windows.Forms.Label label_ID;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator2;
        private System.Windows.Forms.Panel panel_DocType;
        public Bunifu.Framework.UI.BunifuFlatButton btn_Type4;
        public Bunifu.Framework.UI.BunifuFlatButton btn_Type3;
        public Bunifu.Framework.UI.BunifuFlatButton btn_Type1;
        public Bunifu.Framework.UI.BunifuFlatButton btn_Type2;
        public Bunifu.Framework.UI.BunifuFlatButton Button_bill;
        private System.Windows.Forms.Label label_ESearchNIC;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator1;
        public Bunifu.Framework.UI.BunifuFlatButton Button_Search;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_SearchNIC;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_SearchNIC;
        private System.Windows.Forms.Label label_Errors;
        private System.Windows.Forms.Label label_EDate;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_NIC;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_pName;
        public Bunifu.Framework.UI.BunifuFlatButton Button_SavePayment;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Date;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_dNIC;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Name;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Title;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator3;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_doctorName;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_appointmentNumber;
        private Bunifu.Framework.UI.BunifuCustomLabel lbl_doctorName;
        private Bunifu.Framework.UI.BunifuCustomLabel lbl_appointmentNumber;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_dFee;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_charge;
        private Bunifu.Framework.UI.BunifuCustomLabel lbl_totalCharge;
        private Bunifu.Framework.UI.BunifuCustomLabel lbl_aTax;
        private Bunifu.Framework.UI.BunifuCustomLabel lbl_hCharge;
        private System.Windows.Forms.Label label_aeTax;
        private System.Windows.Forms.Label label_heCharge;
        private System.Windows.Forms.Label label_deFee;
        public Bunifu.Framework.UI.BunifuFlatButton btn_result;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_dFee;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_hCharge;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_aTax;
    }
}
