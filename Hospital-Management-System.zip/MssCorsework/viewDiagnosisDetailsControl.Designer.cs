﻿namespace MssCorsework
{
    partial class viewDiagnosisDetailsControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(viewDiagnosisDetailsControl));
            this.bunifuGradientPanel1 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.Button_Search = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Textbox_SearchNo = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label_eRepNo = new System.Windows.Forms.Label();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Textbox_labReports = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Textbox_remarks = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label_labReport = new System.Windows.Forms.Label();
            this.label_pEPrescription = new System.Windows.Forms.Label();
            this.Textbox_prescription = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel3 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.label_Errors = new System.Windows.Forms.Label();
            this.label_pERemarks = new System.Windows.Forms.Label();
            this.label_pEchange = new System.Windows.Forms.Label();
            this.label_pESym = new System.Windows.Forms.Label();
            this.label_pEDia = new System.Windows.Forms.Label();
            this.label_pENIC = new System.Windows.Forms.Label();
            this.Textbox_NIC = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Textbox_Sym = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Textbox_changeDetails = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Textbox_Dia = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Button_Report = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Label_Gender = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_TelephoneNum = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_Age = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_Address = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_NIC = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_Title = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuSeparator1 = new Bunifu.Framework.UI.BunifuSeparator();
            this.bunifuGradientPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.Controls.Add(this.bunifuSeparator1);
            this.bunifuGradientPanel1.Controls.Add(this.Button_Search);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_SearchNo);
            this.bunifuGradientPanel1.Controls.Add(this.label_eRepNo);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuCustomLabel1);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_labReports);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_remarks);
            this.bunifuGradientPanel1.Controls.Add(this.label_labReport);
            this.bunifuGradientPanel1.Controls.Add(this.label_pEPrescription);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_prescription);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuCustomLabel2);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuCustomLabel3);
            this.bunifuGradientPanel1.Controls.Add(this.label_Errors);
            this.bunifuGradientPanel1.Controls.Add(this.label_pERemarks);
            this.bunifuGradientPanel1.Controls.Add(this.label_pEchange);
            this.bunifuGradientPanel1.Controls.Add(this.label_pESym);
            this.bunifuGradientPanel1.Controls.Add(this.label_pEDia);
            this.bunifuGradientPanel1.Controls.Add(this.label_pENIC);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_NIC);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_Sym);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_changeDetails);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_Dia);
            this.bunifuGradientPanel1.Controls.Add(this.Button_Report);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Gender);
            this.bunifuGradientPanel1.Controls.Add(this.Label_TelephoneNum);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Age);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Address);
            this.bunifuGradientPanel1.Controls.Add(this.Label_NIC);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Title);
            this.bunifuGradientPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.Black;
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.Gray;
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(1140, 812);
            this.bunifuGradientPanel1.TabIndex = 2;
            // 
            // Button_Search
            // 
            this.Button_Search.Activecolor = System.Drawing.Color.ForestGreen;
            this.Button_Search.BackColor = System.Drawing.Color.ForestGreen;
            this.Button_Search.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_Search.BorderRadius = 0;
            this.Button_Search.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Button_Search.ButtonText = "SEARCH";
            this.Button_Search.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_Search.DisabledColor = System.Drawing.Color.Gray;
            this.Button_Search.ForeColor = System.Drawing.Color.White;
            this.Button_Search.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_Search.Iconimage = null;
            this.Button_Search.Iconimage_right = null;
            this.Button_Search.Iconimage_right_Selected = null;
            this.Button_Search.Iconimage_Selected = null;
            this.Button_Search.IconMarginLeft = 0;
            this.Button_Search.IconMarginRight = 0;
            this.Button_Search.IconRightVisible = true;
            this.Button_Search.IconRightZoom = 0D;
            this.Button_Search.IconVisible = true;
            this.Button_Search.IconZoom = 90D;
            this.Button_Search.IsTab = false;
            this.Button_Search.Location = new System.Drawing.Point(596, 106);
            this.Button_Search.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_Search.Name = "Button_Search";
            this.Button_Search.Normalcolor = System.Drawing.Color.ForestGreen;
            this.Button_Search.OnHovercolor = System.Drawing.Color.Transparent;
            this.Button_Search.OnHoverTextColor = System.Drawing.Color.Black;
            this.Button_Search.selected = false;
            this.Button_Search.Size = new System.Drawing.Size(480, 60);
            this.Button_Search.TabIndex = 91;
            this.Button_Search.Text = "SEARCH";
            this.Button_Search.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_Search.Textcolor = System.Drawing.Color.White;
            this.Button_Search.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Search.Click += new System.EventHandler(this.Button_Search_Click);
            // 
            // Textbox_SearchNo
            // 
            this.Textbox_SearchNo.BackColor = System.Drawing.Color.Silver;
            this.Textbox_SearchNo.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_SearchNo.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_SearchNo.ForeColor = System.Drawing.Color.Black;
            this.Textbox_SearchNo.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_SearchNo.HintText = "Report Number";
            this.Textbox_SearchNo.isPassword = false;
            this.Textbox_SearchNo.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_SearchNo.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_SearchNo.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_SearchNo.LineThickness = 3;
            this.Textbox_SearchNo.Location = new System.Drawing.Point(61, 694);
            this.Textbox_SearchNo.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_SearchNo.Name = "Textbox_SearchNo";
            this.Textbox_SearchNo.Size = new System.Drawing.Size(480, 64);
            this.Textbox_SearchNo.TabIndex = 90;
            this.Textbox_SearchNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Textbox_SearchNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_SearchNo_KeyPress);
            // 
            // label_eRepNo
            // 
            this.label_eRepNo.AutoSize = true;
            this.label_eRepNo.BackColor = System.Drawing.Color.Transparent;
            this.label_eRepNo.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_eRepNo.ForeColor = System.Drawing.Color.Red;
            this.label_eRepNo.Location = new System.Drawing.Point(57, 768);
            this.label_eRepNo.Name = "label_eRepNo";
            this.label_eRepNo.Size = new System.Drawing.Size(60, 19);
            this.label_eRepNo.TabIndex = 89;
            this.label_eRepNo.Text = "label6";
            this.label_eRepNo.Visible = false;
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.Black;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(52, 655);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(194, 32);
            this.bunifuCustomLabel1.TabIndex = 88;
            this.bunifuCustomLabel1.Text = "Report Number";
            // 
            // Textbox_labReports
            // 
            this.Textbox_labReports.BackColor = System.Drawing.Color.Silver;
            this.Textbox_labReports.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_labReports.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_labReports.ForeColor = System.Drawing.Color.Black;
            this.Textbox_labReports.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_labReports.HintText = "Lab Report";
            this.Textbox_labReports.isPassword = false;
            this.Textbox_labReports.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_labReports.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_labReports.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_labReports.LineThickness = 3;
            this.Textbox_labReports.Location = new System.Drawing.Point(596, 549);
            this.Textbox_labReports.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_labReports.Name = "Textbox_labReports";
            this.Textbox_labReports.Size = new System.Drawing.Size(480, 60);
            this.Textbox_labReports.TabIndex = 84;
            this.Textbox_labReports.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // Textbox_remarks
            // 
            this.Textbox_remarks.BackColor = System.Drawing.Color.Silver;
            this.Textbox_remarks.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_remarks.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_remarks.ForeColor = System.Drawing.Color.Black;
            this.Textbox_remarks.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_remarks.HintText = "Remarks";
            this.Textbox_remarks.isPassword = false;
            this.Textbox_remarks.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_remarks.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_remarks.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_remarks.LineThickness = 3;
            this.Textbox_remarks.Location = new System.Drawing.Point(596, 402);
            this.Textbox_remarks.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_remarks.Name = "Textbox_remarks";
            this.Textbox_remarks.Size = new System.Drawing.Size(480, 60);
            this.Textbox_remarks.TabIndex = 83;
            this.Textbox_remarks.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label_labReport
            // 
            this.label_labReport.AutoSize = true;
            this.label_labReport.BackColor = System.Drawing.Color.Transparent;
            this.label_labReport.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_labReport.ForeColor = System.Drawing.Color.Red;
            this.label_labReport.Location = new System.Drawing.Point(592, 613);
            this.label_labReport.Name = "label_labReport";
            this.label_labReport.Size = new System.Drawing.Size(60, 19);
            this.label_labReport.TabIndex = 82;
            this.label_labReport.Text = "label6";
            this.label_labReport.Visible = false;
            // 
            // label_pEPrescription
            // 
            this.label_pEPrescription.AutoSize = true;
            this.label_pEPrescription.BackColor = System.Drawing.Color.Transparent;
            this.label_pEPrescription.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_pEPrescription.ForeColor = System.Drawing.Color.Red;
            this.label_pEPrescription.Location = new System.Drawing.Point(57, 613);
            this.label_pEPrescription.Name = "label_pEPrescription";
            this.label_pEPrescription.Size = new System.Drawing.Size(60, 19);
            this.label_pEPrescription.TabIndex = 81;
            this.label_pEPrescription.Text = "label5";
            this.label_pEPrescription.Visible = false;
            // 
            // Textbox_prescription
            // 
            this.Textbox_prescription.BackColor = System.Drawing.Color.Silver;
            this.Textbox_prescription.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_prescription.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_prescription.ForeColor = System.Drawing.Color.Black;
            this.Textbox_prescription.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_prescription.HintText = "Prescription";
            this.Textbox_prescription.isPassword = false;
            this.Textbox_prescription.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_prescription.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_prescription.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_prescription.LineThickness = 3;
            this.Textbox_prescription.Location = new System.Drawing.Point(58, 549);
            this.Textbox_prescription.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_prescription.Name = "Textbox_prescription";
            this.Textbox_prescription.Size = new System.Drawing.Size(480, 60);
            this.Textbox_prescription.TabIndex = 79;
            this.Textbox_prescription.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel2.ForeColor = System.Drawing.Color.Black;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(590, 498);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(140, 32);
            this.bunifuCustomLabel2.TabIndex = 78;
            this.bunifuCustomLabel2.Text = "Lab Report";
            // 
            // bunifuCustomLabel3
            // 
            this.bunifuCustomLabel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuCustomLabel3.AutoSize = true;
            this.bunifuCustomLabel3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel3.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel3.ForeColor = System.Drawing.Color.Black;
            this.bunifuCustomLabel3.Location = new System.Drawing.Point(52, 498);
            this.bunifuCustomLabel3.Name = "bunifuCustomLabel3";
            this.bunifuCustomLabel3.Size = new System.Drawing.Size(154, 32);
            this.bunifuCustomLabel3.TabIndex = 77;
            this.bunifuCustomLabel3.Text = "Prescription";
            // 
            // label_Errors
            // 
            this.label_Errors.AutoSize = true;
            this.label_Errors.BackColor = System.Drawing.Color.Transparent;
            this.label_Errors.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Errors.ForeColor = System.Drawing.Color.Red;
            this.label_Errors.Location = new System.Drawing.Point(595, 768);
            this.label_Errors.Name = "label_Errors";
            this.label_Errors.Size = new System.Drawing.Size(60, 19);
            this.label_Errors.TabIndex = 75;
            this.label_Errors.Text = "label5";
            this.label_Errors.Visible = false;
            // 
            // label_pERemarks
            // 
            this.label_pERemarks.AutoSize = true;
            this.label_pERemarks.BackColor = System.Drawing.Color.Transparent;
            this.label_pERemarks.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_pERemarks.ForeColor = System.Drawing.Color.Red;
            this.label_pERemarks.Location = new System.Drawing.Point(592, 476);
            this.label_pERemarks.Name = "label_pERemarks";
            this.label_pERemarks.Size = new System.Drawing.Size(60, 19);
            this.label_pERemarks.TabIndex = 74;
            this.label_pERemarks.Text = "label6";
            this.label_pERemarks.Visible = false;
            // 
            // label_pEchange
            // 
            this.label_pEchange.AutoSize = true;
            this.label_pEchange.BackColor = System.Drawing.Color.Transparent;
            this.label_pEchange.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_pEchange.ForeColor = System.Drawing.Color.Red;
            this.label_pEchange.Location = new System.Drawing.Point(54, 476);
            this.label_pEchange.Name = "label_pEchange";
            this.label_pEchange.Size = new System.Drawing.Size(60, 19);
            this.label_pEchange.TabIndex = 73;
            this.label_pEchange.Text = "label5";
            this.label_pEchange.Visible = false;
            // 
            // label_pESym
            // 
            this.label_pESym.AutoSize = true;
            this.label_pESym.BackColor = System.Drawing.Color.Transparent;
            this.label_pESym.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_pESym.ForeColor = System.Drawing.Color.Red;
            this.label_pESym.Location = new System.Drawing.Point(592, 328);
            this.label_pESym.Name = "label_pESym";
            this.label_pESym.Size = new System.Drawing.Size(60, 19);
            this.label_pESym.TabIndex = 72;
            this.label_pESym.Text = "label4";
            this.label_pESym.Visible = false;
            // 
            // label_pEDia
            // 
            this.label_pEDia.AutoSize = true;
            this.label_pEDia.BackColor = System.Drawing.Color.Transparent;
            this.label_pEDia.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_pEDia.ForeColor = System.Drawing.Color.Red;
            this.label_pEDia.Location = new System.Drawing.Point(54, 328);
            this.label_pEDia.Name = "label_pEDia";
            this.label_pEDia.Size = new System.Drawing.Size(60, 19);
            this.label_pEDia.TabIndex = 71;
            this.label_pEDia.Text = "label3";
            this.label_pEDia.Visible = false;
            // 
            // label_pENIC
            // 
            this.label_pENIC.AutoSize = true;
            this.label_pENIC.BackColor = System.Drawing.Color.Transparent;
            this.label_pENIC.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_pENIC.ForeColor = System.Drawing.Color.Red;
            this.label_pENIC.Location = new System.Drawing.Point(57, 177);
            this.label_pENIC.Name = "label_pENIC";
            this.label_pENIC.Size = new System.Drawing.Size(60, 19);
            this.label_pENIC.TabIndex = 70;
            this.label_pENIC.Text = "label2";
            this.label_pENIC.Visible = false;
            // 
            // Textbox_NIC
            // 
            this.Textbox_NIC.AutoSize = true;
            this.Textbox_NIC.BackColor = System.Drawing.Color.Silver;
            this.Textbox_NIC.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_NIC.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_NIC.ForeColor = System.Drawing.Color.Black;
            this.Textbox_NIC.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_NIC.HintText = "Patient\'s NIC";
            this.Textbox_NIC.isPassword = false;
            this.Textbox_NIC.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_NIC.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_NIC.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_NIC.LineThickness = 3;
            this.Textbox_NIC.Location = new System.Drawing.Point(61, 106);
            this.Textbox_NIC.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_NIC.Name = "Textbox_NIC";
            this.Textbox_NIC.Size = new System.Drawing.Size(480, 60);
            this.Textbox_NIC.TabIndex = 66;
            this.Textbox_NIC.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Textbox_NIC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_NIC_KeyPress);
            // 
            // Textbox_Sym
            // 
            this.Textbox_Sym.BackColor = System.Drawing.Color.Silver;
            this.Textbox_Sym.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_Sym.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Sym.ForeColor = System.Drawing.Color.Black;
            this.Textbox_Sym.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_Sym.HintText = "Symptoms";
            this.Textbox_Sym.isPassword = false;
            this.Textbox_Sym.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_Sym.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_Sym.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_Sym.LineThickness = 3;
            this.Textbox_Sym.Location = new System.Drawing.Point(596, 256);
            this.Textbox_Sym.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_Sym.Name = "Textbox_Sym";
            this.Textbox_Sym.Size = new System.Drawing.Size(480, 60);
            this.Textbox_Sym.TabIndex = 64;
            this.Textbox_Sym.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // Textbox_changeDetails
            // 
            this.Textbox_changeDetails.BackColor = System.Drawing.Color.Silver;
            this.Textbox_changeDetails.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_changeDetails.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_changeDetails.ForeColor = System.Drawing.Color.Black;
            this.Textbox_changeDetails.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_changeDetails.HintText = "Change Details";
            this.Textbox_changeDetails.isPassword = false;
            this.Textbox_changeDetails.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_changeDetails.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_changeDetails.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_changeDetails.LineThickness = 3;
            this.Textbox_changeDetails.Location = new System.Drawing.Point(58, 402);
            this.Textbox_changeDetails.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_changeDetails.Name = "Textbox_changeDetails";
            this.Textbox_changeDetails.Size = new System.Drawing.Size(480, 60);
            this.Textbox_changeDetails.TabIndex = 63;
            this.Textbox_changeDetails.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // Textbox_Dia
            // 
            this.Textbox_Dia.BackColor = System.Drawing.Color.Silver;
            this.Textbox_Dia.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_Dia.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Dia.ForeColor = System.Drawing.Color.Black;
            this.Textbox_Dia.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_Dia.HintText = "Diagnosis";
            this.Textbox_Dia.isPassword = false;
            this.Textbox_Dia.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_Dia.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_Dia.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_Dia.LineThickness = 3;
            this.Textbox_Dia.Location = new System.Drawing.Point(58, 256);
            this.Textbox_Dia.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_Dia.Name = "Textbox_Dia";
            this.Textbox_Dia.Size = new System.Drawing.Size(480, 60);
            this.Textbox_Dia.TabIndex = 62;
            this.Textbox_Dia.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // Button_Report
            // 
            this.Button_Report.Activecolor = System.Drawing.Color.Crimson;
            this.Button_Report.BackColor = System.Drawing.Color.Crimson;
            this.Button_Report.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_Report.BorderRadius = 0;
            this.Button_Report.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Button_Report.ButtonText = "VIEW LAB REPORT";
            this.Button_Report.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_Report.DisabledColor = System.Drawing.Color.Gray;
            this.Button_Report.ForeColor = System.Drawing.Color.White;
            this.Button_Report.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_Report.Iconimage = null;
            this.Button_Report.Iconimage_right = null;
            this.Button_Report.Iconimage_right_Selected = null;
            this.Button_Report.Iconimage_Selected = null;
            this.Button_Report.IconMarginLeft = 0;
            this.Button_Report.IconMarginRight = 0;
            this.Button_Report.IconRightVisible = true;
            this.Button_Report.IconRightZoom = 0D;
            this.Button_Report.IconVisible = true;
            this.Button_Report.IconZoom = 90D;
            this.Button_Report.IsTab = false;
            this.Button_Report.Location = new System.Drawing.Point(599, 694);
            this.Button_Report.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_Report.Name = "Button_Report";
            this.Button_Report.Normalcolor = System.Drawing.Color.Crimson;
            this.Button_Report.OnHovercolor = System.Drawing.Color.Transparent;
            this.Button_Report.OnHoverTextColor = System.Drawing.Color.Black;
            this.Button_Report.selected = false;
            this.Button_Report.Size = new System.Drawing.Size(480, 64);
            this.Button_Report.TabIndex = 58;
            this.Button_Report.Text = "VIEW LAB REPORT";
            this.Button_Report.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_Report.Textcolor = System.Drawing.Color.White;
            this.Button_Report.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Report.Click += new System.EventHandler(this.Button_Report_Click);
            // 
            // Label_Gender
            // 
            this.Label_Gender.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Gender.AutoSize = true;
            this.Label_Gender.BackColor = System.Drawing.Color.Transparent;
            this.Label_Gender.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Gender.ForeColor = System.Drawing.Color.Black;
            this.Label_Gender.Location = new System.Drawing.Point(590, 351);
            this.Label_Gender.Name = "Label_Gender";
            this.Label_Gender.Size = new System.Drawing.Size(113, 32);
            this.Label_Gender.TabIndex = 31;
            this.Label_Gender.Text = "Remarks";
            // 
            // Label_TelephoneNum
            // 
            this.Label_TelephoneNum.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_TelephoneNum.AutoSize = true;
            this.Label_TelephoneNum.BackColor = System.Drawing.Color.Transparent;
            this.Label_TelephoneNum.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_TelephoneNum.ForeColor = System.Drawing.Color.Black;
            this.Label_TelephoneNum.Location = new System.Drawing.Point(52, 351);
            this.Label_TelephoneNum.Name = "Label_TelephoneNum";
            this.Label_TelephoneNum.Size = new System.Drawing.Size(185, 32);
            this.Label_TelephoneNum.TabIndex = 29;
            this.Label_TelephoneNum.Text = "Change Details";
            // 
            // Label_Age
            // 
            this.Label_Age.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Age.AutoSize = true;
            this.Label_Age.BackColor = System.Drawing.Color.Transparent;
            this.Label_Age.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Age.ForeColor = System.Drawing.Color.Black;
            this.Label_Age.Location = new System.Drawing.Point(590, 205);
            this.Label_Age.Name = "Label_Age";
            this.Label_Age.Size = new System.Drawing.Size(135, 32);
            this.Label_Age.TabIndex = 27;
            this.Label_Age.Text = "Symptoms";
            // 
            // Label_Address
            // 
            this.Label_Address.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Address.AutoSize = true;
            this.Label_Address.BackColor = System.Drawing.Color.Transparent;
            this.Label_Address.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Address.ForeColor = System.Drawing.Color.Black;
            this.Label_Address.Location = new System.Drawing.Point(52, 205);
            this.Label_Address.Name = "Label_Address";
            this.Label_Address.Size = new System.Drawing.Size(127, 32);
            this.Label_Address.TabIndex = 25;
            this.Label_Address.Text = "Diagnosis";
            // 
            // Label_NIC
            // 
            this.Label_NIC.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_NIC.AutoSize = true;
            this.Label_NIC.BackColor = System.Drawing.Color.Transparent;
            this.Label_NIC.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_NIC.ForeColor = System.Drawing.Color.Black;
            this.Label_NIC.Location = new System.Drawing.Point(55, 55);
            this.Label_NIC.Name = "Label_NIC";
            this.Label_NIC.Size = new System.Drawing.Size(163, 32);
            this.Label_NIC.TabIndex = 23;
            this.Label_NIC.Text = "Patient\'s NIC";
            // 
            // Label_Title
            // 
            this.Label_Title.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Title.AutoSize = true;
            this.Label_Title.BackColor = System.Drawing.Color.Transparent;
            this.Label_Title.Font = new System.Drawing.Font("Felix Titling", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Title.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.Label_Title.Location = new System.Drawing.Point(313, 9);
            this.Label_Title.Name = "Label_Title";
            this.Label_Title.Size = new System.Drawing.Size(545, 35);
            this.Label_Title.TabIndex = 18;
            this.Label_Title.Text = "Patient’s history management";
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.Black;
            this.bunifuSeparator1.LineThickness = 3;
            this.bunifuSeparator1.Location = new System.Drawing.Point(58, 639);
            this.bunifuSeparator1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Size = new System.Drawing.Size(1018, 15);
            this.bunifuSeparator1.TabIndex = 92;
            this.bunifuSeparator1.Transparency = 255;
            this.bunifuSeparator1.Vertical = false;
            // 
            // viewDiagnosisDetailsControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.bunifuGradientPanel1);
            this.Name = "viewDiagnosisDetailsControl";
            this.Size = new System.Drawing.Size(1140, 812);
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel1;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_labReports;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_remarks;
        private System.Windows.Forms.Label label_labReport;
        private System.Windows.Forms.Label label_pEPrescription;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_prescription;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel3;
        private System.Windows.Forms.Label label_Errors;
        private System.Windows.Forms.Label label_pERemarks;
        private System.Windows.Forms.Label label_pEchange;
        private System.Windows.Forms.Label label_pESym;
        private System.Windows.Forms.Label label_pEDia;
        private System.Windows.Forms.Label label_pENIC;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_NIC;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_Sym;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_changeDetails;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_Dia;
        public Bunifu.Framework.UI.BunifuFlatButton Button_Report;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Gender;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_TelephoneNum;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Age;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Address;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_NIC;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Title;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_SearchNo;
        private System.Windows.Forms.Label label_eRepNo;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        public Bunifu.Framework.UI.BunifuFlatButton Button_Search;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator1;
    }
}
