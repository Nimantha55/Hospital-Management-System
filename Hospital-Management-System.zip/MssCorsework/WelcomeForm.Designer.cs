﻿namespace MssCorsework
{
    partial class WelcomeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WelcomeForm));
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.panel_top = new System.Windows.Forms.Panel();
            this.btn_close = new Bunifu.Framework.UI.BunifuImageButton();
            this.btn_minimize = new Bunifu.Framework.UI.BunifuImageButton();
            this.panel_body = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.btn_Start = new Bunifu.Framework.UI.BunifuThinButton2();
            this.Label_title = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.pictureBox_welcome = new System.Windows.Forms.PictureBox();
            this.WelcomedragControl = new Project_SDC.DragControl();
            this.panel_top.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btn_close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_minimize)).BeginInit();
            this.panel_body.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_welcome)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 0;
            this.bunifuElipse1.TargetControl = this;
            // 
            // panel_top
            // 
            this.panel_top.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.panel_top.Controls.Add(this.btn_close);
            this.panel_top.Controls.Add(this.btn_minimize);
            this.panel_top.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_top.Location = new System.Drawing.Point(0, 0);
            this.panel_top.Name = "panel_top";
            this.panel_top.Size = new System.Drawing.Size(1494, 58);
            this.panel_top.TabIndex = 0;
            // 
            // btn_close
            // 
            this.btn_close.BackColor = System.Drawing.Color.Transparent;
            this.btn_close.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_close.Image = ((System.Drawing.Image)(resources.GetObject("btn_close.Image")));
            this.btn_close.ImageActive = null;
            this.btn_close.Location = new System.Drawing.Point(1444, 10);
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(40, 40);
            this.btn_close.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btn_close.TabIndex = 0;
            this.btn_close.TabStop = false;
            this.btn_close.Zoom = 10;
            this.btn_close.Click += new System.EventHandler(this.Btn_close_Click);
            // 
            // btn_minimize
            // 
            this.btn_minimize.BackColor = System.Drawing.Color.Transparent;
            this.btn_minimize.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_minimize.Image = ((System.Drawing.Image)(resources.GetObject("btn_minimize.Image")));
            this.btn_minimize.ImageActive = null;
            this.btn_minimize.Location = new System.Drawing.Point(1403, 10);
            this.btn_minimize.Name = "btn_minimize";
            this.btn_minimize.Size = new System.Drawing.Size(40, 40);
            this.btn_minimize.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btn_minimize.TabIndex = 1;
            this.btn_minimize.TabStop = false;
            this.btn_minimize.Zoom = 10;
            this.btn_minimize.Click += new System.EventHandler(this.Btn_minimize_Click);
            // 
            // panel_body
            // 
            this.panel_body.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel_body.BackgroundImage")));
            this.panel_body.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel_body.Controls.Add(this.btn_Start);
            this.panel_body.Controls.Add(this.Label_title);
            this.panel_body.Controls.Add(this.pictureBox_welcome);
            this.panel_body.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_body.GradientBottomLeft = System.Drawing.Color.Thistle;
            this.panel_body.GradientBottomRight = System.Drawing.Color.Black;
            this.panel_body.GradientTopLeft = System.Drawing.Color.Black;
            this.panel_body.GradientTopRight = System.Drawing.Color.Black;
            this.panel_body.Location = new System.Drawing.Point(0, 58);
            this.panel_body.Name = "panel_body";
            this.panel_body.Quality = 10;
            this.panel_body.Size = new System.Drawing.Size(1494, 808);
            this.panel_body.TabIndex = 1;
            // 
            // btn_Start
            // 
            this.btn_Start.ActiveBorderThickness = 1;
            this.btn_Start.ActiveCornerRadius = 10;
            this.btn_Start.ActiveFillColor = System.Drawing.Color.Transparent;
            this.btn_Start.ActiveForecolor = System.Drawing.Color.RoyalBlue;
            this.btn_Start.ActiveLineColor = System.Drawing.Color.RoyalBlue;
            this.btn_Start.BackColor = System.Drawing.Color.Transparent;
            this.btn_Start.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Start.BackgroundImage")));
            this.btn_Start.ButtonText = "GET STARTED";
            this.btn_Start.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Start.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Start.ForeColor = System.Drawing.Color.White;
            this.btn_Start.IdleBorderThickness = 1;
            this.btn_Start.IdleCornerRadius = 10;
            this.btn_Start.IdleFillColor = System.Drawing.Color.Transparent;
            this.btn_Start.IdleForecolor = System.Drawing.Color.White;
            this.btn_Start.IdleLineColor = System.Drawing.Color.White;
            this.btn_Start.Location = new System.Drawing.Point(632, 467);
            this.btn_Start.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btn_Start.Name = "btn_Start";
            this.btn_Start.Size = new System.Drawing.Size(319, 99);
            this.btn_Start.TabIndex = 4;
            this.btn_Start.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Start.Click += new System.EventHandler(this.Btn_Start_Click);
            // 
            // Label_title
            // 
            this.Label_title.AutoSize = true;
            this.Label_title.BackColor = System.Drawing.Color.Transparent;
            this.Label_title.Font = new System.Drawing.Font("Stencil", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_title.ForeColor = System.Drawing.Color.White;
            this.Label_title.Location = new System.Drawing.Point(491, 337);
            this.Label_title.Name = "Label_title";
            this.Label_title.Size = new System.Drawing.Size(554, 47);
            this.Label_title.TabIndex = 3;
            this.Label_title.Text = "Asceso Hospitals pvt Ltd ";
            // 
            // pictureBox_welcome
            // 
            this.pictureBox_welcome.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox_welcome.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_welcome.Image")));
            this.pictureBox_welcome.Location = new System.Drawing.Point(482, 112);
            this.pictureBox_welcome.Name = "pictureBox_welcome";
            this.pictureBox_welcome.Size = new System.Drawing.Size(601, 277);
            this.pictureBox_welcome.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_welcome.TabIndex = 2;
            this.pictureBox_welcome.TabStop = false;
            // 
            // WelcomedragControl
            // 
            this.WelcomedragControl.SelectControl = this.panel_body;
            // 
            // WelcomeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1494, 866);
            this.Controls.Add(this.panel_body);
            this.Controls.Add(this.panel_top);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "WelcomeForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "WelcomeForm";
            this.panel_top.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btn_close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_minimize)).EndInit();
            this.panel_body.ResumeLayout(false);
            this.panel_body.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_welcome)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private Bunifu.Framework.UI.BunifuGradientPanel panel_body;
        private System.Windows.Forms.Panel panel_top;
        private Bunifu.Framework.UI.BunifuImageButton btn_minimize;
        private Bunifu.Framework.UI.BunifuImageButton btn_close;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_title;
        private System.Windows.Forms.PictureBox pictureBox_welcome;
        private Bunifu.Framework.UI.BunifuThinButton2 btn_Start;
        private Project_SDC.DragControl WelcomedragControl;
    }
}