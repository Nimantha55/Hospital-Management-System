﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MssCorsework
{
    public partial class addPatientControl : UserControl
    {
        public bool isCollapsed;

        public addPatientControl()
        {
            InitializeComponent();
        }

        SQLQueries sqlq = new SQLQueries();

        private void Checkbox1_OnChange(object sender, EventArgs e)
        {
            if (Checkbox1.Checked == true)
            {
                Textbox_GuardianNIC.BringToFront();
                Label_NIC.Text = "Guardian's NIC";
            }
            else
            {
                Textbox_NIC.BringToFront();
                Label_NIC.Text = "Patient's NIC";
                Checkbox1.Checked = false;
            }
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            if (isCollapsed)
            {
                panel_Gender.Height += 10;
                if (panel_Gender.Size == panel_Gender.MaximumSize)
                {
                    timer1.Stop();
                    isCollapsed = false;
                }
            }
            else
            {
                panel_Gender.Height -= 10;
                if (panel_Gender.Size == panel_Gender.MinimumSize)
                {
                    timer1.Stop();
                    isCollapsed = true;
                }
            }
        }

        private void Btn_Male_Click(object sender, EventArgs e)
        {
            Button_Gender.Text = "Male";
            if (label_pEGender.Visible == true)
            {
                label_pEGender.Visible = false;
                label_Errors.Visible = false;
            }
        }

        private void Btn_Female_Click(object sender, EventArgs e)
        {
            Button_Gender.Text = "Female";
            if (label_pEGender.Visible == true)
            {
                label_pEGender.Visible = false;
                label_Errors.Visible = false;
            }
        }

        private void clear()
        {
            Textbox_pName.Text = "";
            Textbox_NIC.Text = "";
            Textbox_GuardianNIC.Text = "";
            Textbox_TelephoneNum.Text = "";
            Textbox_Address.Text = "";
            Textbox_Age.Text = "";
            Button_Gender.Text = "Gender";
        }

        private void Button_Clear_Click(object sender, EventArgs e)
        {
            this.clear();
        }

        private void Button_ADD_Click(object sender, EventArgs e)
        {
            if(Textbox_pName.Text == "" && Textbox_NIC.Text == "" && Textbox_GuardianNIC.Text == "" && Textbox_TelephoneNum.Text == "" && Textbox_Address.Text == "" && Textbox_Age.Text == "" && Button_Gender.Text == "Gender")
            {
                label_Errors.Visible = true;
                label_Errors.Text = "Please Enter All Details!";
            }
            else if (Textbox_pName.Text == "")
            {
                label_pEName.Visible = true;
                label_pEName.Text = "Patient's Name is Required!";
            }
            else if (Checkbox1.Checked == false && Textbox_NIC.Text == "")
            {
                label_pENIC.Visible = true;
                label_pENIC.Text = "Patient's NIC is Required!";
            }
            else if (Checkbox1.Checked == true && Textbox_GuardianNIC.Text == "")
            {
                label_pENIC.Visible = true;
                label_pENIC.Text = "Guardian's NIC is Required!";
            }
            else if (Textbox_TelephoneNum.Text == "")
            {
                label_pETelephoneNum.Visible = true;
                label_pETelephoneNum.Text = "Patient's Telephone Number is Required!";
            }
            else if (Textbox_Address.Text == "")
            {
                label_pEAddress.Visible = true;
                label_pEAddress.Text = "Patient's Address is Required!";
            }
            else if (Textbox_Age.Text == "")
            {
                label_pEAge.Visible = true;
                label_pEAge.Text = "Patient's Age is Required!";
            }
            else if (Button_Gender.Text == "Gender")
            {
                label_pEGender.Visible = true;
                label_pEGender.Text = "Patient's Gender is Required!";
            }
            else
            {
                try
                {
                    string pnic = "";

                    if (Textbox_NIC.Text != "" && Textbox_GuardianNIC.Text == "")
                    {
                        pnic = Textbox_NIC.Text;
                        Label_NICStatus.Text = "Normal";
                    }
                    if (Textbox_NIC.Text == "" && Textbox_GuardianNIC.Text != "")
                    {
                        pnic = Textbox_GuardianNIC.Text;
                        Label_NICStatus.Text = "Guardian NIC";
                    }

                    string pname = Textbox_pName.Text;
                    string pNIC = pnic;
                    string pnicStstus = Label_NICStatus.Text;
                    string paddress = Textbox_Address.Text;
                    int pAge = int.Parse(Textbox_Age.Text);
                    string pTelNO = Textbox_TelephoneNum.Text;
                    string pGender = Button_Gender.Text;

                    //pass values for insertPatientsDetails query which include in SQLQueries class
                    sqlq.insertPatientsDetails(pname, pNIC, pnicStstus, paddress, pAge, pTelNO, pGender);
                    Message1 pr = new Message1();
                    pr.Show();
                    this.clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Please Check The Values" + ex, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void Textbox_pName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_pName.Text != "")
            {
                label_pEName.Visible = false;
                label_Errors.Visible = false;
            }

            //allow only characters values for textbox
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar) && e.KeyChar != '.')
            {
                e.Handled = true;
            }
        }

        private void Textbox_NIC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Checkbox1.Checked == false && Textbox_NIC.Text != "")
            {
                label_pENIC.Visible = false;
                label_Errors.Visible = false;
            }
        }

        private void Textbox_Address_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_Address.Text != "")
            {
                label_pEAddress.Visible = false;
                label_Errors.Visible = false;
            }
        }

        private void Textbox_Age_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_Age.Text != "")
            {
                label_pEAge.Visible = false;
                label_Errors.Visible = false;
            }

            //allow only numaric values for contact number
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 32)
            {
                e.Handled = true;
            }
        }

        private void Textbox_TelephoneNum_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_TelephoneNum.Text != "")
            {
                label_pETelephoneNum.Visible = false;
                label_Errors.Visible = false;
            }

            //allow only numaric values for contact number
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 32 && e.KeyChar != '+')
            {
                e.Handled = true;
            }
        }

        private void Textbox_Gender_KeyPress(object sender, KeyPressEventArgs e)
        {
            //allow only characters values for textbox
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }

            if (Button_Gender.Text != "Gender")
            {
                label_pEGender.Visible = false;
                label_Errors.Visible = false;
            }
            timer1.Stop();
            isCollapsed = true;
        }

        private void Textbox_GuardianNIC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Checkbox1.Checked == true && Textbox_GuardianNIC.Text != "")
            {
                label_pENIC.Visible = false;
                label_Errors.Visible = false;
            }
        }

        private void Button_Gender_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }
    }
}
