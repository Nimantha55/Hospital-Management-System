﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MssCorsework
{
    public partial class chartsControl : UserControl
    {

        public chartsControl()
        {
            InitializeComponent();
        }

        labReportViewer lrv = new labReportViewer();

        private void Button_Appointement_Click(object sender, EventArgs e)
        {
            ChartReport1 lr = new ChartReport1();
            SqlConnection con = new SqlConnection();
            con = MSSDBConnection.MSSConnection();
            string labAge = "SELECT * FROM TablePatients";
            DataSet ds = new DataSet();
            SqlDataAdapter sda = new SqlDataAdapter(labAge, con);
            sda.Fill(ds, "TablePatients");

            lr.SetDataSource(ds.Tables["TablePatients"]);
            lrv.crystalReportViewer1.ReportSource = lr;
            lrv.crystalReportViewer1.Refresh();
            lrv.Show();
        }
    }
}
