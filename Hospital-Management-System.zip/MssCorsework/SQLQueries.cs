﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace MssCorsework
{
    class SQLQueries
    {
        //Patients Registration
        public void insertPatientsDetails(string pname, string pnic, string pnicStstus, string paddress, int pAge, string pTelNo, string pGender)
        {
            string insertPatients = "INSERT INTO TablePatients VALUES('" + pname + "','" + pnic + "','" + pnicStstus + "','" + paddress + "'," + pAge + ",'" + pTelNo + "','" + pGender + "')";
            SqlCommand com = new SqlCommand(insertPatients, MSSDBConnection.MSSConnection());
            com.ExecuteNonQuery();
        }

        //User Registration
        public void userRegistration(string accountType, string username, string password)
        {
            string insertUser = "INSERT INTO Users VALUES('" + accountType + "','" + username + "','" + password + "')";
            SqlCommand com = new SqlCommand(insertUser, MSSDBConnection.MSSConnection());
            com.ExecuteNonQuery();
        }

        //User Login
        public SqlDataReader userLogins(string username, string password)
        {
            string sqluserlogin = "SELECT * FROM Users WHERE Username = '" + username + "' AND Password = '" + password + "'";
            SqlCommand com = new SqlCommand(sqluserlogin, MSSDBConnection.MSSConnection());
            SqlDataReader dr = com.ExecuteReader();
            return dr;
        }

        //Display Patient's Details
        public SqlDataReader patientDetails(string pNIC)
        {
            string patientDetail = "SELECT * FROM TablePatients WHERE P_NIC = '" + pNIC + "'";
            SqlCommand com = new SqlCommand(patientDetail, MSSDBConnection.MSSConnection());
            SqlDataReader dr = com.ExecuteReader();
            return dr;
        }

        //Update Patient's Details
        public void updatePatientDetails(string puName, string puNIC, string puStatus, string puAddress, int puAge, string puTelNO, string puGender, int ID)
        {
          string patientPatient = "UPDATE TablePatients SET P_Name = '" + puName + "', P_NIC = '" +puNIC+ "', P_NICStatus = '" + puStatus + "', P_Address = '" + puAddress + "', P_Age = " + puAge + ", P_TelephoneNO = '" + puTelNO + "', P_Gender = '" + puGender + "' WHERE Id = " + ID + "";
          SqlCommand com = new SqlCommand(patientPatient, MSSDBConnection.MSSConnection());
          com.ExecuteNonQuery();
        }

        //Insert Doctors Details
        public void insertDoctorsDetails(string dname, string dnic, string daddress, int dExp, string dTelNo, string dType)
        {
            string insertDoctors = "INSERT INTO TableDoctors VALUES('" + dname + "','" + dnic + "','" + daddress + "','" + dExp + "','" + dTelNo + "','" + dType + "')";
            SqlCommand com = new SqlCommand(insertDoctors, MSSDBConnection.MSSConnection());
            com.ExecuteNonQuery();
        }

        //Display Doctor's Details
        public SqlDataReader DoctorsDetails(string dNIC)
        {
            string doctorsDetail = "SELECT * FROM TableDoctors WHERE dNIC = '" + dNIC + "'";
            SqlCommand com = new SqlCommand(doctorsDetail, MSSDBConnection.MSSConnection());
            SqlDataReader dr = com.ExecuteReader();
            return dr;
        }

        //Update Doctor's Details
        public void updateDoctorsDetails(string duName, string duNIC, string duAddress, int duExp, string duTelNO, string puType, int ID)
        {
            string updateDoctors = "UPDATE TableDoctors SET dName = '" + duName + "', dNIC = '" + duNIC + "', dAddress = '" + duAddress + "', dExperience = " + duExp + ", dTelNO = '" + duTelNO + "', dType = '" + puType + "' WHERE Id = " + ID + "";
            SqlCommand com = new SqlCommand(updateDoctors, MSSDBConnection.MSSConnection());
            com.ExecuteNonQuery();
        }

        //Add Appointments
        public void addAppointments(string appNum, string pNIC, string pName, string dName, string dNIC, DateTime aDate, string aTime, int charge, int doctorFee)
        {
            string insertAppointments = "INSERT INTO TableAppointments VALUES('" + appNum + "', '" + pNIC + "','" + pName + "', '" + dName + "','" + dNIC + "','" + aDate + "','" + aTime + "', " + charge + ", " + doctorFee + ")";
            SqlCommand com = new SqlCommand(insertAppointments, MSSDBConnection.MSSConnection());
            com.ExecuteNonQuery();
        }

        //Display appointment Details
        public SqlDataReader appointmentDetails(string pNIC, DateTime aDate)
        {
            string appointmentsDetail = "SELECT * FROM TableAppointments WHERE pNIC = '" + pNIC + "' AND aDate = '" + aDate + "'";
            SqlCommand com = new SqlCommand(appointmentsDetail, MSSDBConnection.MSSConnection());
            SqlDataReader dr = com.ExecuteReader();
            return dr;
        }

        //Update charge and doctor fee
        public void updateAppointment(int aCharge, int dFee, int ID)
        {
            string updateApp = "UPDATE TableAppointments SET charge = " + aCharge + ", doctorFee = " + dFee + " WHERE Id = " + ID + "";
            SqlCommand com = new SqlCommand(updateApp, MSSDBConnection.MSSConnection());
            com.ExecuteNonQuery();
        }

        //Get Weekly Earned Amount
        public SqlDataReader earnedAmount(DateTime startDate, DateTime endDate, string dNIC)
        {
            string amount = "SELECT SUM(doctorFee) FROM TableAppointments WHERE aDate BETWEEN '" + startDate + "' AND '" + endDate + "' AND dNIC = '" + dNIC + "'"; 
            SqlCommand com = new SqlCommand(amount, MSSDBConnection.MSSConnection());
            SqlDataReader dr = com.ExecuteReader();
            return dr;
        }

        //Insert weekly earned amount details
        public void weeklyAmount(string dnic, DateTime sDate, DateTime eDate, int eAmount, int dCharge)
        {
            string weeklyEarned = "INSERT INTO TableWeeklyAmount VALUES('" + dnic + "','" + sDate + "','" + eDate + "'," + eAmount + "," + dCharge + ")";
            SqlCommand com = new SqlCommand(weeklyEarned, MSSDBConnection.MSSConnection());
            com.ExecuteNonQuery();
        }

        //Insert patients history
        public void patientHistory(string dName, string dnic, string diagnosis, string symptoms, string changeDetails, string remarks, string prescription, string labReport)
        {
            string history = "INSERT INTO TablePatientsHistory VALUES('" + dName + "','" + dnic + "','" + diagnosis + "','" + symptoms + "','" + changeDetails + "','" + remarks + "','" + prescription + "','" + labReport + "')";
            SqlCommand com = new SqlCommand(history, MSSDBConnection.MSSConnection());
            com.ExecuteNonQuery();
        }

        //Display Patient's History
        public SqlDataReader getHistory(string pNIC)
        {
            string pHistory = "SELECT * FROM TablePatientsHistory WHERE pNIC = '" + pNIC + "'";
            SqlCommand com = new SqlCommand(pHistory, MSSDBConnection.MSSConnection());
            SqlDataReader dr = com.ExecuteReader();
            return dr;
        }

        //Insert lab report details
        public void labreportDetails(string repNo, string typeOfR, string results, DateTime sampleRD, DateTime sampleTD, string techRM, string softCL)
        {
            string labReports = "INSERT INTO TableLabReports VALUES('" + repNo + "','" + typeOfR + "','" + results + "','" + sampleRD + "','" + sampleTD + "','" + techRM + "','" + softCL + "')";
            SqlCommand com = new SqlCommand(labReports, MSSDBConnection.MSSConnection());
            com.ExecuteNonQuery();
        }

        //Display Prescription details
        public SqlDataReader getTablePatientsHistory(string pNIC)
        {
            string Prescription = "SELECT * FROM TablePatientsHistory WHERE pNIC = '" + pNIC + "'";
            SqlCommand com = new SqlCommand(Prescription, MSSDBConnection.MSSConnection());
            SqlDataReader dr = com.ExecuteReader();
            return dr;
        }

        //Insert inventory details
        public void inventoryDetails(DateTime date, string preName, int costP, int salesP, int stock, int reLevel, int quentity, int total, string pNIC)
        {
            string inventory = "INSERT INTO TableInventory VALUES('" + date + "','" + preName + "'," + costP + "," + salesP + "," + stock + "," + reLevel + "," + quentity + "," + total + ",'" + pNIC + "')";
            SqlCommand com = new SqlCommand(inventory, MSSDBConnection.MSSConnection());
            com.ExecuteNonQuery();
        }

        //Insert Internal patient details
        public void internalPatientDetails(string pNIC, string pName, string pAddress, int age, int addNumber, int wardNumber, string pres, string reports, DateTime date, int rCharge, int mCharge, int repCharge, int totalCharge)
        {
            string internalPatient = "INSERT INTO TableInternalPatients VALUES('" + pNIC + "','" + pName + "','" + pAddress + "'," + age + "," + addNumber + "," + wardNumber + ",'" + pres + "','" + reports + "','" + date + "', " + rCharge + "," + mCharge + "," + repCharge + "," + totalCharge + ")";
            SqlCommand com = new SqlCommand(internalPatient, MSSDBConnection.MSSConnection());
            com.ExecuteNonQuery();
        }

        //Display Internal patient details
        public SqlDataReader getInternalPatientDetails(string pNIC)
        {
            string InternalPatient = "SELECT * FROM TableInternalPatients WHERE pNIC = '" + pNIC + "'";
            SqlCommand com = new SqlCommand(InternalPatient, MSSDBConnection.MSSConnection());
            SqlDataReader dr = com.ExecuteReader();
            return dr;
        }

        //Update Internal patient details
        public void updateInternalPatient(string prescriptions, string reports, int ID)
        {
            string updatepatient = "UPDATE TableInternalPatients SET prescriptions = '" + prescriptions + "', reports = '" + reports + "' WHERE Id = " + ID + "";
            SqlCommand com = new SqlCommand(updatepatient, MSSDBConnection.MSSConnection());
            com.ExecuteNonQuery();
        }

        //Internal patient charges
        public SqlDataReader InternalPatient(string pNIC, DateTime date)
        {
            string PatientCharges = "SELECT * FROM TableInternalPatients WHERE pNIC = '" + pNIC + "' AND addmittedDate = '" + date + "'";
            SqlCommand com = new SqlCommand(PatientCharges, MSSDBConnection.MSSConnection());
            SqlDataReader dr = com.ExecuteReader();
            return dr;
        }

        //Calculate Internal Patient Bill
        public void internalPatientCharges(int Rcharge, int Mcharge, int RepCharge, int Total, int ID)
        {
            string internalCharges = "UPDATE TableInternalPatients SET  rCharge = " + Rcharge + ", mCharge = " + Mcharge + ", RepCharge = " + RepCharge + ", totalCharge = " + Total + " WHERE Id = " + ID + "";
            SqlCommand com = new SqlCommand(internalCharges, MSSDBConnection.MSSConnection());
            com.ExecuteNonQuery();
        }

        //Internal patient charges
        public SqlDataReader genderCount()
        {
            string count = "SELECT COUNT(Age) FROM TablePatients GROUP BY Age";
            SqlCommand com = new SqlCommand(count, MSSDBConnection.MSSConnection());
            SqlDataReader dr = com.ExecuteReader();
            return dr;
        }
    }
}
