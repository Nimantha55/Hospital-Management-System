﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MssCorsework
{
    public partial class caculateAmountControl : UserControl
    {
        public caculateAmountControl()
        {
            InitializeComponent();
        }

        paymentGetway pg = new paymentGetway();
        SQLQueries sqlq = new SQLQueries();

        private void Button_payPal_Click(object sender, EventArgs e)
        {
            pg.webBrowser1.Navigate("https://www.paypal.com/in/signin");
            pg.Show();
        }

        private void Button_masterCard_Click(object sender, EventArgs e)
        {
            pg.webBrowser1.Navigate("https://www.mastercardconnect.com/business/public/en-us/public/signin.html?TAM_OP=token_login&ERROR_CODE=0x00000000&ERROR_TEXT=HPDBA0521I%20%20%20Successful%20completion&URL=%2Fpkmsvouchfor%3Fprodmcc%26https%3A%2F%2Fwww.mastercardconnect.com%2Fbusiness%2Fsecured%2Fen-us%2Fcmscommon%2Fhome.html&REFERER=https%3A%2F%2Fwww.google.com%2F&HOSTNAME=www.mastercardconnect.com&AUTHNLEVEL=&LRR_TOKEN=f6efdfaa-4422-4b15-8d7f-9c1fbcdaea32");
            pg.Show();
        }

        private void Button_visa_Click(object sender, EventArgs e)
        {
            pg.webBrowser1.Navigate("https://www.visaonline.com/login/LoginMain.aspx?goto=https%3A%2F%2Fsecure.visaonline.com%2F");
            pg.Show();
        }

        private void Button_Search_Click(object sender, EventArgs e)
        {
            if (Textbox_SearchNIC.Text == "")
            {
                label_ESearchNIC.Visible = true;
                label_ESearchNIC.Text = "Doctor's NIC is Required!";
            }
            else
            {


                DateTime svDate = Datepicker_aDate.Value.Date;
                DateTime evDate = dateTimePicker_eDate.Value.Date;

                TimeSpan ts = evDate - svDate;
                int days = ts.Days;
                int week = 7;

                //Validate a week
                if (days != week)
                {
                    MessageBox.Show("Please select a week!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    DateTime sDate = Datepicker_aDate.Value;
                    DateTime eDate = dateTimePicker_eDate.Value;
                    string dNIC = Textbox_SearchNIC.Text;

                    SqlDataReader dr = sqlq.earnedAmount(sDate, eDate, dNIC);
                    if (dr.Read())
                    {
                        Textbox_dAmount.Text = dr[0].ToString();
                    }
                    else
                    {
                        MessageBox.Show("Invalid Patient's or Guardian's NIC", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void Button_result_Click(object sender, EventArgs e)
        {
            if (Textbox_dAmount.Text == "")
            {
                label_eEa.Visible = true;
                label_eEa.Text = "Earned Amount is Required!";
            }
            else if (Textbox_hCharge.Text == "")
            {
                label_eAF.Visible = true;
                label_eAF.Text = "Administration Fee is Required!";
            }
            else
            {
                string value = Textbox_dAmount.Text.Trim().ToString();
                string percentage = Textbox_hCharge.Text.Trim().ToString();
                int percentageResult;
                int result;

                //Get percentage and final result
                if (!string.IsNullOrEmpty(percentage) && !string.IsNullOrEmpty(value))
                {
                    int intPer = 0;
                    Double doubleValue = 0.0;

                    if (int.TryParse(percentage, out intPer) && Double.TryParse(value, out doubleValue))
                    {
                        Double doubleResult = (doubleValue * intPer) / 100;
                        percentageResult = Convert.ToInt32(doubleResult);
                        result = int.Parse(value) - percentageResult;
                        Textbox_charge.Text = result.ToString();
                    }
                    else
                    {
                        MessageBox.Show("Can't convert this value!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void Checkbox1_OnChange(object sender, EventArgs e)
        {
            if(Checkbox1.Checked == false)
            {
                Textbox_hCharge.Enabled = false;
            }
            else
            {
                Textbox_hCharge.Enabled = true;
            }
        }

        private void clear()
        {
            Textbox_SearchNIC.Text = "";
            Textbox_dAmount.Text = "";
            Textbox_charge.Text = "";
        }

        private void Button_SaveDetails_Click(object sender, EventArgs e)
        {
            if(Textbox_charge.Text == "")
            {
                label_eDC.Visible = true;
                label_eDC.Text = "Doctor's Charge is Required!";
            }
            else
            {
                try
                {
                    string dNIC = Textbox_SearchNIC.Text;
                    DateTime sDate = Datepicker_aDate.Value.Date;
                    DateTime eDate = dateTimePicker_eDate.Value.Date;
                    int eAmount = int.Parse(Textbox_dAmount.Text);
                    int dCharge = int.Parse(Textbox_charge.Text);

                    //pass values for weeklyAmount query which include in SQLQueries class
                    sqlq.weeklyAmount(dNIC, sDate, eDate, eAmount, dCharge);
                    Message1 pr = new Message1();
                    pr.label1.Text = "Details Added Successfully!";
                    pr.label1.Location = new System.Drawing.Point(85, 200);
                    pr.Show();
                    this.clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Please Check The Values" + ex, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void Textbox_SearchNIC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_SearchNIC.Text != "")
            {
                label_ESearchNIC.Visible = false;
            }
        }

        private void Textbox_dAmount_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_dAmount.Text != "")
            {
                label_eEa.Visible = false;
            }

            //allow only numaric values for contact number
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 32)
            {
                e.Handled = true;
            }
        }

        private void Textbox_hCharge_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_hCharge.Text != "")
            {
                label_eAF.Visible = false;
            }

            //allow only numaric values for contact number
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 32)
            {
                e.Handled = true;
            }
        }

        private void Textbox_charge_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_charge.Text != "")
            {
                label_eDC.Visible = false;
            }

            //allow only numaric values for contact number
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 32)
            {
                e.Handled = true;
            }
        }

        private void Datepicker_aDate_MouseDown(object sender, MouseEventArgs e)
        {
            Datepicker_aDate.CustomFormat = "MM/dd/yyyy";
        }

        private void DateTimePicker_eDate_MouseDown(object sender, MouseEventArgs e)
        {
            dateTimePicker_eDate.CustomFormat = "MM/dd/yyyy";
        }
    }
}
