﻿namespace MssCorsework
{
    partial class UpdateInternalPatientsControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UpdateInternalPatientsControl));
            this.bunifuGradientPanel1 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.Textbox_reports = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label_R = new System.Windows.Forms.Label();
            this.label_prescription = new System.Windows.Forms.Label();
            this.Textbox_pres = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.label_ESearchNIC = new System.Windows.Forms.Label();
            this.bunifuSeparator1 = new Bunifu.Framework.UI.BunifuSeparator();
            this.Button_Search = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Label_SearchNIC = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Textbox_SearchNIC = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Textbox_wardNumber = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Label_reports = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_pre = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_ID = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.label_Errors = new System.Windows.Forms.Label();
            this.label_wardNum = new System.Windows.Forms.Label();
            this.label_admission = new System.Windows.Forms.Label();
            this.label_pEAge = new System.Windows.Forms.Label();
            this.label_pEName = new System.Windows.Forms.Label();
            this.Textbox_Age = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Textbox_AdmissionNum = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Textbox_pName = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Button_Clear = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Button_UPDATE = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Label_Gender = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_TelephoneNum = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_Age = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_Name = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_Title = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuGradientPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_reports);
            this.bunifuGradientPanel1.Controls.Add(this.label_R);
            this.bunifuGradientPanel1.Controls.Add(this.label_prescription);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_pres);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuCustomLabel1);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuCustomLabel2);
            this.bunifuGradientPanel1.Controls.Add(this.label_ESearchNIC);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuSeparator1);
            this.bunifuGradientPanel1.Controls.Add(this.Button_Search);
            this.bunifuGradientPanel1.Controls.Add(this.Label_SearchNIC);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_SearchNIC);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_wardNumber);
            this.bunifuGradientPanel1.Controls.Add(this.Label_reports);
            this.bunifuGradientPanel1.Controls.Add(this.Label_pre);
            this.bunifuGradientPanel1.Controls.Add(this.Label_ID);
            this.bunifuGradientPanel1.Controls.Add(this.label_Errors);
            this.bunifuGradientPanel1.Controls.Add(this.label_wardNum);
            this.bunifuGradientPanel1.Controls.Add(this.label_admission);
            this.bunifuGradientPanel1.Controls.Add(this.label_pEAge);
            this.bunifuGradientPanel1.Controls.Add(this.label_pEName);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_Age);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_AdmissionNum);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_pName);
            this.bunifuGradientPanel1.Controls.Add(this.Button_Clear);
            this.bunifuGradientPanel1.Controls.Add(this.Button_UPDATE);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Gender);
            this.bunifuGradientPanel1.Controls.Add(this.Label_TelephoneNum);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Age);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Name);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Title);
            this.bunifuGradientPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.Black;
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.Gray;
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(1140, 812);
            this.bunifuGradientPanel1.TabIndex = 2;
            // 
            // Textbox_reports
            // 
            this.Textbox_reports.BackColor = System.Drawing.Color.Silver;
            this.Textbox_reports.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_reports.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_reports.ForeColor = System.Drawing.Color.Black;
            this.Textbox_reports.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_reports.HintText = "Reports";
            this.Textbox_reports.isPassword = false;
            this.Textbox_reports.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_reports.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_reports.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_reports.LineThickness = 3;
            this.Textbox_reports.Location = new System.Drawing.Point(583, 567);
            this.Textbox_reports.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_reports.Name = "Textbox_reports";
            this.Textbox_reports.Size = new System.Drawing.Size(480, 92);
            this.Textbox_reports.TabIndex = 91;
            this.Textbox_reports.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Textbox_reports.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_reports_KeyPress);
            // 
            // label_R
            // 
            this.label_R.AutoSize = true;
            this.label_R.BackColor = System.Drawing.Color.Transparent;
            this.label_R.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_R.ForeColor = System.Drawing.Color.Red;
            this.label_R.Location = new System.Drawing.Point(579, 665);
            this.label_R.Name = "label_R";
            this.label_R.Size = new System.Drawing.Size(60, 19);
            this.label_R.TabIndex = 90;
            this.label_R.Text = "label6";
            this.label_R.Visible = false;
            // 
            // label_prescription
            // 
            this.label_prescription.AutoSize = true;
            this.label_prescription.BackColor = System.Drawing.Color.Transparent;
            this.label_prescription.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_prescription.ForeColor = System.Drawing.Color.Red;
            this.label_prescription.Location = new System.Drawing.Point(60, 665);
            this.label_prescription.Name = "label_prescription";
            this.label_prescription.Size = new System.Drawing.Size(60, 19);
            this.label_prescription.TabIndex = 89;
            this.label_prescription.Text = "label5";
            this.label_prescription.Visible = false;
            // 
            // Textbox_pres
            // 
            this.Textbox_pres.BackColor = System.Drawing.Color.Silver;
            this.Textbox_pres.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_pres.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_pres.ForeColor = System.Drawing.Color.Black;
            this.Textbox_pres.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_pres.HintText = "Prescriptions";
            this.Textbox_pres.isPassword = false;
            this.Textbox_pres.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_pres.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_pres.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_pres.LineThickness = 3;
            this.Textbox_pres.Location = new System.Drawing.Point(64, 567);
            this.Textbox_pres.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_pres.Name = "Textbox_pres";
            this.Textbox_pres.Size = new System.Drawing.Size(480, 92);
            this.Textbox_pres.TabIndex = 88;
            this.Textbox_pres.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Textbox_pres.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_pres_KeyPress);
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.Black;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(577, 518);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(104, 32);
            this.bunifuCustomLabel1.TabIndex = 87;
            this.bunifuCustomLabel1.Text = "Reports";
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel2.ForeColor = System.Drawing.Color.Black;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(58, 518);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(165, 32);
            this.bunifuCustomLabel2.TabIndex = 86;
            this.bunifuCustomLabel2.Text = "Prescriptions";
            // 
            // label_ESearchNIC
            // 
            this.label_ESearchNIC.AutoSize = true;
            this.label_ESearchNIC.BackColor = System.Drawing.Color.Transparent;
            this.label_ESearchNIC.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ESearchNIC.ForeColor = System.Drawing.Color.Red;
            this.label_ESearchNIC.Location = new System.Drawing.Point(60, 153);
            this.label_ESearchNIC.Name = "label_ESearchNIC";
            this.label_ESearchNIC.Size = new System.Drawing.Size(60, 19);
            this.label_ESearchNIC.TabIndex = 85;
            this.label_ESearchNIC.Text = "label5";
            this.label_ESearchNIC.Visible = false;
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator1.LineThickness = 2;
            this.bunifuSeparator1.Location = new System.Drawing.Point(64, 176);
            this.bunifuSeparator1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Size = new System.Drawing.Size(1018, 10);
            this.bunifuSeparator1.TabIndex = 84;
            this.bunifuSeparator1.Transparency = 255;
            this.bunifuSeparator1.Vertical = false;
            // 
            // Button_Search
            // 
            this.Button_Search.Activecolor = System.Drawing.Color.DarkViolet;
            this.Button_Search.BackColor = System.Drawing.Color.DarkViolet;
            this.Button_Search.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_Search.BorderRadius = 0;
            this.Button_Search.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Button_Search.ButtonText = "SEARCH";
            this.Button_Search.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_Search.DisabledColor = System.Drawing.Color.Gray;
            this.Button_Search.ForeColor = System.Drawing.Color.White;
            this.Button_Search.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_Search.Iconimage = null;
            this.Button_Search.Iconimage_right = null;
            this.Button_Search.Iconimage_right_Selected = null;
            this.Button_Search.Iconimage_Selected = null;
            this.Button_Search.IconMarginLeft = 0;
            this.Button_Search.IconMarginRight = 0;
            this.Button_Search.IconRightVisible = true;
            this.Button_Search.IconRightZoom = 0D;
            this.Button_Search.IconVisible = true;
            this.Button_Search.IconZoom = 90D;
            this.Button_Search.IsTab = false;
            this.Button_Search.Location = new System.Drawing.Point(746, 91);
            this.Button_Search.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_Search.Name = "Button_Search";
            this.Button_Search.Normalcolor = System.Drawing.Color.DarkViolet;
            this.Button_Search.OnHovercolor = System.Drawing.Color.Transparent;
            this.Button_Search.OnHoverTextColor = System.Drawing.Color.Black;
            this.Button_Search.selected = false;
            this.Button_Search.Size = new System.Drawing.Size(280, 57);
            this.Button_Search.TabIndex = 83;
            this.Button_Search.Text = "SEARCH";
            this.Button_Search.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_Search.Textcolor = System.Drawing.Color.White;
            this.Button_Search.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Search.Click += new System.EventHandler(this.Button_Search_Click);
            // 
            // Label_SearchNIC
            // 
            this.Label_SearchNIC.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_SearchNIC.AutoSize = true;
            this.Label_SearchNIC.BackColor = System.Drawing.Color.Transparent;
            this.Label_SearchNIC.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SearchNIC.ForeColor = System.Drawing.Color.Black;
            this.Label_SearchNIC.Location = new System.Drawing.Point(138, 106);
            this.Label_SearchNIC.Name = "Label_SearchNIC";
            this.Label_SearchNIC.Size = new System.Drawing.Size(163, 32);
            this.Label_SearchNIC.TabIndex = 82;
            this.Label_SearchNIC.Text = "Patient\'s NIC";
            // 
            // Textbox_SearchNIC
            // 
            this.Textbox_SearchNIC.BackColor = System.Drawing.Color.Silver;
            this.Textbox_SearchNIC.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_SearchNIC.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_SearchNIC.ForeColor = System.Drawing.Color.Black;
            this.Textbox_SearchNIC.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_SearchNIC.HintText = "Patient\'s NIC";
            this.Textbox_SearchNIC.isPassword = false;
            this.Textbox_SearchNIC.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_SearchNIC.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_SearchNIC.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_SearchNIC.LineThickness = 3;
            this.Textbox_SearchNIC.Location = new System.Drawing.Point(334, 97);
            this.Textbox_SearchNIC.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_SearchNIC.Name = "Textbox_SearchNIC";
            this.Textbox_SearchNIC.Size = new System.Drawing.Size(373, 45);
            this.Textbox_SearchNIC.TabIndex = 81;
            this.Textbox_SearchNIC.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Textbox_SearchNIC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_SearchNIC_KeyPress);
            // 
            // Textbox_wardNumber
            // 
            this.Textbox_wardNumber.BackColor = System.Drawing.Color.Silver;
            this.Textbox_wardNumber.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_wardNumber.Enabled = false;
            this.Textbox_wardNumber.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_wardNumber.ForeColor = System.Drawing.Color.Black;
            this.Textbox_wardNumber.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_wardNumber.HintText = "Ward Number";
            this.Textbox_wardNumber.isPassword = false;
            this.Textbox_wardNumber.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_wardNumber.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_wardNumber.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_wardNumber.LineThickness = 3;
            this.Textbox_wardNumber.Location = new System.Drawing.Point(583, 413);
            this.Textbox_wardNumber.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_wardNumber.Name = "Textbox_wardNumber";
            this.Textbox_wardNumber.Size = new System.Drawing.Size(480, 60);
            this.Textbox_wardNumber.TabIndex = 79;
            this.Textbox_wardNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // Label_reports
            // 
            this.Label_reports.AutoSize = true;
            this.Label_reports.BackColor = System.Drawing.Color.Transparent;
            this.Label_reports.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_reports.ForeColor = System.Drawing.Color.Black;
            this.Label_reports.Location = new System.Drawing.Point(978, 20);
            this.Label_reports.Name = "Label_reports";
            this.Label_reports.Size = new System.Drawing.Size(56, 19);
            this.Label_reports.TabIndex = 78;
            this.Label_reports.Text = "Empty";
            this.Label_reports.Visible = false;
            // 
            // Label_pre
            // 
            this.Label_pre.AutoSize = true;
            this.Label_pre.BackColor = System.Drawing.Color.Transparent;
            this.Label_pre.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_pre.ForeColor = System.Drawing.Color.Black;
            this.Label_pre.Location = new System.Drawing.Point(916, 20);
            this.Label_pre.Name = "Label_pre";
            this.Label_pre.Size = new System.Drawing.Size(56, 19);
            this.Label_pre.TabIndex = 77;
            this.Label_pre.Text = "Empty";
            this.Label_pre.Visible = false;
            // 
            // Label_ID
            // 
            this.Label_ID.AutoSize = true;
            this.Label_ID.BackColor = System.Drawing.Color.Transparent;
            this.Label_ID.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_ID.ForeColor = System.Drawing.Color.Black;
            this.Label_ID.Location = new System.Drawing.Point(1053, 20);
            this.Label_ID.Name = "Label_ID";
            this.Label_ID.Size = new System.Drawing.Size(26, 19);
            this.Label_ID.TabIndex = 76;
            this.Label_ID.Text = "ID";
            this.Label_ID.Visible = false;
            // 
            // label_Errors
            // 
            this.label_Errors.AutoSize = true;
            this.label_Errors.BackColor = System.Drawing.Color.Transparent;
            this.label_Errors.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Errors.ForeColor = System.Drawing.Color.Red;
            this.label_Errors.Location = new System.Drawing.Point(57, 771);
            this.label_Errors.Name = "label_Errors";
            this.label_Errors.Size = new System.Drawing.Size(60, 19);
            this.label_Errors.TabIndex = 75;
            this.label_Errors.Text = "label5";
            this.label_Errors.Visible = false;
            // 
            // label_wardNum
            // 
            this.label_wardNum.AutoSize = true;
            this.label_wardNum.BackColor = System.Drawing.Color.Transparent;
            this.label_wardNum.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_wardNum.ForeColor = System.Drawing.Color.Red;
            this.label_wardNum.Location = new System.Drawing.Point(579, 487);
            this.label_wardNum.Name = "label_wardNum";
            this.label_wardNum.Size = new System.Drawing.Size(60, 19);
            this.label_wardNum.TabIndex = 74;
            this.label_wardNum.Text = "label6";
            this.label_wardNum.Visible = false;
            // 
            // label_admission
            // 
            this.label_admission.AutoSize = true;
            this.label_admission.BackColor = System.Drawing.Color.Transparent;
            this.label_admission.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_admission.ForeColor = System.Drawing.Color.Red;
            this.label_admission.Location = new System.Drawing.Point(60, 487);
            this.label_admission.Name = "label_admission";
            this.label_admission.Size = new System.Drawing.Size(60, 19);
            this.label_admission.TabIndex = 73;
            this.label_admission.Text = "label5";
            this.label_admission.Visible = false;
            // 
            // label_pEAge
            // 
            this.label_pEAge.AutoSize = true;
            this.label_pEAge.BackColor = System.Drawing.Color.Transparent;
            this.label_pEAge.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_pEAge.ForeColor = System.Drawing.Color.Red;
            this.label_pEAge.Location = new System.Drawing.Point(579, 328);
            this.label_pEAge.Name = "label_pEAge";
            this.label_pEAge.Size = new System.Drawing.Size(60, 19);
            this.label_pEAge.TabIndex = 72;
            this.label_pEAge.Text = "label4";
            this.label_pEAge.Visible = false;
            // 
            // label_pEName
            // 
            this.label_pEName.AutoSize = true;
            this.label_pEName.BackColor = System.Drawing.Color.Transparent;
            this.label_pEName.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_pEName.ForeColor = System.Drawing.Color.Red;
            this.label_pEName.Location = new System.Drawing.Point(60, 327);
            this.label_pEName.Name = "label_pEName";
            this.label_pEName.Size = new System.Drawing.Size(60, 19);
            this.label_pEName.TabIndex = 69;
            this.label_pEName.Text = "label1";
            this.label_pEName.Visible = false;
            // 
            // Textbox_Age
            // 
            this.Textbox_Age.BackColor = System.Drawing.Color.Silver;
            this.Textbox_Age.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_Age.Enabled = false;
            this.Textbox_Age.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Age.ForeColor = System.Drawing.Color.Black;
            this.Textbox_Age.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_Age.HintText = "Patient\'s Age";
            this.Textbox_Age.isPassword = false;
            this.Textbox_Age.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_Age.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_Age.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_Age.LineThickness = 3;
            this.Textbox_Age.Location = new System.Drawing.Point(583, 256);
            this.Textbox_Age.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_Age.Name = "Textbox_Age";
            this.Textbox_Age.Size = new System.Drawing.Size(480, 60);
            this.Textbox_Age.TabIndex = 64;
            this.Textbox_Age.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // Textbox_AdmissionNum
            // 
            this.Textbox_AdmissionNum.BackColor = System.Drawing.Color.Silver;
            this.Textbox_AdmissionNum.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_AdmissionNum.Enabled = false;
            this.Textbox_AdmissionNum.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_AdmissionNum.ForeColor = System.Drawing.Color.Black;
            this.Textbox_AdmissionNum.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_AdmissionNum.HintText = "Admission Number";
            this.Textbox_AdmissionNum.isPassword = false;
            this.Textbox_AdmissionNum.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_AdmissionNum.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_AdmissionNum.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_AdmissionNum.LineThickness = 3;
            this.Textbox_AdmissionNum.Location = new System.Drawing.Point(64, 413);
            this.Textbox_AdmissionNum.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_AdmissionNum.Name = "Textbox_AdmissionNum";
            this.Textbox_AdmissionNum.Size = new System.Drawing.Size(480, 60);
            this.Textbox_AdmissionNum.TabIndex = 63;
            this.Textbox_AdmissionNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // Textbox_pName
            // 
            this.Textbox_pName.BackColor = System.Drawing.Color.Silver;
            this.Textbox_pName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_pName.Enabled = false;
            this.Textbox_pName.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_pName.ForeColor = System.Drawing.Color.Black;
            this.Textbox_pName.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_pName.HintText = "Patient\'s Name";
            this.Textbox_pName.isPassword = false;
            this.Textbox_pName.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_pName.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_pName.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_pName.LineThickness = 3;
            this.Textbox_pName.Location = new System.Drawing.Point(64, 256);
            this.Textbox_pName.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_pName.Name = "Textbox_pName";
            this.Textbox_pName.Size = new System.Drawing.Size(480, 60);
            this.Textbox_pName.TabIndex = 61;
            this.Textbox_pName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // Button_Clear
            // 
            this.Button_Clear.Activecolor = System.Drawing.Color.Crimson;
            this.Button_Clear.BackColor = System.Drawing.Color.Crimson;
            this.Button_Clear.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_Clear.BorderRadius = 0;
            this.Button_Clear.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Button_Clear.ButtonText = "CLEAR";
            this.Button_Clear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_Clear.DisabledColor = System.Drawing.Color.Gray;
            this.Button_Clear.ForeColor = System.Drawing.Color.White;
            this.Button_Clear.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_Clear.Iconimage = null;
            this.Button_Clear.Iconimage_right = null;
            this.Button_Clear.Iconimage_right_Selected = null;
            this.Button_Clear.Iconimage_Selected = null;
            this.Button_Clear.IconMarginLeft = 0;
            this.Button_Clear.IconMarginRight = 0;
            this.Button_Clear.IconRightVisible = true;
            this.Button_Clear.IconRightZoom = 0D;
            this.Button_Clear.IconVisible = true;
            this.Button_Clear.IconZoom = 90D;
            this.Button_Clear.IsTab = false;
            this.Button_Clear.Location = new System.Drawing.Point(583, 697);
            this.Button_Clear.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_Clear.Name = "Button_Clear";
            this.Button_Clear.Normalcolor = System.Drawing.Color.Crimson;
            this.Button_Clear.OnHovercolor = System.Drawing.Color.Transparent;
            this.Button_Clear.OnHoverTextColor = System.Drawing.Color.Black;
            this.Button_Clear.selected = false;
            this.Button_Clear.Size = new System.Drawing.Size(480, 64);
            this.Button_Clear.TabIndex = 58;
            this.Button_Clear.Text = "CLEAR";
            this.Button_Clear.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_Clear.Textcolor = System.Drawing.Color.White;
            this.Button_Clear.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Clear.Click += new System.EventHandler(this.Button_Clear_Click);
            // 
            // Button_UPDATE
            // 
            this.Button_UPDATE.Activecolor = System.Drawing.Color.ForestGreen;
            this.Button_UPDATE.BackColor = System.Drawing.Color.ForestGreen;
            this.Button_UPDATE.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_UPDATE.BorderRadius = 0;
            this.Button_UPDATE.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Button_UPDATE.ButtonText = "UPDATE";
            this.Button_UPDATE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_UPDATE.DisabledColor = System.Drawing.Color.Gray;
            this.Button_UPDATE.ForeColor = System.Drawing.Color.White;
            this.Button_UPDATE.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_UPDATE.Iconimage = null;
            this.Button_UPDATE.Iconimage_right = null;
            this.Button_UPDATE.Iconimage_right_Selected = null;
            this.Button_UPDATE.Iconimage_Selected = null;
            this.Button_UPDATE.IconMarginLeft = 0;
            this.Button_UPDATE.IconMarginRight = 0;
            this.Button_UPDATE.IconRightVisible = true;
            this.Button_UPDATE.IconRightZoom = 0D;
            this.Button_UPDATE.IconVisible = true;
            this.Button_UPDATE.IconZoom = 90D;
            this.Button_UPDATE.IsTab = false;
            this.Button_UPDATE.Location = new System.Drawing.Point(61, 697);
            this.Button_UPDATE.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_UPDATE.Name = "Button_UPDATE";
            this.Button_UPDATE.Normalcolor = System.Drawing.Color.ForestGreen;
            this.Button_UPDATE.OnHovercolor = System.Drawing.Color.Transparent;
            this.Button_UPDATE.OnHoverTextColor = System.Drawing.Color.Black;
            this.Button_UPDATE.selected = false;
            this.Button_UPDATE.Size = new System.Drawing.Size(480, 64);
            this.Button_UPDATE.TabIndex = 57;
            this.Button_UPDATE.Text = "UPDATE";
            this.Button_UPDATE.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_UPDATE.Textcolor = System.Drawing.Color.White;
            this.Button_UPDATE.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_UPDATE.Click += new System.EventHandler(this.Button_UPDATE_Click);
            // 
            // Label_Gender
            // 
            this.Label_Gender.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Gender.AutoSize = true;
            this.Label_Gender.BackColor = System.Drawing.Color.Transparent;
            this.Label_Gender.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Gender.ForeColor = System.Drawing.Color.Black;
            this.Label_Gender.Location = new System.Drawing.Point(577, 362);
            this.Label_Gender.Name = "Label_Gender";
            this.Label_Gender.Size = new System.Drawing.Size(178, 32);
            this.Label_Gender.TabIndex = 31;
            this.Label_Gender.Text = "Ward Number";
            // 
            // Label_TelephoneNum
            // 
            this.Label_TelephoneNum.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_TelephoneNum.AutoSize = true;
            this.Label_TelephoneNum.BackColor = System.Drawing.Color.Transparent;
            this.Label_TelephoneNum.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_TelephoneNum.ForeColor = System.Drawing.Color.Black;
            this.Label_TelephoneNum.Location = new System.Drawing.Point(58, 362);
            this.Label_TelephoneNum.Name = "Label_TelephoneNum";
            this.Label_TelephoneNum.Size = new System.Drawing.Size(236, 32);
            this.Label_TelephoneNum.TabIndex = 29;
            this.Label_TelephoneNum.Text = "Admission Number";
            // 
            // Label_Age
            // 
            this.Label_Age.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Age.AutoSize = true;
            this.Label_Age.BackColor = System.Drawing.Color.Transparent;
            this.Label_Age.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Age.ForeColor = System.Drawing.Color.Black;
            this.Label_Age.Location = new System.Drawing.Point(577, 205);
            this.Label_Age.Name = "Label_Age";
            this.Label_Age.Size = new System.Drawing.Size(166, 32);
            this.Label_Age.TabIndex = 27;
            this.Label_Age.Text = "Patient\'s Age";
            // 
            // Label_Name
            // 
            this.Label_Name.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Name.AutoSize = true;
            this.Label_Name.BackColor = System.Drawing.Color.Transparent;
            this.Label_Name.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Name.ForeColor = System.Drawing.Color.Black;
            this.Label_Name.Location = new System.Drawing.Point(58, 205);
            this.Label_Name.Name = "Label_Name";
            this.Label_Name.Size = new System.Drawing.Size(188, 32);
            this.Label_Name.TabIndex = 19;
            this.Label_Name.Text = "Patient\'s Name";
            // 
            // Label_Title
            // 
            this.Label_Title.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Title.AutoSize = true;
            this.Label_Title.BackColor = System.Drawing.Color.Transparent;
            this.Label_Title.Font = new System.Drawing.Font("Felix Titling", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Title.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.Label_Title.Location = new System.Drawing.Point(286, 29);
            this.Label_Title.Name = "Label_Title";
            this.Label_Title.Size = new System.Drawing.Size(582, 35);
            this.Label_Title.TabIndex = 18;
            this.Label_Title.Text = "Update Internal Patient Details";
            // 
            // UpdateInternalPatientsControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.bunifuGradientPanel1);
            this.Name = "UpdateInternalPatientsControl";
            this.Size = new System.Drawing.Size(1140, 812);
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel1;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_wardNumber;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_reports;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_pre;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_ID;
        private System.Windows.Forms.Label label_Errors;
        private System.Windows.Forms.Label label_wardNum;
        private System.Windows.Forms.Label label_admission;
        private System.Windows.Forms.Label label_pEAge;
        private System.Windows.Forms.Label label_pEName;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_Age;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_AdmissionNum;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_pName;
        public Bunifu.Framework.UI.BunifuFlatButton Button_Clear;
        public Bunifu.Framework.UI.BunifuFlatButton Button_UPDATE;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Gender;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_TelephoneNum;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Age;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Name;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Title;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_reports;
        private System.Windows.Forms.Label label_R;
        private System.Windows.Forms.Label label_prescription;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_pres;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private System.Windows.Forms.Label label_ESearchNIC;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator1;
        public Bunifu.Framework.UI.BunifuFlatButton Button_Search;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_SearchNIC;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_SearchNIC;
    }
}
