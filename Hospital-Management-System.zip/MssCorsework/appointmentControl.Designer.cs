﻿namespace MssCorsework
{
    partial class appointmentControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(appointmentControl));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.bunifuGradientPanel1 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.bunifuSeparator4 = new Bunifu.Framework.UI.BunifuSeparator();
            this.label_doctorFee = new System.Windows.Forms.Label();
            this.label_Charge = new System.Windows.Forms.Label();
            this.app_Number = new System.Windows.Forms.NumericUpDown();
            this.label_AppointmentNumber = new System.Windows.Forms.Label();
            this.label_count = new System.Windows.Forms.Label();
            this.Datepicker_aTime1 = new System.Windows.Forms.DateTimePicker();
            this.lab_time = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Datepicker_aDate = new System.Windows.Forms.DateTimePicker();
            this.label_dName = new System.Windows.Forms.Label();
            this.label_ID = new System.Windows.Forms.Label();
            this.Datepicker_aTime = new System.Windows.Forms.DateTimePicker();
            this.bunifuSeparator3 = new Bunifu.Framework.UI.BunifuSeparator();
            this.bunifuSeparator2 = new Bunifu.Framework.UI.BunifuSeparator();
            this.panel_DocType = new System.Windows.Forms.Panel();
            this.btn_Type4 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btn_Type3 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btn_Type1 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btn_Type2 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Button_Type = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.DataGrid1 = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dNIC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dAddressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dExperienceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dTelNODataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dTypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tableDoctorsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mSSDBDataSet = new MssCorsework.MSSDBDataSet();
            this.label_ESearchNIC = new System.Windows.Forms.Label();
            this.bunifuSeparator1 = new Bunifu.Framework.UI.BunifuSeparator();
            this.Button_Search = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Label_SearchNIC = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Textbox_SearchNIC = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label_Errors = new System.Windows.Forms.Label();
            this.label_ETime = new System.Windows.Forms.Label();
            this.label_EDate = new System.Windows.Forms.Label();
            this.label_dENIC = new System.Windows.Forms.Label();
            this.label_pEName = new System.Windows.Forms.Label();
            this.Textbox_NIC = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Textbox_pName = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Button_ADDAPP = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Label_Time = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_Date = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_dNIC = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_Name = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_Title = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.searchDoctorsToolStrip = new System.Windows.Forms.ToolStrip();
            this.dTypeToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.dTypeToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.searchDoctorsToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.tableDoctorsTableAdapter = new MssCorsework.MSSDBDataSetTableAdapters.TableDoctorsTableAdapter();
            this.bunifuGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.app_Number)).BeginInit();
            this.panel_DocType.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGrid1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableDoctorsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mSSDBDataSet)).BeginInit();
            this.searchDoctorsToolStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.Controls.Add(this.bunifuSeparator4);
            this.bunifuGradientPanel1.Controls.Add(this.label_doctorFee);
            this.bunifuGradientPanel1.Controls.Add(this.label_Charge);
            this.bunifuGradientPanel1.Controls.Add(this.app_Number);
            this.bunifuGradientPanel1.Controls.Add(this.label_AppointmentNumber);
            this.bunifuGradientPanel1.Controls.Add(this.label_count);
            this.bunifuGradientPanel1.Controls.Add(this.Datepicker_aTime1);
            this.bunifuGradientPanel1.Controls.Add(this.lab_time);
            this.bunifuGradientPanel1.Controls.Add(this.Datepicker_aDate);
            this.bunifuGradientPanel1.Controls.Add(this.label_dName);
            this.bunifuGradientPanel1.Controls.Add(this.label_ID);
            this.bunifuGradientPanel1.Controls.Add(this.Datepicker_aTime);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuSeparator3);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuSeparator2);
            this.bunifuGradientPanel1.Controls.Add(this.panel_DocType);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuCustomLabel1);
            this.bunifuGradientPanel1.Controls.Add(this.DataGrid1);
            this.bunifuGradientPanel1.Controls.Add(this.label_ESearchNIC);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuSeparator1);
            this.bunifuGradientPanel1.Controls.Add(this.Button_Search);
            this.bunifuGradientPanel1.Controls.Add(this.Label_SearchNIC);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_SearchNIC);
            this.bunifuGradientPanel1.Controls.Add(this.label_Errors);
            this.bunifuGradientPanel1.Controls.Add(this.label_ETime);
            this.bunifuGradientPanel1.Controls.Add(this.label_EDate);
            this.bunifuGradientPanel1.Controls.Add(this.label_dENIC);
            this.bunifuGradientPanel1.Controls.Add(this.label_pEName);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_NIC);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_pName);
            this.bunifuGradientPanel1.Controls.Add(this.Button_ADDAPP);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Time);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Date);
            this.bunifuGradientPanel1.Controls.Add(this.Label_dNIC);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Name);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Title);
            this.bunifuGradientPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.Black;
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.Gray;
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(1140, 816);
            this.bunifuGradientPanel1.TabIndex = 1;
            // 
            // bunifuSeparator4
            // 
            this.bunifuSeparator4.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator4.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuSeparator4.LineThickness = 3;
            this.bunifuSeparator4.Location = new System.Drawing.Point(873, 394);
            this.bunifuSeparator4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator4.Name = "bunifuSeparator4";
            this.bunifuSeparator4.Size = new System.Drawing.Size(206, 10);
            this.bunifuSeparator4.TabIndex = 106;
            this.bunifuSeparator4.Transparency = 255;
            this.bunifuSeparator4.Vertical = false;
            // 
            // label_doctorFee
            // 
            this.label_doctorFee.AutoSize = true;
            this.label_doctorFee.BackColor = System.Drawing.Color.Transparent;
            this.label_doctorFee.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_doctorFee.ForeColor = System.Drawing.Color.Black;
            this.label_doctorFee.Location = new System.Drawing.Point(124, 25);
            this.label_doctorFee.Name = "label_doctorFee";
            this.label_doctorFee.Size = new System.Drawing.Size(19, 19);
            this.label_doctorFee.TabIndex = 105;
            this.label_doctorFee.Text = "0";
            this.label_doctorFee.Visible = false;
            // 
            // label_Charge
            // 
            this.label_Charge.AutoSize = true;
            this.label_Charge.BackColor = System.Drawing.Color.Transparent;
            this.label_Charge.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Charge.ForeColor = System.Drawing.Color.Black;
            this.label_Charge.Location = new System.Drawing.Point(124, 55);
            this.label_Charge.Name = "label_Charge";
            this.label_Charge.Size = new System.Drawing.Size(19, 19);
            this.label_Charge.TabIndex = 104;
            this.label_Charge.Text = "0";
            this.label_Charge.Visible = false;
            // 
            // app_Number
            // 
            this.app_Number.BackColor = System.Drawing.Color.Silver;
            this.app_Number.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.app_Number.Location = new System.Drawing.Point(989, 19);
            this.app_Number.MinimumSize = new System.Drawing.Size(90, 0);
            this.app_Number.Name = "app_Number";
            this.app_Number.Size = new System.Drawing.Size(90, 30);
            this.app_Number.TabIndex = 103;
            this.app_Number.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.App_Number_KeyPress_1);
            // 
            // label_AppointmentNumber
            // 
            this.label_AppointmentNumber.AutoSize = true;
            this.label_AppointmentNumber.BackColor = System.Drawing.Color.Transparent;
            this.label_AppointmentNumber.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_AppointmentNumber.ForeColor = System.Drawing.Color.Black;
            this.label_AppointmentNumber.Location = new System.Drawing.Point(837, 23);
            this.label_AppointmentNumber.Name = "label_AppointmentNumber";
            this.label_AppointmentNumber.Size = new System.Drawing.Size(134, 23);
            this.label_AppointmentNumber.TabIndex = 102;
            this.label_AppointmentNumber.Text = "App. Number";
            // 
            // label_count
            // 
            this.label_count.AutoSize = true;
            this.label_count.BackColor = System.Drawing.Color.Transparent;
            this.label_count.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_count.ForeColor = System.Drawing.Color.Black;
            this.label_count.Location = new System.Drawing.Point(313, 27);
            this.label_count.Name = "label_count";
            this.label_count.Size = new System.Drawing.Size(57, 19);
            this.label_count.TabIndex = 100;
            this.label_count.Text = "Count";
            this.label_count.Visible = false;
            // 
            // Datepicker_aTime1
            // 
            this.Datepicker_aTime1.CalendarFont = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Datepicker_aTime1.CalendarForeColor = System.Drawing.Color.White;
            this.Datepicker_aTime1.CalendarMonthBackground = System.Drawing.Color.Black;
            this.Datepicker_aTime1.CalendarTitleBackColor = System.Drawing.Color.Black;
            this.Datepicker_aTime1.CalendarTitleForeColor = System.Drawing.Color.White;
            this.Datepicker_aTime1.CustomFormat = " ";
            this.Datepicker_aTime1.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Datepicker_aTime1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Datepicker_aTime1.Location = new System.Drawing.Point(873, 344);
            this.Datepicker_aTime1.Margin = new System.Windows.Forms.Padding(10, 3, 3, 3);
            this.Datepicker_aTime1.MinimumSize = new System.Drawing.Size(4, 43);
            this.Datepicker_aTime1.Name = "Datepicker_aTime1";
            this.Datepicker_aTime1.ShowUpDown = true;
            this.Datepicker_aTime1.Size = new System.Drawing.Size(206, 43);
            this.Datepicker_aTime1.TabIndex = 99;
            this.Datepicker_aTime1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Datepicker_aTime1_KeyDown);
            this.Datepicker_aTime1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Datepicker_aTime1_KeyPress);
            this.Datepicker_aTime1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Datepicker_aTime1_MouseDown);
            // 
            // lab_time
            // 
            this.lab_time.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lab_time.AutoSize = true;
            this.lab_time.BackColor = System.Drawing.Color.Transparent;
            this.lab_time.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_time.ForeColor = System.Drawing.Color.Black;
            this.lab_time.Location = new System.Drawing.Point(818, 352);
            this.lab_time.Name = "lab_time";
            this.lab_time.Size = new System.Drawing.Size(44, 32);
            this.lab_time.TabIndex = 98;
            this.lab_time.Text = "To";
            // 
            // Datepicker_aDate
            // 
            this.Datepicker_aDate.CustomFormat = "MM/dd/yyyy";
            this.Datepicker_aDate.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Datepicker_aDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Datepicker_aDate.Location = new System.Drawing.Point(61, 344);
            this.Datepicker_aDate.MinimumSize = new System.Drawing.Size(4, 44);
            this.Datepicker_aDate.Name = "Datepicker_aDate";
            this.Datepicker_aDate.Size = new System.Drawing.Size(480, 44);
            this.Datepicker_aDate.TabIndex = 97;
            this.Datepicker_aDate.Value = new System.DateTime(2019, 12, 23, 0, 0, 0, 0);
            this.Datepicker_aDate.Leave += new System.EventHandler(this.Datepicker_aDate_Leave);
            this.Datepicker_aDate.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Datepicker_aDate_MouseDown);
            // 
            // label_dName
            // 
            this.label_dName.AutoSize = true;
            this.label_dName.BackColor = System.Drawing.Color.Transparent;
            this.label_dName.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_dName.ForeColor = System.Drawing.Color.Black;
            this.label_dName.Location = new System.Drawing.Point(200, 27);
            this.label_dName.Name = "label_dName";
            this.label_dName.Size = new System.Drawing.Size(60, 19);
            this.label_dName.TabIndex = 96;
            this.label_dName.Text = "Name";
            this.label_dName.Visible = false;
            // 
            // label_ID
            // 
            this.label_ID.AutoSize = true;
            this.label_ID.BackColor = System.Drawing.Color.Transparent;
            this.label_ID.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ID.ForeColor = System.Drawing.Color.Black;
            this.label_ID.Location = new System.Drawing.Point(200, 55);
            this.label_ID.Name = "label_ID";
            this.label_ID.Size = new System.Drawing.Size(26, 19);
            this.label_ID.TabIndex = 95;
            this.label_ID.Text = "ID";
            this.label_ID.Visible = false;
            // 
            // Datepicker_aTime
            // 
            this.Datepicker_aTime.CalendarFont = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Datepicker_aTime.CalendarForeColor = System.Drawing.Color.White;
            this.Datepicker_aTime.CalendarMonthBackground = System.Drawing.Color.Black;
            this.Datepicker_aTime.CalendarTitleBackColor = System.Drawing.Color.Black;
            this.Datepicker_aTime.CalendarTitleForeColor = System.Drawing.Color.White;
            this.Datepicker_aTime.CustomFormat = " ";
            this.Datepicker_aTime.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Datepicker_aTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Datepicker_aTime.Location = new System.Drawing.Point(599, 344);
            this.Datepicker_aTime.Margin = new System.Windows.Forms.Padding(10, 3, 3, 3);
            this.Datepicker_aTime.MinimumSize = new System.Drawing.Size(4, 43);
            this.Datepicker_aTime.Name = "Datepicker_aTime";
            this.Datepicker_aTime.ShowUpDown = true;
            this.Datepicker_aTime.Size = new System.Drawing.Size(206, 43);
            this.Datepicker_aTime.TabIndex = 94;
            this.Datepicker_aTime.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Datepicker_aTime_KeyDown);
            this.Datepicker_aTime.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Datepicker_aTime_KeyPress);
            this.Datepicker_aTime.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Datepicker_aTime_MouseDown);
            // 
            // bunifuSeparator3
            // 
            this.bunifuSeparator3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator3.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuSeparator3.LineThickness = 3;
            this.bunifuSeparator3.Location = new System.Drawing.Point(599, 395);
            this.bunifuSeparator3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator3.Name = "bunifuSeparator3";
            this.bunifuSeparator3.Size = new System.Drawing.Size(206, 10);
            this.bunifuSeparator3.TabIndex = 93;
            this.bunifuSeparator3.Transparency = 255;
            this.bunifuSeparator3.Vertical = false;
            // 
            // bunifuSeparator2
            // 
            this.bunifuSeparator2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator2.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuSeparator2.LineThickness = 3;
            this.bunifuSeparator2.Location = new System.Drawing.Point(61, 397);
            this.bunifuSeparator2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator2.Name = "bunifuSeparator2";
            this.bunifuSeparator2.Size = new System.Drawing.Size(480, 10);
            this.bunifuSeparator2.TabIndex = 92;
            this.bunifuSeparator2.Transparency = 255;
            this.bunifuSeparator2.Vertical = false;
            // 
            // panel_DocType
            // 
            this.panel_DocType.BackColor = System.Drawing.Color.Transparent;
            this.panel_DocType.Controls.Add(this.btn_Type4);
            this.panel_DocType.Controls.Add(this.btn_Type3);
            this.panel_DocType.Controls.Add(this.btn_Type1);
            this.panel_DocType.Controls.Add(this.btn_Type2);
            this.panel_DocType.Controls.Add(this.Button_Type);
            this.panel_DocType.Location = new System.Drawing.Point(599, 471);
            this.panel_DocType.MaximumSize = new System.Drawing.Size(480, 242);
            this.panel_DocType.MinimumSize = new System.Drawing.Size(480, 64);
            this.panel_DocType.Name = "panel_DocType";
            this.panel_DocType.Size = new System.Drawing.Size(480, 64);
            this.panel_DocType.TabIndex = 88;
            // 
            // btn_Type4
            // 
            this.btn_Type4.Activecolor = System.Drawing.Color.SteelBlue;
            this.btn_Type4.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_Type4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Type4.BorderRadius = 0;
            this.btn_Type4.ButtonText = "Surgeon";
            this.btn_Type4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Type4.DisabledColor = System.Drawing.Color.Gray;
            this.btn_Type4.Iconcolor = System.Drawing.Color.Transparent;
            this.btn_Type4.Iconimage = null;
            this.btn_Type4.Iconimage_right = null;
            this.btn_Type4.Iconimage_right_Selected = null;
            this.btn_Type4.Iconimage_Selected = null;
            this.btn_Type4.IconMarginLeft = 0;
            this.btn_Type4.IconMarginRight = 0;
            this.btn_Type4.IconRightVisible = true;
            this.btn_Type4.IconRightZoom = 0D;
            this.btn_Type4.IconVisible = true;
            this.btn_Type4.IconZoom = 90D;
            this.btn_Type4.IsTab = false;
            this.btn_Type4.Location = new System.Drawing.Point(0, 199);
            this.btn_Type4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Type4.Name = "btn_Type4";
            this.btn_Type4.Normalcolor = System.Drawing.Color.SteelBlue;
            this.btn_Type4.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.btn_Type4.OnHoverTextColor = System.Drawing.Color.White;
            this.btn_Type4.selected = false;
            this.btn_Type4.Size = new System.Drawing.Size(480, 42);
            this.btn_Type4.TabIndex = 60;
            this.btn_Type4.Text = "Surgeon";
            this.btn_Type4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Type4.Textcolor = System.Drawing.Color.White;
            this.btn_Type4.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Type4.Click += new System.EventHandler(this.Btn_Type4_Click);
            // 
            // btn_Type3
            // 
            this.btn_Type3.Activecolor = System.Drawing.Color.SteelBlue;
            this.btn_Type3.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_Type3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Type3.BorderRadius = 0;
            this.btn_Type3.ButtonText = "Ophthalmologist";
            this.btn_Type3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Type3.DisabledColor = System.Drawing.Color.Gray;
            this.btn_Type3.Iconcolor = System.Drawing.Color.Transparent;
            this.btn_Type3.Iconimage = null;
            this.btn_Type3.Iconimage_right = null;
            this.btn_Type3.Iconimage_right_Selected = null;
            this.btn_Type3.Iconimage_Selected = null;
            this.btn_Type3.IconMarginLeft = 0;
            this.btn_Type3.IconMarginRight = 0;
            this.btn_Type3.IconRightVisible = true;
            this.btn_Type3.IconRightZoom = 0D;
            this.btn_Type3.IconVisible = true;
            this.btn_Type3.IconZoom = 90D;
            this.btn_Type3.IsTab = false;
            this.btn_Type3.Location = new System.Drawing.Point(0, 155);
            this.btn_Type3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Type3.Name = "btn_Type3";
            this.btn_Type3.Normalcolor = System.Drawing.Color.SteelBlue;
            this.btn_Type3.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.btn_Type3.OnHoverTextColor = System.Drawing.Color.White;
            this.btn_Type3.selected = false;
            this.btn_Type3.Size = new System.Drawing.Size(480, 42);
            this.btn_Type3.TabIndex = 59;
            this.btn_Type3.Text = "Ophthalmologist";
            this.btn_Type3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Type3.Textcolor = System.Drawing.Color.White;
            this.btn_Type3.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Type3.Click += new System.EventHandler(this.Btn_Type3_Click);
            // 
            // btn_Type1
            // 
            this.btn_Type1.Activecolor = System.Drawing.Color.SteelBlue;
            this.btn_Type1.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_Type1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Type1.BorderRadius = 0;
            this.btn_Type1.ButtonText = "Cardiologist";
            this.btn_Type1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Type1.DisabledColor = System.Drawing.Color.Gray;
            this.btn_Type1.Iconcolor = System.Drawing.Color.Transparent;
            this.btn_Type1.Iconimage = null;
            this.btn_Type1.Iconimage_right = null;
            this.btn_Type1.Iconimage_right_Selected = null;
            this.btn_Type1.Iconimage_Selected = null;
            this.btn_Type1.IconMarginLeft = 0;
            this.btn_Type1.IconMarginRight = 0;
            this.btn_Type1.IconRightVisible = true;
            this.btn_Type1.IconRightZoom = 0D;
            this.btn_Type1.IconVisible = true;
            this.btn_Type1.IconZoom = 90D;
            this.btn_Type1.IsTab = false;
            this.btn_Type1.Location = new System.Drawing.Point(0, 67);
            this.btn_Type1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Type1.Name = "btn_Type1";
            this.btn_Type1.Normalcolor = System.Drawing.Color.SteelBlue;
            this.btn_Type1.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.btn_Type1.OnHoverTextColor = System.Drawing.Color.White;
            this.btn_Type1.selected = false;
            this.btn_Type1.Size = new System.Drawing.Size(480, 42);
            this.btn_Type1.TabIndex = 25;
            this.btn_Type1.Text = "Cardiologist";
            this.btn_Type1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Type1.Textcolor = System.Drawing.Color.White;
            this.btn_Type1.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Type1.Click += new System.EventHandler(this.Btn_Type1_Click);
            // 
            // btn_Type2
            // 
            this.btn_Type2.Activecolor = System.Drawing.Color.SteelBlue;
            this.btn_Type2.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_Type2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Type2.BorderRadius = 0;
            this.btn_Type2.ButtonText = "Family Physician";
            this.btn_Type2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Type2.DisabledColor = System.Drawing.Color.Gray;
            this.btn_Type2.Iconcolor = System.Drawing.Color.Transparent;
            this.btn_Type2.Iconimage = null;
            this.btn_Type2.Iconimage_right = null;
            this.btn_Type2.Iconimage_right_Selected = null;
            this.btn_Type2.Iconimage_Selected = null;
            this.btn_Type2.IconMarginLeft = 0;
            this.btn_Type2.IconMarginRight = 0;
            this.btn_Type2.IconRightVisible = true;
            this.btn_Type2.IconRightZoom = 0D;
            this.btn_Type2.IconVisible = true;
            this.btn_Type2.IconZoom = 90D;
            this.btn_Type2.IsTab = false;
            this.btn_Type2.Location = new System.Drawing.Point(0, 111);
            this.btn_Type2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Type2.Name = "btn_Type2";
            this.btn_Type2.Normalcolor = System.Drawing.Color.SteelBlue;
            this.btn_Type2.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.btn_Type2.OnHoverTextColor = System.Drawing.Color.White;
            this.btn_Type2.selected = false;
            this.btn_Type2.Size = new System.Drawing.Size(480, 42);
            this.btn_Type2.TabIndex = 26;
            this.btn_Type2.Text = "Family Physician";
            this.btn_Type2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Type2.Textcolor = System.Drawing.Color.White;
            this.btn_Type2.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Type2.Click += new System.EventHandler(this.Btn_Type2_Click);
            // 
            // Button_Type
            // 
            this.Button_Type.Activecolor = System.Drawing.Color.Crimson;
            this.Button_Type.BackColor = System.Drawing.Color.Crimson;
            this.Button_Type.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_Type.BorderRadius = 0;
            this.Button_Type.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Button_Type.ButtonText = "TYPE OF DOCTORS";
            this.Button_Type.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_Type.DisabledColor = System.Drawing.Color.Gray;
            this.Button_Type.ForeColor = System.Drawing.Color.White;
            this.Button_Type.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_Type.Iconimage = null;
            this.Button_Type.Iconimage_right = null;
            this.Button_Type.Iconimage_right_Selected = null;
            this.Button_Type.Iconimage_Selected = null;
            this.Button_Type.IconMarginLeft = 0;
            this.Button_Type.IconMarginRight = 0;
            this.Button_Type.IconRightVisible = true;
            this.Button_Type.IconRightZoom = 0D;
            this.Button_Type.IconVisible = true;
            this.Button_Type.IconZoom = 90D;
            this.Button_Type.IsTab = false;
            this.Button_Type.Location = new System.Drawing.Point(0, 0);
            this.Button_Type.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_Type.Name = "Button_Type";
            this.Button_Type.Normalcolor = System.Drawing.Color.Crimson;
            this.Button_Type.OnHovercolor = System.Drawing.Color.Transparent;
            this.Button_Type.OnHoverTextColor = System.Drawing.Color.Black;
            this.Button_Type.selected = false;
            this.Button_Type.Size = new System.Drawing.Size(480, 64);
            this.Button_Type.TabIndex = 58;
            this.Button_Type.Text = "TYPE OF DOCTORS";
            this.Button_Type.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_Type.Textcolor = System.Drawing.Color.White;
            this.Button_Type.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Type.Click += new System.EventHandler(this.Button_Type_Click);
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.Black;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(55, 547);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(263, 32);
            this.bunifuCustomLabel1.TabIndex = 87;
            this.bunifuCustomLabel1.Text = "Available Doctors List";
            // 
            // DataGrid1
            // 
            this.DataGrid1.AllowUserToAddRows = false;
            this.DataGrid1.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.DataGrid1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.DataGrid1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DataGrid1.AutoGenerateColumns = false;
            this.DataGrid1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DataGrid1.BackgroundColor = System.Drawing.Color.White;
            this.DataGrid1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DataGrid1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.DataGrid1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DataGrid1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.DataGrid1.ColumnHeadersHeight = 35;
            this.DataGrid1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.dName,
            this.dNIC,
            this.dAddressDataGridViewTextBoxColumn,
            this.dExperienceDataGridViewTextBoxColumn,
            this.dTelNODataGridViewTextBoxColumn,
            this.dTypeDataGridViewTextBoxColumn});
            this.DataGrid1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DataGrid1.DataSource = this.tableDoctorsBindingSource;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Century", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DataGrid1.DefaultCellStyle = dataGridViewCellStyle3;
            this.DataGrid1.DoubleBuffered = true;
            this.DataGrid1.EnableHeadersVisualStyles = false;
            this.DataGrid1.GridColor = System.Drawing.Color.White;
            this.DataGrid1.HeaderBgColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.DataGrid1.HeaderForeColor = System.Drawing.Color.White;
            this.DataGrid1.Location = new System.Drawing.Point(61, 589);
            this.DataGrid1.MultiSelect = false;
            this.DataGrid1.Name = "DataGrid1";
            this.DataGrid1.ReadOnly = true;
            this.DataGrid1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Century", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DataGrid1.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.DataGrid1.RowHeadersVisible = false;
            this.DataGrid1.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.White;
            this.DataGrid1.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Century", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DataGrid1.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.DataGrid1.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Silver;
            this.DataGrid1.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.DataGrid1.RowTemplate.DividerHeight = 3;
            this.DataGrid1.RowTemplate.Height = 40;
            this.DataGrid1.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.DataGrid1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DataGrid1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DataGrid1.Size = new System.Drawing.Size(1018, 211);
            this.DataGrid1.TabIndex = 86;
            this.DataGrid1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGrid1_CellContentClick);
            this.DataGrid1.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.DataGrid1_CellMouseClick);
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            this.idDataGridViewTextBoxColumn.Visible = false;
            // 
            // dName
            // 
            this.dName.DataPropertyName = "dName";
            this.dName.HeaderText = "Name";
            this.dName.Name = "dName";
            this.dName.ReadOnly = true;
            // 
            // dNIC
            // 
            this.dNIC.DataPropertyName = "dNIC";
            this.dNIC.HeaderText = "NIC";
            this.dNIC.Name = "dNIC";
            this.dNIC.ReadOnly = true;
            // 
            // dAddressDataGridViewTextBoxColumn
            // 
            this.dAddressDataGridViewTextBoxColumn.DataPropertyName = "dAddress";
            this.dAddressDataGridViewTextBoxColumn.HeaderText = "Address";
            this.dAddressDataGridViewTextBoxColumn.Name = "dAddressDataGridViewTextBoxColumn";
            this.dAddressDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dExperienceDataGridViewTextBoxColumn
            // 
            this.dExperienceDataGridViewTextBoxColumn.DataPropertyName = "dExperience";
            this.dExperienceDataGridViewTextBoxColumn.HeaderText = "Experience";
            this.dExperienceDataGridViewTextBoxColumn.Name = "dExperienceDataGridViewTextBoxColumn";
            this.dExperienceDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dTelNODataGridViewTextBoxColumn
            // 
            this.dTelNODataGridViewTextBoxColumn.DataPropertyName = "dTelNO";
            this.dTelNODataGridViewTextBoxColumn.HeaderText = "TelNO";
            this.dTelNODataGridViewTextBoxColumn.Name = "dTelNODataGridViewTextBoxColumn";
            this.dTelNODataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dTypeDataGridViewTextBoxColumn
            // 
            this.dTypeDataGridViewTextBoxColumn.DataPropertyName = "dType";
            this.dTypeDataGridViewTextBoxColumn.HeaderText = "Type";
            this.dTypeDataGridViewTextBoxColumn.Name = "dTypeDataGridViewTextBoxColumn";
            this.dTypeDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // tableDoctorsBindingSource
            // 
            this.tableDoctorsBindingSource.DataMember = "TableDoctors";
            this.tableDoctorsBindingSource.DataSource = this.mSSDBDataSet;
            // 
            // mSSDBDataSet
            // 
            this.mSSDBDataSet.DataSetName = "MSSDBDataSet";
            this.mSSDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label_ESearchNIC
            // 
            this.label_ESearchNIC.AutoSize = true;
            this.label_ESearchNIC.BackColor = System.Drawing.Color.Transparent;
            this.label_ESearchNIC.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ESearchNIC.ForeColor = System.Drawing.Color.Red;
            this.label_ESearchNIC.Location = new System.Drawing.Point(57, 133);
            this.label_ESearchNIC.Name = "label_ESearchNIC";
            this.label_ESearchNIC.Size = new System.Drawing.Size(60, 19);
            this.label_ESearchNIC.TabIndex = 85;
            this.label_ESearchNIC.Text = "label5";
            this.label_ESearchNIC.Visible = false;
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator1.LineThickness = 2;
            this.bunifuSeparator1.Location = new System.Drawing.Point(61, 156);
            this.bunifuSeparator1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Size = new System.Drawing.Size(1018, 10);
            this.bunifuSeparator1.TabIndex = 84;
            this.bunifuSeparator1.Transparency = 255;
            this.bunifuSeparator1.Vertical = false;
            // 
            // Button_Search
            // 
            this.Button_Search.Activecolor = System.Drawing.Color.DarkViolet;
            this.Button_Search.BackColor = System.Drawing.Color.DarkViolet;
            this.Button_Search.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_Search.BorderRadius = 0;
            this.Button_Search.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Button_Search.ButtonText = "SEARCH";
            this.Button_Search.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_Search.DisabledColor = System.Drawing.Color.Gray;
            this.Button_Search.ForeColor = System.Drawing.Color.White;
            this.Button_Search.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_Search.Iconimage = null;
            this.Button_Search.Iconimage_right = null;
            this.Button_Search.Iconimage_right_Selected = null;
            this.Button_Search.Iconimage_Selected = null;
            this.Button_Search.IconMarginLeft = 0;
            this.Button_Search.IconMarginRight = 0;
            this.Button_Search.IconRightVisible = true;
            this.Button_Search.IconRightZoom = 0D;
            this.Button_Search.IconVisible = true;
            this.Button_Search.IconZoom = 90D;
            this.Button_Search.IsTab = false;
            this.Button_Search.Location = new System.Drawing.Point(799, 77);
            this.Button_Search.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_Search.Name = "Button_Search";
            this.Button_Search.Normalcolor = System.Drawing.Color.DarkViolet;
            this.Button_Search.OnHovercolor = System.Drawing.Color.Transparent;
            this.Button_Search.OnHoverTextColor = System.Drawing.Color.Black;
            this.Button_Search.selected = false;
            this.Button_Search.Size = new System.Drawing.Size(280, 49);
            this.Button_Search.TabIndex = 83;
            this.Button_Search.Text = "SEARCH";
            this.Button_Search.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_Search.Textcolor = System.Drawing.Color.White;
            this.Button_Search.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Search.Click += new System.EventHandler(this.Button_Search_Click);
            // 
            // Label_SearchNIC
            // 
            this.Label_SearchNIC.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_SearchNIC.AutoSize = true;
            this.Label_SearchNIC.BackColor = System.Drawing.Color.Transparent;
            this.Label_SearchNIC.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SearchNIC.ForeColor = System.Drawing.Color.Black;
            this.Label_SearchNIC.Location = new System.Drawing.Point(55, 84);
            this.Label_SearchNIC.Name = "Label_SearchNIC";
            this.Label_SearchNIC.Size = new System.Drawing.Size(315, 32);
            this.Label_SearchNIC.TabIndex = 82;
            this.Label_SearchNIC.Text = "Patient\'s Or Gurdian\'s NIC";
            // 
            // Textbox_SearchNIC
            // 
            this.Textbox_SearchNIC.BackColor = System.Drawing.Color.Silver;
            this.Textbox_SearchNIC.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_SearchNIC.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_SearchNIC.ForeColor = System.Drawing.Color.Black;
            this.Textbox_SearchNIC.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_SearchNIC.HintText = "Patient\'s Or Gurdian\'s NIC";
            this.Textbox_SearchNIC.isPassword = false;
            this.Textbox_SearchNIC.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_SearchNIC.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_SearchNIC.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_SearchNIC.LineThickness = 3;
            this.Textbox_SearchNIC.Location = new System.Drawing.Point(395, 77);
            this.Textbox_SearchNIC.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_SearchNIC.Name = "Textbox_SearchNIC";
            this.Textbox_SearchNIC.Size = new System.Drawing.Size(373, 45);
            this.Textbox_SearchNIC.TabIndex = 81;
            this.Textbox_SearchNIC.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Textbox_SearchNIC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_SearchNIC_KeyPress);
            // 
            // label_Errors
            // 
            this.label_Errors.AutoSize = true;
            this.label_Errors.BackColor = System.Drawing.Color.Transparent;
            this.label_Errors.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Errors.ForeColor = System.Drawing.Color.Red;
            this.label_Errors.Location = new System.Drawing.Point(57, 442);
            this.label_Errors.Name = "label_Errors";
            this.label_Errors.Size = new System.Drawing.Size(60, 19);
            this.label_Errors.TabIndex = 75;
            this.label_Errors.Text = "label5";
            this.label_Errors.Visible = false;
            // 
            // label_ETime
            // 
            this.label_ETime.AutoSize = true;
            this.label_ETime.BackColor = System.Drawing.Color.Transparent;
            this.label_ETime.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ETime.ForeColor = System.Drawing.Color.Red;
            this.label_ETime.Location = new System.Drawing.Point(595, 417);
            this.label_ETime.Name = "label_ETime";
            this.label_ETime.Size = new System.Drawing.Size(60, 19);
            this.label_ETime.TabIndex = 72;
            this.label_ETime.Text = "label4";
            this.label_ETime.Visible = false;
            // 
            // label_EDate
            // 
            this.label_EDate.AutoSize = true;
            this.label_EDate.BackColor = System.Drawing.Color.Transparent;
            this.label_EDate.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_EDate.ForeColor = System.Drawing.Color.Red;
            this.label_EDate.Location = new System.Drawing.Point(57, 417);
            this.label_EDate.Name = "label_EDate";
            this.label_EDate.Size = new System.Drawing.Size(60, 19);
            this.label_EDate.TabIndex = 71;
            this.label_EDate.Text = "label3";
            this.label_EDate.Visible = false;
            // 
            // label_dENIC
            // 
            this.label_dENIC.AutoSize = true;
            this.label_dENIC.BackColor = System.Drawing.Color.Transparent;
            this.label_dENIC.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_dENIC.ForeColor = System.Drawing.Color.Red;
            this.label_dENIC.Location = new System.Drawing.Point(595, 281);
            this.label_dENIC.Name = "label_dENIC";
            this.label_dENIC.Size = new System.Drawing.Size(60, 19);
            this.label_dENIC.TabIndex = 70;
            this.label_dENIC.Text = "label2";
            this.label_dENIC.Visible = false;
            // 
            // label_pEName
            // 
            this.label_pEName.AutoSize = true;
            this.label_pEName.BackColor = System.Drawing.Color.Transparent;
            this.label_pEName.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_pEName.ForeColor = System.Drawing.Color.Red;
            this.label_pEName.Location = new System.Drawing.Point(57, 281);
            this.label_pEName.Name = "label_pEName";
            this.label_pEName.Size = new System.Drawing.Size(60, 19);
            this.label_pEName.TabIndex = 69;
            this.label_pEName.Text = "label1";
            this.label_pEName.Visible = false;
            // 
            // Textbox_NIC
            // 
            this.Textbox_NIC.BackColor = System.Drawing.Color.Silver;
            this.Textbox_NIC.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_NIC.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_NIC.ForeColor = System.Drawing.Color.Black;
            this.Textbox_NIC.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_NIC.HintText = "Doctor\'s NIC";
            this.Textbox_NIC.isPassword = false;
            this.Textbox_NIC.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_NIC.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_NIC.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_NIC.LineThickness = 3;
            this.Textbox_NIC.Location = new System.Drawing.Point(599, 210);
            this.Textbox_NIC.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_NIC.Name = "Textbox_NIC";
            this.Textbox_NIC.Size = new System.Drawing.Size(480, 60);
            this.Textbox_NIC.TabIndex = 66;
            this.Textbox_NIC.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Textbox_NIC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_NIC_KeyPress);
            // 
            // Textbox_pName
            // 
            this.Textbox_pName.BackColor = System.Drawing.Color.Silver;
            this.Textbox_pName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_pName.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_pName.ForeColor = System.Drawing.Color.Black;
            this.Textbox_pName.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_pName.HintText = "Patient\'s Name";
            this.Textbox_pName.isPassword = false;
            this.Textbox_pName.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_pName.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_pName.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_pName.LineThickness = 3;
            this.Textbox_pName.Location = new System.Drawing.Point(61, 210);
            this.Textbox_pName.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_pName.Name = "Textbox_pName";
            this.Textbox_pName.Size = new System.Drawing.Size(480, 60);
            this.Textbox_pName.TabIndex = 61;
            this.Textbox_pName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Textbox_pName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_pName_KeyPress);
            // 
            // Button_ADDAPP
            // 
            this.Button_ADDAPP.Activecolor = System.Drawing.Color.ForestGreen;
            this.Button_ADDAPP.BackColor = System.Drawing.Color.ForestGreen;
            this.Button_ADDAPP.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_ADDAPP.BorderRadius = 0;
            this.Button_ADDAPP.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Button_ADDAPP.ButtonText = "ADD APPOINTMENT";
            this.Button_ADDAPP.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_ADDAPP.DisabledColor = System.Drawing.Color.Gray;
            this.Button_ADDAPP.ForeColor = System.Drawing.Color.White;
            this.Button_ADDAPP.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_ADDAPP.Iconimage = null;
            this.Button_ADDAPP.Iconimage_right = null;
            this.Button_ADDAPP.Iconimage_right_Selected = null;
            this.Button_ADDAPP.Iconimage_Selected = null;
            this.Button_ADDAPP.IconMarginLeft = 0;
            this.Button_ADDAPP.IconMarginRight = 0;
            this.Button_ADDAPP.IconRightVisible = true;
            this.Button_ADDAPP.IconRightZoom = 0D;
            this.Button_ADDAPP.IconVisible = true;
            this.Button_ADDAPP.IconZoom = 90D;
            this.Button_ADDAPP.IsTab = false;
            this.Button_ADDAPP.Location = new System.Drawing.Point(61, 471);
            this.Button_ADDAPP.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_ADDAPP.Name = "Button_ADDAPP";
            this.Button_ADDAPP.Normalcolor = System.Drawing.Color.ForestGreen;
            this.Button_ADDAPP.OnHovercolor = System.Drawing.Color.Transparent;
            this.Button_ADDAPP.OnHoverTextColor = System.Drawing.Color.Black;
            this.Button_ADDAPP.selected = false;
            this.Button_ADDAPP.Size = new System.Drawing.Size(480, 64);
            this.Button_ADDAPP.TabIndex = 57;
            this.Button_ADDAPP.Text = "ADD APPOINTMENT";
            this.Button_ADDAPP.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_ADDAPP.Textcolor = System.Drawing.Color.White;
            this.Button_ADDAPP.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_ADDAPP.Click += new System.EventHandler(this.Button_ADDAPP_Click);
            // 
            // Label_Time
            // 
            this.Label_Time.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Time.AutoSize = true;
            this.Label_Time.BackColor = System.Drawing.Color.Transparent;
            this.Label_Time.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Time.ForeColor = System.Drawing.Color.Black;
            this.Label_Time.Location = new System.Drawing.Point(593, 309);
            this.Label_Time.Name = "Label_Time";
            this.Label_Time.Size = new System.Drawing.Size(71, 32);
            this.Label_Time.TabIndex = 27;
            this.Label_Time.Text = "Time";
            // 
            // Label_Date
            // 
            this.Label_Date.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Date.AutoSize = true;
            this.Label_Date.BackColor = System.Drawing.Color.Transparent;
            this.Label_Date.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Date.ForeColor = System.Drawing.Color.Black;
            this.Label_Date.Location = new System.Drawing.Point(55, 309);
            this.Label_Date.Name = "Label_Date";
            this.Label_Date.Size = new System.Drawing.Size(68, 32);
            this.Label_Date.TabIndex = 25;
            this.Label_Date.Text = "Date";
            // 
            // Label_dNIC
            // 
            this.Label_dNIC.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_dNIC.AutoSize = true;
            this.Label_dNIC.BackColor = System.Drawing.Color.Transparent;
            this.Label_dNIC.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_dNIC.ForeColor = System.Drawing.Color.Black;
            this.Label_dNIC.Location = new System.Drawing.Point(593, 174);
            this.Label_dNIC.Name = "Label_dNIC";
            this.Label_dNIC.Size = new System.Drawing.Size(161, 32);
            this.Label_dNIC.TabIndex = 23;
            this.Label_dNIC.Text = "Doctor\'s NIC";
            // 
            // Label_Name
            // 
            this.Label_Name.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Name.AutoSize = true;
            this.Label_Name.BackColor = System.Drawing.Color.Transparent;
            this.Label_Name.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Name.ForeColor = System.Drawing.Color.Black;
            this.Label_Name.Location = new System.Drawing.Point(55, 174);
            this.Label_Name.Name = "Label_Name";
            this.Label_Name.Size = new System.Drawing.Size(188, 32);
            this.Label_Name.TabIndex = 19;
            this.Label_Name.Text = "Patient\'s Name";
            // 
            // Label_Title
            // 
            this.Label_Title.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Title.AutoSize = true;
            this.Label_Title.BackColor = System.Drawing.Color.Transparent;
            this.Label_Title.Font = new System.Drawing.Font("Felix Titling", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Title.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.Label_Title.Location = new System.Drawing.Point(396, 15);
            this.Label_Title.Name = "Label_Title";
            this.Label_Title.Size = new System.Drawing.Size(337, 35);
            this.Label_Title.TabIndex = 18;
            this.Label_Title.Text = "Add Appointments";
            // 
            // timer1
            // 
            this.timer1.Interval = 1;
            this.timer1.Tick += new System.EventHandler(this.Timer1_Tick);
            // 
            // searchDoctorsToolStrip
            // 
            this.searchDoctorsToolStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.searchDoctorsToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dTypeToolStripLabel,
            this.dTypeToolStripTextBox,
            this.searchDoctorsToolStripButton});
            this.searchDoctorsToolStrip.Location = new System.Drawing.Point(0, 0);
            this.searchDoctorsToolStrip.Name = "searchDoctorsToolStrip";
            this.searchDoctorsToolStrip.Size = new System.Drawing.Size(1140, 27);
            this.searchDoctorsToolStrip.TabIndex = 2;
            this.searchDoctorsToolStrip.Text = "searchDoctorsToolStrip";
            this.searchDoctorsToolStrip.Visible = false;
            // 
            // dTypeToolStripLabel
            // 
            this.dTypeToolStripLabel.Name = "dTypeToolStripLabel";
            this.dTypeToolStripLabel.Size = new System.Drawing.Size(52, 24);
            this.dTypeToolStripLabel.Text = "dType:";
            // 
            // dTypeToolStripTextBox
            // 
            this.dTypeToolStripTextBox.Name = "dTypeToolStripTextBox";
            this.dTypeToolStripTextBox.Size = new System.Drawing.Size(100, 27);
            // 
            // searchDoctorsToolStripButton
            // 
            this.searchDoctorsToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.searchDoctorsToolStripButton.Name = "searchDoctorsToolStripButton";
            this.searchDoctorsToolStripButton.Size = new System.Drawing.Size(107, 24);
            this.searchDoctorsToolStripButton.Text = "searchDoctors";
            this.searchDoctorsToolStripButton.Click += new System.EventHandler(this.SearchDoctorsToolStripButton_Click);
            // 
            // tableDoctorsTableAdapter
            // 
            this.tableDoctorsTableAdapter.ClearBeforeFill = true;
            // 
            // appointmentControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.searchDoctorsToolStrip);
            this.Controls.Add(this.bunifuGradientPanel1);
            this.Name = "appointmentControl";
            this.Size = new System.Drawing.Size(1140, 816);
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.app_Number)).EndInit();
            this.panel_DocType.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DataGrid1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableDoctorsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mSSDBDataSet)).EndInit();
            this.searchDoctorsToolStrip.ResumeLayout(false);
            this.searchDoctorsToolStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel1;
        private System.Windows.Forms.Label label_Errors;
        private System.Windows.Forms.Label label_ETime;
        private System.Windows.Forms.Label label_EDate;
        private System.Windows.Forms.Label label_dENIC;
        private System.Windows.Forms.Label label_pEName;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_NIC;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_pName;
        public Bunifu.Framework.UI.BunifuFlatButton Button_Type;
        public Bunifu.Framework.UI.BunifuFlatButton Button_ADDAPP;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Time;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Date;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_dNIC;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Name;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Title;
        private System.Windows.Forms.Label label_ESearchNIC;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator1;
        public Bunifu.Framework.UI.BunifuFlatButton Button_Search;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_SearchNIC;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_SearchNIC;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuCustomDataGrid DataGrid1;
        private System.Windows.Forms.Panel panel_DocType;
        public Bunifu.Framework.UI.BunifuFlatButton btn_Type4;
        public Bunifu.Framework.UI.BunifuFlatButton btn_Type3;
        public Bunifu.Framework.UI.BunifuFlatButton btn_Type1;
        public Bunifu.Framework.UI.BunifuFlatButton btn_Type2;
        private System.Windows.Forms.Timer timer1;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator2;
        public System.Windows.Forms.DateTimePicker Datepicker_aTime;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator3;
        private System.Windows.Forms.Label label_ID;
        private System.Windows.Forms.BindingSource tableDoctorsBindingSource;
        private MSSDBDataSet mSSDBDataSet;
        private MSSDBDataSetTableAdapters.TableDoctorsTableAdapter tableDoctorsTableAdapter;
        private System.Windows.Forms.ToolStrip searchDoctorsToolStrip;
        private System.Windows.Forms.ToolStripLabel dTypeToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox dTypeToolStripTextBox;
        private System.Windows.Forms.ToolStripButton searchDoctorsToolStripButton;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dName;
        private System.Windows.Forms.DataGridViewTextBoxColumn dNIC;
        private System.Windows.Forms.DataGridViewTextBoxColumn dAddressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dExperienceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dTelNODataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dTypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label_dName;
        private System.Windows.Forms.DateTimePicker Datepicker_aDate;
        public System.Windows.Forms.DateTimePicker Datepicker_aTime1;
        private Bunifu.Framework.UI.BunifuCustomLabel lab_time;
        private System.Windows.Forms.Label label_count;
        private System.Windows.Forms.Label label_AppointmentNumber;
        private System.Windows.Forms.NumericUpDown app_Number;
        private System.Windows.Forms.Label label_Charge;
        private System.Windows.Forms.Label label_doctorFee;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator4;
    }
}
