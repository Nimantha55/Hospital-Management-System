﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace MssCorsework
{
    class AccountControl
    {
        public string username;

        public void Admin()
        {
            Dashboard db = new Dashboard();
            db.Show();
            db.Label_User.Text = "Admin - " + username;
            db.panel_Patients.Visible = false;
            db.Button_Appointments.Visible = false;
            db.Button_addDiagnosisDetails.Visible = false;
            db.Separator_IPH.Visible = false;
            db.Button_internalPatient.Visible = false;
            db.Button_UpdateInternal.Visible = false;
            db.Separator_MH.Visible = false;

            db.panel_doctors.Location = new System.Drawing.Point(5, 105);
            db.Button_Payments.Location = new System.Drawing.Point(5, 185);
            db.Button_amount.Location = new System.Drawing.Point(5, 265);
            db.Button_calculateBill.Location = new System.Drawing.Point(5, 345);
            db.Button_appointmentHistory.BringToFront();
            db.Button_appointmentHistory.Location = new System.Drawing.Point(5, 425);
        }
        public void Clerk()
        {
            Dashboard db = new Dashboard();
            db.Show();
            db.Label_User.Text = "Clerk - " + username;
            db.panel_doctors.Visible = false;
            db.Button_Payments.Visible = false;
            db.Button_amount.Visible = false;
            db.Button_calculateBill.Visible = false;
            db.Button_addDiagnosisDetails.Visible = false;
            db.Separator_amo.Visible = false;
            db.Separator_MH.Visible = false;
            db.Separator_IPH.Visible = false;
            db.Button_charts.Visible = false;
            db.Button_appointmentHistory.Visible = false;

            db.Button_Appointments.Location = new System.Drawing.Point(5, 185);
            db.Button_internalPatient.Location = new System.Drawing.Point(5, 265);
            db.Button_UpdateInternal.BringToFront();
            db.Button_UpdateInternal.Location = new System.Drawing.Point(5, 343);
        }
        public void Doctor()
        {
            DashboardNew db = new DashboardNew();
            db.Show();
            db.Label_User.Text = "Doctor - " + username;
            db.panel_labReports.Visible = false;
            db.Button_Inventory.Visible = false;
            db.Button_createInventory.Visible = false;
            db.Button_Payments.Visible = false;
            db.Button_updateInternalPatients.Visible = false;
            db.Separator_CRI.Visible = false;
            db.Separator_PD.Visible = false;
            db.Separator_RDD.Visible = false;
            db.Separator_UIP.Visible = false;
            db.Separator_VDD.Visible = false;
            db.Button_inventoryReport.Visible = false;

            db.Button_addDiagnosisDetails.Location = new System.Drawing.Point(5, 105);
            db.Button_viewDiagnosisDetails.Location = new System.Drawing.Point(5, 185);
        }
        public void Technician()
        {
            DashboardNew db = new DashboardNew();
            db.Show();
            db.Label_User.Text = "Lab Technician - " + username;
            db.Button_Inventory.Visible = false;
            db.Button_createInventory.Visible = false;
            db.Button_Payments.Visible = false;
            db.Button_updateInternalPatients.Visible = false;
            db.Separator_CRI.Visible = false;
            db.Separator_PD.Visible = false;
            db.Separator_RDD.Visible = false;
            db.Separator_UIP.Visible = false;
            db.Separator_VDD.Visible = false;
            db.Button_addDiagnosisDetails.Visible = false;
            db.Button_viewDiagnosisDetails.Visible = false;
            db.Separator_ID.Visible = false;
            db.Button_inventoryReport.Visible = false;
        }
        public void Pharmacist()
        {
            DashboardNew db = new DashboardNew();
            db.Show();
            db.Label_User.Text = "Pharmacist - " + username;
            db.Button_Payments.Visible = false;
            db.Button_updateInternalPatients.Visible = false;
            db.Separator_PD.Visible = false;
            db.Separator_RDD.Visible = false;
            db.Separator_UIP.Visible = false;
            db.Separator_VDD.Visible = false;
            db.Button_addDiagnosisDetails.Visible = false;
            db.Button_viewDiagnosisDetails.Visible = false;
            db.panel_labReports.Visible = false;
            db.Button_createInventory.Visible = false;
            db.Separator_CRI.Visible = false;

            db.Button_Inventory.Location = new System.Drawing.Point(5, 105);
            db.Button_inventoryReport.BringToFront();
            db.Button_inventoryReport.Location = new System.Drawing.Point(5, 185);
        }
        public void Assistant()
        {
            Dashboard db = new Dashboard();
            db.Show();
            db.Label_User.Text = "Assistant - " + username;
            db.panel_Patients.Visible = false;
            db.Separator3.Visible = false;
            db.Separator_app.Visible = false;
            db.Button_Appointments.Visible = false;
            db.Separator_app.Visible = false;
            db.Separator_IPH.Visible = false;
            db.Button_internalPatient.Visible = false;
            db.panel_doctors.Visible = false;
            db.Button_Payments.Visible = false;
            db.Button_amount.Visible = false;
            db.Button_calculateBill.Visible = false;
            db.Separator_amo.Visible = false;
            db.Separator_MH.Visible = false;
            db.Separator_IPH.Visible = false;
            db.Separator_pay.Visible = false;
            db.Button_UpdateInternal.Visible = false;
            db.Button_charts.Visible = false;
            db.Button_appointmentHistory.Visible = false;

            db.Button_addDiagnosisDetails.BringToFront();
            db.Button_addDiagnosisDetails.Location = new System.Drawing.Point(5, 107);
        }
    }
}
