﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MssCorsework
{
    public partial class appointmentControl : UserControl
    {
        public bool isCollapsed;

        public appointmentControl()
        {
            InitializeComponent();
        }

        SQLQueries sqlq = new SQLQueries();

        private void Button_Type_Click(object sender, EventArgs e)
        {
            timer1.Start();
            try
            {
                this.tableDoctorsTableAdapter.searchDoctors(this.mSSDBDataSet.TableDoctors, Button_Type.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            if (isCollapsed)
            {
                panel_DocType.Height += 10;
                if (panel_DocType.Size == panel_DocType.MaximumSize)
                {
                    timer1.Stop();
                    isCollapsed = false;
                }
            }
            else
            {
                panel_DocType.Height -= 10;
                if (panel_DocType.Size == panel_DocType.MinimumSize)
                {
                    timer1.Stop();
                    isCollapsed = true;
                }
            }
        }

        private void Btn_Type1_Click(object sender, EventArgs e)
        {
            Button_Type.Text = "Cardiologist";
            Button_Type.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
        }

        private void Btn_Type2_Click(object sender, EventArgs e)
        {
            Button_Type.Text = "Family Physician";
            Button_Type.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
        }

        private void Btn_Type3_Click(object sender, EventArgs e)
        {
            Button_Type.Text = "Ophthalmologist";
            Button_Type.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
        }

        private void Btn_Type4_Click(object sender, EventArgs e)
        {
            Button_Type.Text = "Surgeon";
            Button_Type.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
        }

        private void Datepicker_aTime_MouseDown(object sender, MouseEventArgs e)
        {
            Datepicker_aTime.CustomFormat = "HH:mm";
        }

        private void Datepicker_aTime_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape || e.KeyCode == Keys.Delete || e.KeyCode == Keys.Back)
            {
                Datepicker_aTime.CustomFormat = " ";
            }
        }

        private void Button_Search_Click(object sender, EventArgs e)
        {
            string searchNIC = Textbox_SearchNIC.Text;

            if (Textbox_SearchNIC.Text == "")
            {
                label_ESearchNIC.Visible = true;
                label_ESearchNIC.Text = "Patient's NIC or Gurdian's NIC is Required!";
            }
            else
            {
                SqlDataReader dr = sqlq.patientDetails(searchNIC);
                if (dr.Read())
                {
                    label_ID.Text = dr[0].ToString();
                    Textbox_pName.Text = dr[1].ToString();
                }
                else
                {
                    MessageBox.Show("Invalid Patient's or Guardian's NIC", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void clear()
        {
            app_Number.Text = "";
            Textbox_SearchNIC.Text = "";
            Textbox_pName.Text = "";
            label_dName.Text = "";
            Textbox_NIC.Text = "";
            Datepicker_aDate.Text = "";
            Datepicker_aTime.Text = "";
            Datepicker_aTime1.Text = "";
        }

        private void Button_ADDAPP_Click(object sender, EventArgs e)
        {
            if (app_Number.Value == null)
            {
                label_Errors.Visible = true;
                label_Errors.Text = "Appointment Number is Required!";
            }
            else if (Textbox_pName.Text == "")
            {
                label_pEName.Visible = true;
                label_pEName.Text = "Patient's Name is Required!";
            }
            else if (Textbox_NIC.Text == "")
            {
                label_dENIC.Visible = true;
                label_dENIC.Text = "Doctor's NIC is Required!";
            }
            else if (Datepicker_aDate.Value == null)
            {
                label_EDate.Visible = true;
                label_EDate.Text = "Appointment Date is Required!";
            }
            else if (Datepicker_aTime.Value == null)
            {
                label_ETime.Visible = true;
                label_ETime.Text = "Appointment Time is Required!";
            }
            else if (Textbox_pName.Text == "" && Textbox_NIC.Text == "" && Datepicker_aDate.Value == null && Datepicker_aTime.Value == null)
            {
                label_Errors.Visible = true;
                label_Errors.Text = "Please Enter All Details!";
            }
            else
            {
                try
                {
                    int count = 15;
                    DateTime cDate = Datepicker_aDate.Value;//
                    string cTime = Datepicker_aTime.Text + " To " + Datepicker_aTime1.Text;

                    //Check Appointment Time Period
                    string doctorsDetail = "SELECT COUNT(dNIC) FROM TableAppointments WHERE aDate = '" + cDate + "' AND aTime = '" + cTime + "'";
                    SqlCommand com = new SqlCommand(doctorsDetail, MSSDBConnection.MSSConnection());
                    Int32 row_count = Convert.ToInt32(com.ExecuteScalar());
                    com.Dispose();
                    label_count.Text = row_count.ToString();


                    if (row_count >= count)
                    {
                        MessageBox.Show("Can't add appointment to this doctor", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        string pvNIC = Textbox_SearchNIC.Text;
                        DateTime avDate = Datepicker_aDate.Value;//

                        //Validate appointment date
                        string dateDetail = "SELECT COUNT(pNIC) FROM TableAppointments WHERE pNIC = '" + pvNIC + "' AND aDate = '" + avDate + "'";
                        SqlCommand com1 = new SqlCommand(dateDetail, MSSDBConnection.MSSConnection());
                        Int32 row_count1 = Convert.ToInt32(com1.ExecuteScalar());
                        com.Dispose();

                        if (row_count1 != 0)
                        {
                            MessageBox.Show("Can't add appointment to this Patient", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        {
                            string appNum = app_Number.Text;
                            string pNIC = Textbox_SearchNIC.Text;
                            string pName = Textbox_pName.Text;
                            string dName = label_dName.Text;
                            string dNIC = Textbox_NIC.Text;
                            DateTime appDate = Datepicker_aDate.Value.Date;//
                            string aTime = Datepicker_aTime.Text + " To " + Datepicker_aTime1.Text;
                            int charge = int.Parse(label_Charge.Text);
                            int doctorFee = int.Parse(label_doctorFee.Text);

                            //pass values for addAppointments query which include in SQLQueries class
                            sqlq.addAppointments(appNum, pNIC, pName, dName, dNIC, appDate, aTime, charge, doctorFee);
                            Message1 pr = new Message1();
                            pr.label1.Text = "Appointment Added Successfully!";
                            pr.label1.Location = new System.Drawing.Point(50, 200);
                            pr.Show();
                            this.clear();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Please Check The Values" + ex, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void Textbox_pName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_pName.Text != "")
            {
                label_pEName.Visible = false;
                label_Errors.Visible = false;
            }

            //allow only characters values for textbox
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar) && e.KeyChar != '.')
            {
                e.Handled = true;
            }
        }

        private void Textbox_NIC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_NIC.Text != "")
            {
                label_dENIC.Visible = false;
                label_Errors.Visible = false;
            }
        }

        private void Datepicker_aDate_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Datepicker_aDate.Value != null)
            {
                label_EDate.Visible = false;
                label_Errors.Visible = false;
            }
        }

        private void Datepicker_aTime_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Datepicker_aTime.Value != null)
            {
                label_ETime.Visible = false;
                label_Errors.Visible = false;
            }
        }

        private void Textbox_SearchNIC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_SearchNIC.Text != "")
            {
                label_ESearchNIC.Visible = false;
                label_Errors.Visible = false;
            }
        }

        private void SearchDoctorsToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.tableDoctorsTableAdapter.searchDoctors(this.mSSDBDataSet.TableDoctors, dTypeToolStripTextBox.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
        }

        private void DataGrid1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if(e.RowIndex >= 0)
            {
                DataGridViewRow row = this.DataGrid1.Rows[e.RowIndex];
                label_dName.Text = row.Cells["dName"].Value.ToString();
                Textbox_NIC.Text = row.Cells["dNIC"].Value.ToString();
            }
        }

        private void Datepicker_aDate_Leave(object sender, EventArgs e)
        {
            //Date validation - User can't input a past data for appontment date
            if (Datepicker_aDate.Value <= System.DateTime.Today)
            {
                MessageBox.Show("Can't input a past data for appontment date", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void DataGrid1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.DataGrid1.Rows[e.RowIndex];
                label_dName.Text = row.Cells["dName"].Value.ToString();
                Textbox_NIC.Text = row.Cells["dNIC"].Value.ToString();
            }
        }

        private void Datepicker_aTime1_MouseDown(object sender, MouseEventArgs e)
        {
            Datepicker_aTime1.CustomFormat = "HH:mm";
        }

        private void Datepicker_aTime1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Datepicker_aTime1.Value != null)
            {
                label_ETime.Visible = false;
                label_Errors.Visible = false;
            }
        }

        private void Datepicker_aTime1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape || e.KeyCode == Keys.Delete || e.KeyCode == Keys.Back)
            {
                Datepicker_aTime1.CustomFormat = " ";
            }
        }

        private void App_Number_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (app_Number.Value != null)
            {
                label_Errors.Visible = false;
            }
        }

        private void Datepicker_aDate_MouseDown(object sender, MouseEventArgs e)
        {
            Datepicker_aDate.CustomFormat = "MM/dd/yyyy";
        }
    }
}
