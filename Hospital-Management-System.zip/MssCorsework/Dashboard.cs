﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MssCorsework
{
    public partial class Dashboard : Form
    {
        public bool isCollapsed;
        public bool isCollapsed1;

        public Dashboard()
        {
            InitializeComponent();
        }

        private void Btn_close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Btn_minimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void Button_hideMenu_Click(object sender, EventArgs e)
        {
            panel_left.Width = 60;
            menuTransition.ShowSync(panel_left);
            Separator1.Visible = false;
            Separator2.Visible = false;
            Separator3.Visible = false;
            Button_showMenu.Visible = true;
        }

        private void Button_showMenu_Click(object sender, EventArgs e)
        {
            panel_left.Width = 267;
            menuTransition.ShowSync(panel_left);
            Separator1.Visible = true;
            Separator2.Visible = true;
            Separator3.Visible = true;
            Button_showMenu.Visible = false;
        }

        private void BunifuThinButton21_Click(object sender, EventArgs e)
        {
            LoginCreate lc = new LoginCreate();
            lc.Show();
            this.Close();
        }

        private void Timer_time_Tick(object sender, EventArgs e)
        {
            label_Date.Text = DateTime.Now.ToLongTimeString();
            timer_time.Start();
        }

        private void Dashboard_Load(object sender, EventArgs e)
        {
            //Set date and time for labels
            timer_time.Start();
            label_Date.Text = DateTime.Now.ToLongTimeString();
            label_time.Text = DateTime.Now.ToLongDateString();
        }

        private void Button_mangePationDetails_Click(object sender, EventArgs e)
        {
            timer1.Start();
            panel_doctors.SendToBack();
            panel_Patients.BringToFront();
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            if (isCollapsed)
            {
                panel_Patients.Height += 10;
                if (panel_Patients.Size == panel_Patients.MaximumSize)
                {
                    timer1.Stop();
                    isCollapsed = false;
                }
            }
            else
            {
                panel_Patients.Height -= 10;
                if (panel_Patients.Size == panel_Patients.MinimumSize)
                {
                    timer1.Stop();
                    isCollapsed = true;
                }
            }
        }

        private void Button_add_Click(object sender, EventArgs e)
        {
            addPatientControl1.BringToFront();
        }

        private void Button_Update_Click(object sender, EventArgs e)
        {
            updatePatientControl1.BringToFront();
        }

        private void Button_Appointments_Click(object sender, EventArgs e)
        {
            appointmentControl1.BringToFront();
        }

        private void Timer2_Tick(object sender, EventArgs e)
        {
            if (isCollapsed1)
            {
                panel_doctors.Height += 10;
                if (panel_doctors.Size == panel_doctors.MaximumSize)
                {
                    timer2.Stop();
                    isCollapsed1 = false;
                }
            }
            else
            {
                panel_doctors.Height -= 10;
                if (panel_doctors.Size == panel_doctors.MinimumSize)
                {
                    timer2.Stop();
                    isCollapsed1 = true;
                }
            }
        }

        private void Btn_addDoctor_Click(object sender, EventArgs e)
        {
            addDoctorsControl1.BringToFront();
        }

        private void Button_ManageDoctorsDetails_Click(object sender, EventArgs e)
        {
            timer2.Start();
            panel_Patients.SendToBack();
            panel_doctors.BringToFront();
        }

        private void Btn_updateDoctors_Click(object sender, EventArgs e)
        {
            updateDoctorsControl1.BringToFront();
        }

        private void Button_Payments_Click(object sender, EventArgs e)
        {
            paymentControl1.BringToFront();
        }

        private void Button_amount_Click(object sender, EventArgs e)
        {
            caculateAmountControl1.BringToFront();
        }

        private void Button_manageHistory_Click(object sender, EventArgs e)
        {
            calculateBillControl1.BringToFront();
        }

        private void Button_ReviewDiagnosis_Click(object sender, EventArgs e)
        {
            patientHistoryManagementControl1.BringToFront();
        }

        private void Button_internalPatient_Click(object sender, EventArgs e)
        {
            internalPatientsControl1.BringToFront();
        }

        private void Button_UpdateInternal_Click(object sender, EventArgs e)
        {
            updateInternalPatientsControl1.BringToFront();
        }

        private void Button_charts_Click(object sender, EventArgs e)
        {
            chartsControl1.BringToFront();
        }

        private void Button_appointmentHistory_Click(object sender, EventArgs e)
        {
            appointmentHistoryControl1.BringToFront();
        }
    }
}
