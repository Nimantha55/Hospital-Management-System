﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MssCorsework
{
    public partial class UpdatePatientControl : UserControl
    {
        public bool isCollapsed;

        public UpdatePatientControl()
        {
            InitializeComponent();
        }

        SQLQueries sqlq = new SQLQueries();

        private void Button_Search_Click(object sender, EventArgs e)
        {
            string searchNIC = Textbox_SearchNIC.Text;

            if (Textbox_SearchNIC.Text == "")
            {
                label_ESearchNIC.Visible = true;
                label_ESearchNIC.Text = "Patient's NIC or Guardian's NIC is required!";
            }
            else
            {
                SqlDataReader dr = sqlq.patientDetails(searchNIC);
                if (dr.Read())
                {
                    Label_ID.Text = dr[0].ToString();
                    Textbox_pName.Text = dr[1].ToString();
                    Textbox_NIC.Text = dr[2].ToString();
                    Label_status.Text = dr[3].ToString();
                    Textbox_Address.Text = dr[4].ToString();
                    Textbox_Age.Text = dr[5].ToString();
                    Textbox_TelephoneNum.Text = dr[6].ToString();
                    Button_Gender.Text = dr[7].ToString();
                }
                else
                {
                    MessageBox.Show("Invalid Patient's or Guardian's NIC", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            if (isCollapsed)
            {
                panel_uGender.Height += 10;
                if (panel_uGender.Size == panel_uGender.MaximumSize)
                {
                    timer1.Stop();
                    isCollapsed = false;
                }
            }
            else
            {
                panel_uGender.Height -= 10;
                if (panel_uGender.Size == panel_uGender.MinimumSize)
                {
                    timer1.Stop();
                    isCollapsed = true;
                }
            }
        }

        private void Btn_Male_Click(object sender, EventArgs e)
        {
            Button_Gender.Text = "Male";
            if (label_pEGender.Visible == true)
            {
                label_pEGender.Visible = false;
                label_Errors.Visible = false;
            }
        }

        private void Btn_Female_Click(object sender, EventArgs e)
        {
            Button_Gender.Text = "Female";
            if (label_pEGender.Visible == true)
            {
                label_pEGender.Visible = false;
                label_Errors.Visible = false;
            }
        }

        private void Button_Gender_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void clear()
        {
            Textbox_SearchNIC.Text = "";
            Textbox_pName.Text = "";
            Textbox_NIC.Text = "";
            Textbox_GuardianNIC.Text = "";
            Textbox_TelephoneNum.Text = "";
            Textbox_Address.Text = "";
            Textbox_Age.Text = "";
            Button_Gender.Text = "Gender";
        }

        private void Button_Clear_Click(object sender, EventArgs e)
        {
            this.clear();
        }

        private void Button_Update_Click(object sender, EventArgs e)
        {
            if (Textbox_pName.Text == "" && Textbox_NIC.Text == "" && Textbox_GuardianNIC.Text == "" && Textbox_TelephoneNum.Text == "" && Textbox_Address.Text == "" && Textbox_Age.Text == "" && Button_Gender.Text == "Gender")
            {
                label_Errors.Visible = true;
                label_Errors.Text = "Please Enter All Details!";
            }
            else if (Textbox_pName.Text == "")
            {
                label_pEName.Visible = true;
                label_pEName.Text = "Patient's Name is Required!";
            }
            else if (Textbox_NIC.Text == "")
            {
                label_pENIC.Visible = true;
                label_pENIC.Text = "Patient's NIC is Required!";
            }
            else if (Textbox_TelephoneNum.Text == "")
            {
                label_pETelephoneNum.Visible = true;
                label_pETelephoneNum.Text = "Patient's Telephone Number is Required!";
            }
            else if (Textbox_Address.Text == "")
            {
                label_pEAddress.Visible = true;
                label_pEAddress.Text = "Patient's Address is Required!";
            }
            else if (Textbox_Age.Text == "")
            {
                label_pEAge.Visible = true;
                label_pEAge.Text = "Patient's Age is Required!";
            }
            else if (Button_Gender.Text == "Gender")
            {
                label_pEGender.Visible = true;
                label_pEGender.Text = "Patient's Gender is Required!";
            }
            else
            {
                try
                {
                    int ID = int.Parse(Label_ID.Text);
                    string pname = Textbox_pName.Text;
                    string pNIC = Textbox_NIC.Text;
                    string pnicStstus = Label_status.Text;
                    string paddress = Textbox_Address.Text;
                    int pAge = int.Parse(Textbox_Age.Text);
                    string pTelNO = Textbox_TelephoneNum.Text;
                    string pGender = Button_Gender.Text;

                    //pass values for updatePatientDetails query which include in SQLQueries class
                    sqlq.updatePatientDetails(pname, pNIC, pnicStstus, paddress, pAge, pTelNO, pGender, ID);
                    Message1 pr = new Message1();
                    pr.label1.Text = "Patient's Details updated Successfully!";
                    pr.label1.Location = new System.Drawing.Point(32, 200);
                    pr.Show();
                    this.clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Please Check The Values" + ex, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void Checkbox1_OnChange(object sender, EventArgs e)
        {
            if (Checkbox1.Checked == true)
            {
                Label_status.Text = "Guardian NIC";
            }
            else
            {
                Label_status.Text = "Normal";
                Checkbox1.Checked = false;
            }
        }

        private void Textbox_pName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_pName.Text != "")
            {
                label_pEName.Visible = false;
                label_Errors.Visible = false;
            }

            //allow only characters values for textbox
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar) && e.KeyChar != '.')
            {
                e.Handled = true;
            }
        }

        private void Textbox_NIC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_NIC.Text != "")
            {
                label_pENIC.Visible = false;
                label_Errors.Visible = false;
            }
        }

        private void Textbox_Address_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_Address.Text != "")
            {
                label_pEAddress.Visible = false;
                label_Errors.Visible = false;
            }
        }

        private void Textbox_Age_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_Age.Text != "")
            {
                label_pEAge.Visible = false;
                label_Errors.Visible = false;
            }

            //allow only numaric values for contact number
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 32)
            {
                e.Handled = true;
            }
        }

        private void Textbox_TelephoneNum_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_TelephoneNum.Text != "")
            {
                label_pETelephoneNum.Visible = false;
                label_Errors.Visible = false;
            }

            //allow only numaric values for contact number
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 32 && e.KeyChar != '+')
            {
                e.Handled = true;
            }
        }

        private void Textbox_SearchNIC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_SearchNIC.Text != "")
            {
                label_ESearchNIC.Visible = false;
                label_Errors.Visible = false;
            }
        }
    }
}
