﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MssCorsework
{
    public partial class PaymentControl : UserControl
    {
        public PaymentControl()
        {
            InitializeComponent();
        }

        SQLQueries sqlq = new SQLQueries();
        labReportViewer lrv = new labReportViewer();

        private void Btn_result_Click(object sender, EventArgs e)
        {
            if (Textbox_dFee.Text == "")
            {
                label_deFee.Visible = true;
                label_deFee.Text = "Doctor Fee is Required!";
            }
            else if (Textbox_hCharge.Text == "")
            {
                label_heCharge.Visible = true;
                label_heCharge.Text = "Hospital Charge is Required!";
            }
            else if (Textbox_aTax.Text == "")
            {
                label_aeTax.Visible = true;
                label_aeTax.Text = "Appointment Tax is Required!";
            }
            else
            {
                int value1 = int.Parse(Textbox_dFee.Text);
                int value2 = int.Parse(Textbox_hCharge.Text);
                int value3 = int.Parse(Textbox_aTax.Text);

                //Find Total Charge
                int result = value1 + value2 + value3;
                Textbox_charge.Text = result.ToString();
            }
        }

        private void Textbox_dFee_KeyPress(object sender, KeyPressEventArgs e)
        {
            //allow only numaric values for contact number
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 32)
            {
                e.Handled = true;
            }

            if (Textbox_dFee.Text != "")
            {
                label_deFee.Visible = false;
            }
            else if (Textbox_hCharge.Text != "")
            {
                label_heCharge.Visible = false;
            }
            else if(Textbox_aTax.Text != "")
            {
                label_aeTax.Visible = false;
            }
        }

        private void Button_Search_Click(object sender, EventArgs e)
        {
            if (Textbox_SearchNIC.Text == "")
            {
                label_ESearchNIC.Visible = true;
                label_ESearchNIC.Text = "Patient's NIC or Gurdian's NIC is Required!";
            }
            else if (Datepicker_aDate.Value == null)
            {
                label_EDate.Visible = true;
                label_EDate.Text = "Appointment Date is Required!";
            }

            string pNIC = Textbox_SearchNIC.Text;
            DateTime aDate = Datepicker_aDate.Value;//

            SqlDataReader dr = sqlq.appointmentDetails(pNIC, aDate);
            if (dr.Read())
            {
                label_ID.Text = dr[0].ToString();
                Textbox_appointmentNumber.Text = dr[1].ToString();
                Textbox_pName.Text = dr[3].ToString();
                Textbox_doctorName.Text = dr[4].ToString();
                Textbox_NIC.Text = dr[5].ToString();
            }
            else
            {
                MessageBox.Show("Invalid NIC or Date!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Textbox_SearchNIC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_SearchNIC.Text != "")
            {
                label_ESearchNIC.Visible = false;
                label_Errors.Visible = false;
            }
        }

        private void Datepicker_aDate_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Datepicker_aDate.Value != null)
            {
                label_EDate.Visible = false;
                label_Errors.Visible = false;
            }
        }

        private void clear()
        {
            Textbox_SearchNIC.Text = "";
            Datepicker_aDate.Text = "";
            Textbox_appointmentNumber.Text = "";
            Textbox_pName.Text = "";
            Textbox_doctorName.Text = "";
            Textbox_NIC.Text = "";
            Textbox_dFee.Text = "";
            Textbox_hCharge.Text = "";
            Textbox_aTax.Text = "";
            Textbox_charge.Text = "";
        }

        private void Button_SavePayment_Click(object sender, EventArgs e)
        {
            if (Textbox_SearchNIC.Text == "" || Datepicker_aDate.Value == null || Textbox_dFee.Text == "" || Textbox_hCharge.Text == "" || Textbox_aTax.Text == "")
            {
                MessageBox.Show("Please fill all details!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    int charge = int.Parse(Textbox_charge.Text);
                    int dFee = int.Parse(Textbox_dFee.Text);
                    int ID = int.Parse(label_ID.Text);

                    //pass values for updateAppointment query which include in SQLQueries class
                    sqlq.updateAppointment(charge, dFee, ID);
                    Message1 pr = new Message1();
                    pr.label1.Text = "Payment Details saved Successfully!";
                    pr.label1.Location = new System.Drawing.Point(38, 200);
                    pr.Show();
                    this.clear();
                }
                catch(Exception ex)
                {
                    MessageBox.Show("Please Check The Values" + ex, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void Button_bill_Click(object sender, EventArgs e)
        {
            string pNIC = Textbox_SearchNIC.Text;
            DateTime aDate = Datepicker_aDate.Value;

            if (Textbox_SearchNIC.Text == "")
            {
                label_ESearchNIC.Visible = true;
                label_ESearchNIC.Text = "Patient's NIC or Gurdian's NIC is Required!";
            }
            else if (Datepicker_aDate.Value == null)
            {
                label_EDate.Visible = true;
                label_EDate.Text = "Appointment Date is Required!";
            }
            else
            {
                Receipt lr = new Receipt();
                SqlConnection con = new SqlConnection();
                con = MSSDBConnection.MSSConnection();
                string labReport = "SELECT * FROM TableAppointments WHERE pNIC = '" + pNIC + "' AND aDate = '" + aDate + "'";
                DataSet ds = new DataSet();
                SqlDataAdapter sda = new SqlDataAdapter(labReport, con);
                sda.Fill(ds, "TableAppointments");

                lr.SetDataSource(ds.Tables["TableAppointments"]);
                lrv.crystalReportViewer1.ReportSource = lr;
                lrv.crystalReportViewer1.Refresh();
                lrv.Show();
            }
        }
    }
}
