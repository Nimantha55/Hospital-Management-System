﻿namespace MssCorsework
{
    partial class LoginCreate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LoginCreate));
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.panel_top = new System.Windows.Forms.Panel();
            this.bunifuImageButton1 = new Bunifu.Framework.UI.BunifuImageButton();
            this.btn_close = new Bunifu.Framework.UI.BunifuImageButton();
            this.btn_minimize = new Bunifu.Framework.UI.BunifuImageButton();
            this.LoginCreatedragControl = new Project_SDC.DragControl();
            this.Panel_content = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.btn_Start = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn_CreateAccount = new Bunifu.Framework.UI.BunifuThinButton2();
            this.btn_loginResponse = new Bunifu.Framework.UI.BunifuThinButton2();
            this.bunifuThinButton21 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.introControl1 = new MssCorsework.IntroControl();
            this.loginControl1 = new MssCorsework.LoginControl();
            this.registrationControl1 = new MssCorsework.RegistrationControl();
            this.panel_top.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_minimize)).BeginInit();
            this.Panel_content.SuspendLayout();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 0;
            this.bunifuElipse1.TargetControl = this;
            // 
            // panel_top
            // 
            this.panel_top.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(20)))), ((int)(((byte)(20)))), ((int)(((byte)(20)))));
            this.panel_top.Controls.Add(this.bunifuImageButton1);
            this.panel_top.Controls.Add(this.btn_close);
            this.panel_top.Controls.Add(this.btn_minimize);
            this.panel_top.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_top.Location = new System.Drawing.Point(0, 0);
            this.panel_top.Name = "panel_top";
            this.panel_top.Size = new System.Drawing.Size(1494, 58);
            this.panel_top.TabIndex = 1;
            // 
            // bunifuImageButton1
            // 
            this.bunifuImageButton1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuImageButton1.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton1.Image")));
            this.bunifuImageButton1.ImageActive = null;
            this.bunifuImageButton1.Location = new System.Drawing.Point(9, 10);
            this.bunifuImageButton1.Name = "bunifuImageButton1";
            this.bunifuImageButton1.Size = new System.Drawing.Size(40, 40);
            this.bunifuImageButton1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bunifuImageButton1.TabIndex = 9;
            this.bunifuImageButton1.TabStop = false;
            this.bunifuImageButton1.Zoom = 10;
            this.bunifuImageButton1.Click += new System.EventHandler(this.BunifuImageButton1_Click);
            // 
            // btn_close
            // 
            this.btn_close.BackColor = System.Drawing.Color.Transparent;
            this.btn_close.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_close.Image = ((System.Drawing.Image)(resources.GetObject("btn_close.Image")));
            this.btn_close.ImageActive = null;
            this.btn_close.Location = new System.Drawing.Point(1444, 10);
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(40, 40);
            this.btn_close.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btn_close.TabIndex = 0;
            this.btn_close.TabStop = false;
            this.btn_close.Zoom = 10;
            this.btn_close.Click += new System.EventHandler(this.Btn_close_Click);
            // 
            // btn_minimize
            // 
            this.btn_minimize.BackColor = System.Drawing.Color.Transparent;
            this.btn_minimize.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_minimize.Image = ((System.Drawing.Image)(resources.GetObject("btn_minimize.Image")));
            this.btn_minimize.ImageActive = null;
            this.btn_minimize.Location = new System.Drawing.Point(1403, 10);
            this.btn_minimize.Name = "btn_minimize";
            this.btn_minimize.Size = new System.Drawing.Size(40, 40);
            this.btn_minimize.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btn_minimize.TabIndex = 1;
            this.btn_minimize.TabStop = false;
            this.btn_minimize.Zoom = 10;
            this.btn_minimize.Click += new System.EventHandler(this.Btn_minimize_Click);
            // 
            // LoginCreatedragControl
            // 
            this.LoginCreatedragControl.SelectControl = this.Panel_content;
            // 
            // Panel_content
            // 
            this.Panel_content.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Panel_content.BackgroundImage")));
            this.Panel_content.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Panel_content.Controls.Add(this.btn_Start);
            this.Panel_content.Controls.Add(this.btn_CreateAccount);
            this.Panel_content.Controls.Add(this.btn_loginResponse);
            this.Panel_content.Controls.Add(this.bunifuThinButton21);
            this.Panel_content.Dock = System.Windows.Forms.DockStyle.Top;
            this.Panel_content.GradientBottomLeft = System.Drawing.Color.SlateGray;
            this.Panel_content.GradientBottomRight = System.Drawing.Color.Black;
            this.Panel_content.GradientTopLeft = System.Drawing.Color.Black;
            this.Panel_content.GradientTopRight = System.Drawing.Color.Black;
            this.Panel_content.Location = new System.Drawing.Point(0, 58);
            this.Panel_content.Name = "Panel_content";
            this.Panel_content.Quality = 10;
            this.Panel_content.Size = new System.Drawing.Size(1494, 148);
            this.Panel_content.TabIndex = 2;
            // 
            // btn_Start
            // 
            this.btn_Start.ActiveBorderThickness = 1;
            this.btn_Start.ActiveCornerRadius = 10;
            this.btn_Start.ActiveFillColor = System.Drawing.Color.Transparent;
            this.btn_Start.ActiveForecolor = System.Drawing.Color.ForestGreen;
            this.btn_Start.ActiveLineColor = System.Drawing.Color.ForestGreen;
            this.btn_Start.AutoValidate = System.Windows.Forms.AutoValidate.Disable;
            this.btn_Start.BackColor = System.Drawing.Color.Transparent;
            this.btn_Start.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_Start.BackgroundImage")));
            this.btn_Start.ButtonText = "Login";
            this.btn_Start.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Start.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Start.ForeColor = System.Drawing.Color.White;
            this.btn_Start.IdleBorderThickness = 1;
            this.btn_Start.IdleCornerRadius = 10;
            this.btn_Start.IdleFillColor = System.Drawing.Color.Transparent;
            this.btn_Start.IdleForecolor = System.Drawing.Color.White;
            this.btn_Start.IdleLineColor = System.Drawing.Color.White;
            this.btn_Start.Location = new System.Drawing.Point(781, 39);
            this.btn_Start.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btn_Start.Name = "btn_Start";
            this.btn_Start.Size = new System.Drawing.Size(312, 72);
            this.btn_Start.TabIndex = 6;
            this.btn_Start.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Start.Click += new System.EventHandler(this.Btn_Start_Click);
            // 
            // btn_CreateAccount
            // 
            this.btn_CreateAccount.ActiveBorderThickness = 1;
            this.btn_CreateAccount.ActiveCornerRadius = 10;
            this.btn_CreateAccount.ActiveFillColor = System.Drawing.Color.Transparent;
            this.btn_CreateAccount.ActiveForecolor = System.Drawing.Color.DarkMagenta;
            this.btn_CreateAccount.ActiveLineColor = System.Drawing.Color.DarkMagenta;
            this.btn_CreateAccount.AutoValidate = System.Windows.Forms.AutoValidate.Disable;
            this.btn_CreateAccount.BackColor = System.Drawing.Color.Transparent;
            this.btn_CreateAccount.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_CreateAccount.BackgroundImage")));
            this.btn_CreateAccount.ButtonText = "Create Account";
            this.btn_CreateAccount.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_CreateAccount.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_CreateAccount.ForeColor = System.Drawing.Color.White;
            this.btn_CreateAccount.IdleBorderThickness = 1;
            this.btn_CreateAccount.IdleCornerRadius = 10;
            this.btn_CreateAccount.IdleFillColor = System.Drawing.Color.Transparent;
            this.btn_CreateAccount.IdleForecolor = System.Drawing.Color.White;
            this.btn_CreateAccount.IdleLineColor = System.Drawing.Color.White;
            this.btn_CreateAccount.Location = new System.Drawing.Point(397, 39);
            this.btn_CreateAccount.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btn_CreateAccount.Name = "btn_CreateAccount";
            this.btn_CreateAccount.Size = new System.Drawing.Size(312, 72);
            this.btn_CreateAccount.TabIndex = 5;
            this.btn_CreateAccount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_CreateAccount.Click += new System.EventHandler(this.Btn_CreateAccount_Click);
            // 
            // btn_loginResponse
            // 
            this.btn_loginResponse.ActiveBorderThickness = 1;
            this.btn_loginResponse.ActiveCornerRadius = 10;
            this.btn_loginResponse.ActiveFillColor = System.Drawing.Color.Transparent;
            this.btn_loginResponse.ActiveForecolor = System.Drawing.Color.Green;
            this.btn_loginResponse.ActiveLineColor = System.Drawing.Color.Green;
            this.btn_loginResponse.BackColor = System.Drawing.SystemColors.Control;
            this.btn_loginResponse.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_loginResponse.BackgroundImage")));
            this.btn_loginResponse.ButtonText = "Login";
            this.btn_loginResponse.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_loginResponse.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_loginResponse.ForeColor = System.Drawing.Color.White;
            this.btn_loginResponse.IdleBorderThickness = 1;
            this.btn_loginResponse.IdleCornerRadius = 10;
            this.btn_loginResponse.IdleFillColor = System.Drawing.Color.Transparent;
            this.btn_loginResponse.IdleForecolor = System.Drawing.Color.LimeGreen;
            this.btn_loginResponse.IdleLineColor = System.Drawing.Color.LimeGreen;
            this.btn_loginResponse.Location = new System.Drawing.Point(781, 39);
            this.btn_loginResponse.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btn_loginResponse.Name = "btn_loginResponse";
            this.btn_loginResponse.Size = new System.Drawing.Size(312, 72);
            this.btn_loginResponse.TabIndex = 7;
            this.btn_loginResponse.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bunifuThinButton21
            // 
            this.bunifuThinButton21.ActiveBorderThickness = 1;
            this.bunifuThinButton21.ActiveCornerRadius = 10;
            this.bunifuThinButton21.ActiveFillColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton21.ActiveForecolor = System.Drawing.Color.BlueViolet;
            this.bunifuThinButton21.ActiveLineColor = System.Drawing.Color.BlueViolet;
            this.bunifuThinButton21.BackColor = System.Drawing.SystemColors.Control;
            this.bunifuThinButton21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton21.BackgroundImage")));
            this.bunifuThinButton21.ButtonText = "Create Account";
            this.bunifuThinButton21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuThinButton21.Font = new System.Drawing.Font("Century Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton21.ForeColor = System.Drawing.Color.White;
            this.bunifuThinButton21.IdleBorderThickness = 1;
            this.bunifuThinButton21.IdleCornerRadius = 10;
            this.bunifuThinButton21.IdleFillColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton21.IdleForecolor = System.Drawing.Color.DarkViolet;
            this.bunifuThinButton21.IdleLineColor = System.Drawing.Color.DarkViolet;
            this.bunifuThinButton21.Location = new System.Drawing.Point(397, 39);
            this.bunifuThinButton21.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.bunifuThinButton21.Name = "bunifuThinButton21";
            this.bunifuThinButton21.Size = new System.Drawing.Size(312, 72);
            this.bunifuThinButton21.TabIndex = 8;
            this.bunifuThinButton21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // introControl1
            // 
            this.introControl1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.introControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.introControl1.Location = new System.Drawing.Point(0, 206);
            this.introControl1.Name = "introControl1";
            this.introControl1.Size = new System.Drawing.Size(1494, 660);
            this.introControl1.TabIndex = 3;
            // 
            // loginControl1
            // 
            this.loginControl1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.loginControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.loginControl1.Location = new System.Drawing.Point(0, 0);
            this.loginControl1.Name = "loginControl1";
            this.loginControl1.Size = new System.Drawing.Size(1494, 866);
            this.loginControl1.TabIndex = 4;
            // 
            // registrationControl1
            // 
            this.registrationControl1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.registrationControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.registrationControl1.Location = new System.Drawing.Point(0, 0);
            this.registrationControl1.Name = "registrationControl1";
            this.registrationControl1.Size = new System.Drawing.Size(1494, 866);
            this.registrationControl1.TabIndex = 5;
            // 
            // LoginCreate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1494, 866);
            this.Controls.Add(this.introControl1);
            this.Controls.Add(this.Panel_content);
            this.Controls.Add(this.panel_top);
            this.Controls.Add(this.loginControl1);
            this.Controls.Add(this.registrationControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "LoginCreate";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LoginCreate";
            this.panel_top.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_minimize)).EndInit();
            this.Panel_content.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.Panel panel_top;
        private Bunifu.Framework.UI.BunifuImageButton btn_close;
        private Bunifu.Framework.UI.BunifuImageButton btn_minimize;
        private Project_SDC.DragControl LoginCreatedragControl;
        private Bunifu.Framework.UI.BunifuGradientPanel Panel_content;
        private Bunifu.Framework.UI.BunifuThinButton2 btn_CreateAccount;
        private IntroControl introControl1;
        private Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton21;
        public Bunifu.Framework.UI.BunifuThinButton2 btn_loginResponse;
        public Bunifu.Framework.UI.BunifuThinButton2 btn_Start;
        private LoginControl loginControl1;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton1;
        private RegistrationControl registrationControl1;
    }
}