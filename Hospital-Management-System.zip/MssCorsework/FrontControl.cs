﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MssCorsework
{
    public partial class FrontControl : UserControl
    {
        public FrontControl()
        {
            InitializeComponent();
        }

        private int imgNumber = 1;

        private void LoadNextImage()
        {
            if(imgNumber == 8)
            {
                imgNumber = 1;
            }
            sliderPic.ImageLocation = string.Format(@"Images\{0}.jpg", imgNumber);
            imgNumber++;
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            LoadNextImage();
        }
    }
}
