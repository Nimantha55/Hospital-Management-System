﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MssCorsework
{
    public partial class displayInventoryControl : UserControl
    {
        public displayInventoryControl()
        {
            InitializeComponent();
        }

        labReportViewer lrv = new labReportViewer();

        private void Button_Search_Click(object sender, EventArgs e)
        {
            if (Textbox_SearchNo.Text == "")
            {
                label_ESearchID.Visible = true;
                label_ESearchID.Text = "Patient's NIC is Required!";
            }
            else
            {
                string pNIC = Textbox_SearchNo.Text;
                DateTime date = Datepicker_aDate.Value;

                string query = "SELECT * FROM TableInventory WHERE pNIC = '" + pNIC + "' AND date = '" + date + "'";
                SqlDataAdapter sqlda = new SqlDataAdapter(query, MSSDBConnection.MSSConnection());
                DataTable dtb1 = new DataTable();
                sqlda.Fill(dtb1);

                DataGrid1.DataSource = dtb1;
            }
        }

        private void Button_Clear_Click(object sender, EventArgs e)
        {
            string pNIC = Textbox_SearchNo.Text;
            DateTime date = Datepicker_aDate.Value;

            InventoryReport lr = new InventoryReport();
            SqlConnection con = new SqlConnection();
            con = MSSDBConnection.MSSConnection();
            string query = "SELECT * FROM TableInventory WHERE pNIC = '" + pNIC + "' AND date = '" + date + "'";
            DataSet ds = new DataSet();
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            sda.Fill(ds, "TableInventory");

            lr.SetDataSource(ds.Tables["TableInventory"]);
            lrv.crystalReportViewer1.ReportSource = lr;
            lrv.crystalReportViewer1.Refresh();
            lrv.Show();
        }

        private void Textbox_SearchNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(Textbox_SearchNo.Text != "")
            {
                label_ESearchID.Visible = false;
            }
        }
    }
}
