﻿namespace MssCorsework
{
    partial class viewLabReportsControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(viewLabReportsControl));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.bunifuGradientPanel1 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.Button_Clear = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Label_Title = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.label_ESearchID = new System.Windows.Forms.Label();
            this.bunifuSeparator7 = new Bunifu.Framework.UI.BunifuSeparator();
            this.Button_Search = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Label_SearchNIC = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Textbox_SearchNo = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.DataGrid1 = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.reportToolStrip = new System.Windows.Forms.ToolStrip();
            this.repNoToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.repNoToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.reportToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.repNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.typeofReportDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.resultsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sampleRDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sampleTDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.techRemarkDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.softCopyLinkDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tableLabReportsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mSSDBDataSet1 = new MssCorsework.MSSDBDataSet1();
            this.tableLabReportsTableAdapter = new MssCorsework.MSSDBDataSet1TableAdapters.TableLabReportsTableAdapter();
            this.bunifuGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGrid1)).BeginInit();
            this.reportToolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tableLabReportsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mSSDBDataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.Controls.Add(this.DataGrid1);
            this.bunifuGradientPanel1.Controls.Add(this.label_ESearchID);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuSeparator7);
            this.bunifuGradientPanel1.Controls.Add(this.Button_Search);
            this.bunifuGradientPanel1.Controls.Add(this.Label_SearchNIC);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_SearchNo);
            this.bunifuGradientPanel1.Controls.Add(this.Button_Clear);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Title);
            this.bunifuGradientPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.Black;
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.Gray;
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(1140, 812);
            this.bunifuGradientPanel1.TabIndex = 3;
            // 
            // Button_Clear
            // 
            this.Button_Clear.Activecolor = System.Drawing.Color.Crimson;
            this.Button_Clear.BackColor = System.Drawing.Color.Crimson;
            this.Button_Clear.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_Clear.BorderRadius = 0;
            this.Button_Clear.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Button_Clear.ButtonText = "CREATE LAB REPORT";
            this.Button_Clear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_Clear.DisabledColor = System.Drawing.Color.Gray;
            this.Button_Clear.ForeColor = System.Drawing.Color.White;
            this.Button_Clear.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_Clear.Iconimage = null;
            this.Button_Clear.Iconimage_right = null;
            this.Button_Clear.Iconimage_right_Selected = null;
            this.Button_Clear.Iconimage_Selected = null;
            this.Button_Clear.IconMarginLeft = 0;
            this.Button_Clear.IconMarginRight = 0;
            this.Button_Clear.IconRightVisible = true;
            this.Button_Clear.IconRightZoom = 0D;
            this.Button_Clear.IconVisible = true;
            this.Button_Clear.IconZoom = 90D;
            this.Button_Clear.IsTab = false;
            this.Button_Clear.Location = new System.Drawing.Point(337, 652);
            this.Button_Clear.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_Clear.Name = "Button_Clear";
            this.Button_Clear.Normalcolor = System.Drawing.Color.Crimson;
            this.Button_Clear.OnHovercolor = System.Drawing.Color.Transparent;
            this.Button_Clear.OnHoverTextColor = System.Drawing.Color.Black;
            this.Button_Clear.selected = false;
            this.Button_Clear.Size = new System.Drawing.Size(480, 64);
            this.Button_Clear.TabIndex = 58;
            this.Button_Clear.Text = "CREATE LAB REPORT";
            this.Button_Clear.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_Clear.Textcolor = System.Drawing.Color.White;
            this.Button_Clear.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Clear.Click += new System.EventHandler(this.Button_Clear_Click);
            // 
            // Label_Title
            // 
            this.Label_Title.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Title.AutoSize = true;
            this.Label_Title.BackColor = System.Drawing.Color.Transparent;
            this.Label_Title.Font = new System.Drawing.Font("Felix Titling", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Title.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.Label_Title.Location = new System.Drawing.Point(405, 45);
            this.Label_Title.Name = "Label_Title";
            this.Label_Title.Size = new System.Drawing.Size(344, 35);
            this.Label_Title.TabIndex = 18;
            this.Label_Title.Text = "Create Lab Report";
            // 
            // label_ESearchID
            // 
            this.label_ESearchID.AutoSize = true;
            this.label_ESearchID.BackColor = System.Drawing.Color.Transparent;
            this.label_ESearchID.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ESearchID.ForeColor = System.Drawing.Color.Red;
            this.label_ESearchID.Location = new System.Drawing.Point(170, 240);
            this.label_ESearchID.Name = "label_ESearchID";
            this.label_ESearchID.Size = new System.Drawing.Size(60, 19);
            this.label_ESearchID.TabIndex = 118;
            this.label_ESearchID.Text = "label5";
            this.label_ESearchID.Visible = false;
            // 
            // bunifuSeparator7
            // 
            this.bunifuSeparator7.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator7.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator7.LineThickness = 2;
            this.bunifuSeparator7.Location = new System.Drawing.Point(60, 263);
            this.bunifuSeparator7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator7.Name = "bunifuSeparator7";
            this.bunifuSeparator7.Size = new System.Drawing.Size(1018, 10);
            this.bunifuSeparator7.TabIndex = 117;
            this.bunifuSeparator7.Transparency = 255;
            this.bunifuSeparator7.Vertical = false;
            // 
            // Button_Search
            // 
            this.Button_Search.Activecolor = System.Drawing.Color.DarkViolet;
            this.Button_Search.BackColor = System.Drawing.Color.DarkViolet;
            this.Button_Search.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_Search.BorderRadius = 0;
            this.Button_Search.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Button_Search.ButtonText = "SEARCH";
            this.Button_Search.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_Search.DisabledColor = System.Drawing.Color.Gray;
            this.Button_Search.ForeColor = System.Drawing.Color.White;
            this.Button_Search.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_Search.Iconimage = null;
            this.Button_Search.Iconimage_right = null;
            this.Button_Search.Iconimage_right_Selected = null;
            this.Button_Search.Iconimage_Selected = null;
            this.Button_Search.IconMarginLeft = 0;
            this.Button_Search.IconMarginRight = 0;
            this.Button_Search.IconRightVisible = true;
            this.Button_Search.IconRightZoom = 0D;
            this.Button_Search.IconVisible = true;
            this.Button_Search.IconZoom = 90D;
            this.Button_Search.IsTab = false;
            this.Button_Search.Location = new System.Drawing.Point(743, 184);
            this.Button_Search.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_Search.Name = "Button_Search";
            this.Button_Search.Normalcolor = System.Drawing.Color.DarkViolet;
            this.Button_Search.OnHovercolor = System.Drawing.Color.Transparent;
            this.Button_Search.OnHoverTextColor = System.Drawing.Color.Black;
            this.Button_Search.selected = false;
            this.Button_Search.Size = new System.Drawing.Size(280, 45);
            this.Button_Search.TabIndex = 116;
            this.Button_Search.Text = "SEARCH";
            this.Button_Search.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_Search.Textcolor = System.Drawing.Color.White;
            this.Button_Search.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Search.Click += new System.EventHandler(this.Button_Search_Click);
            // 
            // Label_SearchNIC
            // 
            this.Label_SearchNIC.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_SearchNIC.AutoSize = true;
            this.Label_SearchNIC.BackColor = System.Drawing.Color.Transparent;
            this.Label_SearchNIC.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SearchNIC.ForeColor = System.Drawing.Color.Black;
            this.Label_SearchNIC.Location = new System.Drawing.Point(106, 191);
            this.Label_SearchNIC.Name = "Label_SearchNIC";
            this.Label_SearchNIC.Size = new System.Drawing.Size(194, 32);
            this.Label_SearchNIC.TabIndex = 115;
            this.Label_SearchNIC.Text = "Report Number";
            // 
            // Textbox_SearchNo
            // 
            this.Textbox_SearchNo.BackColor = System.Drawing.Color.Silver;
            this.Textbox_SearchNo.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_SearchNo.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_SearchNo.ForeColor = System.Drawing.Color.Black;
            this.Textbox_SearchNo.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_SearchNo.HintText = "Report Number";
            this.Textbox_SearchNo.isPassword = false;
            this.Textbox_SearchNo.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_SearchNo.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_SearchNo.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_SearchNo.LineThickness = 3;
            this.Textbox_SearchNo.Location = new System.Drawing.Point(328, 184);
            this.Textbox_SearchNo.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_SearchNo.Name = "Textbox_SearchNo";
            this.Textbox_SearchNo.Size = new System.Drawing.Size(373, 45);
            this.Textbox_SearchNo.TabIndex = 114;
            this.Textbox_SearchNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Textbox_SearchNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_SearchID_KeyPress);
            // 
            // DataGrid1
            // 
            this.DataGrid1.AllowUserToAddRows = false;
            this.DataGrid1.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.DataGrid1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.DataGrid1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DataGrid1.AutoGenerateColumns = false;
            this.DataGrid1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DataGrid1.BackgroundColor = System.Drawing.Color.White;
            this.DataGrid1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DataGrid1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.DataGrid1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DataGrid1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.DataGrid1.ColumnHeadersHeight = 65;
            this.DataGrid1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.repNoDataGridViewTextBoxColumn,
            this.typeofReportDataGridViewTextBoxColumn,
            this.resultsDataGridViewTextBoxColumn,
            this.sampleRDateDataGridViewTextBoxColumn,
            this.sampleTDateDataGridViewTextBoxColumn,
            this.techRemarkDataGridViewTextBoxColumn,
            this.softCopyLinkDataGridViewTextBoxColumn});
            this.DataGrid1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DataGrid1.DataSource = this.tableLabReportsBindingSource;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Century", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DataGrid1.DefaultCellStyle = dataGridViewCellStyle3;
            this.DataGrid1.DoubleBuffered = true;
            this.DataGrid1.EnableHeadersVisualStyles = false;
            this.DataGrid1.GridColor = System.Drawing.Color.White;
            this.DataGrid1.HeaderBgColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.DataGrid1.HeaderForeColor = System.Drawing.Color.White;
            this.DataGrid1.Location = new System.Drawing.Point(60, 334);
            this.DataGrid1.MultiSelect = false;
            this.DataGrid1.Name = "DataGrid1";
            this.DataGrid1.ReadOnly = true;
            this.DataGrid1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Century", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DataGrid1.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.DataGrid1.RowHeadersVisible = false;
            this.DataGrid1.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.White;
            this.DataGrid1.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Century", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DataGrid1.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.DataGrid1.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Silver;
            this.DataGrid1.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.DataGrid1.RowTemplate.DividerHeight = 3;
            this.DataGrid1.RowTemplate.Height = 70;
            this.DataGrid1.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.DataGrid1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DataGrid1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DataGrid1.Size = new System.Drawing.Size(1018, 265);
            this.DataGrid1.TabIndex = 119;
            // 
            // reportToolStrip
            // 
            this.reportToolStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.reportToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.repNoToolStripLabel,
            this.repNoToolStripTextBox,
            this.reportToolStripButton});
            this.reportToolStrip.Location = new System.Drawing.Point(0, 0);
            this.reportToolStrip.Name = "reportToolStrip";
            this.reportToolStrip.Size = new System.Drawing.Size(1140, 27);
            this.reportToolStrip.TabIndex = 4;
            this.reportToolStrip.Text = "reportToolStrip";
            this.reportToolStrip.Visible = false;
            // 
            // repNoToolStripLabel
            // 
            this.repNoToolStripLabel.Name = "repNoToolStripLabel";
            this.repNoToolStripLabel.Size = new System.Drawing.Size(54, 24);
            this.repNoToolStripLabel.Text = "repNo:";
            // 
            // repNoToolStripTextBox
            // 
            this.repNoToolStripTextBox.Name = "repNoToolStripTextBox";
            this.repNoToolStripTextBox.Size = new System.Drawing.Size(100, 27);
            // 
            // reportToolStripButton
            // 
            this.reportToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.reportToolStripButton.Name = "reportToolStripButton";
            this.reportToolStripButton.Size = new System.Drawing.Size(54, 24);
            this.reportToolStripButton.Text = "report";
            this.reportToolStripButton.Click += new System.EventHandler(this.ReportToolStripButton_Click);
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // repNoDataGridViewTextBoxColumn
            // 
            this.repNoDataGridViewTextBoxColumn.DataPropertyName = "repNo";
            this.repNoDataGridViewTextBoxColumn.HeaderText = "Report Number";
            this.repNoDataGridViewTextBoxColumn.Name = "repNoDataGridViewTextBoxColumn";
            this.repNoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // typeofReportDataGridViewTextBoxColumn
            // 
            this.typeofReportDataGridViewTextBoxColumn.DataPropertyName = "typeofReport";
            this.typeofReportDataGridViewTextBoxColumn.HeaderText = "Type of Report";
            this.typeofReportDataGridViewTextBoxColumn.Name = "typeofReportDataGridViewTextBoxColumn";
            this.typeofReportDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // resultsDataGridViewTextBoxColumn
            // 
            this.resultsDataGridViewTextBoxColumn.DataPropertyName = "results";
            this.resultsDataGridViewTextBoxColumn.HeaderText = "Results";
            this.resultsDataGridViewTextBoxColumn.Name = "resultsDataGridViewTextBoxColumn";
            this.resultsDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // sampleRDateDataGridViewTextBoxColumn
            // 
            this.sampleRDateDataGridViewTextBoxColumn.DataPropertyName = "sampleRDate";
            this.sampleRDateDataGridViewTextBoxColumn.HeaderText = "Sample R. Date";
            this.sampleRDateDataGridViewTextBoxColumn.Name = "sampleRDateDataGridViewTextBoxColumn";
            this.sampleRDateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // sampleTDateDataGridViewTextBoxColumn
            // 
            this.sampleTDateDataGridViewTextBoxColumn.DataPropertyName = "sampleTDate";
            this.sampleTDateDataGridViewTextBoxColumn.HeaderText = "Sample T. Date";
            this.sampleTDateDataGridViewTextBoxColumn.Name = "sampleTDateDataGridViewTextBoxColumn";
            this.sampleTDateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // techRemarkDataGridViewTextBoxColumn
            // 
            this.techRemarkDataGridViewTextBoxColumn.DataPropertyName = "TechRemark";
            this.techRemarkDataGridViewTextBoxColumn.HeaderText = "Technician Remark";
            this.techRemarkDataGridViewTextBoxColumn.Name = "techRemarkDataGridViewTextBoxColumn";
            this.techRemarkDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // softCopyLinkDataGridViewTextBoxColumn
            // 
            this.softCopyLinkDataGridViewTextBoxColumn.DataPropertyName = "softCopyLink";
            this.softCopyLinkDataGridViewTextBoxColumn.HeaderText = "Soft Copy Link";
            this.softCopyLinkDataGridViewTextBoxColumn.Name = "softCopyLinkDataGridViewTextBoxColumn";
            this.softCopyLinkDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // tableLabReportsBindingSource
            // 
            this.tableLabReportsBindingSource.DataMember = "TableLabReports";
            this.tableLabReportsBindingSource.DataSource = this.mSSDBDataSet1;
            // 
            // mSSDBDataSet1
            // 
            this.mSSDBDataSet1.DataSetName = "MSSDBDataSet1";
            this.mSSDBDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tableLabReportsTableAdapter
            // 
            this.tableLabReportsTableAdapter.ClearBeforeFill = true;
            // 
            // viewLabReportsControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.reportToolStrip);
            this.Controls.Add(this.bunifuGradientPanel1);
            this.Name = "viewLabReportsControl";
            this.Size = new System.Drawing.Size(1140, 812);
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGrid1)).EndInit();
            this.reportToolStrip.ResumeLayout(false);
            this.reportToolStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tableLabReportsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mSSDBDataSet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel1;
        public Bunifu.Framework.UI.BunifuFlatButton Button_Clear;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Title;
        private System.Windows.Forms.Label label_ESearchID;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator7;
        public Bunifu.Framework.UI.BunifuFlatButton Button_Search;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_SearchNIC;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_SearchNo;
        private Bunifu.Framework.UI.BunifuCustomDataGrid DataGrid1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn repNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn typeofReportDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn resultsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sampleRDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sampleTDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn techRemarkDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn softCopyLinkDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource tableLabReportsBindingSource;
        private MSSDBDataSet1 mSSDBDataSet1;
        private MSSDBDataSet1TableAdapters.TableLabReportsTableAdapter tableLabReportsTableAdapter;
        private System.Windows.Forms.ToolStrip reportToolStrip;
        private System.Windows.Forms.ToolStripLabel repNoToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox repNoToolStripTextBox;
        private System.Windows.Forms.ToolStripButton reportToolStripButton;
    }
}
