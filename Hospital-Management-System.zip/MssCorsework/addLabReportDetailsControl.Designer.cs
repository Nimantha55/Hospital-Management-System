﻿namespace MssCorsework
{
    partial class addLabReportDetailsControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(addLabReportDetailsControl));
            this.bunifuGradientPanel1 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.app_Number = new System.Windows.Forms.NumericUpDown();
            this.label_AppointmentNumber = new System.Windows.Forms.Label();
            this.bunifuSeparator6 = new Bunifu.Framework.UI.BunifuSeparator();
            this.bunifuSeparator5 = new Bunifu.Framework.UI.BunifuSeparator();
            this.bunifuSeparator4 = new Bunifu.Framework.UI.BunifuSeparator();
            this.textBox_SCL = new System.Windows.Forms.TextBox();
            this.bunifuSeparator3 = new Bunifu.Framework.UI.BunifuSeparator();
            this.textBox_TR = new System.Windows.Forms.TextBox();
            this.bunifuSeparator2 = new Bunifu.Framework.UI.BunifuSeparator();
            this.textBox_Result = new System.Windows.Forms.TextBox();
            this.bunifuSeparator1 = new Bunifu.Framework.UI.BunifuSeparator();
            this.textBox_typeR = new System.Windows.Forms.TextBox();
            this.Datepicker_aSTDate = new System.Windows.Forms.DateTimePicker();
            this.Datepicker_aSRDate = new System.Windows.Forms.DateTimePicker();
            this.label_Errors = new System.Windows.Forms.Label();
            this.label_ESCL = new System.Windows.Forms.Label();
            this.label_ETechR = new System.Windows.Forms.Label();
            this.label_ETD = new System.Windows.Forms.Label();
            this.label_ESRD = new System.Windows.Forms.Label();
            this.label_ER = new System.Windows.Forms.Label();
            this.label_ETR = new System.Windows.Forms.Label();
            this.Button_Clear = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Button_Save = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Label_Gender = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_TelephoneNum = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_Age = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_Address = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_NIC = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_Name = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_Title = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.app_Number)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.Controls.Add(this.app_Number);
            this.bunifuGradientPanel1.Controls.Add(this.label_AppointmentNumber);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuSeparator6);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuSeparator5);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuSeparator4);
            this.bunifuGradientPanel1.Controls.Add(this.textBox_SCL);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuSeparator3);
            this.bunifuGradientPanel1.Controls.Add(this.textBox_TR);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuSeparator2);
            this.bunifuGradientPanel1.Controls.Add(this.textBox_Result);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuSeparator1);
            this.bunifuGradientPanel1.Controls.Add(this.textBox_typeR);
            this.bunifuGradientPanel1.Controls.Add(this.Datepicker_aSTDate);
            this.bunifuGradientPanel1.Controls.Add(this.Datepicker_aSRDate);
            this.bunifuGradientPanel1.Controls.Add(this.label_Errors);
            this.bunifuGradientPanel1.Controls.Add(this.label_ESCL);
            this.bunifuGradientPanel1.Controls.Add(this.label_ETechR);
            this.bunifuGradientPanel1.Controls.Add(this.label_ETD);
            this.bunifuGradientPanel1.Controls.Add(this.label_ESRD);
            this.bunifuGradientPanel1.Controls.Add(this.label_ER);
            this.bunifuGradientPanel1.Controls.Add(this.label_ETR);
            this.bunifuGradientPanel1.Controls.Add(this.Button_Clear);
            this.bunifuGradientPanel1.Controls.Add(this.Button_Save);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Gender);
            this.bunifuGradientPanel1.Controls.Add(this.Label_TelephoneNum);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Age);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Address);
            this.bunifuGradientPanel1.Controls.Add(this.Label_NIC);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Name);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Title);
            this.bunifuGradientPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.Black;
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.Gray;
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(1140, 812);
            this.bunifuGradientPanel1.TabIndex = 2;
            // 
            // app_Number
            // 
            this.app_Number.BackColor = System.Drawing.Color.Silver;
            this.app_Number.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.app_Number.Location = new System.Drawing.Point(962, 71);
            this.app_Number.MinimumSize = new System.Drawing.Size(90, 0);
            this.app_Number.Name = "app_Number";
            this.app_Number.Size = new System.Drawing.Size(90, 30);
            this.app_Number.TabIndex = 115;
            // 
            // label_AppointmentNumber
            // 
            this.label_AppointmentNumber.AutoSize = true;
            this.label_AppointmentNumber.BackColor = System.Drawing.Color.Transparent;
            this.label_AppointmentNumber.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_AppointmentNumber.ForeColor = System.Drawing.Color.Black;
            this.label_AppointmentNumber.Location = new System.Drawing.Point(930, 33);
            this.label_AppointmentNumber.Name = "label_AppointmentNumber";
            this.label_AppointmentNumber.Size = new System.Drawing.Size(149, 23);
            this.label_AppointmentNumber.TabIndex = 114;
            this.label_AppointmentNumber.Text = "Report Number";
            // 
            // bunifuSeparator6
            // 
            this.bunifuSeparator6.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator6.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuSeparator6.LineThickness = 3;
            this.bunifuSeparator6.Location = new System.Drawing.Point(599, 404);
            this.bunifuSeparator6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator6.Name = "bunifuSeparator6";
            this.bunifuSeparator6.Size = new System.Drawing.Size(480, 10);
            this.bunifuSeparator6.TabIndex = 113;
            this.bunifuSeparator6.Transparency = 255;
            this.bunifuSeparator6.Vertical = false;
            // 
            // bunifuSeparator5
            // 
            this.bunifuSeparator5.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator5.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuSeparator5.LineThickness = 3;
            this.bunifuSeparator5.Location = new System.Drawing.Point(61, 404);
            this.bunifuSeparator5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator5.Name = "bunifuSeparator5";
            this.bunifuSeparator5.Size = new System.Drawing.Size(480, 10);
            this.bunifuSeparator5.TabIndex = 112;
            this.bunifuSeparator5.Transparency = 255;
            this.bunifuSeparator5.Vertical = false;
            // 
            // bunifuSeparator4
            // 
            this.bunifuSeparator4.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator4.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuSeparator4.LineThickness = 3;
            this.bunifuSeparator4.Location = new System.Drawing.Point(599, 604);
            this.bunifuSeparator4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator4.Name = "bunifuSeparator4";
            this.bunifuSeparator4.Size = new System.Drawing.Size(480, 10);
            this.bunifuSeparator4.TabIndex = 111;
            this.bunifuSeparator4.Transparency = 255;
            this.bunifuSeparator4.Vertical = false;
            // 
            // textBox_SCL
            // 
            this.textBox_SCL.BackColor = System.Drawing.Color.Silver;
            this.textBox_SCL.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.textBox_SCL.Location = new System.Drawing.Point(599, 504);
            this.textBox_SCL.Multiline = true;
            this.textBox_SCL.Name = "textBox_SCL";
            this.textBox_SCL.Size = new System.Drawing.Size(480, 100);
            this.textBox_SCL.TabIndex = 110;
            this.textBox_SCL.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBox_SCL_KeyPress);
            // 
            // bunifuSeparator3
            // 
            this.bunifuSeparator3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator3.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuSeparator3.LineThickness = 3;
            this.bunifuSeparator3.Location = new System.Drawing.Point(61, 604);
            this.bunifuSeparator3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator3.Name = "bunifuSeparator3";
            this.bunifuSeparator3.Size = new System.Drawing.Size(480, 10);
            this.bunifuSeparator3.TabIndex = 109;
            this.bunifuSeparator3.Transparency = 255;
            this.bunifuSeparator3.Vertical = false;
            // 
            // textBox_TR
            // 
            this.textBox_TR.BackColor = System.Drawing.Color.Silver;
            this.textBox_TR.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.textBox_TR.Location = new System.Drawing.Point(61, 504);
            this.textBox_TR.Multiline = true;
            this.textBox_TR.Name = "textBox_TR";
            this.textBox_TR.Size = new System.Drawing.Size(480, 100);
            this.textBox_TR.TabIndex = 108;
            this.textBox_TR.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBox_TR_KeyPress);
            // 
            // bunifuSeparator2
            // 
            this.bunifuSeparator2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator2.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuSeparator2.LineThickness = 3;
            this.bunifuSeparator2.Location = new System.Drawing.Point(599, 258);
            this.bunifuSeparator2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator2.Name = "bunifuSeparator2";
            this.bunifuSeparator2.Size = new System.Drawing.Size(480, 10);
            this.bunifuSeparator2.TabIndex = 107;
            this.bunifuSeparator2.Transparency = 255;
            this.bunifuSeparator2.Vertical = false;
            // 
            // textBox_Result
            // 
            this.textBox_Result.BackColor = System.Drawing.Color.Silver;
            this.textBox_Result.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.textBox_Result.Location = new System.Drawing.Point(599, 158);
            this.textBox_Result.Multiline = true;
            this.textBox_Result.Name = "textBox_Result";
            this.textBox_Result.Size = new System.Drawing.Size(480, 100);
            this.textBox_Result.TabIndex = 106;
            this.textBox_Result.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBox_Result_KeyPress);
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuSeparator1.LineThickness = 3;
            this.bunifuSeparator1.Location = new System.Drawing.Point(61, 258);
            this.bunifuSeparator1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Size = new System.Drawing.Size(480, 10);
            this.bunifuSeparator1.TabIndex = 105;
            this.bunifuSeparator1.Transparency = 255;
            this.bunifuSeparator1.Vertical = false;
            // 
            // textBox_typeR
            // 
            this.textBox_typeR.BackColor = System.Drawing.Color.Silver;
            this.textBox_typeR.Font = new System.Drawing.Font("Century Gothic", 12F);
            this.textBox_typeR.Location = new System.Drawing.Point(61, 158);
            this.textBox_typeR.Multiline = true;
            this.textBox_typeR.Name = "textBox_typeR";
            this.textBox_typeR.Size = new System.Drawing.Size(480, 100);
            this.textBox_typeR.TabIndex = 101;
            this.textBox_typeR.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBox_typeR_KeyPress);
            // 
            // Datepicker_aSTDate
            // 
            this.Datepicker_aSTDate.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Datepicker_aSTDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Datepicker_aSTDate.Location = new System.Drawing.Point(599, 356);
            this.Datepicker_aSTDate.MinimumSize = new System.Drawing.Size(4, 44);
            this.Datepicker_aSTDate.Name = "Datepicker_aSTDate";
            this.Datepicker_aSTDate.Size = new System.Drawing.Size(480, 44);
            this.Datepicker_aSTDate.TabIndex = 99;
            // 
            // Datepicker_aSRDate
            // 
            this.Datepicker_aSRDate.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Datepicker_aSRDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Datepicker_aSRDate.Location = new System.Drawing.Point(61, 356);
            this.Datepicker_aSRDate.MinimumSize = new System.Drawing.Size(4, 44);
            this.Datepicker_aSRDate.Name = "Datepicker_aSRDate";
            this.Datepicker_aSRDate.Size = new System.Drawing.Size(480, 44);
            this.Datepicker_aSRDate.TabIndex = 98;
            // 
            // label_Errors
            // 
            this.label_Errors.AutoSize = true;
            this.label_Errors.BackColor = System.Drawing.Color.Transparent;
            this.label_Errors.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Errors.ForeColor = System.Drawing.Color.Red;
            this.label_Errors.Location = new System.Drawing.Point(57, 739);
            this.label_Errors.Name = "label_Errors";
            this.label_Errors.Size = new System.Drawing.Size(60, 19);
            this.label_Errors.TabIndex = 75;
            this.label_Errors.Text = "label5";
            this.label_Errors.Visible = false;
            // 
            // label_ESCL
            // 
            this.label_ESCL.AutoSize = true;
            this.label_ESCL.BackColor = System.Drawing.Color.Transparent;
            this.label_ESCL.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ESCL.ForeColor = System.Drawing.Color.Red;
            this.label_ESCL.Location = new System.Drawing.Point(595, 620);
            this.label_ESCL.Name = "label_ESCL";
            this.label_ESCL.Size = new System.Drawing.Size(60, 19);
            this.label_ESCL.TabIndex = 74;
            this.label_ESCL.Text = "label6";
            this.label_ESCL.Visible = false;
            // 
            // label_ETechR
            // 
            this.label_ETechR.AutoSize = true;
            this.label_ETechR.BackColor = System.Drawing.Color.Transparent;
            this.label_ETechR.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ETechR.ForeColor = System.Drawing.Color.Red;
            this.label_ETechR.Location = new System.Drawing.Point(57, 620);
            this.label_ETechR.Name = "label_ETechR";
            this.label_ETechR.Size = new System.Drawing.Size(60, 19);
            this.label_ETechR.TabIndex = 73;
            this.label_ETechR.Text = "label5";
            this.label_ETechR.Visible = false;
            // 
            // label_ETD
            // 
            this.label_ETD.AutoSize = true;
            this.label_ETD.BackColor = System.Drawing.Color.Transparent;
            this.label_ETD.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ETD.ForeColor = System.Drawing.Color.Red;
            this.label_ETD.Location = new System.Drawing.Point(595, 426);
            this.label_ETD.Name = "label_ETD";
            this.label_ETD.Size = new System.Drawing.Size(60, 19);
            this.label_ETD.TabIndex = 72;
            this.label_ETD.Text = "label4";
            this.label_ETD.Visible = false;
            // 
            // label_ESRD
            // 
            this.label_ESRD.AutoSize = true;
            this.label_ESRD.BackColor = System.Drawing.Color.Transparent;
            this.label_ESRD.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ESRD.ForeColor = System.Drawing.Color.Red;
            this.label_ESRD.Location = new System.Drawing.Point(57, 426);
            this.label_ESRD.Name = "label_ESRD";
            this.label_ESRD.Size = new System.Drawing.Size(60, 19);
            this.label_ESRD.TabIndex = 71;
            this.label_ESRD.Text = "label3";
            this.label_ESRD.Visible = false;
            // 
            // label_ER
            // 
            this.label_ER.AutoSize = true;
            this.label_ER.BackColor = System.Drawing.Color.Transparent;
            this.label_ER.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ER.ForeColor = System.Drawing.Color.Red;
            this.label_ER.Location = new System.Drawing.Point(595, 273);
            this.label_ER.Name = "label_ER";
            this.label_ER.Size = new System.Drawing.Size(60, 19);
            this.label_ER.TabIndex = 70;
            this.label_ER.Text = "label2";
            this.label_ER.Visible = false;
            // 
            // label_ETR
            // 
            this.label_ETR.AutoSize = true;
            this.label_ETR.BackColor = System.Drawing.Color.Transparent;
            this.label_ETR.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ETR.ForeColor = System.Drawing.Color.Red;
            this.label_ETR.Location = new System.Drawing.Point(57, 273);
            this.label_ETR.Name = "label_ETR";
            this.label_ETR.Size = new System.Drawing.Size(60, 19);
            this.label_ETR.TabIndex = 69;
            this.label_ETR.Text = "label1";
            this.label_ETR.Visible = false;
            // 
            // Button_Clear
            // 
            this.Button_Clear.Activecolor = System.Drawing.Color.Crimson;
            this.Button_Clear.BackColor = System.Drawing.Color.Crimson;
            this.Button_Clear.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_Clear.BorderRadius = 0;
            this.Button_Clear.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Button_Clear.ButtonText = "CLEAR";
            this.Button_Clear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_Clear.DisabledColor = System.Drawing.Color.Gray;
            this.Button_Clear.ForeColor = System.Drawing.Color.White;
            this.Button_Clear.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_Clear.Iconimage = null;
            this.Button_Clear.Iconimage_right = null;
            this.Button_Clear.Iconimage_right_Selected = null;
            this.Button_Clear.Iconimage_Selected = null;
            this.Button_Clear.IconMarginLeft = 0;
            this.Button_Clear.IconMarginRight = 0;
            this.Button_Clear.IconRightVisible = true;
            this.Button_Clear.IconRightZoom = 0D;
            this.Button_Clear.IconVisible = true;
            this.Button_Clear.IconZoom = 90D;
            this.Button_Clear.IsTab = false;
            this.Button_Clear.Location = new System.Drawing.Point(599, 665);
            this.Button_Clear.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_Clear.Name = "Button_Clear";
            this.Button_Clear.Normalcolor = System.Drawing.Color.Crimson;
            this.Button_Clear.OnHovercolor = System.Drawing.Color.Transparent;
            this.Button_Clear.OnHoverTextColor = System.Drawing.Color.Black;
            this.Button_Clear.selected = false;
            this.Button_Clear.Size = new System.Drawing.Size(480, 64);
            this.Button_Clear.TabIndex = 58;
            this.Button_Clear.Text = "CLEAR";
            this.Button_Clear.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_Clear.Textcolor = System.Drawing.Color.White;
            this.Button_Clear.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Clear.Click += new System.EventHandler(this.Button_Clear_Click);
            // 
            // Button_Save
            // 
            this.Button_Save.Activecolor = System.Drawing.Color.ForestGreen;
            this.Button_Save.BackColor = System.Drawing.Color.ForestGreen;
            this.Button_Save.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_Save.BorderRadius = 0;
            this.Button_Save.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Button_Save.ButtonText = "SAVE REPORT";
            this.Button_Save.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_Save.DisabledColor = System.Drawing.Color.Gray;
            this.Button_Save.ForeColor = System.Drawing.Color.White;
            this.Button_Save.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_Save.Iconimage = null;
            this.Button_Save.Iconimage_right = null;
            this.Button_Save.Iconimage_right_Selected = null;
            this.Button_Save.Iconimage_Selected = null;
            this.Button_Save.IconMarginLeft = 0;
            this.Button_Save.IconMarginRight = 0;
            this.Button_Save.IconRightVisible = true;
            this.Button_Save.IconRightZoom = 0D;
            this.Button_Save.IconVisible = true;
            this.Button_Save.IconZoom = 90D;
            this.Button_Save.IsTab = false;
            this.Button_Save.Location = new System.Drawing.Point(61, 665);
            this.Button_Save.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_Save.Name = "Button_Save";
            this.Button_Save.Normalcolor = System.Drawing.Color.ForestGreen;
            this.Button_Save.OnHovercolor = System.Drawing.Color.Transparent;
            this.Button_Save.OnHoverTextColor = System.Drawing.Color.Black;
            this.Button_Save.selected = false;
            this.Button_Save.Size = new System.Drawing.Size(480, 64);
            this.Button_Save.TabIndex = 57;
            this.Button_Save.Text = "SAVE REPORT";
            this.Button_Save.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_Save.Textcolor = System.Drawing.Color.White;
            this.Button_Save.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Save.Click += new System.EventHandler(this.Button_Save_Click);
            // 
            // Label_Gender
            // 
            this.Label_Gender.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Gender.AutoSize = true;
            this.Label_Gender.BackColor = System.Drawing.Color.Transparent;
            this.Label_Gender.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Gender.ForeColor = System.Drawing.Color.Black;
            this.Label_Gender.Location = new System.Drawing.Point(593, 451);
            this.Label_Gender.Name = "Label_Gender";
            this.Label_Gender.Size = new System.Drawing.Size(180, 32);
            this.Label_Gender.TabIndex = 31;
            this.Label_Gender.Text = "Soft Copy Link";
            // 
            // Label_TelephoneNum
            // 
            this.Label_TelephoneNum.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_TelephoneNum.AutoSize = true;
            this.Label_TelephoneNum.BackColor = System.Drawing.Color.Transparent;
            this.Label_TelephoneNum.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_TelephoneNum.ForeColor = System.Drawing.Color.Black;
            this.Label_TelephoneNum.Location = new System.Drawing.Point(55, 451);
            this.Label_TelephoneNum.Name = "Label_TelephoneNum";
            this.Label_TelephoneNum.Size = new System.Drawing.Size(231, 32);
            this.Label_TelephoneNum.TabIndex = 29;
            this.Label_TelephoneNum.Text = "Technician Remark";
            // 
            // Label_Age
            // 
            this.Label_Age.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Age.AutoSize = true;
            this.Label_Age.BackColor = System.Drawing.Color.Transparent;
            this.Label_Age.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Age.ForeColor = System.Drawing.Color.Black;
            this.Label_Age.Location = new System.Drawing.Point(593, 305);
            this.Label_Age.Name = "Label_Age";
            this.Label_Age.Size = new System.Drawing.Size(240, 32);
            this.Label_Age.TabIndex = 27;
            this.Label_Age.Text = "Sample Tested Date";
            // 
            // Label_Address
            // 
            this.Label_Address.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Address.AutoSize = true;
            this.Label_Address.BackColor = System.Drawing.Color.Transparent;
            this.Label_Address.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Address.ForeColor = System.Drawing.Color.Black;
            this.Label_Address.Location = new System.Drawing.Point(55, 305);
            this.Label_Address.Name = "Label_Address";
            this.Label_Address.Size = new System.Drawing.Size(267, 32);
            this.Label_Address.TabIndex = 25;
            this.Label_Address.Text = "Sample Received Date";
            // 
            // Label_NIC
            // 
            this.Label_NIC.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_NIC.AutoSize = true;
            this.Label_NIC.BackColor = System.Drawing.Color.Transparent;
            this.Label_NIC.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_NIC.ForeColor = System.Drawing.Color.Black;
            this.Label_NIC.Location = new System.Drawing.Point(593, 105);
            this.Label_NIC.Name = "Label_NIC";
            this.Label_NIC.Size = new System.Drawing.Size(97, 32);
            this.Label_NIC.TabIndex = 23;
            this.Label_NIC.Text = "Results";
            // 
            // Label_Name
            // 
            this.Label_Name.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Name.AutoSize = true;
            this.Label_Name.BackColor = System.Drawing.Color.Transparent;
            this.Label_Name.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Name.ForeColor = System.Drawing.Color.Black;
            this.Label_Name.Location = new System.Drawing.Point(55, 105);
            this.Label_Name.Name = "Label_Name";
            this.Label_Name.Size = new System.Drawing.Size(186, 32);
            this.Label_Name.TabIndex = 19;
            this.Label_Name.Text = "Type of Report";
            // 
            // Label_Title
            // 
            this.Label_Title.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Title.AutoSize = true;
            this.Label_Title.BackColor = System.Drawing.Color.Transparent;
            this.Label_Title.Font = new System.Drawing.Font("Felix Titling", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Title.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.Label_Title.Location = new System.Drawing.Point(319, 23);
            this.Label_Title.Name = "Label_Title";
            this.Label_Title.Size = new System.Drawing.Size(513, 35);
            this.Label_Title.TabIndex = 18;
            this.Label_Title.Text = "Add New Lab Report Details";
            // 
            // addLabReportDetailsControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.bunifuGradientPanel1);
            this.Name = "addLabReportDetailsControl";
            this.Size = new System.Drawing.Size(1140, 812);
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.app_Number)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel1;
        private System.Windows.Forms.Label label_Errors;
        private System.Windows.Forms.Label label_ESCL;
        private System.Windows.Forms.Label label_ETechR;
        private System.Windows.Forms.Label label_ETD;
        private System.Windows.Forms.Label label_ESRD;
        private System.Windows.Forms.Label label_ER;
        private System.Windows.Forms.Label label_ETR;
        public Bunifu.Framework.UI.BunifuFlatButton Button_Clear;
        public Bunifu.Framework.UI.BunifuFlatButton Button_Save;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Gender;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_TelephoneNum;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Age;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Address;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_NIC;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Name;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Title;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator6;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator5;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator4;
        private System.Windows.Forms.TextBox textBox_SCL;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator3;
        private System.Windows.Forms.TextBox textBox_TR;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator2;
        private System.Windows.Forms.TextBox textBox_Result;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator1;
        private System.Windows.Forms.TextBox textBox_typeR;
        private System.Windows.Forms.DateTimePicker Datepicker_aSTDate;
        private System.Windows.Forms.DateTimePicker Datepicker_aSRDate;
        private System.Windows.Forms.NumericUpDown app_Number;
        private System.Windows.Forms.Label label_AppointmentNumber;
    }
}
