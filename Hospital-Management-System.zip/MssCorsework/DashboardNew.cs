﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MssCorsework
{
    public partial class DashboardNew : Form
    {
        public bool isCollapsed;

        public DashboardNew()
        {
            InitializeComponent();
        }

        private void Btn_minimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void Btn_close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Button_hideMenu_Click(object sender, EventArgs e)
        {
            panel_left.Width = 60;
            menuTransition.ShowSync(panel_left);
            Separator1.Visible = false;
            Separator2.Visible = false;
            Separator_ID.Visible = false;
            Button_showMenu.Visible = true;
        }

        private void Button_showMenu_Click(object sender, EventArgs e)
        {
            panel_left.Width = 267;
            menuTransition.ShowSync(panel_left);
            Separator1.Visible = true;
            Separator2.Visible = true;
            Separator_ID.Visible = true;
            Button_showMenu.Visible = false;
        }

        private void Button_logOut_Click(object sender, EventArgs e)
        {
            LoginCreate lc = new LoginCreate();
            lc.Show();
            this.Close();
        }

        private void Timer_time_Tick(object sender, EventArgs e)
        {
            label_Date.Text = DateTime.Now.ToLongTimeString();
            timer_time.Start();
        }

        private void DashboardNew_Load(object sender, EventArgs e)
        {
            //Set date and time for labels
            timer_time.Start();
            label_Date.Text = DateTime.Now.ToLongTimeString();
            label_time.Text = DateTime.Now.ToLongDateString();
        }

        private void Button_mangeLabReportDetails_Click(object sender, EventArgs e)
        {
            timer1.Start();
            panel_labReports.BringToFront();
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            if (isCollapsed)
            {
                panel_labReports.Height += 10;
                if (panel_labReports.Size == panel_labReports.MaximumSize)
                {
                    timer1.Stop();
                    isCollapsed = false;
                }
            }
            else
            {
                panel_labReports.Height -= 10;
                if (panel_labReports.Size == panel_labReports.MinimumSize)
                {
                    timer1.Stop();
                    isCollapsed = true;
                }
            }
        }

        private void Button_add_Click(object sender, EventArgs e)
        {
            addLabReportDetailsControl1.BringToFront();
        }

        private void Button_View_Click(object sender, EventArgs e)
        {
            viewLabReportsControl1.BringToFront();
        }

        private void Button_Inventory_Click(object sender, EventArgs e)
        {
            pharmacyControl1.BringToFront();
        }

        private void Button_Appointments_Click(object sender, EventArgs e)
        {
            displayInventoryControl1.BringToFront();
        }

        private void Button_Payments_Click(object sender, EventArgs e)
        {
            internalPatientsControl1.BringToFront();
        }

        private void Button_updateInternalPatients_Click(object sender, EventArgs e)
        {
            updateInternalPatientsControl1.BringToFront();
        }

        private void Button_addDiagnosisDetails_Click(object sender, EventArgs e)
        {
            patientHistoryManagementControl1.BringToFront();
        }

        private void Button_viewDiagnosisDetails_Click(object sender, EventArgs e)
        {
            viewDiagnosisDetailsControl1.BringToFront();
        }

        private void Button_inventoryReport_Click(object sender, EventArgs e)
        {
            viewInventoryControl1.BringToFront();
        }
    }
}
