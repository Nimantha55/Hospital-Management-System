﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MssCorsework
{
    public partial class viewInventoryControl : UserControl
    {
        public viewInventoryControl()
        {
            InitializeComponent();
        }

        labReportViewer lrv = new labReportViewer();

        private void Button_Search_Click(object sender, EventArgs e)
        {
            string NIC = Textbox_NIC.Text;
            DateTime date = Datepicker_aDate.Value;

            if (Textbox_NIC.Text == "")
            {
                label_pENIC.Visible = true;
                label_pENIC.Text = "Patient's NIC is Required!";
            }
            else
            {
                string amount = "SELECT * FROM TableInventory WHERE date = '" + date + "' AND pNIC = '" + NIC + "'";
                SqlDataAdapter sqlda4 = new SqlDataAdapter(amount, MSSDBConnection.MSSConnection());
                DataTable dtb5 = new DataTable();
                sqlda4.Fill(dtb5);

                DataGrid1.DataSource = dtb5;
            }
        }

        private void Button_Clear_Click(object sender, EventArgs e)
        {
            string NIC = Textbox_NIC.Text;
            DateTime date = Datepicker_aDate.Value;

            InventoryReport lr = new InventoryReport();
            string amount = "SELECT * FROM TableInventory WHERE date = '" + date + "' AND pNIC = '" + NIC + "'";
            DataSet ds = new DataSet();
            SqlDataAdapter sda = new SqlDataAdapter(amount, MSSDBConnection.MSSConnection());
            sda.Fill(ds, "TableInventory");

            lr.SetDataSource(ds.Tables["TableInventory"]);
            lrv.crystalReportViewer1.ReportSource = lr;
            lrv.crystalReportViewer1.Refresh();
            lrv.Show();
        }

        private void Textbox_NIC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_NIC.Text != "")
            {
                label_pENIC.Visible = false;
            }
        }
    }
}
