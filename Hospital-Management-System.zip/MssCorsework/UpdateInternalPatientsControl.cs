﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MssCorsework
{
    public partial class UpdateInternalPatientsControl : UserControl
    {
        public UpdateInternalPatientsControl()
        {
            InitializeComponent();
        }

        SQLQueries sqlq = new SQLQueries();

        private void Button_Search_Click(object sender, EventArgs e)
        {
            string searchNIC = Textbox_SearchNIC.Text;

            if (Textbox_SearchNIC.Text == "")
            {
                label_ESearchNIC.Visible = true;
                label_ESearchNIC.Text = "Patient's NIC or Guardian's NIC is required!";
            }
            else
            {
                SqlDataReader dr = sqlq.getInternalPatientDetails(searchNIC);
                if (dr.Read())
                {
                    Label_ID.Text = dr[0].ToString();
                    Textbox_pName.Text = dr[2].ToString();
                    Textbox_Age.Text = dr[4].ToString();
                    Textbox_AdmissionNum.Text = dr[5].ToString();
                    Textbox_wardNumber.Text = dr[6].ToString();
                }
                else
                {
                    MessageBox.Show("Invalid Patient's or Guardian's NIC", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void clear()
        {
            Textbox_SearchNIC.Text = "";
            Textbox_pres.Text = "";
            Textbox_reports.Text = "";
        }

        private void Button_UPDATE_Click(object sender, EventArgs e)
        {
            if (Textbox_SearchNIC.Text == "")
            {
                label_ESearchNIC.Visible = true;
                label_ESearchNIC.Text = "Patient's NIC is Required!";
            }
            else if (Textbox_pres.Text == "")
            {
                label_prescription.Visible = true;
                label_prescription.Text = "Prescriptions is Required!";
            }
            else if (Textbox_reports.Text == "")
            {
                label_R.Visible = true;
                label_R.Text = "Report is Required!";
            }
            else
            {
                try
                {
                    int ID = int.Parse(Label_ID.Text);
                    string pre = Textbox_pres.Text;
                    string report = Textbox_reports.Text;

                    //pass values for updateInternalPatient query which include in SQLQueries class
                    sqlq.updateInternalPatient(pre, report, ID);
                    Message1 pr = new Message1();
                    pr.label1.Text = "Patient's Details updated Successfully!";
                    pr.label1.Location = new System.Drawing.Point(32, 200);
                    pr.Show();
                    this.clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Please Check The Values" + ex, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void Button_Clear_Click(object sender, EventArgs e)
        {
            this.clear();
        }

        private void Textbox_pres_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_pres.Text != "")
            {
                label_prescription.Visible = false;
                label_Errors.Visible = false;
            }
        }

        private void Textbox_reports_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_reports.Text != "")
            {
                label_ESearchNIC.Visible = false;
                label_Errors.Visible = false;
            }
        }

        private void Textbox_SearchNIC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_SearchNIC.Text != "")
            {
                label_R.Visible = false;
                label_Errors.Visible = false;
            }
        }
    }
}
