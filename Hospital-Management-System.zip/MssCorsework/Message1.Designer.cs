﻿namespace MssCorsework
{
    partial class Message1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Message1));
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.Transition1 = new Bunifu.Framework.UI.BunifuFormFadeTransition(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btn_ok = new Bunifu.Framework.UI.BunifuFlatButton();
            this.dragControl1 = new Project_SDC.DragControl();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 5;
            this.bunifuElipse1.TargetControl = this;
            // 
            // Transition1
            // 
            this.Transition1.Delay = 1;
            this.Transition1.TransitionEnd += new System.EventHandler(this.Transition1_TransitionEnd);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 3800;
            this.timer1.Tick += new System.EventHandler(this.Timer1_Tick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.OliveDrab;
            this.label1.Location = new System.Drawing.Point(92, 250);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(380, 28);
            this.label1.TabIndex = 57;
            this.label1.Text = "Patient Registered Successfully";
            this.label1.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Enabled = false;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(158, 25);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(253, 195);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 56;
            this.pictureBox1.TabStop = false;
            // 
            // btn_ok
            // 
            this.btn_ok.Activecolor = System.Drawing.Color.Transparent;
            this.btn_ok.BackColor = System.Drawing.Color.Teal;
            this.btn_ok.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_ok.BorderRadius = 5;
            this.btn_ok.ButtonText = "OK";
            this.btn_ok.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_ok.DisabledColor = System.Drawing.Color.Gray;
            this.btn_ok.ForeColor = System.Drawing.Color.White;
            this.btn_ok.Iconcolor = System.Drawing.Color.Transparent;
            this.btn_ok.Iconimage = null;
            this.btn_ok.Iconimage_right = null;
            this.btn_ok.Iconimage_right_Selected = null;
            this.btn_ok.Iconimage_Selected = null;
            this.btn_ok.IconMarginLeft = 0;
            this.btn_ok.IconMarginRight = 0;
            this.btn_ok.IconRightVisible = true;
            this.btn_ok.IconRightZoom = 0D;
            this.btn_ok.IconVisible = true;
            this.btn_ok.IconZoom = 90D;
            this.btn_ok.IsTab = false;
            this.btn_ok.Location = new System.Drawing.Point(194, 309);
            this.btn_ok.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_ok.Name = "btn_ok";
            this.btn_ok.Normalcolor = System.Drawing.Color.Teal;
            this.btn_ok.OnHovercolor = System.Drawing.Color.DarkGray;
            this.btn_ok.OnHoverTextColor = System.Drawing.Color.Black;
            this.btn_ok.selected = false;
            this.btn_ok.Size = new System.Drawing.Size(192, 55);
            this.btn_ok.TabIndex = 55;
            this.btn_ok.Text = "OK";
            this.btn_ok.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_ok.Textcolor = System.Drawing.Color.White;
            this.btn_ok.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ok.Visible = false;
            this.btn_ok.Click += new System.EventHandler(this.Btn_ok_Click);
            // 
            // dragControl1
            // 
            this.dragControl1.SelectControl = this;
            // 
            // Message1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(565, 389);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btn_ok);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Message1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Message1";
            this.Load += new System.EventHandler(this.Message1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private Project_SDC.DragControl dragControl1;
        public System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Bunifu.Framework.UI.BunifuFlatButton btn_ok;
        private Bunifu.Framework.UI.BunifuFormFadeTransition Transition1;
        private System.Windows.Forms.Timer timer1;
    }
}