﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MssCorsework
{
    public partial class viewDiagnosisDetailsControl : UserControl
    {
        public viewDiagnosisDetailsControl()
        {
            InitializeComponent();
        }

        SQLQueries sqlq = new SQLQueries();
        labReportViewer lrv = new labReportViewer();

        private void Button_Search_Click(object sender, EventArgs e)
        {
            if (Textbox_NIC.Text == "")
            {
                label_pENIC.Visible = true;
                label_pENIC.Text = "Patient's NIC is Required!";
            }
            else
            {
                string searchNIC = Textbox_NIC.Text;

                SqlDataReader dr = sqlq.getHistory(searchNIC);
                if (dr.Read())
                {
                    Textbox_Dia.Text = dr[3].ToString();
                    Textbox_Sym.Text = dr[4].ToString();
                    Textbox_changeDetails.Text = dr[5].ToString();
                    Textbox_remarks.Text = dr[6].ToString();
                    Textbox_prescription.Text = dr[7].ToString();
                    Textbox_labReports.Text = dr[8].ToString();
                }
                else
                {
                    MessageBox.Show("Invalid Patient's or Guardian's NIC", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void Textbox_NIC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_NIC.Text != "")
            {
                label_pENIC.Visible = false;
            }
        }

        private void Button_Report_Click(object sender, EventArgs e)
        {           
            string ID = Textbox_SearchNo.Text;

            if (Textbox_SearchNo.Text == "")
            {
                label_eRepNo.Visible = true;
                label_eRepNo.Text = "Report Number is Required!";
            }
            else
            {
                labReport1 lr = new labReport1();
                SqlConnection con = new SqlConnection();
                con = MSSDBConnection.MSSConnection();
                string labReport = "SELECT * FROM TableLabReports WHERE repNo = " + ID + "";
                DataSet ds = new DataSet();
                SqlDataAdapter sda = new SqlDataAdapter(labReport, con);
                sda.Fill(ds, "TableLabReports");

                lr.SetDataSource(ds.Tables["TableLabReports"]);
                lrv.crystalReportViewer1.ReportSource = lr;
                lrv.crystalReportViewer1.Refresh();
                lrv.Show();
            }
        }

        private void Textbox_SearchNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_SearchNo.Text != "")
            {
                label_eRepNo.Visible = false;
            }
        }
    }
}
