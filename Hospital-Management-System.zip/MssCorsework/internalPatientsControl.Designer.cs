﻿namespace MssCorsework
{
    partial class internalPatientsControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(internalPatientsControl));
            this.bunifuGradientPanel1 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.Textbox_wardNumber = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Label_reports = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_pre = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_NICStatus = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.label_Errors = new System.Windows.Forms.Label();
            this.label_wardNum = new System.Windows.Forms.Label();
            this.label_admission = new System.Windows.Forms.Label();
            this.label_pEAge = new System.Windows.Forms.Label();
            this.label_pEAddress = new System.Windows.Forms.Label();
            this.label_pENIC = new System.Windows.Forms.Label();
            this.label_pEName = new System.Windows.Forms.Label();
            this.Textbox_NIC = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Textbox_Age = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Textbox_AdmissionNum = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Textbox_Address = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Textbox_pName = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Checkbox1 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.Button_Clear = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Button_ADD = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Label_Gender = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_TelephoneNum = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_Age = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_Address = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_NIC = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_Name = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_Title = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.label_rCharge = new System.Windows.Forms.Label();
            this.label_mCharge = new System.Windows.Forms.Label();
            this.label_repCharge = new System.Windows.Forms.Label();
            this.label_totalCharge = new System.Windows.Forms.Label();
            this.bunifuGradientPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.Controls.Add(this.label_totalCharge);
            this.bunifuGradientPanel1.Controls.Add(this.label_repCharge);
            this.bunifuGradientPanel1.Controls.Add(this.label_mCharge);
            this.bunifuGradientPanel1.Controls.Add(this.label_rCharge);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_wardNumber);
            this.bunifuGradientPanel1.Controls.Add(this.Label_reports);
            this.bunifuGradientPanel1.Controls.Add(this.Label_pre);
            this.bunifuGradientPanel1.Controls.Add(this.Label_NICStatus);
            this.bunifuGradientPanel1.Controls.Add(this.label_Errors);
            this.bunifuGradientPanel1.Controls.Add(this.label_wardNum);
            this.bunifuGradientPanel1.Controls.Add(this.label_admission);
            this.bunifuGradientPanel1.Controls.Add(this.label_pEAge);
            this.bunifuGradientPanel1.Controls.Add(this.label_pEAddress);
            this.bunifuGradientPanel1.Controls.Add(this.label_pENIC);
            this.bunifuGradientPanel1.Controls.Add(this.label_pEName);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_NIC);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_Age);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_AdmissionNum);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_Address);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_pName);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuCustomLabel1);
            this.bunifuGradientPanel1.Controls.Add(this.Checkbox1);
            this.bunifuGradientPanel1.Controls.Add(this.Button_Clear);
            this.bunifuGradientPanel1.Controls.Add(this.Button_ADD);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Gender);
            this.bunifuGradientPanel1.Controls.Add(this.Label_TelephoneNum);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Age);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Address);
            this.bunifuGradientPanel1.Controls.Add(this.Label_NIC);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Name);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Title);
            this.bunifuGradientPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.Black;
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.Gray;
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(1140, 812);
            this.bunifuGradientPanel1.TabIndex = 1;
            // 
            // Textbox_wardNumber
            // 
            this.Textbox_wardNumber.BackColor = System.Drawing.Color.Silver;
            this.Textbox_wardNumber.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_wardNumber.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_wardNumber.ForeColor = System.Drawing.Color.Black;
            this.Textbox_wardNumber.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_wardNumber.HintText = "Ward Number";
            this.Textbox_wardNumber.isPassword = false;
            this.Textbox_wardNumber.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_wardNumber.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_wardNumber.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_wardNumber.LineThickness = 3;
            this.Textbox_wardNumber.Location = new System.Drawing.Point(599, 530);
            this.Textbox_wardNumber.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_wardNumber.Name = "Textbox_wardNumber";
            this.Textbox_wardNumber.Size = new System.Drawing.Size(480, 60);
            this.Textbox_wardNumber.TabIndex = 79;
            this.Textbox_wardNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Textbox_wardNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_wardNumber_KeyPress);
            // 
            // Label_reports
            // 
            this.Label_reports.AutoSize = true;
            this.Label_reports.BackColor = System.Drawing.Color.Transparent;
            this.Label_reports.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_reports.ForeColor = System.Drawing.Color.Black;
            this.Label_reports.Location = new System.Drawing.Point(989, 82);
            this.Label_reports.Name = "Label_reports";
            this.Label_reports.Size = new System.Drawing.Size(56, 19);
            this.Label_reports.TabIndex = 78;
            this.Label_reports.Text = "Empty";
            this.Label_reports.Visible = false;
            // 
            // Label_pre
            // 
            this.Label_pre.AutoSize = true;
            this.Label_pre.BackColor = System.Drawing.Color.Transparent;
            this.Label_pre.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_pre.ForeColor = System.Drawing.Color.Black;
            this.Label_pre.Location = new System.Drawing.Point(988, 38);
            this.Label_pre.Name = "Label_pre";
            this.Label_pre.Size = new System.Drawing.Size(56, 19);
            this.Label_pre.TabIndex = 77;
            this.Label_pre.Text = "Empty";
            this.Label_pre.Visible = false;
            // 
            // Label_NICStatus
            // 
            this.Label_NICStatus.AutoSize = true;
            this.Label_NICStatus.BackColor = System.Drawing.Color.Transparent;
            this.Label_NICStatus.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_NICStatus.ForeColor = System.Drawing.Color.Black;
            this.Label_NICStatus.Location = new System.Drawing.Point(989, 127);
            this.Label_NICStatus.Name = "Label_NICStatus";
            this.Label_NICStatus.Size = new System.Drawing.Size(63, 19);
            this.Label_NICStatus.TabIndex = 76;
            this.Label_NICStatus.Text = "Normal";
            this.Label_NICStatus.Visible = false;
            // 
            // label_Errors
            // 
            this.label_Errors.AutoSize = true;
            this.label_Errors.BackColor = System.Drawing.Color.Transparent;
            this.label_Errors.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Errors.ForeColor = System.Drawing.Color.Red;
            this.label_Errors.Location = new System.Drawing.Point(57, 739);
            this.label_Errors.Name = "label_Errors";
            this.label_Errors.Size = new System.Drawing.Size(60, 19);
            this.label_Errors.TabIndex = 75;
            this.label_Errors.Text = "label5";
            this.label_Errors.Visible = false;
            // 
            // label_wardNum
            // 
            this.label_wardNum.AutoSize = true;
            this.label_wardNum.BackColor = System.Drawing.Color.Transparent;
            this.label_wardNum.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_wardNum.ForeColor = System.Drawing.Color.Red;
            this.label_wardNum.Location = new System.Drawing.Point(595, 604);
            this.label_wardNum.Name = "label_wardNum";
            this.label_wardNum.Size = new System.Drawing.Size(60, 19);
            this.label_wardNum.TabIndex = 74;
            this.label_wardNum.Text = "label6";
            this.label_wardNum.Visible = false;
            // 
            // label_admission
            // 
            this.label_admission.AutoSize = true;
            this.label_admission.BackColor = System.Drawing.Color.Transparent;
            this.label_admission.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_admission.ForeColor = System.Drawing.Color.Red;
            this.label_admission.Location = new System.Drawing.Point(57, 604);
            this.label_admission.Name = "label_admission";
            this.label_admission.Size = new System.Drawing.Size(60, 19);
            this.label_admission.TabIndex = 73;
            this.label_admission.Text = "label5";
            this.label_admission.Visible = false;
            // 
            // label_pEAge
            // 
            this.label_pEAge.AutoSize = true;
            this.label_pEAge.BackColor = System.Drawing.Color.Transparent;
            this.label_pEAge.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_pEAge.ForeColor = System.Drawing.Color.Red;
            this.label_pEAge.Location = new System.Drawing.Point(595, 441);
            this.label_pEAge.Name = "label_pEAge";
            this.label_pEAge.Size = new System.Drawing.Size(60, 19);
            this.label_pEAge.TabIndex = 72;
            this.label_pEAge.Text = "label4";
            this.label_pEAge.Visible = false;
            // 
            // label_pEAddress
            // 
            this.label_pEAddress.AutoSize = true;
            this.label_pEAddress.BackColor = System.Drawing.Color.Transparent;
            this.label_pEAddress.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_pEAddress.ForeColor = System.Drawing.Color.Red;
            this.label_pEAddress.Location = new System.Drawing.Point(57, 441);
            this.label_pEAddress.Name = "label_pEAddress";
            this.label_pEAddress.Size = new System.Drawing.Size(60, 19);
            this.label_pEAddress.TabIndex = 71;
            this.label_pEAddress.Text = "label3";
            this.label_pEAddress.Visible = false;
            // 
            // label_pENIC
            // 
            this.label_pENIC.AutoSize = true;
            this.label_pENIC.BackColor = System.Drawing.Color.Transparent;
            this.label_pENIC.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_pENIC.ForeColor = System.Drawing.Color.Red;
            this.label_pENIC.Location = new System.Drawing.Point(57, 283);
            this.label_pENIC.Name = "label_pENIC";
            this.label_pENIC.Size = new System.Drawing.Size(60, 19);
            this.label_pENIC.TabIndex = 70;
            this.label_pENIC.Text = "label2";
            this.label_pENIC.Visible = false;
            // 
            // label_pEName
            // 
            this.label_pEName.AutoSize = true;
            this.label_pEName.BackColor = System.Drawing.Color.Transparent;
            this.label_pEName.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_pEName.ForeColor = System.Drawing.Color.Red;
            this.label_pEName.Location = new System.Drawing.Point(595, 283);
            this.label_pEName.Name = "label_pEName";
            this.label_pEName.Size = new System.Drawing.Size(60, 19);
            this.label_pEName.TabIndex = 69;
            this.label_pEName.Text = "label1";
            this.label_pEName.Visible = false;
            // 
            // Textbox_NIC
            // 
            this.Textbox_NIC.BackColor = System.Drawing.Color.Silver;
            this.Textbox_NIC.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_NIC.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_NIC.ForeColor = System.Drawing.Color.Black;
            this.Textbox_NIC.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_NIC.HintText = "Patient\'s NIC";
            this.Textbox_NIC.isPassword = false;
            this.Textbox_NIC.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_NIC.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_NIC.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_NIC.LineThickness = 3;
            this.Textbox_NIC.Location = new System.Drawing.Point(61, 212);
            this.Textbox_NIC.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_NIC.Name = "Textbox_NIC";
            this.Textbox_NIC.Size = new System.Drawing.Size(480, 60);
            this.Textbox_NIC.TabIndex = 66;
            this.Textbox_NIC.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Textbox_NIC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_NIC_KeyPress);
            // 
            // Textbox_Age
            // 
            this.Textbox_Age.BackColor = System.Drawing.Color.Silver;
            this.Textbox_Age.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_Age.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Age.ForeColor = System.Drawing.Color.Black;
            this.Textbox_Age.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_Age.HintText = "Patient\'s Age";
            this.Textbox_Age.isPassword = false;
            this.Textbox_Age.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_Age.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_Age.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_Age.LineThickness = 3;
            this.Textbox_Age.Location = new System.Drawing.Point(599, 369);
            this.Textbox_Age.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_Age.Name = "Textbox_Age";
            this.Textbox_Age.Size = new System.Drawing.Size(480, 60);
            this.Textbox_Age.TabIndex = 64;
            this.Textbox_Age.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Textbox_Age.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Age_KeyPress);
            // 
            // Textbox_AdmissionNum
            // 
            this.Textbox_AdmissionNum.BackColor = System.Drawing.Color.Silver;
            this.Textbox_AdmissionNum.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_AdmissionNum.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_AdmissionNum.ForeColor = System.Drawing.Color.Black;
            this.Textbox_AdmissionNum.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_AdmissionNum.HintText = "Admission Number";
            this.Textbox_AdmissionNum.isPassword = false;
            this.Textbox_AdmissionNum.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_AdmissionNum.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_AdmissionNum.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_AdmissionNum.LineThickness = 3;
            this.Textbox_AdmissionNum.Location = new System.Drawing.Point(61, 530);
            this.Textbox_AdmissionNum.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_AdmissionNum.Name = "Textbox_AdmissionNum";
            this.Textbox_AdmissionNum.Size = new System.Drawing.Size(480, 60);
            this.Textbox_AdmissionNum.TabIndex = 63;
            this.Textbox_AdmissionNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Textbox_AdmissionNum.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_AdmissionNum_KeyPress);
            // 
            // Textbox_Address
            // 
            this.Textbox_Address.BackColor = System.Drawing.Color.Silver;
            this.Textbox_Address.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_Address.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Address.ForeColor = System.Drawing.Color.Black;
            this.Textbox_Address.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_Address.HintText = "Patient\'s Address";
            this.Textbox_Address.isPassword = false;
            this.Textbox_Address.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_Address.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_Address.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_Address.LineThickness = 3;
            this.Textbox_Address.Location = new System.Drawing.Point(61, 369);
            this.Textbox_Address.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_Address.Name = "Textbox_Address";
            this.Textbox_Address.Size = new System.Drawing.Size(480, 60);
            this.Textbox_Address.TabIndex = 62;
            this.Textbox_Address.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Textbox_Address.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Address_KeyPress);
            // 
            // Textbox_pName
            // 
            this.Textbox_pName.BackColor = System.Drawing.Color.Silver;
            this.Textbox_pName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_pName.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_pName.ForeColor = System.Drawing.Color.Black;
            this.Textbox_pName.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_pName.HintText = "Patient\'s Name";
            this.Textbox_pName.isPassword = false;
            this.Textbox_pName.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_pName.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_pName.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_pName.LineThickness = 3;
            this.Textbox_pName.Location = new System.Drawing.Point(599, 212);
            this.Textbox_pName.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_pName.Name = "Textbox_pName";
            this.Textbox_pName.Size = new System.Drawing.Size(480, 60);
            this.Textbox_pName.TabIndex = 61;
            this.Textbox_pName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Textbox_pName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_pName_KeyPress);
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.Black;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(989, 162);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(62, 19);
            this.bunifuCustomLabel1.TabIndex = 60;
            this.bunifuCustomLabel1.Text = "No NIC";
            this.bunifuCustomLabel1.Visible = false;
            // 
            // Checkbox1
            // 
            this.Checkbox1.BackColor = System.Drawing.Color.Silver;
            this.Checkbox1.ChechedOffColor = System.Drawing.Color.Silver;
            this.Checkbox1.Checked = false;
            this.Checkbox1.CheckedOnColor = System.Drawing.Color.DeepSkyBlue;
            this.Checkbox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Checkbox1.ForeColor = System.Drawing.Color.Black;
            this.Checkbox1.Location = new System.Drawing.Point(1059, 161);
            this.Checkbox1.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.Checkbox1.Name = "Checkbox1";
            this.Checkbox1.Size = new System.Drawing.Size(20, 20);
            this.Checkbox1.TabIndex = 59;
            this.Checkbox1.Visible = false;
            // 
            // Button_Clear
            // 
            this.Button_Clear.Activecolor = System.Drawing.Color.Crimson;
            this.Button_Clear.BackColor = System.Drawing.Color.Crimson;
            this.Button_Clear.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_Clear.BorderRadius = 0;
            this.Button_Clear.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Button_Clear.ButtonText = "CLEAR";
            this.Button_Clear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_Clear.DisabledColor = System.Drawing.Color.Gray;
            this.Button_Clear.ForeColor = System.Drawing.Color.White;
            this.Button_Clear.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_Clear.Iconimage = null;
            this.Button_Clear.Iconimage_right = null;
            this.Button_Clear.Iconimage_right_Selected = null;
            this.Button_Clear.Iconimage_Selected = null;
            this.Button_Clear.IconMarginLeft = 0;
            this.Button_Clear.IconMarginRight = 0;
            this.Button_Clear.IconRightVisible = true;
            this.Button_Clear.IconRightZoom = 0D;
            this.Button_Clear.IconVisible = true;
            this.Button_Clear.IconZoom = 90D;
            this.Button_Clear.IsTab = false;
            this.Button_Clear.Location = new System.Drawing.Point(599, 665);
            this.Button_Clear.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_Clear.Name = "Button_Clear";
            this.Button_Clear.Normalcolor = System.Drawing.Color.Crimson;
            this.Button_Clear.OnHovercolor = System.Drawing.Color.Transparent;
            this.Button_Clear.OnHoverTextColor = System.Drawing.Color.Black;
            this.Button_Clear.selected = false;
            this.Button_Clear.Size = new System.Drawing.Size(480, 64);
            this.Button_Clear.TabIndex = 58;
            this.Button_Clear.Text = "CLEAR";
            this.Button_Clear.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_Clear.Textcolor = System.Drawing.Color.White;
            this.Button_Clear.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Clear.Click += new System.EventHandler(this.Button_Clear_Click);
            // 
            // Button_ADD
            // 
            this.Button_ADD.Activecolor = System.Drawing.Color.ForestGreen;
            this.Button_ADD.BackColor = System.Drawing.Color.ForestGreen;
            this.Button_ADD.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_ADD.BorderRadius = 0;
            this.Button_ADD.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Button_ADD.ButtonText = "ADD";
            this.Button_ADD.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_ADD.DisabledColor = System.Drawing.Color.Gray;
            this.Button_ADD.ForeColor = System.Drawing.Color.White;
            this.Button_ADD.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_ADD.Iconimage = null;
            this.Button_ADD.Iconimage_right = null;
            this.Button_ADD.Iconimage_right_Selected = null;
            this.Button_ADD.Iconimage_Selected = null;
            this.Button_ADD.IconMarginLeft = 0;
            this.Button_ADD.IconMarginRight = 0;
            this.Button_ADD.IconRightVisible = true;
            this.Button_ADD.IconRightZoom = 0D;
            this.Button_ADD.IconVisible = true;
            this.Button_ADD.IconZoom = 90D;
            this.Button_ADD.IsTab = false;
            this.Button_ADD.Location = new System.Drawing.Point(61, 665);
            this.Button_ADD.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_ADD.Name = "Button_ADD";
            this.Button_ADD.Normalcolor = System.Drawing.Color.ForestGreen;
            this.Button_ADD.OnHovercolor = System.Drawing.Color.Transparent;
            this.Button_ADD.OnHoverTextColor = System.Drawing.Color.Black;
            this.Button_ADD.selected = false;
            this.Button_ADD.Size = new System.Drawing.Size(480, 64);
            this.Button_ADD.TabIndex = 57;
            this.Button_ADD.Text = "ADD";
            this.Button_ADD.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_ADD.Textcolor = System.Drawing.Color.White;
            this.Button_ADD.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_ADD.Click += new System.EventHandler(this.Button_ADD_Click);
            // 
            // Label_Gender
            // 
            this.Label_Gender.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Gender.AutoSize = true;
            this.Label_Gender.BackColor = System.Drawing.Color.Transparent;
            this.Label_Gender.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Gender.ForeColor = System.Drawing.Color.Black;
            this.Label_Gender.Location = new System.Drawing.Point(593, 479);
            this.Label_Gender.Name = "Label_Gender";
            this.Label_Gender.Size = new System.Drawing.Size(178, 32);
            this.Label_Gender.TabIndex = 31;
            this.Label_Gender.Text = "Ward Number";
            // 
            // Label_TelephoneNum
            // 
            this.Label_TelephoneNum.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_TelephoneNum.AutoSize = true;
            this.Label_TelephoneNum.BackColor = System.Drawing.Color.Transparent;
            this.Label_TelephoneNum.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_TelephoneNum.ForeColor = System.Drawing.Color.Black;
            this.Label_TelephoneNum.Location = new System.Drawing.Point(55, 479);
            this.Label_TelephoneNum.Name = "Label_TelephoneNum";
            this.Label_TelephoneNum.Size = new System.Drawing.Size(236, 32);
            this.Label_TelephoneNum.TabIndex = 29;
            this.Label_TelephoneNum.Text = "Admission Number";
            // 
            // Label_Age
            // 
            this.Label_Age.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Age.AutoSize = true;
            this.Label_Age.BackColor = System.Drawing.Color.Transparent;
            this.Label_Age.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Age.ForeColor = System.Drawing.Color.Black;
            this.Label_Age.Location = new System.Drawing.Point(593, 318);
            this.Label_Age.Name = "Label_Age";
            this.Label_Age.Size = new System.Drawing.Size(166, 32);
            this.Label_Age.TabIndex = 27;
            this.Label_Age.Text = "Patient\'s Age";
            // 
            // Label_Address
            // 
            this.Label_Address.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Address.AutoSize = true;
            this.Label_Address.BackColor = System.Drawing.Color.Transparent;
            this.Label_Address.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Address.ForeColor = System.Drawing.Color.Black;
            this.Label_Address.Location = new System.Drawing.Point(55, 318);
            this.Label_Address.Name = "Label_Address";
            this.Label_Address.Size = new System.Drawing.Size(213, 32);
            this.Label_Address.TabIndex = 25;
            this.Label_Address.Text = "Patient\'s Address";
            // 
            // Label_NIC
            // 
            this.Label_NIC.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_NIC.AutoSize = true;
            this.Label_NIC.BackColor = System.Drawing.Color.Transparent;
            this.Label_NIC.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_NIC.ForeColor = System.Drawing.Color.Black;
            this.Label_NIC.Location = new System.Drawing.Point(55, 161);
            this.Label_NIC.Name = "Label_NIC";
            this.Label_NIC.Size = new System.Drawing.Size(163, 32);
            this.Label_NIC.TabIndex = 23;
            this.Label_NIC.Text = "Patient\'s NIC";
            // 
            // Label_Name
            // 
            this.Label_Name.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Name.AutoSize = true;
            this.Label_Name.BackColor = System.Drawing.Color.Transparent;
            this.Label_Name.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Name.ForeColor = System.Drawing.Color.Black;
            this.Label_Name.Location = new System.Drawing.Point(593, 161);
            this.Label_Name.Name = "Label_Name";
            this.Label_Name.Size = new System.Drawing.Size(188, 32);
            this.Label_Name.TabIndex = 19;
            this.Label_Name.Text = "Patient\'s Name";
            // 
            // Label_Title
            // 
            this.Label_Title.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Title.AutoSize = true;
            this.Label_Title.BackColor = System.Drawing.Color.Transparent;
            this.Label_Title.Font = new System.Drawing.Font("Felix Titling", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Title.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.Label_Title.Location = new System.Drawing.Point(267, 38);
            this.Label_Title.Name = "Label_Title";
            this.Label_Title.Size = new System.Drawing.Size(615, 35);
            this.Label_Title.TabIndex = 18;
            this.Label_Title.Text = "Add New Internal Patient Details";
            // 
            // label_rCharge
            // 
            this.label_rCharge.AutoSize = true;
            this.label_rCharge.BackColor = System.Drawing.Color.Transparent;
            this.label_rCharge.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_rCharge.ForeColor = System.Drawing.Color.Black;
            this.label_rCharge.Location = new System.Drawing.Point(57, 104);
            this.label_rCharge.Name = "label_rCharge";
            this.label_rCharge.Size = new System.Drawing.Size(19, 19);
            this.label_rCharge.TabIndex = 106;
            this.label_rCharge.Text = "0";
            this.label_rCharge.Visible = false;
            // 
            // label_mCharge
            // 
            this.label_mCharge.AutoSize = true;
            this.label_mCharge.BackColor = System.Drawing.Color.Transparent;
            this.label_mCharge.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_mCharge.ForeColor = System.Drawing.Color.Black;
            this.label_mCharge.Location = new System.Drawing.Point(126, 104);
            this.label_mCharge.Name = "label_mCharge";
            this.label_mCharge.Size = new System.Drawing.Size(19, 19);
            this.label_mCharge.TabIndex = 107;
            this.label_mCharge.Text = "0";
            this.label_mCharge.Visible = false;
            // 
            // label_repCharge
            // 
            this.label_repCharge.AutoSize = true;
            this.label_repCharge.BackColor = System.Drawing.Color.Transparent;
            this.label_repCharge.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_repCharge.ForeColor = System.Drawing.Color.Black;
            this.label_repCharge.Location = new System.Drawing.Point(199, 104);
            this.label_repCharge.Name = "label_repCharge";
            this.label_repCharge.Size = new System.Drawing.Size(19, 19);
            this.label_repCharge.TabIndex = 108;
            this.label_repCharge.Text = "0";
            this.label_repCharge.Visible = false;
            // 
            // label_totalCharge
            // 
            this.label_totalCharge.AutoSize = true;
            this.label_totalCharge.BackColor = System.Drawing.Color.Transparent;
            this.label_totalCharge.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_totalCharge.ForeColor = System.Drawing.Color.Black;
            this.label_totalCharge.Location = new System.Drawing.Point(269, 104);
            this.label_totalCharge.Name = "label_totalCharge";
            this.label_totalCharge.Size = new System.Drawing.Size(19, 19);
            this.label_totalCharge.TabIndex = 109;
            this.label_totalCharge.Text = "0";
            this.label_totalCharge.Visible = false;
            // 
            // internalPatientsControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.bunifuGradientPanel1);
            this.Name = "internalPatientsControl";
            this.Size = new System.Drawing.Size(1140, 812);
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel1;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_NICStatus;
        private System.Windows.Forms.Label label_Errors;
        private System.Windows.Forms.Label label_wardNum;
        private System.Windows.Forms.Label label_admission;
        private System.Windows.Forms.Label label_pEAge;
        private System.Windows.Forms.Label label_pEAddress;
        private System.Windows.Forms.Label label_pENIC;
        private System.Windows.Forms.Label label_pEName;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_NIC;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_Age;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_AdmissionNum;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_Address;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_pName;
        public Bunifu.Framework.UI.BunifuFlatButton Button_Clear;
        public Bunifu.Framework.UI.BunifuFlatButton Button_ADD;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Gender;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_TelephoneNum;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Age;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Address;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_NIC;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Name;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Title;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuCheckbox Checkbox1;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_reports;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_pre;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_wardNumber;
        private System.Windows.Forms.Label label_totalCharge;
        private System.Windows.Forms.Label label_repCharge;
        private System.Windows.Forms.Label label_mCharge;
        private System.Windows.Forms.Label label_rCharge;
    }
}
