﻿namespace MssCorsework
{
    partial class pharmacyControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(pharmacyControl));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.bunifuGradientPanel1 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.label_total = new System.Windows.Forms.Label();
            this.label_sPrice = new System.Windows.Forms.Label();
            this.label_saleP = new System.Windows.Forms.Label();
            this.label_cate = new System.Windows.Forms.Label();
            this.label_relevel = new System.Windows.Forms.Label();
            this.app_Number = new System.Windows.Forms.NumericUpDown();
            this.bunifuSeparator2 = new Bunifu.Framework.UI.BunifuSeparator();
            this.DataGrid1 = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.preName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.costPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.salesPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stocks = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.reorderLevel = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.category = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tablePrescriptionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.mSSDBDataSet2 = new MssCorsework.MSSDBDataSet2();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Textbox_preName = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Textbox_salesPrice = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.btn_result = new Bunifu.Framework.UI.BunifuFlatButton();
            this.label_cost = new System.Windows.Forms.Label();
            this.label_qun = new System.Windows.Forms.Label();
            this.label_stocks = new System.Windows.Forms.Label();
            this.Textbox_cost = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.lbl_totalCharge = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lbl_aTax = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lbl_hCharge = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_dFee = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuSeparator3 = new Bunifu.Framework.UI.BunifuSeparator();
            this.Textbox_prescriptions = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Textbox_diagnosis = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.lbl_doctorName = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lbl_diagnosis = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.label_ID = new System.Windows.Forms.Label();
            this.panel_PresType = new System.Windows.Forms.Panel();
            this.Button_prescriptions = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btn_Type4 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btn_Type3 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btn_Type1 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btn_Type2 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.label_ESearchNIC = new System.Windows.Forms.Label();
            this.bunifuSeparator1 = new Bunifu.Framework.UI.BunifuSeparator();
            this.Button_Search = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Label_SearchNIC = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Textbox_SearchNIC = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label_Errors = new System.Windows.Forms.Label();
            this.Button_SavePayment = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Label_Title = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.preToolStrip = new System.Windows.Forms.ToolStrip();
            this.categoryToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.categoryToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.preToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.tablePrescriptionTableAdapter = new MssCorsework.MSSDBDataSet2TableAdapters.TablePrescriptionTableAdapter();
            this.bunifuGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.app_Number)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGrid1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablePrescriptionBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mSSDBDataSet2)).BeginInit();
            this.panel_PresType.SuspendLayout();
            this.preToolStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.Controls.Add(this.label_total);
            this.bunifuGradientPanel1.Controls.Add(this.label_sPrice);
            this.bunifuGradientPanel1.Controls.Add(this.label_saleP);
            this.bunifuGradientPanel1.Controls.Add(this.label_cate);
            this.bunifuGradientPanel1.Controls.Add(this.label_relevel);
            this.bunifuGradientPanel1.Controls.Add(this.app_Number);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuSeparator2);
            this.bunifuGradientPanel1.Controls.Add(this.DataGrid1);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuCustomLabel1);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_preName);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_salesPrice);
            this.bunifuGradientPanel1.Controls.Add(this.btn_result);
            this.bunifuGradientPanel1.Controls.Add(this.label_cost);
            this.bunifuGradientPanel1.Controls.Add(this.label_qun);
            this.bunifuGradientPanel1.Controls.Add(this.label_stocks);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_cost);
            this.bunifuGradientPanel1.Controls.Add(this.lbl_totalCharge);
            this.bunifuGradientPanel1.Controls.Add(this.lbl_aTax);
            this.bunifuGradientPanel1.Controls.Add(this.lbl_hCharge);
            this.bunifuGradientPanel1.Controls.Add(this.Label_dFee);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuSeparator3);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_prescriptions);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_diagnosis);
            this.bunifuGradientPanel1.Controls.Add(this.lbl_doctorName);
            this.bunifuGradientPanel1.Controls.Add(this.lbl_diagnosis);
            this.bunifuGradientPanel1.Controls.Add(this.label_ID);
            this.bunifuGradientPanel1.Controls.Add(this.panel_PresType);
            this.bunifuGradientPanel1.Controls.Add(this.label_ESearchNIC);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuSeparator1);
            this.bunifuGradientPanel1.Controls.Add(this.Button_Search);
            this.bunifuGradientPanel1.Controls.Add(this.Label_SearchNIC);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_SearchNIC);
            this.bunifuGradientPanel1.Controls.Add(this.label_Errors);
            this.bunifuGradientPanel1.Controls.Add(this.Button_SavePayment);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Title);
            this.bunifuGradientPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.Black;
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.Gray;
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(1140, 816);
            this.bunifuGradientPanel1.TabIndex = 3;
            // 
            // label_total
            // 
            this.label_total.AutoSize = true;
            this.label_total.BackColor = System.Drawing.Color.Transparent;
            this.label_total.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_total.ForeColor = System.Drawing.Color.Red;
            this.label_total.Location = new System.Drawing.Point(698, 143);
            this.label_total.Name = "label_total";
            this.label_total.Size = new System.Drawing.Size(60, 19);
            this.label_total.TabIndex = 131;
            this.label_total.Text = "label5";
            this.label_total.Visible = false;
            // 
            // label_sPrice
            // 
            this.label_sPrice.AutoSize = true;
            this.label_sPrice.BackColor = System.Drawing.Color.Transparent;
            this.label_sPrice.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_sPrice.ForeColor = System.Drawing.Color.Red;
            this.label_sPrice.Location = new System.Drawing.Point(607, 143);
            this.label_sPrice.Name = "label_sPrice";
            this.label_sPrice.Size = new System.Drawing.Size(60, 19);
            this.label_sPrice.TabIndex = 130;
            this.label_sPrice.Text = "label5";
            this.label_sPrice.Visible = false;
            // 
            // label_saleP
            // 
            this.label_saleP.AutoSize = true;
            this.label_saleP.BackColor = System.Drawing.Color.Transparent;
            this.label_saleP.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_saleP.ForeColor = System.Drawing.Color.Red;
            this.label_saleP.Location = new System.Drawing.Point(316, 705);
            this.label_saleP.Name = "label_saleP";
            this.label_saleP.Size = new System.Drawing.Size(60, 19);
            this.label_saleP.TabIndex = 129;
            this.label_saleP.Text = "label5";
            this.label_saleP.Visible = false;
            // 
            // label_cate
            // 
            this.label_cate.AutoSize = true;
            this.label_cate.BackColor = System.Drawing.Color.Transparent;
            this.label_cate.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_cate.ForeColor = System.Drawing.Color.Red;
            this.label_cate.Location = new System.Drawing.Point(1016, 344);
            this.label_cate.Name = "label_cate";
            this.label_cate.Size = new System.Drawing.Size(60, 19);
            this.label_cate.TabIndex = 128;
            this.label_cate.Text = "label5";
            this.label_cate.Visible = false;
            // 
            // label_relevel
            // 
            this.label_relevel.AutoSize = true;
            this.label_relevel.BackColor = System.Drawing.Color.Transparent;
            this.label_relevel.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_relevel.ForeColor = System.Drawing.Color.Red;
            this.label_relevel.Location = new System.Drawing.Point(921, 344);
            this.label_relevel.Name = "label_relevel";
            this.label_relevel.Size = new System.Drawing.Size(60, 19);
            this.label_relevel.TabIndex = 127;
            this.label_relevel.Text = "label5";
            this.label_relevel.Visible = false;
            // 
            // app_Number
            // 
            this.app_Number.BackColor = System.Drawing.Color.Silver;
            this.app_Number.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.app_Number.Location = new System.Drawing.Point(598, 649);
            this.app_Number.MinimumSize = new System.Drawing.Size(90, 0);
            this.app_Number.Name = "app_Number";
            this.app_Number.Size = new System.Drawing.Size(137, 30);
            this.app_Number.TabIndex = 126;
            // 
            // bunifuSeparator2
            // 
            this.bunifuSeparator2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator2.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator2.LineThickness = 2;
            this.bunifuSeparator2.Location = new System.Drawing.Point(61, 584);
            this.bunifuSeparator2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator2.Name = "bunifuSeparator2";
            this.bunifuSeparator2.Size = new System.Drawing.Size(1018, 10);
            this.bunifuSeparator2.TabIndex = 125;
            this.bunifuSeparator2.Transparency = 255;
            this.bunifuSeparator2.Vertical = false;
            // 
            // DataGrid1
            // 
            this.DataGrid1.AllowUserToAddRows = false;
            this.DataGrid1.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.DataGrid1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.DataGrid1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DataGrid1.AutoGenerateColumns = false;
            this.DataGrid1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DataGrid1.BackgroundColor = System.Drawing.Color.White;
            this.DataGrid1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DataGrid1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.DataGrid1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DataGrid1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.DataGrid1.ColumnHeadersHeight = 35;
            this.DataGrid1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.preName,
            this.costPrice,
            this.salesPrice,
            this.stocks,
            this.reorderLevel,
            this.category});
            this.DataGrid1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DataGrid1.DataSource = this.tablePrescriptionBindingSource;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Century", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DataGrid1.DefaultCellStyle = dataGridViewCellStyle3;
            this.DataGrid1.DoubleBuffered = true;
            this.DataGrid1.EnableHeadersVisualStyles = false;
            this.DataGrid1.GridColor = System.Drawing.Color.White;
            this.DataGrid1.HeaderBgColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.DataGrid1.HeaderForeColor = System.Drawing.Color.White;
            this.DataGrid1.Location = new System.Drawing.Point(66, 398);
            this.DataGrid1.MultiSelect = false;
            this.DataGrid1.Name = "DataGrid1";
            this.DataGrid1.ReadOnly = true;
            this.DataGrid1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Century", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DataGrid1.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.DataGrid1.RowHeadersVisible = false;
            this.DataGrid1.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.White;
            this.DataGrid1.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Century", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DataGrid1.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.DataGrid1.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Silver;
            this.DataGrid1.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.DataGrid1.RowTemplate.DividerHeight = 3;
            this.DataGrid1.RowTemplate.Height = 40;
            this.DataGrid1.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.DataGrid1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DataGrid1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DataGrid1.Size = new System.Drawing.Size(1013, 183);
            this.DataGrid1.TabIndex = 124;
            this.DataGrid1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGrid1_CellContentClick);
            this.DataGrid1.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.DataGrid1_CellMouseClick);
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // preName
            // 
            this.preName.DataPropertyName = "preName";
            this.preName.HeaderText = "Pre. Name";
            this.preName.Name = "preName";
            this.preName.ReadOnly = true;
            // 
            // costPrice
            // 
            this.costPrice.DataPropertyName = "costPrice";
            this.costPrice.HeaderText = "Cost Price";
            this.costPrice.Name = "costPrice";
            this.costPrice.ReadOnly = true;
            // 
            // salesPrice
            // 
            this.salesPrice.DataPropertyName = "salesPrice";
            this.salesPrice.HeaderText = "Sales Price";
            this.salesPrice.Name = "salesPrice";
            this.salesPrice.ReadOnly = true;
            // 
            // stocks
            // 
            this.stocks.DataPropertyName = "stocks";
            this.stocks.HeaderText = "Stocks";
            this.stocks.Name = "stocks";
            this.stocks.ReadOnly = true;
            // 
            // reorderLevel
            // 
            this.reorderLevel.DataPropertyName = "reorderLevel";
            this.reorderLevel.HeaderText = "R. Level";
            this.reorderLevel.Name = "reorderLevel";
            this.reorderLevel.ReadOnly = true;
            // 
            // category
            // 
            this.category.DataPropertyName = "Category";
            this.category.HeaderText = "Category";
            this.category.Name = "category";
            this.category.ReadOnly = true;
            // 
            // tablePrescriptionBindingSource
            // 
            this.tablePrescriptionBindingSource.DataMember = "TablePrescription";
            this.tablePrescriptionBindingSource.DataSource = this.mSSDBDataSet2;
            // 
            // mSSDBDataSet2
            // 
            this.mSSDBDataSet2.DataSetName = "MSSDBDataSet2";
            this.mSSDBDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.Black;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(60, 349);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(282, 32);
            this.bunifuCustomLabel1.TabIndex = 123;
            this.bunifuCustomLabel1.Text = "Prescription Categories";
            // 
            // Textbox_preName
            // 
            this.Textbox_preName.BackColor = System.Drawing.Color.Silver;
            this.Textbox_preName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_preName.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_preName.ForeColor = System.Drawing.Color.Black;
            this.Textbox_preName.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_preName.HintText = "Pre. Name ";
            this.Textbox_preName.isPassword = false;
            this.Textbox_preName.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_preName.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_preName.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_preName.LineThickness = 3;
            this.Textbox_preName.Location = new System.Drawing.Point(66, 635);
            this.Textbox_preName.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_preName.Name = "Textbox_preName";
            this.Textbox_preName.Size = new System.Drawing.Size(208, 58);
            this.Textbox_preName.TabIndex = 122;
            this.Textbox_preName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // Textbox_salesPrice
            // 
            this.Textbox_salesPrice.BackColor = System.Drawing.Color.Silver;
            this.Textbox_salesPrice.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_salesPrice.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_salesPrice.ForeColor = System.Drawing.Color.Black;
            this.Textbox_salesPrice.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_salesPrice.HintText = "Sales price";
            this.Textbox_salesPrice.isPassword = false;
            this.Textbox_salesPrice.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_salesPrice.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_salesPrice.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_salesPrice.LineThickness = 3;
            this.Textbox_salesPrice.Location = new System.Drawing.Point(320, 635);
            this.Textbox_salesPrice.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_salesPrice.Name = "Textbox_salesPrice";
            this.Textbox_salesPrice.Size = new System.Drawing.Size(208, 58);
            this.Textbox_salesPrice.TabIndex = 121;
            this.Textbox_salesPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // btn_result
            // 
            this.btn_result.Activecolor = System.Drawing.Color.RoyalBlue;
            this.btn_result.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn_result.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_result.BorderRadius = 0;
            this.btn_result.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.btn_result.ButtonText = "TOTAL";
            this.btn_result.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_result.DisabledColor = System.Drawing.Color.Gray;
            this.btn_result.ForeColor = System.Drawing.Color.White;
            this.btn_result.Iconcolor = System.Drawing.Color.Transparent;
            this.btn_result.Iconimage = null;
            this.btn_result.Iconimage_right = null;
            this.btn_result.Iconimage_right_Selected = null;
            this.btn_result.Iconimage_Selected = null;
            this.btn_result.IconMarginLeft = 0;
            this.btn_result.IconMarginRight = 0;
            this.btn_result.IconRightVisible = true;
            this.btn_result.IconRightZoom = 0D;
            this.btn_result.IconVisible = true;
            this.btn_result.IconZoom = 90D;
            this.btn_result.IsTab = false;
            this.btn_result.Location = new System.Drawing.Point(599, 728);
            this.btn_result.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_result.Name = "btn_result";
            this.btn_result.Normalcolor = System.Drawing.Color.RoyalBlue;
            this.btn_result.OnHovercolor = System.Drawing.Color.Transparent;
            this.btn_result.OnHoverTextColor = System.Drawing.Color.Black;
            this.btn_result.selected = false;
            this.btn_result.Size = new System.Drawing.Size(480, 64);
            this.btn_result.TabIndex = 118;
            this.btn_result.Text = "TOTAL";
            this.btn_result.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_result.Textcolor = System.Drawing.Color.White;
            this.btn_result.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_result.Click += new System.EventHandler(this.Btn_result_Click);
            // 
            // label_cost
            // 
            this.label_cost.AutoSize = true;
            this.label_cost.BackColor = System.Drawing.Color.Transparent;
            this.label_cost.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_cost.ForeColor = System.Drawing.Color.Red;
            this.label_cost.Location = new System.Drawing.Point(753, 344);
            this.label_cost.Name = "label_cost";
            this.label_cost.Size = new System.Drawing.Size(60, 19);
            this.label_cost.TabIndex = 116;
            this.label_cost.Text = "label5";
            this.label_cost.Visible = false;
            // 
            // label_qun
            // 
            this.label_qun.AutoSize = true;
            this.label_qun.BackColor = System.Drawing.Color.Transparent;
            this.label_qun.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_qun.ForeColor = System.Drawing.Color.Red;
            this.label_qun.Location = new System.Drawing.Point(595, 695);
            this.label_qun.Name = "label_qun";
            this.label_qun.Size = new System.Drawing.Size(60, 19);
            this.label_qun.TabIndex = 115;
            this.label_qun.Text = "label5";
            this.label_qun.Visible = false;
            // 
            // label_stocks
            // 
            this.label_stocks.AutoSize = true;
            this.label_stocks.BackColor = System.Drawing.Color.Transparent;
            this.label_stocks.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_stocks.ForeColor = System.Drawing.Color.Red;
            this.label_stocks.Location = new System.Drawing.Point(836, 344);
            this.label_stocks.Name = "label_stocks";
            this.label_stocks.Size = new System.Drawing.Size(60, 19);
            this.label_stocks.TabIndex = 114;
            this.label_stocks.Text = "label5";
            this.label_stocks.Visible = false;
            // 
            // Textbox_cost
            // 
            this.Textbox_cost.BackColor = System.Drawing.Color.Silver;
            this.Textbox_cost.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_cost.Enabled = false;
            this.Textbox_cost.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_cost.ForeColor = System.Drawing.Color.Black;
            this.Textbox_cost.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_cost.HintText = "Total Cost";
            this.Textbox_cost.isPassword = false;
            this.Textbox_cost.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_cost.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_cost.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_cost.LineThickness = 3;
            this.Textbox_cost.Location = new System.Drawing.Point(823, 635);
            this.Textbox_cost.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_cost.Name = "Textbox_cost";
            this.Textbox_cost.Size = new System.Drawing.Size(253, 58);
            this.Textbox_cost.TabIndex = 113;
            this.Textbox_cost.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // lbl_totalCharge
            // 
            this.lbl_totalCharge.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_totalCharge.AutoSize = true;
            this.lbl_totalCharge.BackColor = System.Drawing.Color.Transparent;
            this.lbl_totalCharge.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_totalCharge.ForeColor = System.Drawing.Color.Black;
            this.lbl_totalCharge.Location = new System.Drawing.Point(817, 598);
            this.lbl_totalCharge.Name = "lbl_totalCharge";
            this.lbl_totalCharge.Size = new System.Drawing.Size(199, 32);
            this.lbl_totalCharge.TabIndex = 112;
            this.lbl_totalCharge.Text = "Total Cost (LKR)";
            // 
            // lbl_aTax
            // 
            this.lbl_aTax.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_aTax.AutoSize = true;
            this.lbl_aTax.BackColor = System.Drawing.Color.Transparent;
            this.lbl_aTax.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_aTax.ForeColor = System.Drawing.Color.Black;
            this.lbl_aTax.Location = new System.Drawing.Point(593, 598);
            this.lbl_aTax.Name = "lbl_aTax";
            this.lbl_aTax.Size = new System.Drawing.Size(114, 32);
            this.lbl_aTax.TabIndex = 109;
            this.lbl_aTax.Text = "Quantity";
            // 
            // lbl_hCharge
            // 
            this.lbl_hCharge.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_hCharge.AutoSize = true;
            this.lbl_hCharge.BackColor = System.Drawing.Color.Transparent;
            this.lbl_hCharge.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_hCharge.ForeColor = System.Drawing.Color.Black;
            this.lbl_hCharge.Location = new System.Drawing.Point(314, 598);
            this.lbl_hCharge.Name = "lbl_hCharge";
            this.lbl_hCharge.Size = new System.Drawing.Size(136, 32);
            this.lbl_hCharge.TabIndex = 106;
            this.lbl_hCharge.Text = "Sales price";
            // 
            // Label_dFee
            // 
            this.Label_dFee.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_dFee.AutoSize = true;
            this.Label_dFee.BackColor = System.Drawing.Color.Transparent;
            this.Label_dFee.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_dFee.ForeColor = System.Drawing.Color.Black;
            this.Label_dFee.Location = new System.Drawing.Point(60, 598);
            this.Label_dFee.Name = "Label_dFee";
            this.Label_dFee.Size = new System.Drawing.Size(141, 32);
            this.Label_dFee.TabIndex = 103;
            this.Label_dFee.Text = "Pre. Name ";
            // 
            // bunifuSeparator3
            // 
            this.bunifuSeparator3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator3.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator3.LineThickness = 2;
            this.bunifuSeparator3.Location = new System.Drawing.Point(61, 326);
            this.bunifuSeparator3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator3.Name = "bunifuSeparator3";
            this.bunifuSeparator3.Size = new System.Drawing.Size(1018, 10);
            this.bunifuSeparator3.TabIndex = 102;
            this.bunifuSeparator3.Transparency = 255;
            this.bunifuSeparator3.Vertical = false;
            // 
            // Textbox_prescriptions
            // 
            this.Textbox_prescriptions.BackColor = System.Drawing.Color.Silver;
            this.Textbox_prescriptions.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_prescriptions.Enabled = false;
            this.Textbox_prescriptions.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_prescriptions.ForeColor = System.Drawing.Color.Black;
            this.Textbox_prescriptions.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_prescriptions.HintText = "Prescriptions";
            this.Textbox_prescriptions.isPassword = false;
            this.Textbox_prescriptions.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_prescriptions.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_prescriptions.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_prescriptions.LineThickness = 3;
            this.Textbox_prescriptions.Location = new System.Drawing.Point(598, 220);
            this.Textbox_prescriptions.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_prescriptions.Name = "Textbox_prescriptions";
            this.Textbox_prescriptions.Size = new System.Drawing.Size(480, 87);
            this.Textbox_prescriptions.TabIndex = 101;
            this.Textbox_prescriptions.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // Textbox_diagnosis
            // 
            this.Textbox_diagnosis.BackColor = System.Drawing.Color.Silver;
            this.Textbox_diagnosis.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_diagnosis.Enabled = false;
            this.Textbox_diagnosis.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_diagnosis.ForeColor = System.Drawing.Color.Black;
            this.Textbox_diagnosis.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_diagnosis.HintText = "Diagnosis";
            this.Textbox_diagnosis.isPassword = false;
            this.Textbox_diagnosis.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_diagnosis.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_diagnosis.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_diagnosis.LineThickness = 3;
            this.Textbox_diagnosis.Location = new System.Drawing.Point(63, 220);
            this.Textbox_diagnosis.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_diagnosis.Name = "Textbox_diagnosis";
            this.Textbox_diagnosis.Size = new System.Drawing.Size(493, 87);
            this.Textbox_diagnosis.TabIndex = 100;
            this.Textbox_diagnosis.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // lbl_doctorName
            // 
            this.lbl_doctorName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_doctorName.AutoSize = true;
            this.lbl_doctorName.BackColor = System.Drawing.Color.Transparent;
            this.lbl_doctorName.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_doctorName.ForeColor = System.Drawing.Color.Black;
            this.lbl_doctorName.Location = new System.Drawing.Point(593, 182);
            this.lbl_doctorName.Name = "lbl_doctorName";
            this.lbl_doctorName.Size = new System.Drawing.Size(165, 32);
            this.lbl_doctorName.TabIndex = 99;
            this.lbl_doctorName.Text = "Prescriptions";
            // 
            // lbl_diagnosis
            // 
            this.lbl_diagnosis.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_diagnosis.AutoSize = true;
            this.lbl_diagnosis.BackColor = System.Drawing.Color.Transparent;
            this.lbl_diagnosis.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_diagnosis.ForeColor = System.Drawing.Color.Black;
            this.lbl_diagnosis.Location = new System.Drawing.Point(60, 181);
            this.lbl_diagnosis.Name = "lbl_diagnosis";
            this.lbl_diagnosis.Size = new System.Drawing.Size(127, 32);
            this.lbl_diagnosis.TabIndex = 98;
            this.lbl_diagnosis.Text = "Diagnosis";
            // 
            // label_ID
            // 
            this.label_ID.AutoSize = true;
            this.label_ID.BackColor = System.Drawing.Color.Transparent;
            this.label_ID.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ID.ForeColor = System.Drawing.Color.Black;
            this.label_ID.Location = new System.Drawing.Point(1053, 27);
            this.label_ID.Name = "label_ID";
            this.label_ID.Size = new System.Drawing.Size(26, 19);
            this.label_ID.TabIndex = 95;
            this.label_ID.Text = "ID";
            this.label_ID.Visible = false;
            // 
            // panel_PresType
            // 
            this.panel_PresType.BackColor = System.Drawing.Color.Transparent;
            this.panel_PresType.Controls.Add(this.Button_prescriptions);
            this.panel_PresType.Controls.Add(this.btn_Type4);
            this.panel_PresType.Controls.Add(this.btn_Type3);
            this.panel_PresType.Controls.Add(this.btn_Type1);
            this.panel_PresType.Controls.Add(this.btn_Type2);
            this.panel_PresType.Location = new System.Drawing.Point(356, 343);
            this.panel_PresType.MaximumSize = new System.Drawing.Size(387, 216);
            this.panel_PresType.MinimumSize = new System.Drawing.Size(387, 45);
            this.panel_PresType.Name = "panel_PresType";
            this.panel_PresType.Size = new System.Drawing.Size(387, 45);
            this.panel_PresType.TabIndex = 88;
            // 
            // Button_prescriptions
            // 
            this.Button_prescriptions.Activecolor = System.Drawing.Color.DarkGoldenrod;
            this.Button_prescriptions.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.Button_prescriptions.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_prescriptions.BorderRadius = 0;
            this.Button_prescriptions.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Button_prescriptions.ButtonText = "Prescription Category";
            this.Button_prescriptions.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_prescriptions.DisabledColor = System.Drawing.Color.Gray;
            this.Button_prescriptions.ForeColor = System.Drawing.Color.White;
            this.Button_prescriptions.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_prescriptions.Iconimage = null;
            this.Button_prescriptions.Iconimage_right = null;
            this.Button_prescriptions.Iconimage_right_Selected = null;
            this.Button_prescriptions.Iconimage_Selected = null;
            this.Button_prescriptions.IconMarginLeft = 0;
            this.Button_prescriptions.IconMarginRight = 0;
            this.Button_prescriptions.IconRightVisible = true;
            this.Button_prescriptions.IconRightZoom = 0D;
            this.Button_prescriptions.IconVisible = true;
            this.Button_prescriptions.IconZoom = 90D;
            this.Button_prescriptions.IsTab = false;
            this.Button_prescriptions.Location = new System.Drawing.Point(1, 1);
            this.Button_prescriptions.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_prescriptions.Name = "Button_prescriptions";
            this.Button_prescriptions.Normalcolor = System.Drawing.Color.DarkGoldenrod;
            this.Button_prescriptions.OnHovercolor = System.Drawing.Color.Transparent;
            this.Button_prescriptions.OnHoverTextColor = System.Drawing.Color.Black;
            this.Button_prescriptions.selected = false;
            this.Button_prescriptions.Size = new System.Drawing.Size(387, 45);
            this.Button_prescriptions.TabIndex = 124;
            this.Button_prescriptions.Text = "Prescription Category";
            this.Button_prescriptions.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_prescriptions.Textcolor = System.Drawing.Color.White;
            this.Button_prescriptions.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_prescriptions.Click += new System.EventHandler(this.Button_prescriptions_Click);
            // 
            // btn_Type4
            // 
            this.btn_Type4.Activecolor = System.Drawing.Color.SteelBlue;
            this.btn_Type4.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_Type4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Type4.BorderRadius = 0;
            this.btn_Type4.ButtonText = "Antibiotics";
            this.btn_Type4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Type4.DisabledColor = System.Drawing.Color.Gray;
            this.btn_Type4.Iconcolor = System.Drawing.Color.Transparent;
            this.btn_Type4.Iconimage = null;
            this.btn_Type4.Iconimage_right = null;
            this.btn_Type4.Iconimage_right_Selected = null;
            this.btn_Type4.Iconimage_Selected = null;
            this.btn_Type4.IconMarginLeft = 0;
            this.btn_Type4.IconMarginRight = 0;
            this.btn_Type4.IconRightVisible = true;
            this.btn_Type4.IconRightZoom = 0D;
            this.btn_Type4.IconVisible = true;
            this.btn_Type4.IconZoom = 90D;
            this.btn_Type4.IsTab = false;
            this.btn_Type4.Location = new System.Drawing.Point(0, 176);
            this.btn_Type4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Type4.Name = "btn_Type4";
            this.btn_Type4.Normalcolor = System.Drawing.Color.SteelBlue;
            this.btn_Type4.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.btn_Type4.OnHoverTextColor = System.Drawing.Color.White;
            this.btn_Type4.selected = false;
            this.btn_Type4.Size = new System.Drawing.Size(387, 42);
            this.btn_Type4.TabIndex = 60;
            this.btn_Type4.Text = "Antibiotics";
            this.btn_Type4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Type4.Textcolor = System.Drawing.Color.White;
            this.btn_Type4.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Type4.Click += new System.EventHandler(this.Btn_Type4_Click);
            // 
            // btn_Type3
            // 
            this.btn_Type3.Activecolor = System.Drawing.Color.SteelBlue;
            this.btn_Type3.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_Type3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Type3.BorderRadius = 0;
            this.btn_Type3.ButtonText = "Antiseptics";
            this.btn_Type3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Type3.DisabledColor = System.Drawing.Color.Gray;
            this.btn_Type3.Iconcolor = System.Drawing.Color.Transparent;
            this.btn_Type3.Iconimage = null;
            this.btn_Type3.Iconimage_right = null;
            this.btn_Type3.Iconimage_right_Selected = null;
            this.btn_Type3.Iconimage_Selected = null;
            this.btn_Type3.IconMarginLeft = 0;
            this.btn_Type3.IconMarginRight = 0;
            this.btn_Type3.IconRightVisible = true;
            this.btn_Type3.IconRightZoom = 0D;
            this.btn_Type3.IconVisible = true;
            this.btn_Type3.IconZoom = 90D;
            this.btn_Type3.IsTab = false;
            this.btn_Type3.Location = new System.Drawing.Point(0, 133);
            this.btn_Type3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Type3.Name = "btn_Type3";
            this.btn_Type3.Normalcolor = System.Drawing.Color.SteelBlue;
            this.btn_Type3.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.btn_Type3.OnHoverTextColor = System.Drawing.Color.White;
            this.btn_Type3.selected = false;
            this.btn_Type3.Size = new System.Drawing.Size(387, 42);
            this.btn_Type3.TabIndex = 59;
            this.btn_Type3.Text = "Antiseptics";
            this.btn_Type3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Type3.Textcolor = System.Drawing.Color.White;
            this.btn_Type3.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Type3.Click += new System.EventHandler(this.Btn_Type3_Click);
            // 
            // btn_Type1
            // 
            this.btn_Type1.Activecolor = System.Drawing.Color.SteelBlue;
            this.btn_Type1.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_Type1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Type1.BorderRadius = 0;
            this.btn_Type1.ButtonText = "Antipyretics";
            this.btn_Type1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Type1.DisabledColor = System.Drawing.Color.Gray;
            this.btn_Type1.Iconcolor = System.Drawing.Color.Transparent;
            this.btn_Type1.Iconimage = null;
            this.btn_Type1.Iconimage_right = null;
            this.btn_Type1.Iconimage_right_Selected = null;
            this.btn_Type1.Iconimage_Selected = null;
            this.btn_Type1.IconMarginLeft = 0;
            this.btn_Type1.IconMarginRight = 0;
            this.btn_Type1.IconRightVisible = true;
            this.btn_Type1.IconRightZoom = 0D;
            this.btn_Type1.IconVisible = true;
            this.btn_Type1.IconZoom = 90D;
            this.btn_Type1.IsTab = false;
            this.btn_Type1.Location = new System.Drawing.Point(0, 47);
            this.btn_Type1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Type1.Name = "btn_Type1";
            this.btn_Type1.Normalcolor = System.Drawing.Color.SteelBlue;
            this.btn_Type1.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.btn_Type1.OnHoverTextColor = System.Drawing.Color.White;
            this.btn_Type1.selected = false;
            this.btn_Type1.Size = new System.Drawing.Size(387, 42);
            this.btn_Type1.TabIndex = 25;
            this.btn_Type1.Text = "Antipyretics";
            this.btn_Type1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Type1.Textcolor = System.Drawing.Color.White;
            this.btn_Type1.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Type1.Click += new System.EventHandler(this.Btn_Type1_Click);
            // 
            // btn_Type2
            // 
            this.btn_Type2.Activecolor = System.Drawing.Color.SteelBlue;
            this.btn_Type2.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_Type2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Type2.BorderRadius = 0;
            this.btn_Type2.ButtonText = "Analgesics";
            this.btn_Type2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Type2.DisabledColor = System.Drawing.Color.Gray;
            this.btn_Type2.Iconcolor = System.Drawing.Color.Transparent;
            this.btn_Type2.Iconimage = null;
            this.btn_Type2.Iconimage_right = null;
            this.btn_Type2.Iconimage_right_Selected = null;
            this.btn_Type2.Iconimage_Selected = null;
            this.btn_Type2.IconMarginLeft = 0;
            this.btn_Type2.IconMarginRight = 0;
            this.btn_Type2.IconRightVisible = true;
            this.btn_Type2.IconRightZoom = 0D;
            this.btn_Type2.IconVisible = true;
            this.btn_Type2.IconZoom = 90D;
            this.btn_Type2.IsTab = false;
            this.btn_Type2.Location = new System.Drawing.Point(0, 90);
            this.btn_Type2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Type2.Name = "btn_Type2";
            this.btn_Type2.Normalcolor = System.Drawing.Color.SteelBlue;
            this.btn_Type2.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.btn_Type2.OnHoverTextColor = System.Drawing.Color.White;
            this.btn_Type2.selected = false;
            this.btn_Type2.Size = new System.Drawing.Size(387, 42);
            this.btn_Type2.TabIndex = 26;
            this.btn_Type2.Text = "Analgesics";
            this.btn_Type2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Type2.Textcolor = System.Drawing.Color.White;
            this.btn_Type2.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Type2.Click += new System.EventHandler(this.Btn_Type2_Click);
            // 
            // label_ESearchNIC
            // 
            this.label_ESearchNIC.AutoSize = true;
            this.label_ESearchNIC.BackColor = System.Drawing.Color.Transparent;
            this.label_ESearchNIC.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ESearchNIC.ForeColor = System.Drawing.Color.Red;
            this.label_ESearchNIC.Location = new System.Drawing.Point(60, 143);
            this.label_ESearchNIC.Name = "label_ESearchNIC";
            this.label_ESearchNIC.Size = new System.Drawing.Size(60, 19);
            this.label_ESearchNIC.TabIndex = 85;
            this.label_ESearchNIC.Text = "label5";
            this.label_ESearchNIC.Visible = false;
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator1.LineThickness = 2;
            this.bunifuSeparator1.Location = new System.Drawing.Point(64, 168);
            this.bunifuSeparator1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Size = new System.Drawing.Size(1015, 10);
            this.bunifuSeparator1.TabIndex = 84;
            this.bunifuSeparator1.Transparency = 255;
            this.bunifuSeparator1.Vertical = false;
            // 
            // Button_Search
            // 
            this.Button_Search.Activecolor = System.Drawing.Color.DarkViolet;
            this.Button_Search.BackColor = System.Drawing.Color.DarkViolet;
            this.Button_Search.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_Search.BorderRadius = 0;
            this.Button_Search.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Button_Search.ButtonText = "SEARCH";
            this.Button_Search.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_Search.DisabledColor = System.Drawing.Color.Gray;
            this.Button_Search.ForeColor = System.Drawing.Color.White;
            this.Button_Search.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_Search.Iconimage = null;
            this.Button_Search.Iconimage_right = null;
            this.Button_Search.Iconimage_right_Selected = null;
            this.Button_Search.Iconimage_Selected = null;
            this.Button_Search.IconMarginLeft = 0;
            this.Button_Search.IconMarginRight = 0;
            this.Button_Search.IconRightVisible = true;
            this.Button_Search.IconRightZoom = 0D;
            this.Button_Search.IconVisible = true;
            this.Button_Search.IconZoom = 90D;
            this.Button_Search.IsTab = false;
            this.Button_Search.Location = new System.Drawing.Point(876, 75);
            this.Button_Search.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_Search.Name = "Button_Search";
            this.Button_Search.Normalcolor = System.Drawing.Color.DarkViolet;
            this.Button_Search.OnHovercolor = System.Drawing.Color.Transparent;
            this.Button_Search.OnHoverTextColor = System.Drawing.Color.Black;
            this.Button_Search.selected = false;
            this.Button_Search.Size = new System.Drawing.Size(167, 55);
            this.Button_Search.TabIndex = 83;
            this.Button_Search.Text = "SEARCH";
            this.Button_Search.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_Search.Textcolor = System.Drawing.Color.White;
            this.Button_Search.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Search.Click += new System.EventHandler(this.Button_Search_Click);
            // 
            // Label_SearchNIC
            // 
            this.Label_SearchNIC.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_SearchNIC.AutoSize = true;
            this.Label_SearchNIC.BackColor = System.Drawing.Color.Transparent;
            this.Label_SearchNIC.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SearchNIC.ForeColor = System.Drawing.Color.Black;
            this.Label_SearchNIC.Location = new System.Drawing.Point(102, 86);
            this.Label_SearchNIC.Name = "Label_SearchNIC";
            this.Label_SearchNIC.Size = new System.Drawing.Size(315, 32);
            this.Label_SearchNIC.TabIndex = 82;
            this.Label_SearchNIC.Text = "Patient\'s Or Gurdian\'s NIC";
            // 
            // Textbox_SearchNIC
            // 
            this.Textbox_SearchNIC.BackColor = System.Drawing.Color.Silver;
            this.Textbox_SearchNIC.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_SearchNIC.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_SearchNIC.ForeColor = System.Drawing.Color.Black;
            this.Textbox_SearchNIC.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_SearchNIC.HintText = "Patient\'s NIC";
            this.Textbox_SearchNIC.isPassword = false;
            this.Textbox_SearchNIC.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_SearchNIC.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_SearchNIC.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_SearchNIC.LineThickness = 3;
            this.Textbox_SearchNIC.Location = new System.Drawing.Point(442, 79);
            this.Textbox_SearchNIC.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_SearchNIC.Name = "Textbox_SearchNIC";
            this.Textbox_SearchNIC.Size = new System.Drawing.Size(400, 45);
            this.Textbox_SearchNIC.TabIndex = 81;
            this.Textbox_SearchNIC.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label_Errors
            // 
            this.label_Errors.AutoSize = true;
            this.label_Errors.BackColor = System.Drawing.Color.Transparent;
            this.label_Errors.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Errors.ForeColor = System.Drawing.Color.Red;
            this.label_Errors.Location = new System.Drawing.Point(819, 705);
            this.label_Errors.Name = "label_Errors";
            this.label_Errors.Size = new System.Drawing.Size(60, 19);
            this.label_Errors.TabIndex = 75;
            this.label_Errors.Text = "label5";
            this.label_Errors.Visible = false;
            // 
            // Button_SavePayment
            // 
            this.Button_SavePayment.Activecolor = System.Drawing.Color.ForestGreen;
            this.Button_SavePayment.BackColor = System.Drawing.Color.ForestGreen;
            this.Button_SavePayment.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_SavePayment.BorderRadius = 0;
            this.Button_SavePayment.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Button_SavePayment.ButtonText = "ADD TO BILL";
            this.Button_SavePayment.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_SavePayment.DisabledColor = System.Drawing.Color.Gray;
            this.Button_SavePayment.ForeColor = System.Drawing.Color.White;
            this.Button_SavePayment.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_SavePayment.Iconimage = null;
            this.Button_SavePayment.Iconimage_right = null;
            this.Button_SavePayment.Iconimage_right_Selected = null;
            this.Button_SavePayment.Iconimage_Selected = null;
            this.Button_SavePayment.IconMarginLeft = 0;
            this.Button_SavePayment.IconMarginRight = 0;
            this.Button_SavePayment.IconRightVisible = true;
            this.Button_SavePayment.IconRightZoom = 0D;
            this.Button_SavePayment.IconVisible = true;
            this.Button_SavePayment.IconZoom = 90D;
            this.Button_SavePayment.IsTab = false;
            this.Button_SavePayment.Location = new System.Drawing.Point(61, 728);
            this.Button_SavePayment.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_SavePayment.Name = "Button_SavePayment";
            this.Button_SavePayment.Normalcolor = System.Drawing.Color.ForestGreen;
            this.Button_SavePayment.OnHovercolor = System.Drawing.Color.Transparent;
            this.Button_SavePayment.OnHoverTextColor = System.Drawing.Color.Black;
            this.Button_SavePayment.selected = false;
            this.Button_SavePayment.Size = new System.Drawing.Size(480, 64);
            this.Button_SavePayment.TabIndex = 57;
            this.Button_SavePayment.Text = "ADD TO BILL";
            this.Button_SavePayment.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_SavePayment.Textcolor = System.Drawing.Color.White;
            this.Button_SavePayment.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_SavePayment.Click += new System.EventHandler(this.Button_SavePayment_Click);
            // 
            // Label_Title
            // 
            this.Label_Title.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Title.AutoSize = true;
            this.Label_Title.BackColor = System.Drawing.Color.Transparent;
            this.Label_Title.Font = new System.Drawing.Font("Felix Titling", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Title.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.Label_Title.Location = new System.Drawing.Point(345, 8);
            this.Label_Title.Name = "Label_Title";
            this.Label_Title.Size = new System.Drawing.Size(530, 35);
            this.Label_Title.TabIndex = 18;
            this.Label_Title.Text = "Prescription Related Details";
            // 
            // timer1
            // 
            this.timer1.Interval = 1;
            this.timer1.Tick += new System.EventHandler(this.Timer1_Tick);
            // 
            // preToolStrip
            // 
            this.preToolStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.preToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.categoryToolStripLabel,
            this.categoryToolStripTextBox,
            this.preToolStripButton});
            this.preToolStrip.Location = new System.Drawing.Point(0, 0);
            this.preToolStrip.Name = "preToolStrip";
            this.preToolStrip.Size = new System.Drawing.Size(1140, 27);
            this.preToolStrip.TabIndex = 4;
            this.preToolStrip.Text = "preToolStrip";
            this.preToolStrip.Visible = false;
            // 
            // categoryToolStripLabel
            // 
            this.categoryToolStripLabel.Name = "categoryToolStripLabel";
            this.categoryToolStripLabel.Size = new System.Drawing.Size(72, 24);
            this.categoryToolStripLabel.Text = "Category:";
            // 
            // categoryToolStripTextBox
            // 
            this.categoryToolStripTextBox.Name = "categoryToolStripTextBox";
            this.categoryToolStripTextBox.Size = new System.Drawing.Size(100, 27);
            // 
            // preToolStripButton
            // 
            this.preToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.preToolStripButton.Name = "preToolStripButton";
            this.preToolStripButton.Size = new System.Drawing.Size(35, 24);
            this.preToolStripButton.Text = "pre";
            this.preToolStripButton.Click += new System.EventHandler(this.PreToolStripButton_Click);
            // 
            // tablePrescriptionTableAdapter
            // 
            this.tablePrescriptionTableAdapter.ClearBeforeFill = true;
            // 
            // pharmacyControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.preToolStrip);
            this.Controls.Add(this.bunifuGradientPanel1);
            this.Name = "pharmacyControl";
            this.Size = new System.Drawing.Size(1140, 816);
            this.Load += new System.EventHandler(this.PharmacyControl_Load);
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.app_Number)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGrid1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tablePrescriptionBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.mSSDBDataSet2)).EndInit();
            this.panel_PresType.ResumeLayout(false);
            this.preToolStrip.ResumeLayout(false);
            this.preToolStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel1;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_preName;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_salesPrice;
        public Bunifu.Framework.UI.BunifuFlatButton btn_result;
        private System.Windows.Forms.Label label_cost;
        private System.Windows.Forms.Label label_qun;
        private System.Windows.Forms.Label label_stocks;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_cost;
        private Bunifu.Framework.UI.BunifuCustomLabel lbl_totalCharge;
        private Bunifu.Framework.UI.BunifuCustomLabel lbl_aTax;
        private Bunifu.Framework.UI.BunifuCustomLabel lbl_hCharge;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_dFee;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator3;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_diagnosis;
        private Bunifu.Framework.UI.BunifuCustomLabel lbl_diagnosis;
        private System.Windows.Forms.Label label_ID;
        private System.Windows.Forms.Panel panel_PresType;
        public Bunifu.Framework.UI.BunifuFlatButton btn_Type4;
        public Bunifu.Framework.UI.BunifuFlatButton btn_Type3;
        public Bunifu.Framework.UI.BunifuFlatButton btn_Type1;
        public Bunifu.Framework.UI.BunifuFlatButton btn_Type2;
        private System.Windows.Forms.Label label_ESearchNIC;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator1;
        public Bunifu.Framework.UI.BunifuFlatButton Button_Search;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_SearchNIC;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_SearchNIC;
        private System.Windows.Forms.Label label_Errors;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Title;
        public Bunifu.Framework.UI.BunifuFlatButton Button_prescriptions;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_prescriptions;
        private Bunifu.Framework.UI.BunifuCustomLabel lbl_doctorName;
        private System.Windows.Forms.Timer timer1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator2;
        private Bunifu.Framework.UI.BunifuCustomDataGrid DataGrid1;
        private System.Windows.Forms.BindingSource tablePrescriptionBindingSource;
        private MSSDBDataSet2 mSSDBDataSet2;
        private MSSDBDataSet2TableAdapters.TablePrescriptionTableAdapter tablePrescriptionTableAdapter;
        private System.Windows.Forms.ToolStrip preToolStrip;
        private System.Windows.Forms.ToolStripLabel categoryToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox categoryToolStripTextBox;
        private System.Windows.Forms.ToolStripButton preToolStripButton;
        public Bunifu.Framework.UI.BunifuFlatButton Button_SavePayment;
        private System.Windows.Forms.NumericUpDown app_Number;
        private System.Windows.Forms.Label label_relevel;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn preName;
        private System.Windows.Forms.DataGridViewTextBoxColumn costPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn salesPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn stocks;
        private System.Windows.Forms.DataGridViewTextBoxColumn reorderLevel;
        private System.Windows.Forms.DataGridViewTextBoxColumn category;
        private System.Windows.Forms.Label label_cate;
        private System.Windows.Forms.Label label_saleP;
        private System.Windows.Forms.Label label_total;
        private System.Windows.Forms.Label label_sPrice;
    }
}
