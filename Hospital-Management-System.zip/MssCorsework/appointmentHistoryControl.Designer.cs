﻿namespace MssCorsework
{
    partial class appointmentHistoryControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(appointmentHistoryControl));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.bunifuGradientPanel1 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.panel_reportTypes = new System.Windows.Forms.Panel();
            this.Button_hospitelBill = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Button_internalPatients = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Button_inventory = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Button_diagnosisDetails = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Button_patientHistory = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Button_doctors = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Button_patients = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Button_totalEarns = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Button_reportType = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Button_appointments = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Button_dEarning = new Bunifu.Framework.UI.BunifuFlatButton();
            this.dateTimePicker_eDate = new System.Windows.Forms.DateTimePicker();
            this.Separator3 = new Bunifu.Framework.UI.BunifuSeparator();
            this.Label_eDate = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Datepicker_aDate = new System.Windows.Forms.DateTimePicker();
            this.Separator2 = new Bunifu.Framework.UI.BunifuSeparator();
            this.Label_Date = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.DataGrid1 = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.bunifuSeparator7 = new Bunifu.Framework.UI.BunifuSeparator();
            this.Button_Search = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Button_Clear = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Label_Title = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.bunifuGradientPanel1.SuspendLayout();
            this.panel_reportTypes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGrid1)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.Controls.Add(this.panel_reportTypes);
            this.bunifuGradientPanel1.Controls.Add(this.dateTimePicker_eDate);
            this.bunifuGradientPanel1.Controls.Add(this.Separator3);
            this.bunifuGradientPanel1.Controls.Add(this.Label_eDate);
            this.bunifuGradientPanel1.Controls.Add(this.Datepicker_aDate);
            this.bunifuGradientPanel1.Controls.Add(this.Separator2);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Date);
            this.bunifuGradientPanel1.Controls.Add(this.DataGrid1);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuSeparator7);
            this.bunifuGradientPanel1.Controls.Add(this.Button_Search);
            this.bunifuGradientPanel1.Controls.Add(this.Button_Clear);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Title);
            this.bunifuGradientPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.Black;
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.Gray;
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(1140, 812);
            this.bunifuGradientPanel1.TabIndex = 5;
            // 
            // panel_reportTypes
            // 
            this.panel_reportTypes.BackColor = System.Drawing.Color.Transparent;
            this.panel_reportTypes.Controls.Add(this.Button_hospitelBill);
            this.panel_reportTypes.Controls.Add(this.Button_internalPatients);
            this.panel_reportTypes.Controls.Add(this.Button_inventory);
            this.panel_reportTypes.Controls.Add(this.Button_diagnosisDetails);
            this.panel_reportTypes.Controls.Add(this.Button_patientHistory);
            this.panel_reportTypes.Controls.Add(this.Button_doctors);
            this.panel_reportTypes.Controls.Add(this.Button_patients);
            this.panel_reportTypes.Controls.Add(this.Button_totalEarns);
            this.panel_reportTypes.Controls.Add(this.Button_reportType);
            this.panel_reportTypes.Controls.Add(this.Button_appointments);
            this.panel_reportTypes.Controls.Add(this.Button_dEarning);
            this.panel_reportTypes.Location = new System.Drawing.Point(735, 22);
            this.panel_reportTypes.MaximumSize = new System.Drawing.Size(343, 497);
            this.panel_reportTypes.MinimumSize = new System.Drawing.Size(343, 64);
            this.panel_reportTypes.Name = "panel_reportTypes";
            this.panel_reportTypes.Size = new System.Drawing.Size(343, 64);
            this.panel_reportTypes.TabIndex = 131;
            // 
            // Button_hospitelBill
            // 
            this.Button_hospitelBill.Activecolor = System.Drawing.Color.SteelBlue;
            this.Button_hospitelBill.BackColor = System.Drawing.Color.SteelBlue;
            this.Button_hospitelBill.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_hospitelBill.BorderRadius = 0;
            this.Button_hospitelBill.ButtonText = "Hospital Bill Details";
            this.Button_hospitelBill.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_hospitelBill.DisabledColor = System.Drawing.Color.Gray;
            this.Button_hospitelBill.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_hospitelBill.Iconimage = null;
            this.Button_hospitelBill.Iconimage_right = null;
            this.Button_hospitelBill.Iconimage_right_Selected = null;
            this.Button_hospitelBill.Iconimage_Selected = null;
            this.Button_hospitelBill.IconMarginLeft = 0;
            this.Button_hospitelBill.IconMarginRight = 0;
            this.Button_hospitelBill.IconRightVisible = true;
            this.Button_hospitelBill.IconRightZoom = 0D;
            this.Button_hospitelBill.IconVisible = true;
            this.Button_hospitelBill.IconZoom = 90D;
            this.Button_hospitelBill.IsTab = false;
            this.Button_hospitelBill.Location = new System.Drawing.Point(0, 454);
            this.Button_hospitelBill.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_hospitelBill.Name = "Button_hospitelBill";
            this.Button_hospitelBill.Normalcolor = System.Drawing.Color.SteelBlue;
            this.Button_hospitelBill.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.Button_hospitelBill.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_hospitelBill.selected = false;
            this.Button_hospitelBill.Size = new System.Drawing.Size(343, 42);
            this.Button_hospitelBill.TabIndex = 125;
            this.Button_hospitelBill.Text = "Hospital Bill Details";
            this.Button_hospitelBill.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_hospitelBill.Textcolor = System.Drawing.Color.White;
            this.Button_hospitelBill.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_hospitelBill.Click += new System.EventHandler(this.Button_hospitelBill_Click);
            // 
            // Button_internalPatients
            // 
            this.Button_internalPatients.Activecolor = System.Drawing.Color.SteelBlue;
            this.Button_internalPatients.BackColor = System.Drawing.Color.SteelBlue;
            this.Button_internalPatients.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_internalPatients.BorderRadius = 0;
            this.Button_internalPatients.ButtonText = "Internal Patients Details";
            this.Button_internalPatients.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_internalPatients.DisabledColor = System.Drawing.Color.Gray;
            this.Button_internalPatients.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_internalPatients.Iconimage = null;
            this.Button_internalPatients.Iconimage_right = null;
            this.Button_internalPatients.Iconimage_right_Selected = null;
            this.Button_internalPatients.Iconimage_Selected = null;
            this.Button_internalPatients.IconMarginLeft = 0;
            this.Button_internalPatients.IconMarginRight = 0;
            this.Button_internalPatients.IconRightVisible = true;
            this.Button_internalPatients.IconRightZoom = 0D;
            this.Button_internalPatients.IconVisible = true;
            this.Button_internalPatients.IconZoom = 90D;
            this.Button_internalPatients.IsTab = false;
            this.Button_internalPatients.Location = new System.Drawing.Point(0, 411);
            this.Button_internalPatients.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_internalPatients.Name = "Button_internalPatients";
            this.Button_internalPatients.Normalcolor = System.Drawing.Color.SteelBlue;
            this.Button_internalPatients.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.Button_internalPatients.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_internalPatients.selected = false;
            this.Button_internalPatients.Size = new System.Drawing.Size(343, 42);
            this.Button_internalPatients.TabIndex = 124;
            this.Button_internalPatients.Text = "Internal Patients Details";
            this.Button_internalPatients.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_internalPatients.Textcolor = System.Drawing.Color.White;
            this.Button_internalPatients.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_internalPatients.Click += new System.EventHandler(this.Button_internalPatients_Click);
            // 
            // Button_inventory
            // 
            this.Button_inventory.Activecolor = System.Drawing.Color.SteelBlue;
            this.Button_inventory.BackColor = System.Drawing.Color.SteelBlue;
            this.Button_inventory.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_inventory.BorderRadius = 0;
            this.Button_inventory.ButtonText = "Pharmacy Income Report";
            this.Button_inventory.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_inventory.DisabledColor = System.Drawing.Color.Gray;
            this.Button_inventory.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_inventory.Iconimage = null;
            this.Button_inventory.Iconimage_right = null;
            this.Button_inventory.Iconimage_right_Selected = null;
            this.Button_inventory.Iconimage_Selected = null;
            this.Button_inventory.IconMarginLeft = 0;
            this.Button_inventory.IconMarginRight = 0;
            this.Button_inventory.IconRightVisible = true;
            this.Button_inventory.IconRightZoom = 0D;
            this.Button_inventory.IconVisible = true;
            this.Button_inventory.IconZoom = 90D;
            this.Button_inventory.IsTab = false;
            this.Button_inventory.Location = new System.Drawing.Point(0, 368);
            this.Button_inventory.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_inventory.Name = "Button_inventory";
            this.Button_inventory.Normalcolor = System.Drawing.Color.SteelBlue;
            this.Button_inventory.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.Button_inventory.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_inventory.selected = false;
            this.Button_inventory.Size = new System.Drawing.Size(343, 42);
            this.Button_inventory.TabIndex = 123;
            this.Button_inventory.Text = "Pharmacy Income Report";
            this.Button_inventory.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_inventory.Textcolor = System.Drawing.Color.White;
            this.Button_inventory.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_inventory.Click += new System.EventHandler(this.Button_inventory_Click);
            // 
            // Button_diagnosisDetails
            // 
            this.Button_diagnosisDetails.Activecolor = System.Drawing.Color.SteelBlue;
            this.Button_diagnosisDetails.BackColor = System.Drawing.Color.SteelBlue;
            this.Button_diagnosisDetails.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_diagnosisDetails.BorderRadius = 0;
            this.Button_diagnosisDetails.ButtonText = "Diagnosis Details";
            this.Button_diagnosisDetails.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_diagnosisDetails.DisabledColor = System.Drawing.Color.Gray;
            this.Button_diagnosisDetails.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_diagnosisDetails.Iconimage = null;
            this.Button_diagnosisDetails.Iconimage_right = null;
            this.Button_diagnosisDetails.Iconimage_right_Selected = null;
            this.Button_diagnosisDetails.Iconimage_Selected = null;
            this.Button_diagnosisDetails.IconMarginLeft = 0;
            this.Button_diagnosisDetails.IconMarginRight = 0;
            this.Button_diagnosisDetails.IconRightVisible = true;
            this.Button_diagnosisDetails.IconRightZoom = 0D;
            this.Button_diagnosisDetails.IconVisible = true;
            this.Button_diagnosisDetails.IconZoom = 90D;
            this.Button_diagnosisDetails.IsTab = false;
            this.Button_diagnosisDetails.Location = new System.Drawing.Point(0, 325);
            this.Button_diagnosisDetails.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_diagnosisDetails.Name = "Button_diagnosisDetails";
            this.Button_diagnosisDetails.Normalcolor = System.Drawing.Color.SteelBlue;
            this.Button_diagnosisDetails.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.Button_diagnosisDetails.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_diagnosisDetails.selected = false;
            this.Button_diagnosisDetails.Size = new System.Drawing.Size(343, 42);
            this.Button_diagnosisDetails.TabIndex = 122;
            this.Button_diagnosisDetails.Text = "Diagnosis Details";
            this.Button_diagnosisDetails.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_diagnosisDetails.Textcolor = System.Drawing.Color.White;
            this.Button_diagnosisDetails.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_diagnosisDetails.Click += new System.EventHandler(this.Button_diagnosisDetails_Click);
            // 
            // Button_patientHistory
            // 
            this.Button_patientHistory.Activecolor = System.Drawing.Color.SteelBlue;
            this.Button_patientHistory.BackColor = System.Drawing.Color.SteelBlue;
            this.Button_patientHistory.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_patientHistory.BorderRadius = 0;
            this.Button_patientHistory.ButtonText = "Lab / Radiology Reports Details";
            this.Button_patientHistory.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_patientHistory.DisabledColor = System.Drawing.Color.Gray;
            this.Button_patientHistory.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_patientHistory.Iconimage = null;
            this.Button_patientHistory.Iconimage_right = null;
            this.Button_patientHistory.Iconimage_right_Selected = null;
            this.Button_patientHistory.Iconimage_Selected = null;
            this.Button_patientHistory.IconMarginLeft = 0;
            this.Button_patientHistory.IconMarginRight = 0;
            this.Button_patientHistory.IconRightVisible = true;
            this.Button_patientHistory.IconRightZoom = 0D;
            this.Button_patientHistory.IconVisible = true;
            this.Button_patientHistory.IconZoom = 90D;
            this.Button_patientHistory.IsTab = false;
            this.Button_patientHistory.Location = new System.Drawing.Point(0, 282);
            this.Button_patientHistory.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_patientHistory.Name = "Button_patientHistory";
            this.Button_patientHistory.Normalcolor = System.Drawing.Color.SteelBlue;
            this.Button_patientHistory.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.Button_patientHistory.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_patientHistory.selected = false;
            this.Button_patientHistory.Size = new System.Drawing.Size(343, 42);
            this.Button_patientHistory.TabIndex = 121;
            this.Button_patientHistory.Text = "Lab / Radiology Reports Details";
            this.Button_patientHistory.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_patientHistory.Textcolor = System.Drawing.Color.White;
            this.Button_patientHistory.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_patientHistory.Click += new System.EventHandler(this.Button_patientHistory_Click);
            // 
            // Button_doctors
            // 
            this.Button_doctors.Activecolor = System.Drawing.Color.SteelBlue;
            this.Button_doctors.BackColor = System.Drawing.Color.SteelBlue;
            this.Button_doctors.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_doctors.BorderRadius = 0;
            this.Button_doctors.ButtonText = "Doctors Details";
            this.Button_doctors.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_doctors.DisabledColor = System.Drawing.Color.Gray;
            this.Button_doctors.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_doctors.Iconimage = null;
            this.Button_doctors.Iconimage_right = null;
            this.Button_doctors.Iconimage_right_Selected = null;
            this.Button_doctors.Iconimage_Selected = null;
            this.Button_doctors.IconMarginLeft = 0;
            this.Button_doctors.IconMarginRight = 0;
            this.Button_doctors.IconRightVisible = true;
            this.Button_doctors.IconRightZoom = 0D;
            this.Button_doctors.IconVisible = true;
            this.Button_doctors.IconZoom = 90D;
            this.Button_doctors.IsTab = false;
            this.Button_doctors.Location = new System.Drawing.Point(0, 239);
            this.Button_doctors.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_doctors.Name = "Button_doctors";
            this.Button_doctors.Normalcolor = System.Drawing.Color.SteelBlue;
            this.Button_doctors.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.Button_doctors.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_doctors.selected = false;
            this.Button_doctors.Size = new System.Drawing.Size(343, 42);
            this.Button_doctors.TabIndex = 120;
            this.Button_doctors.Text = "Doctors Details";
            this.Button_doctors.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_doctors.Textcolor = System.Drawing.Color.White;
            this.Button_doctors.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_doctors.Click += new System.EventHandler(this.Button_doctors_Click);
            // 
            // Button_patients
            // 
            this.Button_patients.Activecolor = System.Drawing.Color.SteelBlue;
            this.Button_patients.BackColor = System.Drawing.Color.SteelBlue;
            this.Button_patients.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_patients.BorderRadius = 0;
            this.Button_patients.ButtonText = "Patients Details";
            this.Button_patients.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_patients.DisabledColor = System.Drawing.Color.Gray;
            this.Button_patients.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_patients.Iconimage = null;
            this.Button_patients.Iconimage_right = null;
            this.Button_patients.Iconimage_right_Selected = null;
            this.Button_patients.Iconimage_Selected = null;
            this.Button_patients.IconMarginLeft = 0;
            this.Button_patients.IconMarginRight = 0;
            this.Button_patients.IconRightVisible = true;
            this.Button_patients.IconRightZoom = 0D;
            this.Button_patients.IconVisible = true;
            this.Button_patients.IconZoom = 90D;
            this.Button_patients.IsTab = false;
            this.Button_patients.Location = new System.Drawing.Point(0, 196);
            this.Button_patients.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_patients.Name = "Button_patients";
            this.Button_patients.Normalcolor = System.Drawing.Color.SteelBlue;
            this.Button_patients.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.Button_patients.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_patients.selected = false;
            this.Button_patients.Size = new System.Drawing.Size(343, 42);
            this.Button_patients.TabIndex = 119;
            this.Button_patients.Text = "Patients Details";
            this.Button_patients.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_patients.Textcolor = System.Drawing.Color.White;
            this.Button_patients.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_patients.Click += new System.EventHandler(this.Button_patients_Click);
            // 
            // Button_totalEarns
            // 
            this.Button_totalEarns.Activecolor = System.Drawing.Color.SteelBlue;
            this.Button_totalEarns.BackColor = System.Drawing.Color.SteelBlue;
            this.Button_totalEarns.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_totalEarns.BorderRadius = 0;
            this.Button_totalEarns.ButtonText = "Weekly Earnings From Appointments";
            this.Button_totalEarns.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_totalEarns.DisabledColor = System.Drawing.Color.Gray;
            this.Button_totalEarns.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_totalEarns.Iconimage = null;
            this.Button_totalEarns.Iconimage_right = null;
            this.Button_totalEarns.Iconimage_right_Selected = null;
            this.Button_totalEarns.Iconimage_Selected = null;
            this.Button_totalEarns.IconMarginLeft = 0;
            this.Button_totalEarns.IconMarginRight = 0;
            this.Button_totalEarns.IconRightVisible = true;
            this.Button_totalEarns.IconRightZoom = 0D;
            this.Button_totalEarns.IconVisible = true;
            this.Button_totalEarns.IconZoom = 90D;
            this.Button_totalEarns.IsTab = false;
            this.Button_totalEarns.Location = new System.Drawing.Point(0, 153);
            this.Button_totalEarns.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_totalEarns.Name = "Button_totalEarns";
            this.Button_totalEarns.Normalcolor = System.Drawing.Color.SteelBlue;
            this.Button_totalEarns.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.Button_totalEarns.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_totalEarns.selected = false;
            this.Button_totalEarns.Size = new System.Drawing.Size(343, 42);
            this.Button_totalEarns.TabIndex = 118;
            this.Button_totalEarns.Text = "Weekly Earnings From Appointments";
            this.Button_totalEarns.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_totalEarns.Textcolor = System.Drawing.Color.White;
            this.Button_totalEarns.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_totalEarns.Click += new System.EventHandler(this.Button_totalEarns_Click);
            // 
            // Button_reportType
            // 
            this.Button_reportType.Activecolor = System.Drawing.Color.LimeGreen;
            this.Button_reportType.BackColor = System.Drawing.Color.LimeGreen;
            this.Button_reportType.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_reportType.BorderRadius = 0;
            this.Button_reportType.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Button_reportType.ButtonText = "REPORT TYPE";
            this.Button_reportType.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_reportType.DisabledColor = System.Drawing.Color.Gray;
            this.Button_reportType.ForeColor = System.Drawing.Color.White;
            this.Button_reportType.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_reportType.Iconimage = null;
            this.Button_reportType.Iconimage_right = null;
            this.Button_reportType.Iconimage_right_Selected = null;
            this.Button_reportType.Iconimage_Selected = null;
            this.Button_reportType.IconMarginLeft = 0;
            this.Button_reportType.IconMarginRight = 0;
            this.Button_reportType.IconRightVisible = true;
            this.Button_reportType.IconRightZoom = 0D;
            this.Button_reportType.IconVisible = true;
            this.Button_reportType.IconZoom = 90D;
            this.Button_reportType.IsTab = false;
            this.Button_reportType.Location = new System.Drawing.Point(0, 0);
            this.Button_reportType.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_reportType.Name = "Button_reportType";
            this.Button_reportType.Normalcolor = System.Drawing.Color.LimeGreen;
            this.Button_reportType.OnHovercolor = System.Drawing.Color.Transparent;
            this.Button_reportType.OnHoverTextColor = System.Drawing.Color.Black;
            this.Button_reportType.selected = false;
            this.Button_reportType.Size = new System.Drawing.Size(343, 64);
            this.Button_reportType.TabIndex = 117;
            this.Button_reportType.Text = "REPORT TYPE";
            this.Button_reportType.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_reportType.Textcolor = System.Drawing.Color.White;
            this.Button_reportType.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_reportType.Click += new System.EventHandler(this.Button_reportType_Click);
            // 
            // Button_appointments
            // 
            this.Button_appointments.Activecolor = System.Drawing.Color.SteelBlue;
            this.Button_appointments.BackColor = System.Drawing.Color.SteelBlue;
            this.Button_appointments.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_appointments.BorderRadius = 0;
            this.Button_appointments.ButtonText = "Appointments Report";
            this.Button_appointments.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_appointments.DisabledColor = System.Drawing.Color.Gray;
            this.Button_appointments.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_appointments.Iconimage = null;
            this.Button_appointments.Iconimage_right = null;
            this.Button_appointments.Iconimage_right_Selected = null;
            this.Button_appointments.Iconimage_Selected = null;
            this.Button_appointments.IconMarginLeft = 0;
            this.Button_appointments.IconMarginRight = 0;
            this.Button_appointments.IconRightVisible = true;
            this.Button_appointments.IconRightZoom = 0D;
            this.Button_appointments.IconVisible = true;
            this.Button_appointments.IconZoom = 90D;
            this.Button_appointments.IsTab = false;
            this.Button_appointments.Location = new System.Drawing.Point(0, 67);
            this.Button_appointments.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_appointments.Name = "Button_appointments";
            this.Button_appointments.Normalcolor = System.Drawing.Color.SteelBlue;
            this.Button_appointments.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.Button_appointments.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_appointments.selected = false;
            this.Button_appointments.Size = new System.Drawing.Size(343, 42);
            this.Button_appointments.TabIndex = 25;
            this.Button_appointments.Text = "Appointments Report";
            this.Button_appointments.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_appointments.Textcolor = System.Drawing.Color.White;
            this.Button_appointments.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_appointments.Click += new System.EventHandler(this.Button_appointments_Click);
            // 
            // Button_dEarning
            // 
            this.Button_dEarning.Activecolor = System.Drawing.Color.SteelBlue;
            this.Button_dEarning.BackColor = System.Drawing.Color.SteelBlue;
            this.Button_dEarning.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_dEarning.BorderRadius = 0;
            this.Button_dEarning.ButtonText = "Doctors Earning Report";
            this.Button_dEarning.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_dEarning.DisabledColor = System.Drawing.Color.Gray;
            this.Button_dEarning.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_dEarning.Iconimage = null;
            this.Button_dEarning.Iconimage_right = null;
            this.Button_dEarning.Iconimage_right_Selected = null;
            this.Button_dEarning.Iconimage_Selected = null;
            this.Button_dEarning.IconMarginLeft = 0;
            this.Button_dEarning.IconMarginRight = 0;
            this.Button_dEarning.IconRightVisible = true;
            this.Button_dEarning.IconRightZoom = 0D;
            this.Button_dEarning.IconVisible = true;
            this.Button_dEarning.IconZoom = 90D;
            this.Button_dEarning.IsTab = false;
            this.Button_dEarning.Location = new System.Drawing.Point(0, 110);
            this.Button_dEarning.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_dEarning.Name = "Button_dEarning";
            this.Button_dEarning.Normalcolor = System.Drawing.Color.SteelBlue;
            this.Button_dEarning.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.Button_dEarning.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_dEarning.selected = false;
            this.Button_dEarning.Size = new System.Drawing.Size(343, 42);
            this.Button_dEarning.TabIndex = 26;
            this.Button_dEarning.Text = "Doctors Earning Report";
            this.Button_dEarning.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_dEarning.Textcolor = System.Drawing.Color.White;
            this.Button_dEarning.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_dEarning.Click += new System.EventHandler(this.Button_dEarning_Click);
            // 
            // dateTimePicker_eDate
            // 
            this.dateTimePicker_eDate.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_eDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker_eDate.Location = new System.Drawing.Point(592, 121);
            this.dateTimePicker_eDate.MinimumSize = new System.Drawing.Size(4, 44);
            this.dateTimePicker_eDate.Name = "dateTimePicker_eDate";
            this.dateTimePicker_eDate.Size = new System.Drawing.Size(480, 44);
            this.dateTimePicker_eDate.TabIndex = 130;
            // 
            // Separator3
            // 
            this.Separator3.BackColor = System.Drawing.Color.Transparent;
            this.Separator3.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Separator3.LineThickness = 3;
            this.Separator3.Location = new System.Drawing.Point(592, 162);
            this.Separator3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Separator3.Name = "Separator3";
            this.Separator3.Size = new System.Drawing.Size(480, 10);
            this.Separator3.TabIndex = 129;
            this.Separator3.Transparency = 255;
            this.Separator3.Vertical = false;
            // 
            // Label_eDate
            // 
            this.Label_eDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_eDate.AutoSize = true;
            this.Label_eDate.BackColor = System.Drawing.Color.Transparent;
            this.Label_eDate.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_eDate.ForeColor = System.Drawing.Color.Black;
            this.Label_eDate.Location = new System.Drawing.Point(586, 83);
            this.Label_eDate.Name = "Label_eDate";
            this.Label_eDate.Size = new System.Drawing.Size(118, 32);
            this.Label_eDate.TabIndex = 127;
            this.Label_eDate.Text = "End Date";
            // 
            // Datepicker_aDate
            // 
            this.Datepicker_aDate.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Datepicker_aDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Datepicker_aDate.Location = new System.Drawing.Point(60, 121);
            this.Datepicker_aDate.MinimumSize = new System.Drawing.Size(4, 44);
            this.Datepicker_aDate.Name = "Datepicker_aDate";
            this.Datepicker_aDate.Size = new System.Drawing.Size(480, 44);
            this.Datepicker_aDate.TabIndex = 126;
            // 
            // Separator2
            // 
            this.Separator2.BackColor = System.Drawing.Color.Transparent;
            this.Separator2.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Separator2.LineThickness = 3;
            this.Separator2.Location = new System.Drawing.Point(60, 162);
            this.Separator2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Separator2.Name = "Separator2";
            this.Separator2.Size = new System.Drawing.Size(480, 10);
            this.Separator2.TabIndex = 125;
            this.Separator2.Transparency = 255;
            this.Separator2.Vertical = false;
            // 
            // Label_Date
            // 
            this.Label_Date.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Date.AutoSize = true;
            this.Label_Date.BackColor = System.Drawing.Color.Transparent;
            this.Label_Date.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Date.ForeColor = System.Drawing.Color.Black;
            this.Label_Date.Location = new System.Drawing.Point(54, 83);
            this.Label_Date.Name = "Label_Date";
            this.Label_Date.Size = new System.Drawing.Size(129, 32);
            this.Label_Date.TabIndex = 123;
            this.Label_Date.Text = "Start Date";
            // 
            // DataGrid1
            // 
            this.DataGrid1.AllowUserToAddRows = false;
            this.DataGrid1.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.DataGrid1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.DataGrid1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DataGrid1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DataGrid1.BackgroundColor = System.Drawing.Color.White;
            this.DataGrid1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DataGrid1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.DataGrid1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DataGrid1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.DataGrid1.ColumnHeadersHeight = 65;
            this.DataGrid1.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Century", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.DataGrid1.DefaultCellStyle = dataGridViewCellStyle3;
            this.DataGrid1.DoubleBuffered = true;
            this.DataGrid1.EnableHeadersVisualStyles = false;
            this.DataGrid1.GridColor = System.Drawing.Color.White;
            this.DataGrid1.HeaderBgColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.DataGrid1.HeaderForeColor = System.Drawing.Color.White;
            this.DataGrid1.Location = new System.Drawing.Point(60, 217);
            this.DataGrid1.MultiSelect = false;
            this.DataGrid1.Name = "DataGrid1";
            this.DataGrid1.ReadOnly = true;
            this.DataGrid1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(14)))), ((int)(((byte)(14)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Century", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.DataGrid1.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.DataGrid1.RowHeadersVisible = false;
            this.DataGrid1.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.White;
            this.DataGrid1.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Century", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DataGrid1.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.DataGrid1.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Silver;
            this.DataGrid1.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.DataGrid1.RowTemplate.DividerHeight = 3;
            this.DataGrid1.RowTemplate.Height = 70;
            this.DataGrid1.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.DataGrid1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DataGrid1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.DataGrid1.Size = new System.Drawing.Size(1018, 474);
            this.DataGrid1.TabIndex = 119;
            // 
            // bunifuSeparator7
            // 
            this.bunifuSeparator7.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator7.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator7.LineThickness = 2;
            this.bunifuSeparator7.Location = new System.Drawing.Point(60, 188);
            this.bunifuSeparator7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator7.Name = "bunifuSeparator7";
            this.bunifuSeparator7.Size = new System.Drawing.Size(1018, 10);
            this.bunifuSeparator7.TabIndex = 117;
            this.bunifuSeparator7.Transparency = 255;
            this.bunifuSeparator7.Vertical = false;
            // 
            // Button_Search
            // 
            this.Button_Search.Activecolor = System.Drawing.Color.DarkViolet;
            this.Button_Search.BackColor = System.Drawing.Color.DarkViolet;
            this.Button_Search.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_Search.BorderRadius = 0;
            this.Button_Search.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Button_Search.ButtonText = "SEARCH";
            this.Button_Search.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_Search.DisabledColor = System.Drawing.Color.Gray;
            this.Button_Search.ForeColor = System.Drawing.Color.White;
            this.Button_Search.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_Search.Iconimage = null;
            this.Button_Search.Iconimage_right = null;
            this.Button_Search.Iconimage_right_Selected = null;
            this.Button_Search.Iconimage_Selected = null;
            this.Button_Search.IconMarginLeft = 0;
            this.Button_Search.IconMarginRight = 0;
            this.Button_Search.IconRightVisible = true;
            this.Button_Search.IconRightZoom = 0D;
            this.Button_Search.IconVisible = true;
            this.Button_Search.IconZoom = 90D;
            this.Button_Search.IsTab = false;
            this.Button_Search.Location = new System.Drawing.Point(722, 719);
            this.Button_Search.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_Search.Name = "Button_Search";
            this.Button_Search.Normalcolor = System.Drawing.Color.DarkViolet;
            this.Button_Search.OnHovercolor = System.Drawing.Color.Transparent;
            this.Button_Search.OnHoverTextColor = System.Drawing.Color.Black;
            this.Button_Search.selected = false;
            this.Button_Search.Size = new System.Drawing.Size(356, 64);
            this.Button_Search.TabIndex = 116;
            this.Button_Search.Text = "SEARCH";
            this.Button_Search.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_Search.Textcolor = System.Drawing.Color.White;
            this.Button_Search.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Search.Click += new System.EventHandler(this.Button_Search_Click);
            // 
            // Button_Clear
            // 
            this.Button_Clear.Activecolor = System.Drawing.Color.Crimson;
            this.Button_Clear.BackColor = System.Drawing.Color.Crimson;
            this.Button_Clear.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_Clear.BorderRadius = 0;
            this.Button_Clear.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Button_Clear.ButtonText = "CREATE REPORT";
            this.Button_Clear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_Clear.DisabledColor = System.Drawing.Color.Gray;
            this.Button_Clear.ForeColor = System.Drawing.Color.White;
            this.Button_Clear.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_Clear.Iconimage = null;
            this.Button_Clear.Iconimage_right = null;
            this.Button_Clear.Iconimage_right_Selected = null;
            this.Button_Clear.Iconimage_Selected = null;
            this.Button_Clear.IconMarginLeft = 0;
            this.Button_Clear.IconMarginRight = 0;
            this.Button_Clear.IconRightVisible = true;
            this.Button_Clear.IconRightZoom = 0D;
            this.Button_Clear.IconVisible = true;
            this.Button_Clear.IconZoom = 90D;
            this.Button_Clear.IsTab = false;
            this.Button_Clear.Location = new System.Drawing.Point(224, 719);
            this.Button_Clear.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_Clear.Name = "Button_Clear";
            this.Button_Clear.Normalcolor = System.Drawing.Color.Crimson;
            this.Button_Clear.OnHovercolor = System.Drawing.Color.Transparent;
            this.Button_Clear.OnHoverTextColor = System.Drawing.Color.Black;
            this.Button_Clear.selected = false;
            this.Button_Clear.Size = new System.Drawing.Size(480, 64);
            this.Button_Clear.TabIndex = 58;
            this.Button_Clear.Text = "CREATE REPORT";
            this.Button_Clear.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_Clear.Textcolor = System.Drawing.Color.White;
            this.Button_Clear.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Clear.Click += new System.EventHandler(this.Button_Clear_Click);
            // 
            // Label_Title
            // 
            this.Label_Title.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Title.AutoSize = true;
            this.Label_Title.BackColor = System.Drawing.Color.Transparent;
            this.Label_Title.Font = new System.Drawing.Font("Felix Titling", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Title.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.Label_Title.Location = new System.Drawing.Point(54, 22);
            this.Label_Title.Name = "Label_Title";
            this.Label_Title.Size = new System.Drawing.Size(625, 35);
            this.Label_Title.TabIndex = 18;
            this.Label_Title.Text = "Weekly Progress Reports / Charts";
            // 
            // timer1
            // 
            this.timer1.Interval = 1;
            this.timer1.Tick += new System.EventHandler(this.Timer1_Tick);
            // 
            // appointmentHistoryControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.bunifuGradientPanel1);
            this.Name = "appointmentHistoryControl";
            this.Size = new System.Drawing.Size(1140, 812);
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            this.panel_reportTypes.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DataGrid1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel1;
        private Bunifu.Framework.UI.BunifuCustomDataGrid DataGrid1;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator7;
        public Bunifu.Framework.UI.BunifuFlatButton Button_Search;
        public Bunifu.Framework.UI.BunifuFlatButton Button_Clear;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Title;
        private System.Windows.Forms.DateTimePicker dateTimePicker_eDate;
        private Bunifu.Framework.UI.BunifuSeparator Separator3;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_eDate;
        private System.Windows.Forms.DateTimePicker Datepicker_aDate;
        private Bunifu.Framework.UI.BunifuSeparator Separator2;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Date;
        public System.Windows.Forms.Panel panel_reportTypes;
        public Bunifu.Framework.UI.BunifuFlatButton Button_reportType;
        public Bunifu.Framework.UI.BunifuFlatButton Button_appointments;
        public Bunifu.Framework.UI.BunifuFlatButton Button_dEarning;
        private System.Windows.Forms.Timer timer1;
        public Bunifu.Framework.UI.BunifuFlatButton Button_totalEarns;
        public Bunifu.Framework.UI.BunifuFlatButton Button_patients;
        public Bunifu.Framework.UI.BunifuFlatButton Button_doctors;
        public Bunifu.Framework.UI.BunifuFlatButton Button_patientHistory;
        public Bunifu.Framework.UI.BunifuFlatButton Button_diagnosisDetails;
        public Bunifu.Framework.UI.BunifuFlatButton Button_inventory;
        public Bunifu.Framework.UI.BunifuFlatButton Button_internalPatients;
        public Bunifu.Framework.UI.BunifuFlatButton Button_hospitelBill;
    }
}
