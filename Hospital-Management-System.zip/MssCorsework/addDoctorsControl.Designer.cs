﻿namespace MssCorsework
{
    partial class addDoctorsControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(addDoctorsControl));
            this.bunifuGradientPanel1 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.Label_NICStatus = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.label_Errors = new System.Windows.Forms.Label();
            this.label_dEType = new System.Windows.Forms.Label();
            this.label_dETelephoneNum = new System.Windows.Forms.Label();
            this.label_dEExperience = new System.Windows.Forms.Label();
            this.label_dEAddress = new System.Windows.Forms.Label();
            this.label_dENIC = new System.Windows.Forms.Label();
            this.label_dEName = new System.Windows.Forms.Label();
            this.panel_Types = new System.Windows.Forms.Panel();
            this.bunifuSeparator1 = new Bunifu.Framework.UI.BunifuSeparator();
            this.Button_Type = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btn_Family = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btn_Cardiologist = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Textbox_NIC = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Textbox_Experience = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Textbox_TelephoneNum = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Textbox_Address = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Textbox_dName = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Button_Clear = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Button_ADD = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Label_Gender = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_TelephoneNum = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_Age = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_Address = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_NIC = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_Name = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_Title = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.btn_Ophthalmologist = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btn_Surgeon = new Bunifu.Framework.UI.BunifuFlatButton();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.bunifuGradientPanel1.SuspendLayout();
            this.panel_Types.SuspendLayout();
            this.SuspendLayout();
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.Controls.Add(this.Label_NICStatus);
            this.bunifuGradientPanel1.Controls.Add(this.label_Errors);
            this.bunifuGradientPanel1.Controls.Add(this.label_dEType);
            this.bunifuGradientPanel1.Controls.Add(this.label_dETelephoneNum);
            this.bunifuGradientPanel1.Controls.Add(this.label_dEExperience);
            this.bunifuGradientPanel1.Controls.Add(this.label_dEAddress);
            this.bunifuGradientPanel1.Controls.Add(this.label_dENIC);
            this.bunifuGradientPanel1.Controls.Add(this.label_dEName);
            this.bunifuGradientPanel1.Controls.Add(this.panel_Types);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_NIC);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_Experience);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_TelephoneNum);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_Address);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_dName);
            this.bunifuGradientPanel1.Controls.Add(this.Button_Clear);
            this.bunifuGradientPanel1.Controls.Add(this.Button_ADD);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Gender);
            this.bunifuGradientPanel1.Controls.Add(this.Label_TelephoneNum);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Age);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Address);
            this.bunifuGradientPanel1.Controls.Add(this.Label_NIC);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Name);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Title);
            this.bunifuGradientPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.Black;
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.Gray;
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(1140, 812);
            this.bunifuGradientPanel1.TabIndex = 1;
            // 
            // Label_NICStatus
            // 
            this.Label_NICStatus.AutoSize = true;
            this.Label_NICStatus.BackColor = System.Drawing.Color.Transparent;
            this.Label_NICStatus.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_NICStatus.ForeColor = System.Drawing.Color.Black;
            this.Label_NICStatus.Location = new System.Drawing.Point(989, 127);
            this.Label_NICStatus.Name = "Label_NICStatus";
            this.Label_NICStatus.Size = new System.Drawing.Size(63, 19);
            this.Label_NICStatus.TabIndex = 76;
            this.Label_NICStatus.Text = "Normal";
            this.Label_NICStatus.Visible = false;
            // 
            // label_Errors
            // 
            this.label_Errors.AutoSize = true;
            this.label_Errors.BackColor = System.Drawing.Color.Transparent;
            this.label_Errors.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Errors.ForeColor = System.Drawing.Color.Red;
            this.label_Errors.Location = new System.Drawing.Point(57, 739);
            this.label_Errors.Name = "label_Errors";
            this.label_Errors.Size = new System.Drawing.Size(60, 19);
            this.label_Errors.TabIndex = 75;
            this.label_Errors.Text = "label5";
            this.label_Errors.Visible = false;
            // 
            // label_dEType
            // 
            this.label_dEType.AutoSize = true;
            this.label_dEType.BackColor = System.Drawing.Color.Transparent;
            this.label_dEType.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_dEType.ForeColor = System.Drawing.Color.Red;
            this.label_dEType.Location = new System.Drawing.Point(595, 604);
            this.label_dEType.Name = "label_dEType";
            this.label_dEType.Size = new System.Drawing.Size(60, 19);
            this.label_dEType.TabIndex = 74;
            this.label_dEType.Text = "label6";
            this.label_dEType.Visible = false;
            // 
            // label_dETelephoneNum
            // 
            this.label_dETelephoneNum.AutoSize = true;
            this.label_dETelephoneNum.BackColor = System.Drawing.Color.Transparent;
            this.label_dETelephoneNum.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_dETelephoneNum.ForeColor = System.Drawing.Color.Red;
            this.label_dETelephoneNum.Location = new System.Drawing.Point(57, 604);
            this.label_dETelephoneNum.Name = "label_dETelephoneNum";
            this.label_dETelephoneNum.Size = new System.Drawing.Size(60, 19);
            this.label_dETelephoneNum.TabIndex = 73;
            this.label_dETelephoneNum.Text = "label5";
            this.label_dETelephoneNum.Visible = false;
            // 
            // label_dEExperience
            // 
            this.label_dEExperience.AutoSize = true;
            this.label_dEExperience.BackColor = System.Drawing.Color.Transparent;
            this.label_dEExperience.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_dEExperience.ForeColor = System.Drawing.Color.Red;
            this.label_dEExperience.Location = new System.Drawing.Point(595, 441);
            this.label_dEExperience.Name = "label_dEExperience";
            this.label_dEExperience.Size = new System.Drawing.Size(60, 19);
            this.label_dEExperience.TabIndex = 72;
            this.label_dEExperience.Text = "label4";
            this.label_dEExperience.Visible = false;
            // 
            // label_dEAddress
            // 
            this.label_dEAddress.AutoSize = true;
            this.label_dEAddress.BackColor = System.Drawing.Color.Transparent;
            this.label_dEAddress.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_dEAddress.ForeColor = System.Drawing.Color.Red;
            this.label_dEAddress.Location = new System.Drawing.Point(57, 441);
            this.label_dEAddress.Name = "label_dEAddress";
            this.label_dEAddress.Size = new System.Drawing.Size(60, 19);
            this.label_dEAddress.TabIndex = 71;
            this.label_dEAddress.Text = "label3";
            this.label_dEAddress.Visible = false;
            // 
            // label_dENIC
            // 
            this.label_dENIC.AutoSize = true;
            this.label_dENIC.BackColor = System.Drawing.Color.Transparent;
            this.label_dENIC.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_dENIC.ForeColor = System.Drawing.Color.Red;
            this.label_dENIC.Location = new System.Drawing.Point(595, 275);
            this.label_dENIC.Name = "label_dENIC";
            this.label_dENIC.Size = new System.Drawing.Size(60, 19);
            this.label_dENIC.TabIndex = 70;
            this.label_dENIC.Text = "label2";
            this.label_dENIC.Visible = false;
            // 
            // label_dEName
            // 
            this.label_dEName.AutoSize = true;
            this.label_dEName.BackColor = System.Drawing.Color.Transparent;
            this.label_dEName.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_dEName.ForeColor = System.Drawing.Color.Red;
            this.label_dEName.Location = new System.Drawing.Point(57, 275);
            this.label_dEName.Name = "label_dEName";
            this.label_dEName.Size = new System.Drawing.Size(60, 19);
            this.label_dEName.TabIndex = 69;
            this.label_dEName.Text = "label1";
            this.label_dEName.Visible = false;
            // 
            // panel_Types
            // 
            this.panel_Types.BackColor = System.Drawing.Color.Transparent;
            this.panel_Types.Controls.Add(this.btn_Surgeon);
            this.panel_Types.Controls.Add(this.Button_Type);
            this.panel_Types.Controls.Add(this.btn_Ophthalmologist);
            this.panel_Types.Controls.Add(this.bunifuSeparator1);
            this.panel_Types.Controls.Add(this.btn_Family);
            this.panel_Types.Controls.Add(this.btn_Cardiologist);
            this.panel_Types.Location = new System.Drawing.Point(599, 530);
            this.panel_Types.MaximumSize = new System.Drawing.Size(480, 238);
            this.panel_Types.MinimumSize = new System.Drawing.Size(480, 60);
            this.panel_Types.Name = "panel_Types";
            this.panel_Types.Size = new System.Drawing.Size(480, 60);
            this.panel_Types.TabIndex = 68;
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuSeparator1.LineThickness = 3;
            this.bunifuSeparator1.Location = new System.Drawing.Point(0, 50);
            this.bunifuSeparator1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Size = new System.Drawing.Size(480, 10);
            this.bunifuSeparator1.TabIndex = 77;
            this.bunifuSeparator1.Transparency = 255;
            this.bunifuSeparator1.Vertical = false;
            // 
            // Button_Type
            // 
            this.Button_Type.Activecolor = System.Drawing.Color.Silver;
            this.Button_Type.BackColor = System.Drawing.Color.Silver;
            this.Button_Type.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_Type.BorderRadius = 0;
            this.Button_Type.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Button_Type.ButtonText = "Doctor\'s Type";
            this.Button_Type.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_Type.DisabledColor = System.Drawing.Color.Gray;
            this.Button_Type.ForeColor = System.Drawing.Color.White;
            this.Button_Type.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_Type.Iconimage = null;
            this.Button_Type.Iconimage_right = null;
            this.Button_Type.Iconimage_right_Selected = null;
            this.Button_Type.Iconimage_Selected = null;
            this.Button_Type.IconMarginLeft = 0;
            this.Button_Type.IconMarginRight = 0;
            this.Button_Type.IconRightVisible = true;
            this.Button_Type.IconRightZoom = 0D;
            this.Button_Type.IconVisible = true;
            this.Button_Type.IconZoom = 90D;
            this.Button_Type.IsTab = false;
            this.Button_Type.Location = new System.Drawing.Point(0, 0);
            this.Button_Type.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_Type.Name = "Button_Type";
            this.Button_Type.Normalcolor = System.Drawing.Color.Silver;
            this.Button_Type.OnHovercolor = System.Drawing.Color.Transparent;
            this.Button_Type.OnHoverTextColor = System.Drawing.Color.Black;
            this.Button_Type.selected = false;
            this.Button_Type.Size = new System.Drawing.Size(480, 56);
            this.Button_Type.TabIndex = 59;
            this.Button_Type.Text = "Doctor\'s Type";
            this.Button_Type.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Button_Type.Textcolor = System.Drawing.Color.Black;
            this.Button_Type.TextFont = new System.Drawing.Font("Century Gothic", 12F);
            this.Button_Type.Click += new System.EventHandler(this.Button_Type_Click);
            // 
            // btn_Family
            // 
            this.btn_Family.Activecolor = System.Drawing.Color.SteelBlue;
            this.btn_Family.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_Family.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Family.BorderRadius = 0;
            this.btn_Family.ButtonText = "Family Physician";
            this.btn_Family.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Family.DisabledColor = System.Drawing.Color.Gray;
            this.btn_Family.Iconcolor = System.Drawing.Color.Transparent;
            this.btn_Family.Iconimage = null;
            this.btn_Family.Iconimage_right = null;
            this.btn_Family.Iconimage_right_Selected = null;
            this.btn_Family.Iconimage_Selected = null;
            this.btn_Family.IconMarginLeft = 0;
            this.btn_Family.IconMarginRight = 0;
            this.btn_Family.IconRightVisible = true;
            this.btn_Family.IconRightZoom = 0D;
            this.btn_Family.IconVisible = true;
            this.btn_Family.IconZoom = 90D;
            this.btn_Family.IsTab = false;
            this.btn_Family.Location = new System.Drawing.Point(0, 64);
            this.btn_Family.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Family.Name = "btn_Family";
            this.btn_Family.Normalcolor = System.Drawing.Color.SteelBlue;
            this.btn_Family.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.btn_Family.OnHoverTextColor = System.Drawing.Color.White;
            this.btn_Family.selected = false;
            this.btn_Family.Size = new System.Drawing.Size(480, 42);
            this.btn_Family.TabIndex = 25;
            this.btn_Family.Text = "Family Physician";
            this.btn_Family.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Family.Textcolor = System.Drawing.Color.White;
            this.btn_Family.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Family.Click += new System.EventHandler(this.Btn_Family_Click);
            // 
            // btn_Cardiologist
            // 
            this.btn_Cardiologist.Activecolor = System.Drawing.Color.SteelBlue;
            this.btn_Cardiologist.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_Cardiologist.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Cardiologist.BorderRadius = 0;
            this.btn_Cardiologist.ButtonText = "Cardiologist";
            this.btn_Cardiologist.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Cardiologist.DisabledColor = System.Drawing.Color.Gray;
            this.btn_Cardiologist.Iconcolor = System.Drawing.Color.Transparent;
            this.btn_Cardiologist.Iconimage = null;
            this.btn_Cardiologist.Iconimage_right = null;
            this.btn_Cardiologist.Iconimage_right_Selected = null;
            this.btn_Cardiologist.Iconimage_Selected = null;
            this.btn_Cardiologist.IconMarginLeft = 0;
            this.btn_Cardiologist.IconMarginRight = 0;
            this.btn_Cardiologist.IconRightVisible = true;
            this.btn_Cardiologist.IconRightZoom = 0D;
            this.btn_Cardiologist.IconVisible = true;
            this.btn_Cardiologist.IconZoom = 90D;
            this.btn_Cardiologist.IsTab = false;
            this.btn_Cardiologist.Location = new System.Drawing.Point(0, 108);
            this.btn_Cardiologist.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Cardiologist.Name = "btn_Cardiologist";
            this.btn_Cardiologist.Normalcolor = System.Drawing.Color.SteelBlue;
            this.btn_Cardiologist.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.btn_Cardiologist.OnHoverTextColor = System.Drawing.Color.White;
            this.btn_Cardiologist.selected = false;
            this.btn_Cardiologist.Size = new System.Drawing.Size(480, 42);
            this.btn_Cardiologist.TabIndex = 26;
            this.btn_Cardiologist.Text = "Cardiologist";
            this.btn_Cardiologist.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Cardiologist.Textcolor = System.Drawing.Color.White;
            this.btn_Cardiologist.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Cardiologist.Click += new System.EventHandler(this.Btn_Cardiologist_Click);
            // 
            // Textbox_NIC
            // 
            this.Textbox_NIC.BackColor = System.Drawing.Color.Silver;
            this.Textbox_NIC.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_NIC.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_NIC.ForeColor = System.Drawing.Color.Black;
            this.Textbox_NIC.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_NIC.HintText = "Doctor\'s NIC";
            this.Textbox_NIC.isPassword = false;
            this.Textbox_NIC.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_NIC.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_NIC.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_NIC.LineThickness = 3;
            this.Textbox_NIC.Location = new System.Drawing.Point(599, 204);
            this.Textbox_NIC.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_NIC.Name = "Textbox_NIC";
            this.Textbox_NIC.Size = new System.Drawing.Size(480, 60);
            this.Textbox_NIC.TabIndex = 66;
            this.Textbox_NIC.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Textbox_NIC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_NIC_KeyPress);
            // 
            // Textbox_Experience
            // 
            this.Textbox_Experience.BackColor = System.Drawing.Color.Silver;
            this.Textbox_Experience.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_Experience.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Experience.ForeColor = System.Drawing.Color.Black;
            this.Textbox_Experience.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_Experience.HintText = "Years of Experience";
            this.Textbox_Experience.isPassword = false;
            this.Textbox_Experience.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_Experience.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_Experience.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_Experience.LineThickness = 3;
            this.Textbox_Experience.Location = new System.Drawing.Point(599, 369);
            this.Textbox_Experience.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_Experience.Name = "Textbox_Experience";
            this.Textbox_Experience.Size = new System.Drawing.Size(480, 60);
            this.Textbox_Experience.TabIndex = 64;
            this.Textbox_Experience.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Textbox_Experience.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Experience_KeyPress);
            // 
            // Textbox_TelephoneNum
            // 
            this.Textbox_TelephoneNum.BackColor = System.Drawing.Color.Silver;
            this.Textbox_TelephoneNum.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_TelephoneNum.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_TelephoneNum.ForeColor = System.Drawing.Color.Black;
            this.Textbox_TelephoneNum.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_TelephoneNum.HintText = "Doctor\'s Telephone Number";
            this.Textbox_TelephoneNum.isPassword = false;
            this.Textbox_TelephoneNum.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_TelephoneNum.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_TelephoneNum.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_TelephoneNum.LineThickness = 3;
            this.Textbox_TelephoneNum.Location = new System.Drawing.Point(61, 530);
            this.Textbox_TelephoneNum.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_TelephoneNum.Name = "Textbox_TelephoneNum";
            this.Textbox_TelephoneNum.Size = new System.Drawing.Size(480, 60);
            this.Textbox_TelephoneNum.TabIndex = 63;
            this.Textbox_TelephoneNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Textbox_TelephoneNum.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_TelephoneNum_KeyPress);
            // 
            // Textbox_Address
            // 
            this.Textbox_Address.BackColor = System.Drawing.Color.Silver;
            this.Textbox_Address.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_Address.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_Address.ForeColor = System.Drawing.Color.Black;
            this.Textbox_Address.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_Address.HintText = "Doctor\'s Address";
            this.Textbox_Address.isPassword = false;
            this.Textbox_Address.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_Address.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_Address.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_Address.LineThickness = 3;
            this.Textbox_Address.Location = new System.Drawing.Point(61, 369);
            this.Textbox_Address.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_Address.Name = "Textbox_Address";
            this.Textbox_Address.Size = new System.Drawing.Size(480, 60);
            this.Textbox_Address.TabIndex = 62;
            this.Textbox_Address.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Textbox_Address.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_Address_KeyPress);
            // 
            // Textbox_dName
            // 
            this.Textbox_dName.BackColor = System.Drawing.Color.Silver;
            this.Textbox_dName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_dName.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_dName.ForeColor = System.Drawing.Color.Black;
            this.Textbox_dName.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_dName.HintText = "Doctor\'s Name";
            this.Textbox_dName.isPassword = false;
            this.Textbox_dName.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_dName.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_dName.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_dName.LineThickness = 3;
            this.Textbox_dName.Location = new System.Drawing.Point(61, 204);
            this.Textbox_dName.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_dName.Name = "Textbox_dName";
            this.Textbox_dName.Size = new System.Drawing.Size(480, 60);
            this.Textbox_dName.TabIndex = 61;
            this.Textbox_dName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Textbox_dName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_dName_KeyPress);
            // 
            // Button_Clear
            // 
            this.Button_Clear.Activecolor = System.Drawing.Color.Crimson;
            this.Button_Clear.BackColor = System.Drawing.Color.Crimson;
            this.Button_Clear.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_Clear.BorderRadius = 0;
            this.Button_Clear.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Button_Clear.ButtonText = "CLEAR";
            this.Button_Clear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_Clear.DisabledColor = System.Drawing.Color.Gray;
            this.Button_Clear.ForeColor = System.Drawing.Color.White;
            this.Button_Clear.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_Clear.Iconimage = null;
            this.Button_Clear.Iconimage_right = null;
            this.Button_Clear.Iconimage_right_Selected = null;
            this.Button_Clear.Iconimage_Selected = null;
            this.Button_Clear.IconMarginLeft = 0;
            this.Button_Clear.IconMarginRight = 0;
            this.Button_Clear.IconRightVisible = true;
            this.Button_Clear.IconRightZoom = 0D;
            this.Button_Clear.IconVisible = true;
            this.Button_Clear.IconZoom = 90D;
            this.Button_Clear.IsTab = false;
            this.Button_Clear.Location = new System.Drawing.Point(599, 665);
            this.Button_Clear.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_Clear.Name = "Button_Clear";
            this.Button_Clear.Normalcolor = System.Drawing.Color.Crimson;
            this.Button_Clear.OnHovercolor = System.Drawing.Color.Transparent;
            this.Button_Clear.OnHoverTextColor = System.Drawing.Color.Black;
            this.Button_Clear.selected = false;
            this.Button_Clear.Size = new System.Drawing.Size(480, 64);
            this.Button_Clear.TabIndex = 58;
            this.Button_Clear.Text = "CLEAR";
            this.Button_Clear.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_Clear.Textcolor = System.Drawing.Color.White;
            this.Button_Clear.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Clear.Click += new System.EventHandler(this.Button_Clear_Click);
            // 
            // Button_ADD
            // 
            this.Button_ADD.Activecolor = System.Drawing.Color.ForestGreen;
            this.Button_ADD.BackColor = System.Drawing.Color.ForestGreen;
            this.Button_ADD.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_ADD.BorderRadius = 0;
            this.Button_ADD.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Button_ADD.ButtonText = "ADD";
            this.Button_ADD.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_ADD.DisabledColor = System.Drawing.Color.Gray;
            this.Button_ADD.ForeColor = System.Drawing.Color.White;
            this.Button_ADD.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_ADD.Iconimage = null;
            this.Button_ADD.Iconimage_right = null;
            this.Button_ADD.Iconimage_right_Selected = null;
            this.Button_ADD.Iconimage_Selected = null;
            this.Button_ADD.IconMarginLeft = 0;
            this.Button_ADD.IconMarginRight = 0;
            this.Button_ADD.IconRightVisible = true;
            this.Button_ADD.IconRightZoom = 0D;
            this.Button_ADD.IconVisible = true;
            this.Button_ADD.IconZoom = 90D;
            this.Button_ADD.IsTab = false;
            this.Button_ADD.Location = new System.Drawing.Point(61, 665);
            this.Button_ADD.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_ADD.Name = "Button_ADD";
            this.Button_ADD.Normalcolor = System.Drawing.Color.ForestGreen;
            this.Button_ADD.OnHovercolor = System.Drawing.Color.Transparent;
            this.Button_ADD.OnHoverTextColor = System.Drawing.Color.Black;
            this.Button_ADD.selected = false;
            this.Button_ADD.Size = new System.Drawing.Size(480, 64);
            this.Button_ADD.TabIndex = 57;
            this.Button_ADD.Text = "ADD";
            this.Button_ADD.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_ADD.Textcolor = System.Drawing.Color.White;
            this.Button_ADD.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_ADD.Click += new System.EventHandler(this.Button_ADD_Click);
            // 
            // Label_Gender
            // 
            this.Label_Gender.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Gender.AutoSize = true;
            this.Label_Gender.BackColor = System.Drawing.Color.Transparent;
            this.Label_Gender.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Gender.ForeColor = System.Drawing.Color.Black;
            this.Label_Gender.Location = new System.Drawing.Point(593, 479);
            this.Label_Gender.Name = "Label_Gender";
            this.Label_Gender.Size = new System.Drawing.Size(174, 32);
            this.Label_Gender.TabIndex = 31;
            this.Label_Gender.Text = "Doctor\'s Type";
            // 
            // Label_TelephoneNum
            // 
            this.Label_TelephoneNum.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_TelephoneNum.AutoSize = true;
            this.Label_TelephoneNum.BackColor = System.Drawing.Color.Transparent;
            this.Label_TelephoneNum.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_TelephoneNum.ForeColor = System.Drawing.Color.Black;
            this.Label_TelephoneNum.Location = new System.Drawing.Point(55, 479);
            this.Label_TelephoneNum.Name = "Label_TelephoneNum";
            this.Label_TelephoneNum.Size = new System.Drawing.Size(339, 32);
            this.Label_TelephoneNum.TabIndex = 29;
            this.Label_TelephoneNum.Text = "Doctor\'s Telephone Number";
            // 
            // Label_Age
            // 
            this.Label_Age.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Age.AutoSize = true;
            this.Label_Age.BackColor = System.Drawing.Color.Transparent;
            this.Label_Age.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Age.ForeColor = System.Drawing.Color.Black;
            this.Label_Age.Location = new System.Drawing.Point(593, 318);
            this.Label_Age.Name = "Label_Age";
            this.Label_Age.Size = new System.Drawing.Size(239, 32);
            this.Label_Age.TabIndex = 27;
            this.Label_Age.Text = "Years of Experience";
            // 
            // Label_Address
            // 
            this.Label_Address.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Address.AutoSize = true;
            this.Label_Address.BackColor = System.Drawing.Color.Transparent;
            this.Label_Address.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Address.ForeColor = System.Drawing.Color.Black;
            this.Label_Address.Location = new System.Drawing.Point(55, 318);
            this.Label_Address.Name = "Label_Address";
            this.Label_Address.Size = new System.Drawing.Size(211, 32);
            this.Label_Address.TabIndex = 25;
            this.Label_Address.Text = "Doctor\'s Address";
            // 
            // Label_NIC
            // 
            this.Label_NIC.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_NIC.AutoSize = true;
            this.Label_NIC.BackColor = System.Drawing.Color.Transparent;
            this.Label_NIC.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_NIC.ForeColor = System.Drawing.Color.Black;
            this.Label_NIC.Location = new System.Drawing.Point(593, 153);
            this.Label_NIC.Name = "Label_NIC";
            this.Label_NIC.Size = new System.Drawing.Size(161, 32);
            this.Label_NIC.TabIndex = 23;
            this.Label_NIC.Text = "Doctor\'s NIC";
            // 
            // Label_Name
            // 
            this.Label_Name.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Name.AutoSize = true;
            this.Label_Name.BackColor = System.Drawing.Color.Transparent;
            this.Label_Name.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Name.ForeColor = System.Drawing.Color.Black;
            this.Label_Name.Location = new System.Drawing.Point(55, 153);
            this.Label_Name.Name = "Label_Name";
            this.Label_Name.Size = new System.Drawing.Size(186, 32);
            this.Label_Name.TabIndex = 19;
            this.Label_Name.Text = "Doctor\'s Name";
            // 
            // Label_Title
            // 
            this.Label_Title.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Title.AutoSize = true;
            this.Label_Title.BackColor = System.Drawing.Color.Transparent;
            this.Label_Title.Font = new System.Drawing.Font("Felix Titling", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Title.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.Label_Title.Location = new System.Drawing.Point(334, 53);
            this.Label_Title.Name = "Label_Title";
            this.Label_Title.Size = new System.Drawing.Size(483, 35);
            this.Label_Title.TabIndex = 18;
            this.Label_Title.Text = "Add New Doctor\'s Details";
            // 
            // btn_Ophthalmologist
            // 
            this.btn_Ophthalmologist.Activecolor = System.Drawing.Color.SteelBlue;
            this.btn_Ophthalmologist.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_Ophthalmologist.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Ophthalmologist.BorderRadius = 0;
            this.btn_Ophthalmologist.ButtonText = "Ophthalmologist";
            this.btn_Ophthalmologist.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Ophthalmologist.DisabledColor = System.Drawing.Color.Gray;
            this.btn_Ophthalmologist.Iconcolor = System.Drawing.Color.Transparent;
            this.btn_Ophthalmologist.Iconimage = null;
            this.btn_Ophthalmologist.Iconimage_right = null;
            this.btn_Ophthalmologist.Iconimage_right_Selected = null;
            this.btn_Ophthalmologist.Iconimage_Selected = null;
            this.btn_Ophthalmologist.IconMarginLeft = 0;
            this.btn_Ophthalmologist.IconMarginRight = 0;
            this.btn_Ophthalmologist.IconRightVisible = true;
            this.btn_Ophthalmologist.IconRightZoom = 0D;
            this.btn_Ophthalmologist.IconVisible = true;
            this.btn_Ophthalmologist.IconZoom = 90D;
            this.btn_Ophthalmologist.IsTab = false;
            this.btn_Ophthalmologist.Location = new System.Drawing.Point(0, 152);
            this.btn_Ophthalmologist.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Ophthalmologist.Name = "btn_Ophthalmologist";
            this.btn_Ophthalmologist.Normalcolor = System.Drawing.Color.SteelBlue;
            this.btn_Ophthalmologist.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.btn_Ophthalmologist.OnHoverTextColor = System.Drawing.Color.White;
            this.btn_Ophthalmologist.selected = false;
            this.btn_Ophthalmologist.Size = new System.Drawing.Size(480, 42);
            this.btn_Ophthalmologist.TabIndex = 78;
            this.btn_Ophthalmologist.Text = "Ophthalmologist";
            this.btn_Ophthalmologist.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Ophthalmologist.Textcolor = System.Drawing.Color.White;
            this.btn_Ophthalmologist.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Ophthalmologist.Click += new System.EventHandler(this.Btn_Ophthalmologist_Click);
            // 
            // btn_Surgeon
            // 
            this.btn_Surgeon.Activecolor = System.Drawing.Color.SteelBlue;
            this.btn_Surgeon.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_Surgeon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Surgeon.BorderRadius = 0;
            this.btn_Surgeon.ButtonText = "Surgeon";
            this.btn_Surgeon.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Surgeon.DisabledColor = System.Drawing.Color.Gray;
            this.btn_Surgeon.Iconcolor = System.Drawing.Color.Transparent;
            this.btn_Surgeon.Iconimage = null;
            this.btn_Surgeon.Iconimage_right = null;
            this.btn_Surgeon.Iconimage_right_Selected = null;
            this.btn_Surgeon.Iconimage_Selected = null;
            this.btn_Surgeon.IconMarginLeft = 0;
            this.btn_Surgeon.IconMarginRight = 0;
            this.btn_Surgeon.IconRightVisible = true;
            this.btn_Surgeon.IconRightZoom = 0D;
            this.btn_Surgeon.IconVisible = true;
            this.btn_Surgeon.IconZoom = 90D;
            this.btn_Surgeon.IsTab = false;
            this.btn_Surgeon.Location = new System.Drawing.Point(0, 196);
            this.btn_Surgeon.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Surgeon.Name = "btn_Surgeon";
            this.btn_Surgeon.Normalcolor = System.Drawing.Color.SteelBlue;
            this.btn_Surgeon.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.btn_Surgeon.OnHoverTextColor = System.Drawing.Color.White;
            this.btn_Surgeon.selected = false;
            this.btn_Surgeon.Size = new System.Drawing.Size(480, 42);
            this.btn_Surgeon.TabIndex = 79;
            this.btn_Surgeon.Text = "Surgeon";
            this.btn_Surgeon.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Surgeon.Textcolor = System.Drawing.Color.White;
            this.btn_Surgeon.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Surgeon.Click += new System.EventHandler(this.Btn_Surgeon_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 1;
            this.timer1.Tick += new System.EventHandler(this.Timer1_Tick);
            // 
            // addDoctorsControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.bunifuGradientPanel1);
            this.Name = "addDoctorsControl";
            this.Size = new System.Drawing.Size(1140, 812);
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            this.panel_Types.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel1;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_NICStatus;
        private System.Windows.Forms.Label label_Errors;
        private System.Windows.Forms.Label label_dEType;
        private System.Windows.Forms.Label label_dETelephoneNum;
        private System.Windows.Forms.Label label_dEExperience;
        private System.Windows.Forms.Label label_dEAddress;
        private System.Windows.Forms.Label label_dENIC;
        private System.Windows.Forms.Label label_dEName;
        private System.Windows.Forms.Panel panel_Types;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator1;
        public Bunifu.Framework.UI.BunifuFlatButton Button_Type;
        public Bunifu.Framework.UI.BunifuFlatButton btn_Family;
        public Bunifu.Framework.UI.BunifuFlatButton btn_Cardiologist;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_NIC;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_Experience;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_TelephoneNum;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_Address;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_dName;
        public Bunifu.Framework.UI.BunifuFlatButton Button_Clear;
        public Bunifu.Framework.UI.BunifuFlatButton Button_ADD;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Gender;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_TelephoneNum;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Age;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Address;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_NIC;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Name;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Title;
        public Bunifu.Framework.UI.BunifuFlatButton btn_Surgeon;
        public Bunifu.Framework.UI.BunifuFlatButton btn_Ophthalmologist;
        private System.Windows.Forms.Timer timer1;
    }
}
