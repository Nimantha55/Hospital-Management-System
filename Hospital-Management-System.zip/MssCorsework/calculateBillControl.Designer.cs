﻿namespace MssCorsework
{
    partial class calculateBillControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(calculateBillControl));
            this.bunifuGradientPanel1 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.Textbox_reports = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Textbox_pres = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Textbox_AdmissionNum = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Label_TelephoneNum = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Textbox_RCharge = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Textbox_MCharge = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Textbox_RepCharge = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.btn_result = new Bunifu.Framework.UI.BunifuFlatButton();
            this.label_RepCharge = new System.Windows.Forms.Label();
            this.label_MCharge = new System.Windows.Forms.Label();
            this.label_RCharge = new System.Windows.Forms.Label();
            this.Textbox_charge = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.lbl_totalCharge = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lbl_aTax = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lbl_hCharge = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_dFee = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuSeparator3 = new Bunifu.Framework.UI.BunifuSeparator();
            this.Datepicker_aDate = new System.Windows.Forms.DateTimePicker();
            this.label_ID = new System.Windows.Forms.Label();
            this.bunifuSeparator2 = new Bunifu.Framework.UI.BunifuSeparator();
            this.panel_DocType = new System.Windows.Forms.Panel();
            this.btn_Type4 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btn_Type3 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btn_Type1 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btn_Type2 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Button_bill = new Bunifu.Framework.UI.BunifuFlatButton();
            this.label_ESearchNIC = new System.Windows.Forms.Label();
            this.bunifuSeparator1 = new Bunifu.Framework.UI.BunifuSeparator();
            this.Button_Search = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Label_SearchNIC = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Textbox_SearchNIC = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label_Errors = new System.Windows.Forms.Label();
            this.label_EDate = new System.Windows.Forms.Label();
            this.Textbox_pName = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Button_SavePayment = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Label_Date = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_Name = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_Title = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuGradientPanel1.SuspendLayout();
            this.panel_DocType.SuspendLayout();
            this.SuspendLayout();
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_reports);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuCustomLabel1);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_pres);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuCustomLabel2);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_AdmissionNum);
            this.bunifuGradientPanel1.Controls.Add(this.Label_TelephoneNum);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_RCharge);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_MCharge);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_RepCharge);
            this.bunifuGradientPanel1.Controls.Add(this.btn_result);
            this.bunifuGradientPanel1.Controls.Add(this.label_RepCharge);
            this.bunifuGradientPanel1.Controls.Add(this.label_MCharge);
            this.bunifuGradientPanel1.Controls.Add(this.label_RCharge);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_charge);
            this.bunifuGradientPanel1.Controls.Add(this.lbl_totalCharge);
            this.bunifuGradientPanel1.Controls.Add(this.lbl_aTax);
            this.bunifuGradientPanel1.Controls.Add(this.lbl_hCharge);
            this.bunifuGradientPanel1.Controls.Add(this.Label_dFee);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuSeparator3);
            this.bunifuGradientPanel1.Controls.Add(this.Datepicker_aDate);
            this.bunifuGradientPanel1.Controls.Add(this.label_ID);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuSeparator2);
            this.bunifuGradientPanel1.Controls.Add(this.panel_DocType);
            this.bunifuGradientPanel1.Controls.Add(this.label_ESearchNIC);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuSeparator1);
            this.bunifuGradientPanel1.Controls.Add(this.Button_Search);
            this.bunifuGradientPanel1.Controls.Add(this.Label_SearchNIC);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_SearchNIC);
            this.bunifuGradientPanel1.Controls.Add(this.label_Errors);
            this.bunifuGradientPanel1.Controls.Add(this.label_EDate);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_pName);
            this.bunifuGradientPanel1.Controls.Add(this.Button_SavePayment);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Date);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Name);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Title);
            this.bunifuGradientPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.Black;
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.Gray;
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(1140, 812);
            this.bunifuGradientPanel1.TabIndex = 3;
            // 
            // Textbox_reports
            // 
            this.Textbox_reports.BackColor = System.Drawing.Color.Silver;
            this.Textbox_reports.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_reports.Enabled = false;
            this.Textbox_reports.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_reports.ForeColor = System.Drawing.Color.Black;
            this.Textbox_reports.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_reports.HintText = "Reports";
            this.Textbox_reports.isPassword = false;
            this.Textbox_reports.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_reports.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_reports.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_reports.LineThickness = 3;
            this.Textbox_reports.Location = new System.Drawing.Point(596, 426);
            this.Textbox_reports.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_reports.Name = "Textbox_reports";
            this.Textbox_reports.Size = new System.Drawing.Size(480, 60);
            this.Textbox_reports.TabIndex = 128;
            this.Textbox_reports.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.Black;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(593, 379);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(104, 32);
            this.bunifuCustomLabel1.TabIndex = 127;
            this.bunifuCustomLabel1.Text = "Reports";
            // 
            // Textbox_pres
            // 
            this.Textbox_pres.BackColor = System.Drawing.Color.Silver;
            this.Textbox_pres.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_pres.Enabled = false;
            this.Textbox_pres.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_pres.ForeColor = System.Drawing.Color.Black;
            this.Textbox_pres.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_pres.HintText = "Prescriptions";
            this.Textbox_pres.isPassword = false;
            this.Textbox_pres.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_pres.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_pres.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_pres.LineThickness = 3;
            this.Textbox_pres.Location = new System.Drawing.Point(61, 426);
            this.Textbox_pres.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_pres.Name = "Textbox_pres";
            this.Textbox_pres.Size = new System.Drawing.Size(480, 60);
            this.Textbox_pres.TabIndex = 126;
            this.Textbox_pres.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel2.ForeColor = System.Drawing.Color.Black;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(58, 379);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(165, 32);
            this.bunifuCustomLabel2.TabIndex = 125;
            this.bunifuCustomLabel2.Text = "Prescriptions";
            // 
            // Textbox_AdmissionNum
            // 
            this.Textbox_AdmissionNum.BackColor = System.Drawing.Color.Silver;
            this.Textbox_AdmissionNum.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_AdmissionNum.Enabled = false;
            this.Textbox_AdmissionNum.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_AdmissionNum.ForeColor = System.Drawing.Color.Black;
            this.Textbox_AdmissionNum.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_AdmissionNum.HintText = "Admission Number";
            this.Textbox_AdmissionNum.isPassword = false;
            this.Textbox_AdmissionNum.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_AdmissionNum.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_AdmissionNum.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_AdmissionNum.LineThickness = 3;
            this.Textbox_AdmissionNum.Location = new System.Drawing.Point(596, 295);
            this.Textbox_AdmissionNum.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_AdmissionNum.Name = "Textbox_AdmissionNum";
            this.Textbox_AdmissionNum.Size = new System.Drawing.Size(480, 60);
            this.Textbox_AdmissionNum.TabIndex = 124;
            this.Textbox_AdmissionNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // Label_TelephoneNum
            // 
            this.Label_TelephoneNum.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_TelephoneNum.AutoSize = true;
            this.Label_TelephoneNum.BackColor = System.Drawing.Color.Transparent;
            this.Label_TelephoneNum.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_TelephoneNum.ForeColor = System.Drawing.Color.Black;
            this.Label_TelephoneNum.Location = new System.Drawing.Point(590, 247);
            this.Label_TelephoneNum.Name = "Label_TelephoneNum";
            this.Label_TelephoneNum.Size = new System.Drawing.Size(236, 32);
            this.Label_TelephoneNum.TabIndex = 123;
            this.Label_TelephoneNum.Text = "Admission Number";
            // 
            // Textbox_RCharge
            // 
            this.Textbox_RCharge.BackColor = System.Drawing.Color.Silver;
            this.Textbox_RCharge.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_RCharge.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_RCharge.ForeColor = System.Drawing.Color.Black;
            this.Textbox_RCharge.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_RCharge.HintText = "Room Charges";
            this.Textbox_RCharge.isPassword = false;
            this.Textbox_RCharge.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_RCharge.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_RCharge.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_RCharge.LineThickness = 3;
            this.Textbox_RCharge.Location = new System.Drawing.Point(66, 564);
            this.Textbox_RCharge.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_RCharge.Name = "Textbox_RCharge";
            this.Textbox_RCharge.Size = new System.Drawing.Size(208, 58);
            this.Textbox_RCharge.TabIndex = 122;
            this.Textbox_RCharge.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Textbox_RCharge.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_dFee_KeyPress);
            // 
            // Textbox_MCharge
            // 
            this.Textbox_MCharge.BackColor = System.Drawing.Color.Silver;
            this.Textbox_MCharge.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_MCharge.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_MCharge.ForeColor = System.Drawing.Color.Black;
            this.Textbox_MCharge.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_MCharge.HintText = "Medicine Charges ";
            this.Textbox_MCharge.isPassword = false;
            this.Textbox_MCharge.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_MCharge.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_MCharge.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_MCharge.LineThickness = 3;
            this.Textbox_MCharge.Location = new System.Drawing.Point(320, 564);
            this.Textbox_MCharge.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_MCharge.Name = "Textbox_MCharge";
            this.Textbox_MCharge.Size = new System.Drawing.Size(208, 58);
            this.Textbox_MCharge.TabIndex = 121;
            this.Textbox_MCharge.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Textbox_MCharge.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_hCharge_KeyPress);
            // 
            // Textbox_RepCharge
            // 
            this.Textbox_RepCharge.BackColor = System.Drawing.Color.Silver;
            this.Textbox_RepCharge.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_RepCharge.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_RepCharge.ForeColor = System.Drawing.Color.Black;
            this.Textbox_RepCharge.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_RepCharge.HintText = "Report Charges    ";
            this.Textbox_RepCharge.isPassword = false;
            this.Textbox_RepCharge.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_RepCharge.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_RepCharge.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_RepCharge.LineThickness = 3;
            this.Textbox_RepCharge.Location = new System.Drawing.Point(572, 564);
            this.Textbox_RepCharge.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_RepCharge.Name = "Textbox_RepCharge";
            this.Textbox_RepCharge.Size = new System.Drawing.Size(208, 58);
            this.Textbox_RepCharge.TabIndex = 120;
            this.Textbox_RepCharge.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Textbox_RepCharge.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_aTax_KeyPress);
            // 
            // btn_result
            // 
            this.btn_result.Activecolor = System.Drawing.Color.RoyalBlue;
            this.btn_result.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn_result.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_result.BorderRadius = 0;
            this.btn_result.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.btn_result.ButtonText = "TOTAL";
            this.btn_result.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_result.DisabledColor = System.Drawing.Color.Gray;
            this.btn_result.ForeColor = System.Drawing.Color.White;
            this.btn_result.Iconcolor = System.Drawing.Color.Transparent;
            this.btn_result.Iconimage = null;
            this.btn_result.Iconimage_right = null;
            this.btn_result.Iconimage_right_Selected = null;
            this.btn_result.Iconimage_Selected = null;
            this.btn_result.IconMarginLeft = 0;
            this.btn_result.IconMarginRight = 0;
            this.btn_result.IconRightVisible = true;
            this.btn_result.IconRightZoom = 0D;
            this.btn_result.IconVisible = true;
            this.btn_result.IconZoom = 90D;
            this.btn_result.IsTab = false;
            this.btn_result.Location = new System.Drawing.Point(823, 637);
            this.btn_result.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_result.Name = "btn_result";
            this.btn_result.Normalcolor = System.Drawing.Color.RoyalBlue;
            this.btn_result.OnHovercolor = System.Drawing.Color.Transparent;
            this.btn_result.OnHoverTextColor = System.Drawing.Color.Black;
            this.btn_result.selected = false;
            this.btn_result.Size = new System.Drawing.Size(253, 52);
            this.btn_result.TabIndex = 118;
            this.btn_result.Text = "TOTAL";
            this.btn_result.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_result.Textcolor = System.Drawing.Color.White;
            this.btn_result.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_result.Click += new System.EventHandler(this.Btn_result_Click);
            // 
            // label_RepCharge
            // 
            this.label_RepCharge.AutoSize = true;
            this.label_RepCharge.BackColor = System.Drawing.Color.Transparent;
            this.label_RepCharge.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_RepCharge.ForeColor = System.Drawing.Color.Red;
            this.label_RepCharge.Location = new System.Drawing.Point(568, 636);
            this.label_RepCharge.Name = "label_RepCharge";
            this.label_RepCharge.Size = new System.Drawing.Size(60, 19);
            this.label_RepCharge.TabIndex = 116;
            this.label_RepCharge.Text = "label5";
            this.label_RepCharge.Visible = false;
            // 
            // label_MCharge
            // 
            this.label_MCharge.AutoSize = true;
            this.label_MCharge.BackColor = System.Drawing.Color.Transparent;
            this.label_MCharge.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_MCharge.ForeColor = System.Drawing.Color.Red;
            this.label_MCharge.Location = new System.Drawing.Point(316, 636);
            this.label_MCharge.Name = "label_MCharge";
            this.label_MCharge.Size = new System.Drawing.Size(60, 19);
            this.label_MCharge.TabIndex = 115;
            this.label_MCharge.Text = "label5";
            this.label_MCharge.Visible = false;
            // 
            // label_RCharge
            // 
            this.label_RCharge.AutoSize = true;
            this.label_RCharge.BackColor = System.Drawing.Color.Transparent;
            this.label_RCharge.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_RCharge.ForeColor = System.Drawing.Color.Red;
            this.label_RCharge.Location = new System.Drawing.Point(62, 636);
            this.label_RCharge.Name = "label_RCharge";
            this.label_RCharge.Size = new System.Drawing.Size(60, 19);
            this.label_RCharge.TabIndex = 114;
            this.label_RCharge.Text = "label5";
            this.label_RCharge.Visible = false;
            // 
            // Textbox_charge
            // 
            this.Textbox_charge.BackColor = System.Drawing.Color.Silver;
            this.Textbox_charge.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_charge.Enabled = false;
            this.Textbox_charge.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_charge.ForeColor = System.Drawing.Color.Black;
            this.Textbox_charge.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_charge.HintText = "Total Charge";
            this.Textbox_charge.isPassword = false;
            this.Textbox_charge.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_charge.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_charge.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_charge.LineThickness = 3;
            this.Textbox_charge.Location = new System.Drawing.Point(823, 564);
            this.Textbox_charge.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_charge.Name = "Textbox_charge";
            this.Textbox_charge.Size = new System.Drawing.Size(253, 58);
            this.Textbox_charge.TabIndex = 113;
            this.Textbox_charge.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // lbl_totalCharge
            // 
            this.lbl_totalCharge.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_totalCharge.AutoSize = true;
            this.lbl_totalCharge.BackColor = System.Drawing.Color.Transparent;
            this.lbl_totalCharge.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_totalCharge.ForeColor = System.Drawing.Color.Black;
            this.lbl_totalCharge.Location = new System.Drawing.Point(817, 527);
            this.lbl_totalCharge.Name = "lbl_totalCharge";
            this.lbl_totalCharge.Size = new System.Drawing.Size(229, 32);
            this.lbl_totalCharge.TabIndex = 112;
            this.lbl_totalCharge.Text = "Total Charge (LKR)";
            // 
            // lbl_aTax
            // 
            this.lbl_aTax.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_aTax.AutoSize = true;
            this.lbl_aTax.BackColor = System.Drawing.Color.Transparent;
            this.lbl_aTax.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_aTax.ForeColor = System.Drawing.Color.Black;
            this.lbl_aTax.Location = new System.Drawing.Point(566, 527);
            this.lbl_aTax.Name = "lbl_aTax";
            this.lbl_aTax.Size = new System.Drawing.Size(219, 32);
            this.lbl_aTax.TabIndex = 109;
            this.lbl_aTax.Text = "Report Charges    ";
            // 
            // lbl_hCharge
            // 
            this.lbl_hCharge.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_hCharge.AutoSize = true;
            this.lbl_hCharge.BackColor = System.Drawing.Color.Transparent;
            this.lbl_hCharge.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_hCharge.ForeColor = System.Drawing.Color.Black;
            this.lbl_hCharge.Location = new System.Drawing.Point(314, 527);
            this.lbl_hCharge.Name = "lbl_hCharge";
            this.lbl_hCharge.Size = new System.Drawing.Size(225, 32);
            this.lbl_hCharge.TabIndex = 106;
            this.lbl_hCharge.Text = "Medicine Charges ";
            // 
            // Label_dFee
            // 
            this.Label_dFee.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_dFee.AutoSize = true;
            this.Label_dFee.BackColor = System.Drawing.Color.Transparent;
            this.Label_dFee.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_dFee.ForeColor = System.Drawing.Color.Black;
            this.Label_dFee.Location = new System.Drawing.Point(60, 527);
            this.Label_dFee.Name = "Label_dFee";
            this.Label_dFee.Size = new System.Drawing.Size(181, 32);
            this.Label_dFee.TabIndex = 103;
            this.Label_dFee.Text = "Room Charges";
            // 
            // bunifuSeparator3
            // 
            this.bunifuSeparator3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator3.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator3.LineThickness = 2;
            this.bunifuSeparator3.Location = new System.Drawing.Point(61, 503);
            this.bunifuSeparator3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator3.Name = "bunifuSeparator3";
            this.bunifuSeparator3.Size = new System.Drawing.Size(1018, 10);
            this.bunifuSeparator3.TabIndex = 102;
            this.bunifuSeparator3.Transparency = 255;
            this.bunifuSeparator3.Vertical = false;
            // 
            // Datepicker_aDate
            // 
            this.Datepicker_aDate.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Datepicker_aDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Datepicker_aDate.Location = new System.Drawing.Point(496, 142);
            this.Datepicker_aDate.MinimumSize = new System.Drawing.Size(4, 44);
            this.Datepicker_aDate.Name = "Datepicker_aDate";
            this.Datepicker_aDate.Size = new System.Drawing.Size(400, 44);
            this.Datepicker_aDate.TabIndex = 97;
            // 
            // label_ID
            // 
            this.label_ID.AutoSize = true;
            this.label_ID.BackColor = System.Drawing.Color.Transparent;
            this.label_ID.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ID.ForeColor = System.Drawing.Color.Black;
            this.label_ID.Location = new System.Drawing.Point(1053, 27);
            this.label_ID.Name = "label_ID";
            this.label_ID.Size = new System.Drawing.Size(26, 19);
            this.label_ID.TabIndex = 95;
            this.label_ID.Text = "ID";
            this.label_ID.Visible = false;
            // 
            // bunifuSeparator2
            // 
            this.bunifuSeparator2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator2.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuSeparator2.LineThickness = 3;
            this.bunifuSeparator2.Location = new System.Drawing.Point(496, 183);
            this.bunifuSeparator2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator2.Name = "bunifuSeparator2";
            this.bunifuSeparator2.Size = new System.Drawing.Size(400, 10);
            this.bunifuSeparator2.TabIndex = 92;
            this.bunifuSeparator2.Transparency = 255;
            this.bunifuSeparator2.Vertical = false;
            // 
            // panel_DocType
            // 
            this.panel_DocType.BackColor = System.Drawing.Color.Transparent;
            this.panel_DocType.Controls.Add(this.btn_Type4);
            this.panel_DocType.Controls.Add(this.btn_Type3);
            this.panel_DocType.Controls.Add(this.btn_Type1);
            this.panel_DocType.Controls.Add(this.btn_Type2);
            this.panel_DocType.Controls.Add(this.Button_bill);
            this.panel_DocType.Location = new System.Drawing.Point(599, 702);
            this.panel_DocType.MaximumSize = new System.Drawing.Size(480, 242);
            this.panel_DocType.MinimumSize = new System.Drawing.Size(480, 64);
            this.panel_DocType.Name = "panel_DocType";
            this.panel_DocType.Size = new System.Drawing.Size(480, 64);
            this.panel_DocType.TabIndex = 88;
            // 
            // btn_Type4
            // 
            this.btn_Type4.Activecolor = System.Drawing.Color.SteelBlue;
            this.btn_Type4.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_Type4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Type4.BorderRadius = 0;
            this.btn_Type4.ButtonText = "Surgeon";
            this.btn_Type4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Type4.DisabledColor = System.Drawing.Color.Gray;
            this.btn_Type4.Iconcolor = System.Drawing.Color.Transparent;
            this.btn_Type4.Iconimage = null;
            this.btn_Type4.Iconimage_right = null;
            this.btn_Type4.Iconimage_right_Selected = null;
            this.btn_Type4.Iconimage_Selected = null;
            this.btn_Type4.IconMarginLeft = 0;
            this.btn_Type4.IconMarginRight = 0;
            this.btn_Type4.IconRightVisible = true;
            this.btn_Type4.IconRightZoom = 0D;
            this.btn_Type4.IconVisible = true;
            this.btn_Type4.IconZoom = 90D;
            this.btn_Type4.IsTab = false;
            this.btn_Type4.Location = new System.Drawing.Point(0, 199);
            this.btn_Type4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Type4.Name = "btn_Type4";
            this.btn_Type4.Normalcolor = System.Drawing.Color.SteelBlue;
            this.btn_Type4.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.btn_Type4.OnHoverTextColor = System.Drawing.Color.White;
            this.btn_Type4.selected = false;
            this.btn_Type4.Size = new System.Drawing.Size(480, 42);
            this.btn_Type4.TabIndex = 60;
            this.btn_Type4.Text = "Surgeon";
            this.btn_Type4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Type4.Textcolor = System.Drawing.Color.White;
            this.btn_Type4.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btn_Type3
            // 
            this.btn_Type3.Activecolor = System.Drawing.Color.SteelBlue;
            this.btn_Type3.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_Type3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Type3.BorderRadius = 0;
            this.btn_Type3.ButtonText = "Ophthalmologist";
            this.btn_Type3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Type3.DisabledColor = System.Drawing.Color.Gray;
            this.btn_Type3.Iconcolor = System.Drawing.Color.Transparent;
            this.btn_Type3.Iconimage = null;
            this.btn_Type3.Iconimage_right = null;
            this.btn_Type3.Iconimage_right_Selected = null;
            this.btn_Type3.Iconimage_Selected = null;
            this.btn_Type3.IconMarginLeft = 0;
            this.btn_Type3.IconMarginRight = 0;
            this.btn_Type3.IconRightVisible = true;
            this.btn_Type3.IconRightZoom = 0D;
            this.btn_Type3.IconVisible = true;
            this.btn_Type3.IconZoom = 90D;
            this.btn_Type3.IsTab = false;
            this.btn_Type3.Location = new System.Drawing.Point(0, 155);
            this.btn_Type3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Type3.Name = "btn_Type3";
            this.btn_Type3.Normalcolor = System.Drawing.Color.SteelBlue;
            this.btn_Type3.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.btn_Type3.OnHoverTextColor = System.Drawing.Color.White;
            this.btn_Type3.selected = false;
            this.btn_Type3.Size = new System.Drawing.Size(480, 42);
            this.btn_Type3.TabIndex = 59;
            this.btn_Type3.Text = "Ophthalmologist";
            this.btn_Type3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Type3.Textcolor = System.Drawing.Color.White;
            this.btn_Type3.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btn_Type1
            // 
            this.btn_Type1.Activecolor = System.Drawing.Color.SteelBlue;
            this.btn_Type1.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_Type1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Type1.BorderRadius = 0;
            this.btn_Type1.ButtonText = "Cardiologist";
            this.btn_Type1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Type1.DisabledColor = System.Drawing.Color.Gray;
            this.btn_Type1.Iconcolor = System.Drawing.Color.Transparent;
            this.btn_Type1.Iconimage = null;
            this.btn_Type1.Iconimage_right = null;
            this.btn_Type1.Iconimage_right_Selected = null;
            this.btn_Type1.Iconimage_Selected = null;
            this.btn_Type1.IconMarginLeft = 0;
            this.btn_Type1.IconMarginRight = 0;
            this.btn_Type1.IconRightVisible = true;
            this.btn_Type1.IconRightZoom = 0D;
            this.btn_Type1.IconVisible = true;
            this.btn_Type1.IconZoom = 90D;
            this.btn_Type1.IsTab = false;
            this.btn_Type1.Location = new System.Drawing.Point(0, 67);
            this.btn_Type1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Type1.Name = "btn_Type1";
            this.btn_Type1.Normalcolor = System.Drawing.Color.SteelBlue;
            this.btn_Type1.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.btn_Type1.OnHoverTextColor = System.Drawing.Color.White;
            this.btn_Type1.selected = false;
            this.btn_Type1.Size = new System.Drawing.Size(480, 42);
            this.btn_Type1.TabIndex = 25;
            this.btn_Type1.Text = "Cardiologist";
            this.btn_Type1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Type1.Textcolor = System.Drawing.Color.White;
            this.btn_Type1.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btn_Type2
            // 
            this.btn_Type2.Activecolor = System.Drawing.Color.SteelBlue;
            this.btn_Type2.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_Type2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Type2.BorderRadius = 0;
            this.btn_Type2.ButtonText = "Family Physician";
            this.btn_Type2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_Type2.DisabledColor = System.Drawing.Color.Gray;
            this.btn_Type2.Iconcolor = System.Drawing.Color.Transparent;
            this.btn_Type2.Iconimage = null;
            this.btn_Type2.Iconimage_right = null;
            this.btn_Type2.Iconimage_right_Selected = null;
            this.btn_Type2.Iconimage_Selected = null;
            this.btn_Type2.IconMarginLeft = 0;
            this.btn_Type2.IconMarginRight = 0;
            this.btn_Type2.IconRightVisible = true;
            this.btn_Type2.IconRightZoom = 0D;
            this.btn_Type2.IconVisible = true;
            this.btn_Type2.IconZoom = 90D;
            this.btn_Type2.IsTab = false;
            this.btn_Type2.Location = new System.Drawing.Point(0, 111);
            this.btn_Type2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_Type2.Name = "btn_Type2";
            this.btn_Type2.Normalcolor = System.Drawing.Color.SteelBlue;
            this.btn_Type2.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.btn_Type2.OnHoverTextColor = System.Drawing.Color.White;
            this.btn_Type2.selected = false;
            this.btn_Type2.Size = new System.Drawing.Size(480, 42);
            this.btn_Type2.TabIndex = 26;
            this.btn_Type2.Text = "Family Physician";
            this.btn_Type2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_Type2.Textcolor = System.Drawing.Color.White;
            this.btn_Type2.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // Button_bill
            // 
            this.Button_bill.Activecolor = System.Drawing.Color.Crimson;
            this.Button_bill.BackColor = System.Drawing.Color.Crimson;
            this.Button_bill.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_bill.BorderRadius = 0;
            this.Button_bill.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Button_bill.ButtonText = "GENERATE BILL";
            this.Button_bill.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_bill.DisabledColor = System.Drawing.Color.Gray;
            this.Button_bill.ForeColor = System.Drawing.Color.White;
            this.Button_bill.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_bill.Iconimage = null;
            this.Button_bill.Iconimage_right = null;
            this.Button_bill.Iconimage_right_Selected = null;
            this.Button_bill.Iconimage_Selected = null;
            this.Button_bill.IconMarginLeft = 0;
            this.Button_bill.IconMarginRight = 0;
            this.Button_bill.IconRightVisible = true;
            this.Button_bill.IconRightZoom = 0D;
            this.Button_bill.IconVisible = true;
            this.Button_bill.IconZoom = 90D;
            this.Button_bill.IsTab = false;
            this.Button_bill.Location = new System.Drawing.Point(0, 0);
            this.Button_bill.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_bill.Name = "Button_bill";
            this.Button_bill.Normalcolor = System.Drawing.Color.Crimson;
            this.Button_bill.OnHovercolor = System.Drawing.Color.Transparent;
            this.Button_bill.OnHoverTextColor = System.Drawing.Color.Black;
            this.Button_bill.selected = false;
            this.Button_bill.Size = new System.Drawing.Size(480, 64);
            this.Button_bill.TabIndex = 58;
            this.Button_bill.Text = "GENERATE BILL";
            this.Button_bill.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_bill.Textcolor = System.Drawing.Color.White;
            this.Button_bill.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_bill.Click += new System.EventHandler(this.Button_bill_Click);
            // 
            // label_ESearchNIC
            // 
            this.label_ESearchNIC.AutoSize = true;
            this.label_ESearchNIC.BackColor = System.Drawing.Color.Transparent;
            this.label_ESearchNIC.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ESearchNIC.ForeColor = System.Drawing.Color.Red;
            this.label_ESearchNIC.Location = new System.Drawing.Point(60, 200);
            this.label_ESearchNIC.Name = "label_ESearchNIC";
            this.label_ESearchNIC.Size = new System.Drawing.Size(60, 19);
            this.label_ESearchNIC.TabIndex = 85;
            this.label_ESearchNIC.Text = "label5";
            this.label_ESearchNIC.Visible = false;
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator1.LineThickness = 2;
            this.bunifuSeparator1.Location = new System.Drawing.Point(64, 233);
            this.bunifuSeparator1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Size = new System.Drawing.Size(1018, 10);
            this.bunifuSeparator1.TabIndex = 84;
            this.bunifuSeparator1.Transparency = 255;
            this.bunifuSeparator1.Vertical = false;
            // 
            // Button_Search
            // 
            this.Button_Search.Activecolor = System.Drawing.Color.DarkViolet;
            this.Button_Search.BackColor = System.Drawing.Color.DarkViolet;
            this.Button_Search.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_Search.BorderRadius = 0;
            this.Button_Search.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Button_Search.ButtonText = "SEARCH";
            this.Button_Search.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_Search.DisabledColor = System.Drawing.Color.Gray;
            this.Button_Search.ForeColor = System.Drawing.Color.White;
            this.Button_Search.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_Search.Iconimage = null;
            this.Button_Search.Iconimage_right = null;
            this.Button_Search.Iconimage_right_Selected = null;
            this.Button_Search.Iconimage_Selected = null;
            this.Button_Search.IconMarginLeft = 0;
            this.Button_Search.IconMarginRight = 0;
            this.Button_Search.IconRightVisible = true;
            this.Button_Search.IconRightZoom = 0D;
            this.Button_Search.IconVisible = true;
            this.Button_Search.IconZoom = 90D;
            this.Button_Search.IsTab = false;
            this.Button_Search.Location = new System.Drawing.Point(915, 142);
            this.Button_Search.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_Search.Name = "Button_Search";
            this.Button_Search.Normalcolor = System.Drawing.Color.DarkViolet;
            this.Button_Search.OnHovercolor = System.Drawing.Color.Transparent;
            this.Button_Search.OnHoverTextColor = System.Drawing.Color.Black;
            this.Button_Search.selected = false;
            this.Button_Search.Size = new System.Drawing.Size(167, 51);
            this.Button_Search.TabIndex = 83;
            this.Button_Search.Text = "SEARCH";
            this.Button_Search.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_Search.Textcolor = System.Drawing.Color.White;
            this.Button_Search.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Search.Click += new System.EventHandler(this.Button_Search_Click);
            // 
            // Label_SearchNIC
            // 
            this.Label_SearchNIC.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_SearchNIC.AutoSize = true;
            this.Label_SearchNIC.BackColor = System.Drawing.Color.Transparent;
            this.Label_SearchNIC.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SearchNIC.ForeColor = System.Drawing.Color.Black;
            this.Label_SearchNIC.Location = new System.Drawing.Point(58, 104);
            this.Label_SearchNIC.Name = "Label_SearchNIC";
            this.Label_SearchNIC.Size = new System.Drawing.Size(163, 32);
            this.Label_SearchNIC.TabIndex = 82;
            this.Label_SearchNIC.Text = "Patient\'s NIC";
            // 
            // Textbox_SearchNIC
            // 
            this.Textbox_SearchNIC.BackColor = System.Drawing.Color.Silver;
            this.Textbox_SearchNIC.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_SearchNIC.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_SearchNIC.ForeColor = System.Drawing.Color.Black;
            this.Textbox_SearchNIC.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_SearchNIC.HintText = "Patient\'s NIC";
            this.Textbox_SearchNIC.isPassword = false;
            this.Textbox_SearchNIC.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_SearchNIC.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_SearchNIC.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_SearchNIC.LineThickness = 3;
            this.Textbox_SearchNIC.Location = new System.Drawing.Point(64, 144);
            this.Textbox_SearchNIC.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_SearchNIC.Name = "Textbox_SearchNIC";
            this.Textbox_SearchNIC.Size = new System.Drawing.Size(400, 45);
            this.Textbox_SearchNIC.TabIndex = 81;
            this.Textbox_SearchNIC.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label_Errors
            // 
            this.label_Errors.AutoSize = true;
            this.label_Errors.BackColor = System.Drawing.Color.Transparent;
            this.label_Errors.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Errors.ForeColor = System.Drawing.Color.Red;
            this.label_Errors.Location = new System.Drawing.Point(59, 669);
            this.label_Errors.Name = "label_Errors";
            this.label_Errors.Size = new System.Drawing.Size(60, 19);
            this.label_Errors.TabIndex = 75;
            this.label_Errors.Text = "label5";
            this.label_Errors.Visible = false;
            // 
            // label_EDate
            // 
            this.label_EDate.AutoSize = true;
            this.label_EDate.BackColor = System.Drawing.Color.Transparent;
            this.label_EDate.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_EDate.ForeColor = System.Drawing.Color.Red;
            this.label_EDate.Location = new System.Drawing.Point(492, 200);
            this.label_EDate.Name = "label_EDate";
            this.label_EDate.Size = new System.Drawing.Size(60, 19);
            this.label_EDate.TabIndex = 71;
            this.label_EDate.Text = "label3";
            this.label_EDate.Visible = false;
            // 
            // Textbox_pName
            // 
            this.Textbox_pName.BackColor = System.Drawing.Color.Silver;
            this.Textbox_pName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_pName.Enabled = false;
            this.Textbox_pName.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_pName.ForeColor = System.Drawing.Color.Black;
            this.Textbox_pName.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_pName.HintText = "Patient\'s Name";
            this.Textbox_pName.isPassword = false;
            this.Textbox_pName.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_pName.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_pName.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_pName.LineThickness = 3;
            this.Textbox_pName.Location = new System.Drawing.Point(63, 295);
            this.Textbox_pName.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_pName.Name = "Textbox_pName";
            this.Textbox_pName.Size = new System.Drawing.Size(480, 60);
            this.Textbox_pName.TabIndex = 61;
            this.Textbox_pName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // Button_SavePayment
            // 
            this.Button_SavePayment.Activecolor = System.Drawing.Color.ForestGreen;
            this.Button_SavePayment.BackColor = System.Drawing.Color.ForestGreen;
            this.Button_SavePayment.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_SavePayment.BorderRadius = 0;
            this.Button_SavePayment.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Button_SavePayment.ButtonText = "SAVE BILL DETAILS";
            this.Button_SavePayment.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_SavePayment.DisabledColor = System.Drawing.Color.Gray;
            this.Button_SavePayment.ForeColor = System.Drawing.Color.White;
            this.Button_SavePayment.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_SavePayment.Iconimage = null;
            this.Button_SavePayment.Iconimage_right = null;
            this.Button_SavePayment.Iconimage_right_Selected = null;
            this.Button_SavePayment.Iconimage_Selected = null;
            this.Button_SavePayment.IconMarginLeft = 0;
            this.Button_SavePayment.IconMarginRight = 0;
            this.Button_SavePayment.IconRightVisible = true;
            this.Button_SavePayment.IconRightZoom = 0D;
            this.Button_SavePayment.IconVisible = true;
            this.Button_SavePayment.IconZoom = 90D;
            this.Button_SavePayment.IsTab = false;
            this.Button_SavePayment.Location = new System.Drawing.Point(61, 702);
            this.Button_SavePayment.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_SavePayment.Name = "Button_SavePayment";
            this.Button_SavePayment.Normalcolor = System.Drawing.Color.ForestGreen;
            this.Button_SavePayment.OnHovercolor = System.Drawing.Color.Transparent;
            this.Button_SavePayment.OnHoverTextColor = System.Drawing.Color.Black;
            this.Button_SavePayment.selected = false;
            this.Button_SavePayment.Size = new System.Drawing.Size(480, 64);
            this.Button_SavePayment.TabIndex = 57;
            this.Button_SavePayment.Text = "SAVE BILL DETAILS";
            this.Button_SavePayment.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_SavePayment.Textcolor = System.Drawing.Color.White;
            this.Button_SavePayment.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_SavePayment.Click += new System.EventHandler(this.Button_SavePayment_Click);
            // 
            // Label_Date
            // 
            this.Label_Date.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Date.AutoSize = true;
            this.Label_Date.BackColor = System.Drawing.Color.Transparent;
            this.Label_Date.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Date.ForeColor = System.Drawing.Color.Black;
            this.Label_Date.Location = new System.Drawing.Point(490, 104);
            this.Label_Date.Name = "Label_Date";
            this.Label_Date.Size = new System.Drawing.Size(68, 32);
            this.Label_Date.TabIndex = 25;
            this.Label_Date.Text = "Date";
            // 
            // Label_Name
            // 
            this.Label_Name.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Name.AutoSize = true;
            this.Label_Name.BackColor = System.Drawing.Color.Transparent;
            this.Label_Name.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Name.ForeColor = System.Drawing.Color.Black;
            this.Label_Name.Location = new System.Drawing.Point(60, 247);
            this.Label_Name.Name = "Label_Name";
            this.Label_Name.Size = new System.Drawing.Size(188, 32);
            this.Label_Name.TabIndex = 19;
            this.Label_Name.Text = "Patient\'s Name";
            // 
            // Label_Title
            // 
            this.Label_Title.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Title.AutoSize = true;
            this.Label_Title.BackColor = System.Drawing.Color.Transparent;
            this.Label_Title.Font = new System.Drawing.Font("Felix Titling", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Title.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.Label_Title.Location = new System.Drawing.Point(465, 27);
            this.Label_Title.Name = "Label_Title";
            this.Label_Title.Size = new System.Drawing.Size(243, 35);
            this.Label_Title.TabIndex = 18;
            this.Label_Title.Text = "Hospital Bill ";
            // 
            // calculateBillControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.bunifuGradientPanel1);
            this.Name = "calculateBillControl";
            this.Size = new System.Drawing.Size(1140, 812);
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            this.panel_DocType.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel1;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_RCharge;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_MCharge;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_RepCharge;
        public Bunifu.Framework.UI.BunifuFlatButton btn_result;
        private System.Windows.Forms.Label label_RepCharge;
        private System.Windows.Forms.Label label_MCharge;
        private System.Windows.Forms.Label label_RCharge;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_charge;
        private Bunifu.Framework.UI.BunifuCustomLabel lbl_totalCharge;
        private Bunifu.Framework.UI.BunifuCustomLabel lbl_aTax;
        private Bunifu.Framework.UI.BunifuCustomLabel lbl_hCharge;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_dFee;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator3;
        private System.Windows.Forms.DateTimePicker Datepicker_aDate;
        private System.Windows.Forms.Label label_ID;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator2;
        private System.Windows.Forms.Panel panel_DocType;
        public Bunifu.Framework.UI.BunifuFlatButton btn_Type4;
        public Bunifu.Framework.UI.BunifuFlatButton btn_Type3;
        public Bunifu.Framework.UI.BunifuFlatButton btn_Type1;
        public Bunifu.Framework.UI.BunifuFlatButton btn_Type2;
        public Bunifu.Framework.UI.BunifuFlatButton Button_bill;
        private System.Windows.Forms.Label label_ESearchNIC;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator1;
        public Bunifu.Framework.UI.BunifuFlatButton Button_Search;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_SearchNIC;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_SearchNIC;
        private System.Windows.Forms.Label label_Errors;
        private System.Windows.Forms.Label label_EDate;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_pName;
        public Bunifu.Framework.UI.BunifuFlatButton Button_SavePayment;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Date;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Name;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Title;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_AdmissionNum;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_TelephoneNum;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_pres;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_reports;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
    }
}
