﻿namespace MssCorsework
{
    partial class LoginControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LoginControl));
            this.panel_log = new System.Windows.Forms.Panel();
            this.lab_UN = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Label_error = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_accountSelect = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_password = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_username = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuSeparator1 = new Bunifu.Framework.UI.BunifuSeparator();
            this.textBox_username = new System.Windows.Forms.TextBox();
            this.bunifuSeparator_password = new Bunifu.Framework.UI.BunifuSeparator();
            this.textBox_password = new System.Windows.Forms.TextBox();
            this.Button_login = new Bunifu.Framework.UI.BunifuFlatButton();
            this.pictureBox_password = new System.Windows.Forms.PictureBox();
            this.pictureBox_username = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.bunifuGradientPanel1 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_title = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.panel_log.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_password)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_username)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.bunifuGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_log
            // 
            this.panel_log.Controls.Add(this.lab_UN);
            this.panel_log.Controls.Add(this.panel1);
            this.panel_log.Controls.Add(this.Label_error);
            this.panel_log.Controls.Add(this.Label_accountSelect);
            this.panel_log.Controls.Add(this.Label_password);
            this.panel_log.Controls.Add(this.Label_username);
            this.panel_log.Controls.Add(this.bunifuSeparator1);
            this.panel_log.Controls.Add(this.textBox_username);
            this.panel_log.Controls.Add(this.bunifuSeparator_password);
            this.panel_log.Controls.Add(this.textBox_password);
            this.panel_log.Controls.Add(this.Button_login);
            this.panel_log.Controls.Add(this.pictureBox_password);
            this.panel_log.Controls.Add(this.pictureBox_username);
            this.panel_log.Controls.Add(this.pictureBox2);
            this.panel_log.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_log.Location = new System.Drawing.Point(0, 0);
            this.panel_log.Name = "panel_log";
            this.panel_log.Size = new System.Drawing.Size(784, 660);
            this.panel_log.TabIndex = 0;
            // 
            // lab_UN
            // 
            this.lab_UN.AutoSize = true;
            this.lab_UN.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_UN.ForeColor = System.Drawing.Color.Blue;
            this.lab_UN.Location = new System.Drawing.Point(502, 97);
            this.lab_UN.Name = "lab_UN";
            this.lab_UN.Size = new System.Drawing.Size(36, 22);
            this.lab_UN.TabIndex = 69;
            this.lab_UN.Text = "UN";
            this.lab_UN.Visible = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(137)))), ((int)(((byte)(218)))));
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(784, 10);
            this.panel1.TabIndex = 68;
            // 
            // Label_error
            // 
            this.Label_error.AutoSize = true;
            this.Label_error.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_error.ForeColor = System.Drawing.Color.Red;
            this.Label_error.Location = new System.Drawing.Point(92, 419);
            this.Label_error.Name = "Label_error";
            this.Label_error.Size = new System.Drawing.Size(186, 22);
            this.Label_error.TabIndex = 67;
            this.Label_error.Text = "Please Fill All Details!";
            this.Label_error.Visible = false;
            // 
            // Label_accountSelect
            // 
            this.Label_accountSelect.AutoSize = true;
            this.Label_accountSelect.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_accountSelect.ForeColor = System.Drawing.Color.Blue;
            this.Label_accountSelect.Location = new System.Drawing.Point(92, 134);
            this.Label_accountSelect.Name = "Label_accountSelect";
            this.Label_accountSelect.Size = new System.Drawing.Size(141, 22);
            this.Label_accountSelect.TabIndex = 66;
            this.Label_accountSelect.Text = "Account Type";
            this.Label_accountSelect.Visible = false;
            // 
            // Label_password
            // 
            this.Label_password.AutoSize = true;
            this.Label_password.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_password.ForeColor = System.Drawing.Color.Blue;
            this.Label_password.Location = new System.Drawing.Point(92, 304);
            this.Label_password.Name = "Label_password";
            this.Label_password.Size = new System.Drawing.Size(95, 22);
            this.Label_password.TabIndex = 62;
            this.Label_password.Text = "Password";
            // 
            // Label_username
            // 
            this.Label_username.AutoSize = true;
            this.Label_username.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_username.ForeColor = System.Drawing.Color.Blue;
            this.Label_username.Location = new System.Drawing.Point(92, 191);
            this.Label_username.Name = "Label_username";
            this.Label_username.Size = new System.Drawing.Size(101, 22);
            this.Label_username.TabIndex = 61;
            this.Label_username.Text = "Username";
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(105)))), ((int)(((byte)(225)))));
            this.bunifuSeparator1.LineThickness = 3;
            this.bunifuSeparator1.Location = new System.Drawing.Point(159, 264);
            this.bunifuSeparator1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Size = new System.Drawing.Size(530, 10);
            this.bunifuSeparator1.TabIndex = 60;
            this.bunifuSeparator1.Transparency = 255;
            this.bunifuSeparator1.Vertical = false;
            // 
            // textBox_username
            // 
            this.textBox_username.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.textBox_username.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_username.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_username.ForeColor = System.Drawing.Color.White;
            this.textBox_username.Location = new System.Drawing.Point(159, 232);
            this.textBox_username.Name = "textBox_username";
            this.textBox_username.Size = new System.Drawing.Size(530, 30);
            this.textBox_username.TabIndex = 59;
            this.textBox_username.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBox_username_KeyPress);
            // 
            // bunifuSeparator_password
            // 
            this.bunifuSeparator_password.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator_password.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(105)))), ((int)(((byte)(225)))));
            this.bunifuSeparator_password.LineThickness = 3;
            this.bunifuSeparator_password.Location = new System.Drawing.Point(159, 376);
            this.bunifuSeparator_password.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator_password.Name = "bunifuSeparator_password";
            this.bunifuSeparator_password.Size = new System.Drawing.Size(530, 10);
            this.bunifuSeparator_password.TabIndex = 58;
            this.bunifuSeparator_password.Transparency = 255;
            this.bunifuSeparator_password.Vertical = false;
            // 
            // textBox_password
            // 
            this.textBox_password.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.textBox_password.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_password.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_password.ForeColor = System.Drawing.Color.White;
            this.textBox_password.Location = new System.Drawing.Point(159, 344);
            this.textBox_password.Name = "textBox_password";
            this.textBox_password.PasswordChar = '*';
            this.textBox_password.Size = new System.Drawing.Size(530, 30);
            this.textBox_password.TabIndex = 57;
            this.textBox_password.UseSystemPasswordChar = true;
            this.textBox_password.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBox_password_KeyPress);
            // 
            // Button_login
            // 
            this.Button_login.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Button_login.BackColor = System.Drawing.Color.DarkViolet;
            this.Button_login.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_login.BorderRadius = 0;
            this.Button_login.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Button_login.ButtonText = "LOGIN";
            this.Button_login.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_login.DisabledColor = System.Drawing.Color.Gray;
            this.Button_login.ForeColor = System.Drawing.Color.White;
            this.Button_login.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_login.Iconimage = null;
            this.Button_login.Iconimage_right = null;
            this.Button_login.Iconimage_right_Selected = null;
            this.Button_login.Iconimage_Selected = null;
            this.Button_login.IconMarginLeft = 0;
            this.Button_login.IconMarginRight = 0;
            this.Button_login.IconRightVisible = true;
            this.Button_login.IconRightZoom = 0D;
            this.Button_login.IconVisible = true;
            this.Button_login.IconZoom = 90D;
            this.Button_login.IsTab = false;
            this.Button_login.Location = new System.Drawing.Point(96, 475);
            this.Button_login.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_login.Name = "Button_login";
            this.Button_login.Normalcolor = System.Drawing.Color.DarkViolet;
            this.Button_login.OnHovercolor = System.Drawing.Color.Transparent;
            this.Button_login.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_login.selected = false;
            this.Button_login.Size = new System.Drawing.Size(593, 78);
            this.Button_login.TabIndex = 56;
            this.Button_login.Text = "LOGIN";
            this.Button_login.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_login.Textcolor = System.Drawing.Color.White;
            this.Button_login.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_login.Click += new System.EventHandler(this.Button_login_Click);
            // 
            // pictureBox_password
            // 
            this.pictureBox_password.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_password.Image")));
            this.pictureBox_password.Location = new System.Drawing.Point(96, 338);
            this.pictureBox_password.Name = "pictureBox_password";
            this.pictureBox_password.Size = new System.Drawing.Size(51, 46);
            this.pictureBox_password.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_password.TabIndex = 55;
            this.pictureBox_password.TabStop = false;
            // 
            // pictureBox_username
            // 
            this.pictureBox_username.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_username.Image")));
            this.pictureBox_username.Location = new System.Drawing.Point(96, 225);
            this.pictureBox_username.Name = "pictureBox_username";
            this.pictureBox_username.Size = new System.Drawing.Size(51, 46);
            this.pictureBox_username.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_username.TabIndex = 54;
            this.pictureBox_username.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(326, -35);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(159, 154);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 53;
            this.pictureBox2.TabStop = false;
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.Controls.Add(this.label2);
            this.bunifuGradientPanel1.Controls.Add(this.label1);
            this.bunifuGradientPanel1.Controls.Add(this.pictureBox1);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuCustomLabel1);
            this.bunifuGradientPanel1.Controls.Add(this.Label_title);
            this.bunifuGradientPanel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.Black;
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.Black;
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.LightSteelBlue;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.Black;
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(783, 0);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(711, 660);
            this.bunifuGradientPanel1.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkKhaki;
            this.label2.Location = new System.Drawing.Point(7, 501);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(538, 23);
            this.label2.TabIndex = 9;
            this.label2.Text = "the cost of health care for patients in the communities we serve.\"";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkKhaki;
            this.label1.Location = new System.Drawing.Point(7, 473);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(630, 23);
            this.label1.TabIndex = 8;
            this.label1.Text = "\"Our vision is to be the unmatched leader in improving quality and reducing";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(19, 172);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(653, 264);
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Yu Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(269, 602);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(166, 22);
            this.bunifuCustomLabel1.TabIndex = 6;
            this.bunifuCustomLabel1.Text = "Design By @NSSC ";
            // 
            // Label_title
            // 
            this.Label_title.AutoSize = true;
            this.Label_title.BackColor = System.Drawing.Color.Transparent;
            this.Label_title.Font = new System.Drawing.Font("Vivaldi", 28.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_title.ForeColor = System.Drawing.Color.RoyalBlue;
            this.Label_title.Location = new System.Drawing.Point(114, 83);
            this.Label_title.Name = "Label_title";
            this.Label_title.Size = new System.Drawing.Size(483, 57);
            this.Label_title.TabIndex = 5;
            this.Label_title.Text = "Asceso Hospitals pvt Ltd ";
            // 
            // LoginControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.Controls.Add(this.bunifuGradientPanel1);
            this.Controls.Add(this.panel_log);
            this.Name = "LoginControl";
            this.Size = new System.Drawing.Size(1494, 660);
            this.panel_log.ResumeLayout(false);
            this.panel_log.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_password)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_username)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_log;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_error;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_accountSelect;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_password;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_username;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator1;
        public System.Windows.Forms.TextBox textBox_username;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator_password;
        public System.Windows.Forms.TextBox textBox_password;
        public Bunifu.Framework.UI.BunifuFlatButton Button_login;
        private System.Windows.Forms.PictureBox pictureBox_password;
        private System.Windows.Forms.PictureBox pictureBox_username;
        private System.Windows.Forms.PictureBox pictureBox2;
        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel1;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_title;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private Bunifu.Framework.UI.BunifuCustomLabel lab_UN;
    }
}
