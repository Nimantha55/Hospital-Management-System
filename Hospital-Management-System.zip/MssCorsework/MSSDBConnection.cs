﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace MssCorsework
{
    class MSSDBConnection
    {
        public static SqlConnection MSSConnection()
        {
            string connectionstring = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=F:\Degree - Software Engineering\MSS\System\MssCorsework\MSSDB.mdf;Integrated Security=True";
            SqlConnection con = new SqlConnection(connectionstring);
            con.Open();
            return con;
        }
    }
}
