﻿namespace MssCorsework
{
    partial class paymentGetway
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(paymentGetway));
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.panel_top = new System.Windows.Forms.Panel();
            this.Button_stop = new Bunifu.Framework.UI.BunifuImageButton();
            this.Button_refresh = new Bunifu.Framework.UI.BunifuImageButton();
            this.btn_close = new Bunifu.Framework.UI.BunifuImageButton();
            this.btn_minimize = new Bunifu.Framework.UI.BunifuImageButton();
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.dragControl1 = new Project_SDC.DragControl();
            this.panel_top.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Button_stop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Button_refresh)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_minimize)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 5;
            this.bunifuElipse1.TargetControl = this;
            // 
            // panel_top
            // 
            this.panel_top.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.panel_top.Controls.Add(this.btn_close);
            this.panel_top.Controls.Add(this.btn_minimize);
            this.panel_top.Controls.Add(this.Button_stop);
            this.panel_top.Controls.Add(this.Button_refresh);
            this.panel_top.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_top.Location = new System.Drawing.Point(0, 0);
            this.panel_top.Name = "panel_top";
            this.panel_top.Size = new System.Drawing.Size(894, 60);
            this.panel_top.TabIndex = 0;
            // 
            // Button_stop
            // 
            this.Button_stop.BackColor = System.Drawing.Color.Transparent;
            this.Button_stop.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_stop.Image = ((System.Drawing.Image)(resources.GetObject("Button_stop.Image")));
            this.Button_stop.ImageActive = null;
            this.Button_stop.Location = new System.Drawing.Point(691, 10);
            this.Button_stop.Name = "Button_stop";
            this.Button_stop.Size = new System.Drawing.Size(40, 40);
            this.Button_stop.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Button_stop.TabIndex = 81;
            this.Button_stop.TabStop = false;
            this.Button_stop.Zoom = 10;
            this.Button_stop.Click += new System.EventHandler(this.Button_stop_Click);
            // 
            // Button_refresh
            // 
            this.Button_refresh.BackColor = System.Drawing.Color.Transparent;
            this.Button_refresh.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_refresh.Image = ((System.Drawing.Image)(resources.GetObject("Button_refresh.Image")));
            this.Button_refresh.ImageActive = null;
            this.Button_refresh.Location = new System.Drawing.Point(737, 10);
            this.Button_refresh.Name = "Button_refresh";
            this.Button_refresh.Size = new System.Drawing.Size(40, 40);
            this.Button_refresh.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Button_refresh.TabIndex = 80;
            this.Button_refresh.TabStop = false;
            this.Button_refresh.Zoom = 10;
            this.Button_refresh.Click += new System.EventHandler(this.Button_refresh_Click);
            // 
            // btn_close
            // 
            this.btn_close.BackColor = System.Drawing.Color.Transparent;
            this.btn_close.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_close.Image = ((System.Drawing.Image)(resources.GetObject("btn_close.Image")));
            this.btn_close.ImageActive = null;
            this.btn_close.Location = new System.Drawing.Point(844, 10);
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(40, 40);
            this.btn_close.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btn_close.TabIndex = 82;
            this.btn_close.TabStop = false;
            this.btn_close.Zoom = 10;
            this.btn_close.Click += new System.EventHandler(this.Btn_close_Click);
            // 
            // btn_minimize
            // 
            this.btn_minimize.BackColor = System.Drawing.Color.Transparent;
            this.btn_minimize.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_minimize.Image = ((System.Drawing.Image)(resources.GetObject("btn_minimize.Image")));
            this.btn_minimize.ImageActive = null;
            this.btn_minimize.Location = new System.Drawing.Point(803, 10);
            this.btn_minimize.Name = "btn_minimize";
            this.btn_minimize.Size = new System.Drawing.Size(40, 40);
            this.btn_minimize.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btn_minimize.TabIndex = 83;
            this.btn_minimize.TabStop = false;
            this.btn_minimize.Zoom = 10;
            this.btn_minimize.Click += new System.EventHandler(this.Btn_minimize_Click);
            // 
            // webBrowser1
            // 
            this.webBrowser1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webBrowser1.Location = new System.Drawing.Point(0, 60);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.Size = new System.Drawing.Size(894, 653);
            this.webBrowser1.TabIndex = 1;
            // 
            // dragControl1
            // 
            this.dragControl1.SelectControl = this.panel_top;
            // 
            // paymentGetway
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(894, 713);
            this.Controls.Add(this.webBrowser1);
            this.Controls.Add(this.panel_top);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "paymentGetway";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "paymentGetway";
            this.panel_top.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Button_stop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Button_refresh)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_minimize)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.Panel panel_top;
        private Bunifu.Framework.UI.BunifuImageButton Button_stop;
        private Bunifu.Framework.UI.BunifuImageButton Button_refresh;
        private Bunifu.Framework.UI.BunifuImageButton btn_close;
        private Bunifu.Framework.UI.BunifuImageButton btn_minimize;
        private Project_SDC.DragControl dragControl1;
        public System.Windows.Forms.WebBrowser webBrowser1;
    }
}