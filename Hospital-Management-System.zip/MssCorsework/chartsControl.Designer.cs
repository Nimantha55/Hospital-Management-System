﻿namespace MssCorsework
{
    partial class chartsControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(chartsControl));
            this.bunifuGradientPanel1 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.bunifuSeparator1 = new Bunifu.Framework.UI.BunifuSeparator();
            this.Button_Appointement = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Label_Title = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.panel_reportType = new System.Windows.Forms.Panel();
            this.Button_appointments = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Button_Update = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuGradientPanel1.SuspendLayout();
            this.panel_reportType.SuspendLayout();
            this.SuspendLayout();
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.Controls.Add(this.panel_reportType);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuSeparator1);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Title);
            this.bunifuGradientPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.Black;
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.Gray;
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(1140, 812);
            this.bunifuGradientPanel1.TabIndex = 4;
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator1.LineThickness = 2;
            this.bunifuSeparator1.Location = new System.Drawing.Point(60, 204);
            this.bunifuSeparator1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Size = new System.Drawing.Size(1018, 10);
            this.bunifuSeparator1.TabIndex = 119;
            this.bunifuSeparator1.Transparency = 255;
            this.bunifuSeparator1.Vertical = false;
            // 
            // Button_Appointement
            // 
            this.Button_Appointement.Activecolor = System.Drawing.Color.DarkViolet;
            this.Button_Appointement.BackColor = System.Drawing.Color.DarkViolet;
            this.Button_Appointement.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_Appointement.BorderRadius = 0;
            this.Button_Appointement.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Button_Appointement.ButtonText = "APPOINTMENT HISTORY";
            this.Button_Appointement.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_Appointement.DisabledColor = System.Drawing.Color.Gray;
            this.Button_Appointement.ForeColor = System.Drawing.Color.White;
            this.Button_Appointement.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_Appointement.Iconimage = null;
            this.Button_Appointement.Iconimage_right = null;
            this.Button_Appointement.Iconimage_right_Selected = null;
            this.Button_Appointement.Iconimage_Selected = null;
            this.Button_Appointement.IconMarginLeft = 0;
            this.Button_Appointement.IconMarginRight = 0;
            this.Button_Appointement.IconRightVisible = true;
            this.Button_Appointement.IconRightZoom = 0D;
            this.Button_Appointement.IconVisible = true;
            this.Button_Appointement.IconZoom = 90D;
            this.Button_Appointement.IsTab = false;
            this.Button_Appointement.Location = new System.Drawing.Point(0, 0);
            this.Button_Appointement.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_Appointement.Name = "Button_Appointement";
            this.Button_Appointement.Normalcolor = System.Drawing.Color.DarkViolet;
            this.Button_Appointement.OnHovercolor = System.Drawing.Color.Transparent;
            this.Button_Appointement.OnHoverTextColor = System.Drawing.Color.Black;
            this.Button_Appointement.selected = false;
            this.Button_Appointement.Size = new System.Drawing.Size(424, 62);
            this.Button_Appointement.TabIndex = 116;
            this.Button_Appointement.Text = "APPOINTMENT HISTORY";
            this.Button_Appointement.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_Appointement.Textcolor = System.Drawing.Color.White;
            this.Button_Appointement.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Appointement.Click += new System.EventHandler(this.Button_Appointement_Click);
            // 
            // Label_Title
            // 
            this.Label_Title.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Title.AutoSize = true;
            this.Label_Title.BackColor = System.Drawing.Color.Transparent;
            this.Label_Title.Font = new System.Drawing.Font("Felix Titling", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Title.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.Label_Title.Location = new System.Drawing.Point(358, 37);
            this.Label_Title.Name = "Label_Title";
            this.Label_Title.Size = new System.Drawing.Size(415, 35);
            this.Label_Title.TabIndex = 18;
            this.Label_Title.Text = "Create Chart Reports";
            // 
            // panel_reportType
            // 
            this.panel_reportType.BackColor = System.Drawing.Color.Transparent;
            this.panel_reportType.Controls.Add(this.Button_appointments);
            this.panel_reportType.Controls.Add(this.Button_Update);
            this.panel_reportType.Controls.Add(this.Button_Appointement);
            this.panel_reportType.Location = new System.Drawing.Point(399, 354);
            this.panel_reportType.MaximumSize = new System.Drawing.Size(343, 167);
            this.panel_reportType.MinimumSize = new System.Drawing.Size(424, 62);
            this.panel_reportType.Name = "panel_reportType";
            this.panel_reportType.Size = new System.Drawing.Size(424, 167);
            this.panel_reportType.TabIndex = 120;
            // 
            // Button_appointments
            // 
            this.Button_appointments.Activecolor = System.Drawing.Color.SteelBlue;
            this.Button_appointments.BackColor = System.Drawing.Color.SteelBlue;
            this.Button_appointments.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_appointments.BorderRadius = 0;
            this.Button_appointments.ButtonText = "Appointment History";
            this.Button_appointments.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_appointments.DisabledColor = System.Drawing.Color.Gray;
            this.Button_appointments.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_appointments.Iconimage = null;
            this.Button_appointments.Iconimage_right = null;
            this.Button_appointments.Iconimage_right_Selected = null;
            this.Button_appointments.Iconimage_Selected = null;
            this.Button_appointments.IconMarginLeft = 0;
            this.Button_appointments.IconMarginRight = 0;
            this.Button_appointments.IconRightVisible = true;
            this.Button_appointments.IconRightZoom = 0D;
            this.Button_appointments.IconVisible = true;
            this.Button_appointments.IconZoom = 90D;
            this.Button_appointments.IsTab = false;
            this.Button_appointments.Location = new System.Drawing.Point(0, 64);
            this.Button_appointments.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_appointments.Name = "Button_appointments";
            this.Button_appointments.Normalcolor = System.Drawing.Color.SteelBlue;
            this.Button_appointments.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.Button_appointments.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_appointments.selected = false;
            this.Button_appointments.Size = new System.Drawing.Size(424, 42);
            this.Button_appointments.TabIndex = 25;
            this.Button_appointments.Text = "Appointment History";
            this.Button_appointments.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_appointments.Textcolor = System.Drawing.Color.White;
            this.Button_appointments.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // Button_Update
            // 
            this.Button_Update.Activecolor = System.Drawing.Color.SteelBlue;
            this.Button_Update.BackColor = System.Drawing.Color.SteelBlue;
            this.Button_Update.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_Update.BorderRadius = 0;
            this.Button_Update.ButtonText = "Update Patient Details";
            this.Button_Update.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_Update.DisabledColor = System.Drawing.Color.Gray;
            this.Button_Update.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_Update.Iconimage = null;
            this.Button_Update.Iconimage_right = null;
            this.Button_Update.Iconimage_right_Selected = null;
            this.Button_Update.Iconimage_Selected = null;
            this.Button_Update.IconMarginLeft = 0;
            this.Button_Update.IconMarginRight = 0;
            this.Button_Update.IconRightVisible = true;
            this.Button_Update.IconRightZoom = 0D;
            this.Button_Update.IconVisible = true;
            this.Button_Update.IconZoom = 90D;
            this.Button_Update.IsTab = false;
            this.Button_Update.Location = new System.Drawing.Point(0, 108);
            this.Button_Update.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_Update.Name = "Button_Update";
            this.Button_Update.Normalcolor = System.Drawing.Color.SteelBlue;
            this.Button_Update.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.Button_Update.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_Update.selected = false;
            this.Button_Update.Size = new System.Drawing.Size(424, 42);
            this.Button_Update.TabIndex = 26;
            this.Button_Update.Text = "Update Patient Details";
            this.Button_Update.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_Update.Textcolor = System.Drawing.Color.White;
            this.Button_Update.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // chartsControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.bunifuGradientPanel1);
            this.Name = "chartsControl";
            this.Size = new System.Drawing.Size(1140, 812);
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            this.panel_reportType.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel1;
        public Bunifu.Framework.UI.BunifuFlatButton Button_Appointement;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Title;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator1;
        public System.Windows.Forms.Panel panel_reportType;
        public Bunifu.Framework.UI.BunifuFlatButton Button_appointments;
        public Bunifu.Framework.UI.BunifuFlatButton Button_Update;
    }
}
