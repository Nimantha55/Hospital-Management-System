﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MssCorsework
{
    public partial class paymentGetway : Form
    {
        public paymentGetway()
        {
            InitializeComponent();
        }

        private void Btn_close_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void Btn_minimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void Button_refresh_Click(object sender, EventArgs e)
        {
            webBrowser1.Refresh();
        }

        private void Button_stop_Click(object sender, EventArgs e)
        {
            webBrowser1.Stop();
        }
    }
}
