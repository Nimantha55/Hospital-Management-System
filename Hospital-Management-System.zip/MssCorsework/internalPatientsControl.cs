﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MssCorsework
{
    public partial class internalPatientsControl : UserControl
    {
        public internalPatientsControl()
        {
            InitializeComponent();
        }

        SQLQueries sqlq = new SQLQueries();

        private void clear()
        {
            Textbox_pName.Text = "";
            Textbox_NIC.Text = "";
            Textbox_AdmissionNum.Text = "";
            Textbox_Address.Text = "";
            Textbox_Age.Text = "";
            Textbox_wardNumber.Text = "";
        }

        private void Button_ADD_Click(object sender, EventArgs e)
        {
            if (Textbox_pName.Text == "" && Textbox_NIC.Text == "" && Textbox_AdmissionNum.Text == "" && Textbox_Address.Text == "" && Textbox_Age.Text == "" && Textbox_wardNumber.Text == "")
            {
                label_Errors.Visible = true;
                label_Errors.Text = "Please Enter All Details!";
            }
            else if (Textbox_pName.Text == "")
            {
                label_pEName.Visible = true;
                label_pEName.Text = "Patient's Name is Required!";
            }
            else if (Textbox_NIC.Text == "")
            {
                label_pENIC.Visible = true;
                label_pENIC.Text = "Patient's NIC is Required!";
            }
            else if (Textbox_AdmissionNum.Text == "")
            {
                label_admission.Visible = true;
                label_admission.Text = "Patient's Admission Number is Required!";
            }
            else if (Textbox_Address.Text == "")
            {
                label_pEAddress.Visible = true;
                label_pEAddress.Text = "Patient's Address is Required!";
            }
            else if (Textbox_Age.Text == "")
            {
                label_pEAge.Visible = true;
                label_pEAge.Text = "Patient's Age is Required!";
            }
            else if (Textbox_wardNumber.Text == "")
            {
                label_wardNum.Visible = true;
                label_wardNum.Text = "Patient's Ward Number is Required!";
            }
            else
            {
                try
                {
                    string pNIC = Textbox_NIC.Text;
                    string pName = Textbox_pName.Text;
                    string paddress = Textbox_Address.Text;
                    int pAge = int.Parse(Textbox_Age.Text);
                    int addNumber = int.Parse(Textbox_AdmissionNum.Text);
                    int wardNumber = int.Parse(Textbox_wardNumber.Text);
                    string prescription = Label_pre.Text;
                    string reports = Label_reports.Text;
                    DateTime date = DateTime.Now.Date;
                    int rCharge = int.Parse(label_rCharge.Text);
                    int mCharge = int.Parse(label_mCharge.Text);
                    int repCharge = int.Parse(label_repCharge.Text);
                    int totalCharge = int.Parse(label_totalCharge.Text);

                    //pass values for internalPatientDetails query which include in SQLQueries class
                    sqlq.internalPatientDetails(pNIC, pName, paddress, pAge, addNumber, wardNumber, prescription, reports, date, rCharge, mCharge, repCharge, totalCharge);
                    Message1 pr = new Message1();
                    pr.label1.Text = "Patient Details Added Successfully!";
                    pr.label1.Location = new System.Drawing.Point(45, 200);
                    pr.Show();
                    this.clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Please Check The Values" + ex, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void Textbox_NIC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_NIC.Text != "")
            {
                label_pENIC.Visible = false;
                label_Errors.Visible = false;
            }
        }

        private void Textbox_pName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_pName.Text != "")
            {
                label_pEName.Visible = false;
                label_Errors.Visible = false;
            }

            //allow only characters values for textbox
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar) && e.KeyChar != '.')
            {
                e.Handled = true;
            }
        }

        private void Textbox_Address_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_Address.Text != "")
            {
                label_pEAddress.Visible = false;
                label_Errors.Visible = false;
            }
        }

        private void Textbox_Age_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_Age.Text != "")
            {
                label_pEAge.Visible = false;
                label_Errors.Visible = false;
            }

            //allow only numaric values for contact number
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 32)
            {
                e.Handled = true;
            }
        }

        private void Textbox_AdmissionNum_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_AdmissionNum.Text != "")
            {
                label_admission.Visible = false;
                label_Errors.Visible = false;
            }

            //allow only numaric values for contact number
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 32)
            {
                e.Handled = true;
            }
        }

        private void Textbox_wardNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_wardNumber.Text != "")
            {
                label_wardNum.Visible = false;
                label_Errors.Visible = false;
            }

            //allow only numaric values for contact number
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 32)
            {
                e.Handled = true;
            }
        }

        private void Button_Clear_Click(object sender, EventArgs e)
        {
            this.clear();
        }
    }
}
