﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MssCorsework
{
    public partial class addLabReportDetailsControl : UserControl
    {
        public addLabReportDetailsControl()
        {
            InitializeComponent();
        }

        SQLQueries sqlq = new SQLQueries();

        private void clear()
        {
            textBox_typeR.Text = "";
            textBox_Result.Text = "";
            textBox_TR.Text = "";
            textBox_SCL.Text = "";
        }

        private void Button_Save_Click(object sender, EventArgs e)
        {
            if (textBox_typeR.Text == "")
            {
                label_ETR.Visible = true;
                label_ETR.Text = "Type of Report is Required!";
            }
            else if (textBox_Result.Text == "")
            {
                label_ER.Visible = true;
                label_ER.Text = "Results is Required!";
            }
            else if (Datepicker_aSRDate.Value == null)
            {
                label_ESRD.Visible = true;
                label_ESRD.Text = "Sample Received Date is Required!";
            }
            else if (Datepicker_aSTDate.Value == null)
            {
                label_ETD.Visible = true;
                label_ETD.Text = "Sample Tested Date is Required!";
            }
            else if (textBox_TR.Text == "")
            {
                label_ETechR.Visible = true;
                label_ETechR.Text = "Technician Remark is Required!";
            }
            else if (textBox_SCL.Text == "")
            {
                label_ESCL.Visible = true;
                label_ESCL.Text = "Soft Copy Link is Required!";
            }
            else if (textBox_typeR.Text == "" && textBox_Result.Text == "" && Datepicker_aSRDate.Value == null && Datepicker_aSTDate.Value == null && textBox_TR.Text == "" && textBox_SCL.Text == "")
            {
                label_Errors.Visible = true;
                label_Errors.Text = "Please fill all details!";
            }
            else
            {
                try
                {
                    string repNum = app_Number.Text;
                    string typeOfR = textBox_typeR.Text;
                    string results = textBox_Result.Text;
                    DateTime samepleRD = Datepicker_aSRDate.Value;
                    DateTime samepleTD = Datepicker_aSTDate.Value;
                    string techRM = textBox_TR.Text;
                    string softCopyL = textBox_SCL.Text;

                    //pass values for labreportDetails query which include in SQLQueries class
                    sqlq.labreportDetails(repNum, typeOfR, results, samepleRD, samepleTD, techRM, softCopyL);
                    Message1 pr = new Message1();
                    pr.label1.Text = "Report Details Added Successfully!";
                    pr.label1.Location = new System.Drawing.Point(44, 200);
                    pr.Show();
                    this.clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Please Check The Values" + ex, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void Button_Clear_Click(object sender, EventArgs e)
        {
            this.clear();
        }

        private void TextBox_typeR_KeyPress(object sender, KeyPressEventArgs e)
        {
            label_ETR.Visible = false;
            label_Errors.Visible = false;
        }

        private void TextBox_Result_KeyPress(object sender, KeyPressEventArgs e)
        {
            label_ER.Visible = false;
            label_Errors.Visible = false;
        }

        private void TextBox_TR_KeyPress(object sender, KeyPressEventArgs e)
        {
            label_ETechR.Visible = false;
            label_Errors.Visible = false;
        }

        private void TextBox_SCL_KeyPress(object sender, KeyPressEventArgs e)
        {
            label_ESCL.Visible = false;
            label_Errors.Visible = false;
        }
    }
}
