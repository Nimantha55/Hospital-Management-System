﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MssCorsework
{
    public partial class appointmentHistoryControl : UserControl
    {
        public bool isCollapsed;

        public appointmentHistoryControl()
        {
            InitializeComponent();
        }

        labReportViewer lrv = new labReportViewer();

        private void Button_Search_Click(object sender, EventArgs e)
        {
            DateTime svDate = Datepicker_aDate.Value.Date;
            DateTime evDate = dateTimePicker_eDate.Value.Date;
            DateTime sDate = Datepicker_aDate.Value;
            DateTime eDate = dateTimePicker_eDate.Value;

            TimeSpan ts = evDate - svDate;
            int days = ts.Days;
            int week = 7;
            int earn = 0;

            if (Button_reportType.Text == "Appointments Report")
            {
                //Validate a week
                if (days != week)
                {
                    MessageBox.Show("Please select a week!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    string amount = "SELECT Id, appNumber, pNIC, pName, dNIC, dName, aDate, aTime FROM TableAppointments WHERE aDate BETWEEN '" + sDate + "' AND '" + eDate + "'";
                    SqlDataAdapter sqlda = new SqlDataAdapter(amount, MSSDBConnection.MSSConnection());
                    DataTable dtb1 = new DataTable();
                    sqlda.Fill(dtb1);

                    DataGrid1.DataSource = dtb1;
                }
            }
            else if(Button_reportType.Text == "Doctors Earning Report")
            {
                //Validate a week
                if (days != week)
                {
                    MessageBox.Show("Please select a week!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    string amount = "SELECT Id, appNumber, dName, dNIC, aDate, doctorFee FROM TableAppointments WHERE aDate BETWEEN '" + sDate + "' AND '" + eDate + "' AND doctorFee != " + earn + "";
                    SqlDataAdapter sqlda1 = new SqlDataAdapter(amount, MSSDBConnection.MSSConnection());
                    DataTable dtb2 = new DataTable();
                    sqlda1.Fill(dtb2);

                    DataGrid1.DataSource = dtb2;
                }
            }
            else if (Button_reportType.Text == "Weekly Earnings From Appointements")
            {
                //Validate a week
                if (days != week)
                {
                    MessageBox.Show("Please select a week!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    string amount = "SELECT Id, appNumber, dName, dNIC, aDate, charge, doctorFee FROM TableAppointments WHERE aDate BETWEEN '" + sDate + "' AND '" + eDate + "' AND doctorFee != " + earn + "";
                    SqlDataAdapter sqlda2 = new SqlDataAdapter(amount, MSSDBConnection.MSSConnection());
                    DataTable dtb3 = new DataTable();
                    sqlda2.Fill(dtb3);

                    DataGrid1.DataSource = dtb3;
                }
            }
            else if (Button_reportType.Text == "Patients Details Report")
            {
                string amount = "SELECT * FROM TablePatients";
                SqlDataAdapter sqlda3 = new SqlDataAdapter(amount, MSSDBConnection.MSSConnection());
                DataTable dtb4 = new DataTable();
                sqlda3.Fill(dtb4);

                DataGrid1.DataSource = dtb4;
            }
            else if (Button_reportType.Text == "Doctors Details Report")
            {
                string amount = "SELECT * FROM TableDoctors";
                SqlDataAdapter sqlda4 = new SqlDataAdapter(amount, MSSDBConnection.MSSConnection());
                DataTable dtb5 = new DataTable();
                sqlda4.Fill(dtb5);

                DataGrid1.DataSource = dtb5;
            }
            else if (Button_reportType.Text == "Lab / Radiology Reports Details")
            {
                string amount = "SELECT Id, pName, pNIC, Diagnosis, Prescription, Lab_Report FROM TablePatientsHistory";
                SqlDataAdapter sqlda5 = new SqlDataAdapter(amount, MSSDBConnection.MSSConnection());
                DataTable dtb6 = new DataTable();
                sqlda5.Fill(dtb6);

                DataGrid1.DataSource = dtb6;
            }
            else if (Button_reportType.Text == "Diagnosis Details")
            {
                string amount = "SELECT Id, pName, pNIC, Diagnosis, Prescription, Lab_Report FROM TablePatientsHistory";
                SqlDataAdapter sqlda6 = new SqlDataAdapter(amount, MSSDBConnection.MSSConnection());
                DataTable dtb7 = new DataTable();
                sqlda6.Fill(dtb7);

                DataGrid1.DataSource = dtb7;
            }
            else if (Button_reportType.Text == "Pharmacy Income Report")
            {
                //Validate a week
                if (days != week)
                {
                    MessageBox.Show("Please select a week!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    string amount = "SELECT Id, date, preName, costPrice, salesPrice, stocks, reLevel, quent, total FROM TableInventory WHERE date BETWEEN '" + sDate + "' AND '" + eDate + "'";
                    SqlDataAdapter sqlda7 = new SqlDataAdapter(amount, MSSDBConnection.MSSConnection());
                    DataTable dtb8 = new DataTable();
                    sqlda7.Fill(dtb8);

                    DataGrid1.DataSource = dtb8;
                }
            }
            else if (Button_reportType.Text == "Internal Patients Details")
            {
                //Validate a week
                if (days != week)
                {
                    MessageBox.Show("Please select a week!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    string amount = "SELECT Id, pNIC, pName, address, age, addNumber, wardNumber, addmittedDate FROM TableInternalPatients WHERE addmittedDate BETWEEN '" + sDate + "' AND '" + eDate + "'";
                    SqlDataAdapter sqlda7 = new SqlDataAdapter(amount, MSSDBConnection.MSSConnection());
                    DataTable dtb8 = new DataTable();
                    sqlda7.Fill(dtb8);

                    DataGrid1.DataSource = dtb8;
                }
            }
            else if (Button_reportType.Text == "Hospital Bill Details")
            {
                //Validate a week
                if (days != week)
                {
                    MessageBox.Show("Please select a week!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    string amount = "SELECT Id, pNIC, pName, addNumber, wardNumber, addmittedDate, rCharge, mCharge, RepCharge, TotalCharge FROM TableInternalPatients WHERE addmittedDate BETWEEN '" + sDate + "' AND '" + eDate + "'";
                    SqlDataAdapter sqlda7 = new SqlDataAdapter(amount, MSSDBConnection.MSSConnection());
                    DataTable dtb8 = new DataTable();
                    sqlda7.Fill(dtb8);

                    DataGrid1.DataSource = dtb8;
                }
            }
        }

        private void Button_Clear_Click(object sender, EventArgs e)
        {
            DateTime sDate = Datepicker_aDate.Value;
            DateTime eDate = dateTimePicker_eDate.Value;
            int earn = 0;

            if (Button_reportType.Text == "Appointments Report")
            {              
                ChartReport2 lr = new ChartReport2();
                string amount = "SELECT * FROM TableAppointments WHERE aDate BETWEEN '" + sDate + "' AND '" + eDate + "'";
                DataSet ds = new DataSet();
                SqlDataAdapter sda = new SqlDataAdapter(amount, MSSDBConnection.MSSConnection());
                sda.Fill(ds, "TableAppointments");

                lr.SetDataSource(ds.Tables["TableAppointments"]);
                lrv.crystalReportViewer1.ReportSource = lr;
                lrv.crystalReportViewer1.Refresh();
                lrv.Show();
            }
            else if (Button_reportType.Text == "Doctors Earning Report")
            {
                ChartReport3 lr = new ChartReport3();
                string amount = "SELECT * FROM TableAppointments WHERE aDate BETWEEN '" + sDate + "' AND '" + eDate + "' AND doctorFee != " + earn + "";
                DataSet ds = new DataSet();
                SqlDataAdapter sda = new SqlDataAdapter(amount, MSSDBConnection.MSSConnection());
                sda.Fill(ds, "TableAppointments");

                lr.SetDataSource(ds.Tables["TableAppointments"]);
                lrv.crystalReportViewer1.ReportSource = lr;
                lrv.crystalReportViewer1.Refresh();
                lrv.Show();
            }
            else if (Button_reportType.Text == "Weekly Earnings From Appointements")
            {
                ChartlReport4 lr = new ChartlReport4();
                string amount = "SELECT * FROM TableAppointments WHERE aDate BETWEEN '" + sDate + "' AND '" + eDate + "' AND doctorFee != " + earn + "";
                DataSet ds = new DataSet();
                SqlDataAdapter sda = new SqlDataAdapter(amount, MSSDBConnection.MSSConnection());
                sda.Fill(ds, "TableAppointments");

                lr.SetDataSource(ds.Tables["TableAppointments"]);
                lrv.crystalReportViewer1.ReportSource = lr;
                lrv.crystalReportViewer1.Refresh();
                lrv.Show();
            }
            else if (Button_reportType.Text == "Patients Details Report")
            {
                ChartReport1 lr = new ChartReport1();
                string amount = "SELECT * FROM TablePatients";
                DataSet ds = new DataSet();
                SqlDataAdapter sda = new SqlDataAdapter(amount, MSSDBConnection.MSSConnection());
                sda.Fill(ds, "TablePatients");

                lr.SetDataSource(ds.Tables["TablePatients"]);
                lrv.crystalReportViewer1.ReportSource = lr;
                lrv.crystalReportViewer1.Refresh();
                lrv.Show();
            }
            else if (Button_reportType.Text == "Doctors Details Report")
            {
                ChartReport5 lr = new ChartReport5();
                string amount = "SELECT * FROM TableDoctors";
                DataSet ds = new DataSet();
                SqlDataAdapter sda = new SqlDataAdapter(amount, MSSDBConnection.MSSConnection());
                sda.Fill(ds, "TableDoctors");

                lr.SetDataSource(ds.Tables["TableDoctors"]);
                lrv.crystalReportViewer1.ReportSource = lr;
                lrv.crystalReportViewer1.Refresh();
                lrv.Show();
            }
            else if (Button_reportType.Text == "Lab / Radiology Reports Details")
            {
                ChartReport6 lr = new ChartReport6();
                string amount = "SELECT Id, pName, pNIC, Diagnosis, Prescription, Lab_Report FROM TablePatientsHistory";
                DataSet ds = new DataSet();
                SqlDataAdapter sda = new SqlDataAdapter(amount, MSSDBConnection.MSSConnection());
                sda.Fill(ds, "TablePatientsHistory");

                lr.SetDataSource(ds.Tables["TablePatientsHistory"]);
                lrv.crystalReportViewer1.ReportSource = lr;
                lrv.crystalReportViewer1.Refresh();
                lrv.Show();
            }
            else if (Button_reportType.Text == "Diagnosis Details")
            {
                ChartReport7 lr = new ChartReport7();
                string amount = "SELECT Id, pName, pNIC, Diagnosis, Prescription, Lab_Report FROM TablePatientsHistory";
                DataSet ds = new DataSet();
                SqlDataAdapter sda = new SqlDataAdapter(amount, MSSDBConnection.MSSConnection());
                sda.Fill(ds, "TablePatientsHistory");

                lr.SetDataSource(ds.Tables["TablePatientsHistory"]);
                lrv.crystalReportViewer1.ReportSource = lr;
                lrv.crystalReportViewer1.Refresh();
                lrv.Show();
            }
            else if (Button_reportType.Text == "Pharmacy Income Report")
            {
                ChartReport8 lr = new ChartReport8();
                string amount = "SELECT Id, date, preName, costPrice, salesPrice, stocks, reLevel, quent, total FROM TableInventory WHERE date BETWEEN '" + sDate + "' AND '" + eDate + "'";
                DataSet ds = new DataSet();
                SqlDataAdapter sda = new SqlDataAdapter(amount, MSSDBConnection.MSSConnection());
                sda.Fill(ds, "TableInventory");

                lr.SetDataSource(ds.Tables["TableInventory"]);
                lrv.crystalReportViewer1.ReportSource = lr;
                lrv.crystalReportViewer1.Refresh();
                lrv.Show();
            }
            else if (Button_reportType.Text == "Internal Patients Details")
            {
                ChartReport9 lr = new ChartReport9();
                string amount = "SELECT Id, pNIC, pName, address, age, addNumber, wardNumber, addmittedDate FROM TableInternalPatients WHERE addmittedDate BETWEEN '" + sDate + "' AND '" + eDate + "'";
                DataSet ds = new DataSet();
                SqlDataAdapter sda = new SqlDataAdapter(amount, MSSDBConnection.MSSConnection());
                sda.Fill(ds, "TableInternalPatients");

                lr.SetDataSource(ds.Tables["TableInternalPatients"]);
                lrv.crystalReportViewer1.ReportSource = lr;
                lrv.crystalReportViewer1.Refresh();
                lrv.Show();
            }
            else if (Button_reportType.Text == "Hospital Bill Details")
            {
                ChartReport10 lr = new ChartReport10();
                string amount = "SELECT Id, pNIC, pName, addNumber, wardNumber, addmittedDate, rCharge, mCharge, RepCharge, TotalCharge FROM TableInternalPatients WHERE addmittedDate BETWEEN '" + sDate + "' AND '" + eDate + "'";
                DataSet ds = new DataSet();
                SqlDataAdapter sda = new SqlDataAdapter(amount, MSSDBConnection.MSSConnection());
                sda.Fill(ds, "TableInternalPatients");

                lr.SetDataSource(ds.Tables["TableInternalPatients"]);
                lrv.crystalReportViewer1.ReportSource = lr;
                lrv.crystalReportViewer1.Refresh();
                lrv.Show();
            }
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            if (isCollapsed)
            {
                panel_reportTypes.Height += 10;
                if (panel_reportTypes.Size == panel_reportTypes.MaximumSize)
                {
                    timer1.Stop();
                    isCollapsed = false;
                }
            }
            else
            {
                panel_reportTypes.Height -= 10;
                if (panel_reportTypes.Size == panel_reportTypes.MinimumSize)
                {
                    timer1.Stop();
                    isCollapsed = true;
                }
            }
        }

        private void Button_reportType_Click(object sender, EventArgs e)
        {
            timer1.Start();
            panel_reportTypes.BringToFront();
        }

        private void Button_appointments_Click(object sender, EventArgs e)
        {
            Button_reportType.Text = "Appointments Report";
            Button_reportType.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            dateTimePicker_eDate.Visible = true;
            Datepicker_aDate.Visible = true;
            Separator2.Visible = true;
            Separator3.Visible = true;
            Label_Date.Visible = true;
            Label_eDate.Visible = true;
        }

        private void Button_dEarning_Click(object sender, EventArgs e)
        {
            Button_reportType.Text = "Doctors Earning Report";
            Button_reportType.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            dateTimePicker_eDate.Visible = true;
            Datepicker_aDate.Visible = true;
            Separator2.Visible = true;
            Separator3.Visible = true;
            Label_Date.Visible = true;
            Label_eDate.Visible = true;
        }

        private void Button_totalEarns_Click(object sender, EventArgs e)
        {
            Button_reportType.Text = "Weekly Earnings From Appointements";
            Button_reportType.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            dateTimePicker_eDate.Visible = true;
            Datepicker_aDate.Visible = true;
            Separator2.Visible = true;
            Separator3.Visible = true;
            Label_Date.Visible = true;
            Label_eDate.Visible = true;
        }

        private void Button_patients_Click(object sender, EventArgs e)
        {
            Button_reportType.Text = "Patients Details Report";
            Button_reportType.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            dateTimePicker_eDate.Visible = false;
            Datepicker_aDate.Visible = false;
            Separator2.Visible = false;
            Separator3.Visible = false;
            Label_Date.Visible = false;
            Label_eDate.Visible = false;
        }

        private void Button_doctors_Click(object sender, EventArgs e)
        {
            Button_reportType.Text = "Doctors Details Report";
            Button_reportType.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            dateTimePicker_eDate.Visible = false;
            Datepicker_aDate.Visible = false;
            Separator2.Visible = false;
            Separator3.Visible = false;
            Label_Date.Visible = false;
            Label_eDate.Visible = false;
        }

        private void Button_patientHistory_Click(object sender, EventArgs e)
        {
            Button_reportType.Text = "Lab / Radiology Reports Details";
            Button_reportType.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            dateTimePicker_eDate.Visible = false;
            Datepicker_aDate.Visible = false;
            Separator2.Visible = false;
            Separator3.Visible = false;
            Label_Date.Visible = false;
            Label_eDate.Visible = false;
        }

        private void Button_diagnosisDetails_Click(object sender, EventArgs e)
        {
            Button_reportType.Text = "Diagnosis Details";
            Button_reportType.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            dateTimePicker_eDate.Visible = false;
            Datepicker_aDate.Visible = false;
            Separator2.Visible = false;
            Separator3.Visible = false;
            Label_Date.Visible = false;
            Label_eDate.Visible = false;
        }

        private void Button_inventory_Click(object sender, EventArgs e)
        {
            Button_reportType.Text = "Pharmacy Income Report";
            Button_reportType.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            dateTimePicker_eDate.Visible = true;
            Datepicker_aDate.Visible = true;
            Separator2.Visible = true;
            Separator3.Visible = true;
            Label_Date.Visible = true;
            Label_eDate.Visible = true;
        }

        private void Button_internalPatients_Click(object sender, EventArgs e)
        {
            Button_reportType.Text = "Internal Patients Details";
            Button_reportType.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            dateTimePicker_eDate.Visible = true;
            Datepicker_aDate.Visible = true;
            Separator2.Visible = true;
            Separator3.Visible = true;
            Label_Date.Visible = true;
            Label_eDate.Visible = true;
        }

        private void Button_hospitelBill_Click(object sender, EventArgs e)
        {
            Button_reportType.Text = "Hospital Bill Details";
            Button_reportType.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            dateTimePicker_eDate.Visible = true;
            Datepicker_aDate.Visible = true;
            Separator2.Visible = true;
            Separator3.Visible = true;
            Label_Date.Visible = true;
            Label_eDate.Visible = true;
        }
    }
}
