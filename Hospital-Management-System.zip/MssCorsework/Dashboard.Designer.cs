﻿namespace MssCorsework
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            BunifuAnimatorNS.Animation animation1 = new BunifuAnimatorNS.Animation();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboard));
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.panel_top = new System.Windows.Forms.Panel();
            this.pictureBox_online = new System.Windows.Forms.PictureBox();
            this.Label_User = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuImageButton1 = new Bunifu.Framework.UI.BunifuImageButton();
            this.label_time = new System.Windows.Forms.Label();
            this.label_Date = new System.Windows.Forms.Label();
            this.Label_timeTitle = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_dateTitle = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuThinButton21 = new Bunifu.Framework.UI.BunifuThinButton2();
            this.Button_maximize = new Bunifu.Framework.UI.BunifuImageButton();
            this.btn_close = new Bunifu.Framework.UI.BunifuImageButton();
            this.btn_minimize = new Bunifu.Framework.UI.BunifuImageButton();
            this.panel_left = new System.Windows.Forms.Panel();
            this.Button_internalPatient = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Separator_IPH = new Bunifu.Framework.UI.BunifuSeparator();
            this.Button_addDiagnosisDetails = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Separator_MH = new Bunifu.Framework.UI.BunifuSeparator();
            this.Button_calculateBill = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Separator_amo = new Bunifu.Framework.UI.BunifuSeparator();
            this.Button_amount = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Separator_pay = new Bunifu.Framework.UI.BunifuSeparator();
            this.Button_Payments = new Bunifu.Framework.UI.BunifuFlatButton();
            this.panel_doctors = new System.Windows.Forms.Panel();
            this.btn_addDoctor = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btn_updateDoctors = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Button_ManageDoctorsDetails = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Separator_app = new Bunifu.Framework.UI.BunifuSeparator();
            this.panel_Patients = new System.Windows.Forms.Panel();
            this.Button_add = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Button_Update = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Button_mangePatientsDetails = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Separator3 = new Bunifu.Framework.UI.BunifuSeparator();
            this.Separator2 = new Bunifu.Framework.UI.BunifuSeparator();
            this.Separator1 = new Bunifu.Framework.UI.BunifuSeparator();
            this.Button_Appointments = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Button_showMenu = new Bunifu.Framework.UI.BunifuImageButton();
            this.Button_hideMenu = new Bunifu.Framework.UI.BunifuImageButton();
            this.Button_home = new Bunifu.Framework.UI.BunifuImageButton();
            this.Button_UpdateInternal = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Button_charts = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Button_appointmentHistory = new Bunifu.Framework.UI.BunifuFlatButton();
            this.menuTransition = new BunifuAnimatorNS.BunifuTransition(this.components);
            this.frontControl1 = new MssCorsework.FrontControl();
            this.addPatientControl1 = new MssCorsework.addPatientControl();
            this.updatePatientControl1 = new MssCorsework.UpdatePatientControl();
            this.appointmentControl1 = new MssCorsework.appointmentControl();
            this.addDoctorsControl1 = new MssCorsework.addDoctorsControl();
            this.updateDoctorsControl1 = new MssCorsework.UpdateDoctorsControl();
            this.paymentControl1 = new MssCorsework.PaymentControl();
            this.caculateAmountControl1 = new MssCorsework.caculateAmountControl();
            this.patientHistoryManagementControl1 = new MssCorsework.patientHistoryManagementControl();
            this.viewDiagnosisDetailsControl1 = new MssCorsework.viewDiagnosisDetailsControl();
            this.calculateBillControl1 = new MssCorsework.calculateBillControl();
            this.internalPatientsControl1 = new MssCorsework.internalPatientsControl();
            this.updateInternalPatientsControl1 = new MssCorsework.UpdateInternalPatientsControl();
            this.chartsControl1 = new MssCorsework.chartsControl();
            this.appointmentHistoryControl1 = new MssCorsework.appointmentHistoryControl();
            this.timer_time = new System.Windows.Forms.Timer(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.dragControl1 = new Project_SDC.DragControl();
            this.panel_top.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_online)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Button_maximize)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_minimize)).BeginInit();
            this.panel_left.SuspendLayout();
            this.panel_doctors.SuspendLayout();
            this.panel_Patients.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Button_showMenu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Button_hideMenu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Button_home)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 0;
            this.bunifuElipse1.TargetControl = this;
            // 
            // panel_top
            // 
            this.panel_top.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.panel_top.Controls.Add(this.pictureBox_online);
            this.panel_top.Controls.Add(this.Label_User);
            this.panel_top.Controls.Add(this.bunifuImageButton1);
            this.panel_top.Controls.Add(this.label_time);
            this.panel_top.Controls.Add(this.label_Date);
            this.panel_top.Controls.Add(this.Label_timeTitle);
            this.panel_top.Controls.Add(this.Label_dateTitle);
            this.panel_top.Controls.Add(this.bunifuThinButton21);
            this.panel_top.Controls.Add(this.Button_maximize);
            this.panel_top.Controls.Add(this.btn_close);
            this.panel_top.Controls.Add(this.btn_minimize);
            this.menuTransition.SetDecoration(this.panel_top, BunifuAnimatorNS.DecorationType.None);
            this.panel_top.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_top.Location = new System.Drawing.Point(0, 0);
            this.panel_top.Name = "panel_top";
            this.panel_top.Size = new System.Drawing.Size(1494, 54);
            this.panel_top.TabIndex = 0;
            // 
            // pictureBox_online
            // 
            this.pictureBox_online.BackColor = System.Drawing.Color.Transparent;
            this.menuTransition.SetDecoration(this.pictureBox_online, BunifuAnimatorNS.DecorationType.None);
            this.pictureBox_online.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_online.Image")));
            this.pictureBox_online.Location = new System.Drawing.Point(64, 19);
            this.pictureBox_online.Name = "pictureBox_online";
            this.pictureBox_online.Size = new System.Drawing.Size(20, 20);
            this.pictureBox_online.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_online.TabIndex = 18;
            this.pictureBox_online.TabStop = false;
            // 
            // Label_User
            // 
            this.Label_User.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_User.AutoSize = true;
            this.Label_User.BackColor = System.Drawing.Color.Transparent;
            this.menuTransition.SetDecoration(this.Label_User, BunifuAnimatorNS.DecorationType.None);
            this.Label_User.Font = new System.Drawing.Font("Franklin Gothic Demi", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_User.ForeColor = System.Drawing.Color.White;
            this.Label_User.Location = new System.Drawing.Point(90, 18);
            this.Label_User.Name = "Label_User";
            this.Label_User.Size = new System.Drawing.Size(63, 24);
            this.Label_User.TabIndex = 17;
            this.Label_User.Text = "Admin";
            // 
            // bunifuImageButton1
            // 
            this.bunifuImageButton1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.bunifuImageButton1, BunifuAnimatorNS.DecorationType.None);
            this.bunifuImageButton1.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton1.Image")));
            this.bunifuImageButton1.ImageActive = null;
            this.bunifuImageButton1.Location = new System.Drawing.Point(18, 6);
            this.bunifuImageButton1.Name = "bunifuImageButton1";
            this.bunifuImageButton1.Size = new System.Drawing.Size(40, 40);
            this.bunifuImageButton1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bunifuImageButton1.TabIndex = 16;
            this.bunifuImageButton1.TabStop = false;
            this.bunifuImageButton1.Zoom = 10;
            // 
            // label_time
            // 
            this.label_time.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label_time.AutoSize = true;
            this.label_time.BackColor = System.Drawing.Color.Transparent;
            this.menuTransition.SetDecoration(this.label_time, BunifuAnimatorNS.DecorationType.None);
            this.label_time.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_time.ForeColor = System.Drawing.Color.White;
            this.label_time.Location = new System.Drawing.Point(887, 16);
            this.label_time.Name = "label_time";
            this.label_time.Size = new System.Drawing.Size(0, 24);
            this.label_time.TabIndex = 15;
            // 
            // label_Date
            // 
            this.label_Date.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label_Date.AutoSize = true;
            this.label_Date.BackColor = System.Drawing.Color.Transparent;
            this.menuTransition.SetDecoration(this.label_Date, BunifuAnimatorNS.DecorationType.None);
            this.label_Date.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Date.ForeColor = System.Drawing.Color.White;
            this.label_Date.Location = new System.Drawing.Point(681, 16);
            this.label_Date.Name = "label_Date";
            this.label_Date.Size = new System.Drawing.Size(0, 24);
            this.label_Date.TabIndex = 14;
            // 
            // Label_timeTitle
            // 
            this.Label_timeTitle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_timeTitle.AutoSize = true;
            this.Label_timeTitle.BackColor = System.Drawing.Color.Transparent;
            this.menuTransition.SetDecoration(this.Label_timeTitle, BunifuAnimatorNS.DecorationType.None);
            this.Label_timeTitle.Font = new System.Drawing.Font("Franklin Gothic Demi", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_timeTitle.ForeColor = System.Drawing.Color.White;
            this.Label_timeTitle.Location = new System.Drawing.Point(610, 16);
            this.Label_timeTitle.Name = "Label_timeTitle";
            this.Label_timeTitle.Size = new System.Drawing.Size(65, 24);
            this.Label_timeTitle.TabIndex = 13;
            this.Label_timeTitle.Text = "Time : ";
            // 
            // Label_dateTitle
            // 
            this.Label_dateTitle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_dateTitle.AutoSize = true;
            this.Label_dateTitle.BackColor = System.Drawing.Color.Transparent;
            this.menuTransition.SetDecoration(this.Label_dateTitle, BunifuAnimatorNS.DecorationType.None);
            this.Label_dateTitle.Font = new System.Drawing.Font("Franklin Gothic Demi", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_dateTitle.ForeColor = System.Drawing.Color.White;
            this.Label_dateTitle.Location = new System.Drawing.Point(809, 16);
            this.Label_dateTitle.Name = "Label_dateTitle";
            this.Label_dateTitle.Size = new System.Drawing.Size(72, 24);
            this.Label_dateTitle.TabIndex = 12;
            this.Label_dateTitle.Text = "Today : ";
            // 
            // bunifuThinButton21
            // 
            this.bunifuThinButton21.ActiveBorderThickness = 1;
            this.bunifuThinButton21.ActiveCornerRadius = 20;
            this.bunifuThinButton21.ActiveFillColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton21.ActiveForecolor = System.Drawing.Color.Firebrick;
            this.bunifuThinButton21.ActiveLineColor = System.Drawing.Color.Firebrick;
            this.bunifuThinButton21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.bunifuThinButton21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuThinButton21.BackgroundImage")));
            this.bunifuThinButton21.ButtonText = "Log Out";
            this.bunifuThinButton21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.bunifuThinButton21, BunifuAnimatorNS.DecorationType.None);
            this.bunifuThinButton21.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuThinButton21.ForeColor = System.Drawing.Color.SeaGreen;
            this.bunifuThinButton21.IdleBorderThickness = 1;
            this.bunifuThinButton21.IdleCornerRadius = 20;
            this.bunifuThinButton21.IdleFillColor = System.Drawing.Color.Transparent;
            this.bunifuThinButton21.IdleForecolor = System.Drawing.Color.Teal;
            this.bunifuThinButton21.IdleLineColor = System.Drawing.Color.Teal;
            this.bunifuThinButton21.Location = new System.Drawing.Point(1244, 2);
            this.bunifuThinButton21.Margin = new System.Windows.Forms.Padding(5);
            this.bunifuThinButton21.Name = "bunifuThinButton21";
            this.bunifuThinButton21.Size = new System.Drawing.Size(110, 48);
            this.bunifuThinButton21.TabIndex = 2;
            this.bunifuThinButton21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuThinButton21.Click += new System.EventHandler(this.BunifuThinButton21_Click);
            // 
            // Button_maximize
            // 
            this.Button_maximize.BackColor = System.Drawing.Color.Transparent;
            this.Button_maximize.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.Button_maximize, BunifuAnimatorNS.DecorationType.None);
            this.Button_maximize.Image = ((System.Drawing.Image)(resources.GetObject("Button_maximize.Image")));
            this.Button_maximize.ImageActive = null;
            this.Button_maximize.Location = new System.Drawing.Point(1408, 6);
            this.Button_maximize.Name = "Button_maximize";
            this.Button_maximize.Size = new System.Drawing.Size(40, 40);
            this.Button_maximize.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Button_maximize.TabIndex = 4;
            this.Button_maximize.TabStop = false;
            this.Button_maximize.Zoom = 10;
            // 
            // btn_close
            // 
            this.btn_close.BackColor = System.Drawing.Color.Transparent;
            this.btn_close.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.btn_close, BunifuAnimatorNS.DecorationType.None);
            this.btn_close.Image = ((System.Drawing.Image)(resources.GetObject("btn_close.Image")));
            this.btn_close.ImageActive = null;
            this.btn_close.Location = new System.Drawing.Point(1449, 6);
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(40, 40);
            this.btn_close.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btn_close.TabIndex = 2;
            this.btn_close.TabStop = false;
            this.btn_close.Zoom = 10;
            this.btn_close.Click += new System.EventHandler(this.Btn_close_Click);
            // 
            // btn_minimize
            // 
            this.btn_minimize.BackColor = System.Drawing.Color.Transparent;
            this.btn_minimize.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.btn_minimize, BunifuAnimatorNS.DecorationType.None);
            this.btn_minimize.Image = ((System.Drawing.Image)(resources.GetObject("btn_minimize.Image")));
            this.btn_minimize.ImageActive = null;
            this.btn_minimize.Location = new System.Drawing.Point(1367, 6);
            this.btn_minimize.Name = "btn_minimize";
            this.btn_minimize.Size = new System.Drawing.Size(40, 40);
            this.btn_minimize.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btn_minimize.TabIndex = 3;
            this.btn_minimize.TabStop = false;
            this.btn_minimize.Zoom = 10;
            this.btn_minimize.Click += new System.EventHandler(this.Btn_minimize_Click);
            // 
            // panel_left
            // 
            this.panel_left.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.panel_left.Controls.Add(this.Button_internalPatient);
            this.panel_left.Controls.Add(this.Separator_IPH);
            this.panel_left.Controls.Add(this.Button_addDiagnosisDetails);
            this.panel_left.Controls.Add(this.Separator_MH);
            this.panel_left.Controls.Add(this.Button_calculateBill);
            this.panel_left.Controls.Add(this.Separator_amo);
            this.panel_left.Controls.Add(this.Button_amount);
            this.panel_left.Controls.Add(this.Separator_pay);
            this.panel_left.Controls.Add(this.Button_Payments);
            this.panel_left.Controls.Add(this.panel_doctors);
            this.panel_left.Controls.Add(this.Separator_app);
            this.panel_left.Controls.Add(this.panel_Patients);
            this.panel_left.Controls.Add(this.Separator3);
            this.panel_left.Controls.Add(this.Separator2);
            this.panel_left.Controls.Add(this.Separator1);
            this.panel_left.Controls.Add(this.Button_Appointments);
            this.panel_left.Controls.Add(this.Button_showMenu);
            this.panel_left.Controls.Add(this.Button_hideMenu);
            this.panel_left.Controls.Add(this.Button_home);
            this.panel_left.Controls.Add(this.Button_UpdateInternal);
            this.panel_left.Controls.Add(this.Button_charts);
            this.panel_left.Controls.Add(this.Button_appointmentHistory);
            this.menuTransition.SetDecoration(this.panel_left, BunifuAnimatorNS.DecorationType.None);
            this.panel_left.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_left.Location = new System.Drawing.Point(0, 54);
            this.panel_left.Name = "panel_left";
            this.panel_left.Size = new System.Drawing.Size(354, 812);
            this.panel_left.TabIndex = 1;
            // 
            // Button_internalPatient
            // 
            this.Button_internalPatient.Activecolor = System.Drawing.Color.Transparent;
            this.Button_internalPatient.BackColor = System.Drawing.Color.Transparent;
            this.Button_internalPatient.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_internalPatient.BorderRadius = 0;
            this.Button_internalPatient.ButtonText = "           Internal Patient Details";
            this.Button_internalPatient.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.Button_internalPatient, BunifuAnimatorNS.DecorationType.None);
            this.Button_internalPatient.DisabledColor = System.Drawing.Color.Gray;
            this.Button_internalPatient.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_internalPatient.Iconimage = ((System.Drawing.Image)(resources.GetObject("Button_internalPatient.Iconimage")));
            this.Button_internalPatient.Iconimage_right = null;
            this.Button_internalPatient.Iconimage_right_Selected = null;
            this.Button_internalPatient.Iconimage_Selected = null;
            this.Button_internalPatient.IconMarginLeft = 0;
            this.Button_internalPatient.IconMarginRight = 0;
            this.Button_internalPatient.IconRightVisible = true;
            this.Button_internalPatient.IconRightZoom = 0D;
            this.Button_internalPatient.IconVisible = true;
            this.Button_internalPatient.IconZoom = 60D;
            this.Button_internalPatient.IsTab = false;
            this.Button_internalPatient.Location = new System.Drawing.Point(5, 708);
            this.Button_internalPatient.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_internalPatient.Name = "Button_internalPatient";
            this.Button_internalPatient.Normalcolor = System.Drawing.Color.Transparent;
            this.Button_internalPatient.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.Button_internalPatient.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_internalPatient.selected = false;
            this.Button_internalPatient.Size = new System.Drawing.Size(343, 70);
            this.Button_internalPatient.TabIndex = 94;
            this.Button_internalPatient.Text = "           Internal Patient Details";
            this.Button_internalPatient.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Button_internalPatient.Textcolor = System.Drawing.Color.White;
            this.Button_internalPatient.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_internalPatient.Click += new System.EventHandler(this.Button_internalPatient_Click);
            // 
            // Separator_IPH
            // 
            this.Separator_IPH.BackColor = System.Drawing.Color.Transparent;
            this.menuTransition.SetDecoration(this.Separator_IPH, BunifuAnimatorNS.DecorationType.None);
            this.Separator_IPH.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.Separator_IPH.LineThickness = 2;
            this.Separator_IPH.Location = new System.Drawing.Point(5, 786);
            this.Separator_IPH.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Separator_IPH.Name = "Separator_IPH";
            this.Separator_IPH.Size = new System.Drawing.Size(343, 10);
            this.Separator_IPH.TabIndex = 93;
            this.Separator_IPH.Transparency = 255;
            this.Separator_IPH.Vertical = false;
            // 
            // Button_addDiagnosisDetails
            // 
            this.Button_addDiagnosisDetails.Activecolor = System.Drawing.Color.Transparent;
            this.Button_addDiagnosisDetails.BackColor = System.Drawing.Color.Transparent;
            this.Button_addDiagnosisDetails.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_addDiagnosisDetails.BorderRadius = 0;
            this.Button_addDiagnosisDetails.ButtonText = "           Record Diagnosis Details";
            this.Button_addDiagnosisDetails.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.Button_addDiagnosisDetails, BunifuAnimatorNS.DecorationType.None);
            this.Button_addDiagnosisDetails.DisabledColor = System.Drawing.Color.Gray;
            this.Button_addDiagnosisDetails.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_addDiagnosisDetails.Iconimage = ((System.Drawing.Image)(resources.GetObject("Button_addDiagnosisDetails.Iconimage")));
            this.Button_addDiagnosisDetails.Iconimage_right = null;
            this.Button_addDiagnosisDetails.Iconimage_right_Selected = null;
            this.Button_addDiagnosisDetails.Iconimage_Selected = null;
            this.Button_addDiagnosisDetails.IconMarginLeft = 0;
            this.Button_addDiagnosisDetails.IconMarginRight = 0;
            this.Button_addDiagnosisDetails.IconRightVisible = true;
            this.Button_addDiagnosisDetails.IconRightZoom = 0D;
            this.Button_addDiagnosisDetails.IconVisible = true;
            this.Button_addDiagnosisDetails.IconZoom = 60D;
            this.Button_addDiagnosisDetails.IsTab = false;
            this.Button_addDiagnosisDetails.Location = new System.Drawing.Point(5, 708);
            this.Button_addDiagnosisDetails.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_addDiagnosisDetails.Name = "Button_addDiagnosisDetails";
            this.Button_addDiagnosisDetails.Normalcolor = System.Drawing.Color.Transparent;
            this.Button_addDiagnosisDetails.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.Button_addDiagnosisDetails.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_addDiagnosisDetails.selected = false;
            this.Button_addDiagnosisDetails.Size = new System.Drawing.Size(343, 70);
            this.Button_addDiagnosisDetails.TabIndex = 92;
            this.Button_addDiagnosisDetails.Text = "           Record Diagnosis Details";
            this.Button_addDiagnosisDetails.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Button_addDiagnosisDetails.Textcolor = System.Drawing.Color.White;
            this.Button_addDiagnosisDetails.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_addDiagnosisDetails.Click += new System.EventHandler(this.Button_ReviewDiagnosis_Click);
            // 
            // Separator_MH
            // 
            this.Separator_MH.BackColor = System.Drawing.Color.Transparent;
            this.menuTransition.SetDecoration(this.Separator_MH, BunifuAnimatorNS.DecorationType.None);
            this.Separator_MH.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.Separator_MH.LineThickness = 2;
            this.Separator_MH.Location = new System.Drawing.Point(5, 690);
            this.Separator_MH.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Separator_MH.Name = "Separator_MH";
            this.Separator_MH.Size = new System.Drawing.Size(343, 10);
            this.Separator_MH.TabIndex = 91;
            this.Separator_MH.Transparency = 255;
            this.Separator_MH.Vertical = false;
            // 
            // Button_calculateBill
            // 
            this.Button_calculateBill.Activecolor = System.Drawing.Color.Transparent;
            this.Button_calculateBill.BackColor = System.Drawing.Color.Transparent;
            this.Button_calculateBill.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_calculateBill.BorderRadius = 0;
            this.Button_calculateBill.ButtonText = "           Internal Patient\'s Bill";
            this.Button_calculateBill.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.Button_calculateBill, BunifuAnimatorNS.DecorationType.None);
            this.Button_calculateBill.DisabledColor = System.Drawing.Color.Gray;
            this.Button_calculateBill.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_calculateBill.Iconimage = ((System.Drawing.Image)(resources.GetObject("Button_calculateBill.Iconimage")));
            this.Button_calculateBill.Iconimage_right = null;
            this.Button_calculateBill.Iconimage_right_Selected = null;
            this.Button_calculateBill.Iconimage_Selected = null;
            this.Button_calculateBill.IconMarginLeft = 0;
            this.Button_calculateBill.IconMarginRight = 0;
            this.Button_calculateBill.IconRightVisible = true;
            this.Button_calculateBill.IconRightZoom = 0D;
            this.Button_calculateBill.IconVisible = true;
            this.Button_calculateBill.IconZoom = 60D;
            this.Button_calculateBill.IsTab = false;
            this.Button_calculateBill.Location = new System.Drawing.Point(5, 612);
            this.Button_calculateBill.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_calculateBill.Name = "Button_calculateBill";
            this.Button_calculateBill.Normalcolor = System.Drawing.Color.Transparent;
            this.Button_calculateBill.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.Button_calculateBill.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_calculateBill.selected = false;
            this.Button_calculateBill.Size = new System.Drawing.Size(343, 70);
            this.Button_calculateBill.TabIndex = 90;
            this.Button_calculateBill.Text = "           Internal Patient\'s Bill";
            this.Button_calculateBill.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Button_calculateBill.Textcolor = System.Drawing.Color.White;
            this.Button_calculateBill.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_calculateBill.Click += new System.EventHandler(this.Button_manageHistory_Click);
            // 
            // Separator_amo
            // 
            this.Separator_amo.BackColor = System.Drawing.Color.Transparent;
            this.menuTransition.SetDecoration(this.Separator_amo, BunifuAnimatorNS.DecorationType.None);
            this.Separator_amo.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.Separator_amo.LineThickness = 2;
            this.Separator_amo.Location = new System.Drawing.Point(7, 594);
            this.Separator_amo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Separator_amo.Name = "Separator_amo";
            this.Separator_amo.Size = new System.Drawing.Size(343, 10);
            this.Separator_amo.TabIndex = 89;
            this.Separator_amo.Transparency = 255;
            this.Separator_amo.Vertical = false;
            // 
            // Button_amount
            // 
            this.Button_amount.Activecolor = System.Drawing.Color.Transparent;
            this.Button_amount.BackColor = System.Drawing.Color.Transparent;
            this.Button_amount.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_amount.BorderRadius = 0;
            this.Button_amount.ButtonText = "           Calculate Amount";
            this.Button_amount.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.Button_amount, BunifuAnimatorNS.DecorationType.None);
            this.Button_amount.DisabledColor = System.Drawing.Color.Gray;
            this.Button_amount.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_amount.Iconimage = ((System.Drawing.Image)(resources.GetObject("Button_amount.Iconimage")));
            this.Button_amount.Iconimage_right = null;
            this.Button_amount.Iconimage_right_Selected = null;
            this.Button_amount.Iconimage_Selected = null;
            this.Button_amount.IconMarginLeft = 0;
            this.Button_amount.IconMarginRight = 0;
            this.Button_amount.IconRightVisible = true;
            this.Button_amount.IconRightZoom = 0D;
            this.Button_amount.IconVisible = true;
            this.Button_amount.IconZoom = 50D;
            this.Button_amount.IsTab = false;
            this.Button_amount.Location = new System.Drawing.Point(5, 516);
            this.Button_amount.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_amount.Name = "Button_amount";
            this.Button_amount.Normalcolor = System.Drawing.Color.Transparent;
            this.Button_amount.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.Button_amount.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_amount.selected = false;
            this.Button_amount.Size = new System.Drawing.Size(343, 70);
            this.Button_amount.TabIndex = 88;
            this.Button_amount.Text = "           Calculate Amount";
            this.Button_amount.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Button_amount.Textcolor = System.Drawing.Color.White;
            this.Button_amount.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_amount.Click += new System.EventHandler(this.Button_amount_Click);
            // 
            // Separator_pay
            // 
            this.Separator_pay.BackColor = System.Drawing.Color.Transparent;
            this.menuTransition.SetDecoration(this.Separator_pay, BunifuAnimatorNS.DecorationType.None);
            this.Separator_pay.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.Separator_pay.LineThickness = 2;
            this.Separator_pay.Location = new System.Drawing.Point(5, 498);
            this.Separator_pay.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Separator_pay.Name = "Separator_pay";
            this.Separator_pay.Size = new System.Drawing.Size(343, 10);
            this.Separator_pay.TabIndex = 87;
            this.Separator_pay.Transparency = 255;
            this.Separator_pay.Vertical = false;
            // 
            // Button_Payments
            // 
            this.Button_Payments.Activecolor = System.Drawing.Color.Transparent;
            this.Button_Payments.BackColor = System.Drawing.Color.Transparent;
            this.Button_Payments.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_Payments.BorderRadius = 0;
            this.Button_Payments.ButtonText = "           Payment Details";
            this.Button_Payments.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.Button_Payments, BunifuAnimatorNS.DecorationType.None);
            this.Button_Payments.DisabledColor = System.Drawing.Color.Gray;
            this.Button_Payments.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_Payments.Iconimage = ((System.Drawing.Image)(resources.GetObject("Button_Payments.Iconimage")));
            this.Button_Payments.Iconimage_right = null;
            this.Button_Payments.Iconimage_right_Selected = null;
            this.Button_Payments.Iconimage_Selected = null;
            this.Button_Payments.IconMarginLeft = 0;
            this.Button_Payments.IconMarginRight = 0;
            this.Button_Payments.IconRightVisible = true;
            this.Button_Payments.IconRightZoom = 0D;
            this.Button_Payments.IconVisible = true;
            this.Button_Payments.IconZoom = 50D;
            this.Button_Payments.IsTab = false;
            this.Button_Payments.Location = new System.Drawing.Point(5, 420);
            this.Button_Payments.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_Payments.Name = "Button_Payments";
            this.Button_Payments.Normalcolor = System.Drawing.Color.Transparent;
            this.Button_Payments.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.Button_Payments.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_Payments.selected = false;
            this.Button_Payments.Size = new System.Drawing.Size(343, 70);
            this.Button_Payments.TabIndex = 86;
            this.Button_Payments.Text = "           Payment Details";
            this.Button_Payments.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Button_Payments.Textcolor = System.Drawing.Color.White;
            this.Button_Payments.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Payments.Click += new System.EventHandler(this.Button_Payments_Click);
            // 
            // panel_doctors
            // 
            this.panel_doctors.BackColor = System.Drawing.Color.Transparent;
            this.panel_doctors.Controls.Add(this.btn_addDoctor);
            this.panel_doctors.Controls.Add(this.btn_updateDoctors);
            this.panel_doctors.Controls.Add(this.Button_ManageDoctorsDetails);
            this.menuTransition.SetDecoration(this.panel_doctors, BunifuAnimatorNS.DecorationType.None);
            this.panel_doctors.Location = new System.Drawing.Point(5, 227);
            this.panel_doctors.MaximumSize = new System.Drawing.Size(343, 167);
            this.panel_doctors.MinimumSize = new System.Drawing.Size(343, 72);
            this.panel_doctors.Name = "panel_doctors";
            this.panel_doctors.Size = new System.Drawing.Size(343, 72);
            this.panel_doctors.TabIndex = 84;
            // 
            // btn_addDoctor
            // 
            this.btn_addDoctor.Activecolor = System.Drawing.Color.SteelBlue;
            this.btn_addDoctor.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_addDoctor.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_addDoctor.BorderRadius = 0;
            this.btn_addDoctor.ButtonText = "Add New Doctor";
            this.btn_addDoctor.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.btn_addDoctor, BunifuAnimatorNS.DecorationType.None);
            this.btn_addDoctor.DisabledColor = System.Drawing.Color.Gray;
            this.btn_addDoctor.Iconcolor = System.Drawing.Color.Transparent;
            this.btn_addDoctor.Iconimage = null;
            this.btn_addDoctor.Iconimage_right = null;
            this.btn_addDoctor.Iconimage_right_Selected = null;
            this.btn_addDoctor.Iconimage_Selected = null;
            this.btn_addDoctor.IconMarginLeft = 0;
            this.btn_addDoctor.IconMarginRight = 0;
            this.btn_addDoctor.IconRightVisible = true;
            this.btn_addDoctor.IconRightZoom = 0D;
            this.btn_addDoctor.IconVisible = true;
            this.btn_addDoctor.IconZoom = 90D;
            this.btn_addDoctor.IsTab = false;
            this.btn_addDoctor.Location = new System.Drawing.Point(0, 76);
            this.btn_addDoctor.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_addDoctor.Name = "btn_addDoctor";
            this.btn_addDoctor.Normalcolor = System.Drawing.Color.SteelBlue;
            this.btn_addDoctor.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.btn_addDoctor.OnHoverTextColor = System.Drawing.Color.White;
            this.btn_addDoctor.selected = false;
            this.btn_addDoctor.Size = new System.Drawing.Size(343, 42);
            this.btn_addDoctor.TabIndex = 25;
            this.btn_addDoctor.Text = "Add New Doctor";
            this.btn_addDoctor.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_addDoctor.Textcolor = System.Drawing.Color.White;
            this.btn_addDoctor.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_addDoctor.Click += new System.EventHandler(this.Btn_addDoctor_Click);
            // 
            // btn_updateDoctors
            // 
            this.btn_updateDoctors.Activecolor = System.Drawing.Color.SteelBlue;
            this.btn_updateDoctors.BackColor = System.Drawing.Color.SteelBlue;
            this.btn_updateDoctors.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_updateDoctors.BorderRadius = 0;
            this.btn_updateDoctors.ButtonText = "Update Doctors Details";
            this.btn_updateDoctors.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.btn_updateDoctors, BunifuAnimatorNS.DecorationType.None);
            this.btn_updateDoctors.DisabledColor = System.Drawing.Color.Gray;
            this.btn_updateDoctors.Iconcolor = System.Drawing.Color.Transparent;
            this.btn_updateDoctors.Iconimage = null;
            this.btn_updateDoctors.Iconimage_right = null;
            this.btn_updateDoctors.Iconimage_right_Selected = null;
            this.btn_updateDoctors.Iconimage_Selected = null;
            this.btn_updateDoctors.IconMarginLeft = 0;
            this.btn_updateDoctors.IconMarginRight = 0;
            this.btn_updateDoctors.IconRightVisible = true;
            this.btn_updateDoctors.IconRightZoom = 0D;
            this.btn_updateDoctors.IconVisible = true;
            this.btn_updateDoctors.IconZoom = 90D;
            this.btn_updateDoctors.IsTab = false;
            this.btn_updateDoctors.Location = new System.Drawing.Point(0, 121);
            this.btn_updateDoctors.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn_updateDoctors.Name = "btn_updateDoctors";
            this.btn_updateDoctors.Normalcolor = System.Drawing.Color.SteelBlue;
            this.btn_updateDoctors.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.btn_updateDoctors.OnHoverTextColor = System.Drawing.Color.White;
            this.btn_updateDoctors.selected = false;
            this.btn_updateDoctors.Size = new System.Drawing.Size(343, 42);
            this.btn_updateDoctors.TabIndex = 26;
            this.btn_updateDoctors.Text = "Update Doctors Details";
            this.btn_updateDoctors.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btn_updateDoctors.Textcolor = System.Drawing.Color.White;
            this.btn_updateDoctors.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_updateDoctors.Click += new System.EventHandler(this.Btn_updateDoctors_Click);
            // 
            // Button_ManageDoctorsDetails
            // 
            this.Button_ManageDoctorsDetails.Activecolor = System.Drawing.Color.Transparent;
            this.Button_ManageDoctorsDetails.BackColor = System.Drawing.Color.Transparent;
            this.Button_ManageDoctorsDetails.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_ManageDoctorsDetails.BorderRadius = 0;
            this.Button_ManageDoctorsDetails.ButtonText = "          Manage Doctors Details";
            this.Button_ManageDoctorsDetails.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.Button_ManageDoctorsDetails, BunifuAnimatorNS.DecorationType.None);
            this.Button_ManageDoctorsDetails.DisabledColor = System.Drawing.Color.Gray;
            this.Button_ManageDoctorsDetails.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_ManageDoctorsDetails.Iconimage = ((System.Drawing.Image)(resources.GetObject("Button_ManageDoctorsDetails.Iconimage")));
            this.Button_ManageDoctorsDetails.Iconimage_right = null;
            this.Button_ManageDoctorsDetails.Iconimage_right_Selected = null;
            this.Button_ManageDoctorsDetails.Iconimage_Selected = null;
            this.Button_ManageDoctorsDetails.IconMarginLeft = 0;
            this.Button_ManageDoctorsDetails.IconMarginRight = 0;
            this.Button_ManageDoctorsDetails.IconRightVisible = true;
            this.Button_ManageDoctorsDetails.IconRightZoom = 0D;
            this.Button_ManageDoctorsDetails.IconVisible = true;
            this.Button_ManageDoctorsDetails.IconZoom = 60D;
            this.Button_ManageDoctorsDetails.IsTab = false;
            this.Button_ManageDoctorsDetails.Location = new System.Drawing.Point(3, 2);
            this.Button_ManageDoctorsDetails.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_ManageDoctorsDetails.Name = "Button_ManageDoctorsDetails";
            this.Button_ManageDoctorsDetails.Normalcolor = System.Drawing.Color.Transparent;
            this.Button_ManageDoctorsDetails.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.Button_ManageDoctorsDetails.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_ManageDoctorsDetails.selected = false;
            this.Button_ManageDoctorsDetails.Size = new System.Drawing.Size(339, 70);
            this.Button_ManageDoctorsDetails.TabIndex = 79;
            this.Button_ManageDoctorsDetails.Text = "          Manage Doctors Details";
            this.Button_ManageDoctorsDetails.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_ManageDoctorsDetails.Textcolor = System.Drawing.Color.White;
            this.Button_ManageDoctorsDetails.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_ManageDoctorsDetails.Click += new System.EventHandler(this.Button_ManageDoctorsDetails_Click);
            // 
            // Separator_app
            // 
            this.Separator_app.BackColor = System.Drawing.Color.Transparent;
            this.menuTransition.SetDecoration(this.Separator_app, BunifuAnimatorNS.DecorationType.None);
            this.Separator_app.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.Separator_app.LineThickness = 2;
            this.Separator_app.Location = new System.Drawing.Point(5, 402);
            this.Separator_app.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Separator_app.Name = "Separator_app";
            this.Separator_app.Size = new System.Drawing.Size(343, 10);
            this.Separator_app.TabIndex = 85;
            this.Separator_app.Transparency = 255;
            this.Separator_app.Vertical = false;
            // 
            // panel_Patients
            // 
            this.panel_Patients.BackColor = System.Drawing.Color.Transparent;
            this.panel_Patients.Controls.Add(this.Button_add);
            this.panel_Patients.Controls.Add(this.Button_Update);
            this.panel_Patients.Controls.Add(this.Button_mangePatientsDetails);
            this.menuTransition.SetDecoration(this.panel_Patients, BunifuAnimatorNS.DecorationType.None);
            this.panel_Patients.Location = new System.Drawing.Point(5, 131);
            this.panel_Patients.MaximumSize = new System.Drawing.Size(343, 167);
            this.panel_Patients.MinimumSize = new System.Drawing.Size(343, 72);
            this.panel_Patients.Name = "panel_Patients";
            this.panel_Patients.Size = new System.Drawing.Size(343, 72);
            this.panel_Patients.TabIndex = 66;
            // 
            // Button_add
            // 
            this.Button_add.Activecolor = System.Drawing.Color.SteelBlue;
            this.Button_add.BackColor = System.Drawing.Color.SteelBlue;
            this.Button_add.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_add.BorderRadius = 0;
            this.Button_add.ButtonText = "Add New Patient";
            this.Button_add.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.Button_add, BunifuAnimatorNS.DecorationType.None);
            this.Button_add.DisabledColor = System.Drawing.Color.Gray;
            this.Button_add.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_add.Iconimage = null;
            this.Button_add.Iconimage_right = null;
            this.Button_add.Iconimage_right_Selected = null;
            this.Button_add.Iconimage_Selected = null;
            this.Button_add.IconMarginLeft = 0;
            this.Button_add.IconMarginRight = 0;
            this.Button_add.IconRightVisible = true;
            this.Button_add.IconRightZoom = 0D;
            this.Button_add.IconVisible = true;
            this.Button_add.IconZoom = 90D;
            this.Button_add.IsTab = false;
            this.Button_add.Location = new System.Drawing.Point(0, 76);
            this.Button_add.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_add.Name = "Button_add";
            this.Button_add.Normalcolor = System.Drawing.Color.SteelBlue;
            this.Button_add.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.Button_add.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_add.selected = false;
            this.Button_add.Size = new System.Drawing.Size(343, 42);
            this.Button_add.TabIndex = 25;
            this.Button_add.Text = "Add New Patient";
            this.Button_add.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_add.Textcolor = System.Drawing.Color.White;
            this.Button_add.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_add.Click += new System.EventHandler(this.Button_add_Click);
            // 
            // Button_Update
            // 
            this.Button_Update.Activecolor = System.Drawing.Color.SteelBlue;
            this.Button_Update.BackColor = System.Drawing.Color.SteelBlue;
            this.Button_Update.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_Update.BorderRadius = 0;
            this.Button_Update.ButtonText = "Update Patient Details";
            this.Button_Update.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.Button_Update, BunifuAnimatorNS.DecorationType.None);
            this.Button_Update.DisabledColor = System.Drawing.Color.Gray;
            this.Button_Update.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_Update.Iconimage = null;
            this.Button_Update.Iconimage_right = null;
            this.Button_Update.Iconimage_right_Selected = null;
            this.Button_Update.Iconimage_Selected = null;
            this.Button_Update.IconMarginLeft = 0;
            this.Button_Update.IconMarginRight = 0;
            this.Button_Update.IconRightVisible = true;
            this.Button_Update.IconRightZoom = 0D;
            this.Button_Update.IconVisible = true;
            this.Button_Update.IconZoom = 90D;
            this.Button_Update.IsTab = false;
            this.Button_Update.Location = new System.Drawing.Point(0, 121);
            this.Button_Update.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_Update.Name = "Button_Update";
            this.Button_Update.Normalcolor = System.Drawing.Color.SteelBlue;
            this.Button_Update.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.Button_Update.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_Update.selected = false;
            this.Button_Update.Size = new System.Drawing.Size(343, 42);
            this.Button_Update.TabIndex = 26;
            this.Button_Update.Text = "Update Patient Details";
            this.Button_Update.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_Update.Textcolor = System.Drawing.Color.White;
            this.Button_Update.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Update.Click += new System.EventHandler(this.Button_Update_Click);
            // 
            // Button_mangePatientsDetails
            // 
            this.Button_mangePatientsDetails.Activecolor = System.Drawing.Color.Transparent;
            this.Button_mangePatientsDetails.BackColor = System.Drawing.Color.Transparent;
            this.Button_mangePatientsDetails.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_mangePatientsDetails.BorderRadius = 0;
            this.Button_mangePatientsDetails.ButtonText = "          Manage Patients Details";
            this.Button_mangePatientsDetails.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.Button_mangePatientsDetails, BunifuAnimatorNS.DecorationType.None);
            this.Button_mangePatientsDetails.DisabledColor = System.Drawing.Color.Gray;
            this.Button_mangePatientsDetails.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_mangePatientsDetails.Iconimage = ((System.Drawing.Image)(resources.GetObject("Button_mangePatientsDetails.Iconimage")));
            this.Button_mangePatientsDetails.Iconimage_right = null;
            this.Button_mangePatientsDetails.Iconimage_right_Selected = null;
            this.Button_mangePatientsDetails.Iconimage_Selected = null;
            this.Button_mangePatientsDetails.IconMarginLeft = 0;
            this.Button_mangePatientsDetails.IconMarginRight = 0;
            this.Button_mangePatientsDetails.IconRightVisible = true;
            this.Button_mangePatientsDetails.IconRightZoom = 0D;
            this.Button_mangePatientsDetails.IconVisible = true;
            this.Button_mangePatientsDetails.IconZoom = 60D;
            this.Button_mangePatientsDetails.IsTab = false;
            this.Button_mangePatientsDetails.Location = new System.Drawing.Point(2, 1);
            this.Button_mangePatientsDetails.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_mangePatientsDetails.Name = "Button_mangePatientsDetails";
            this.Button_mangePatientsDetails.Normalcolor = System.Drawing.Color.Transparent;
            this.Button_mangePatientsDetails.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.Button_mangePatientsDetails.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_mangePatientsDetails.selected = false;
            this.Button_mangePatientsDetails.Size = new System.Drawing.Size(339, 70);
            this.Button_mangePatientsDetails.TabIndex = 79;
            this.Button_mangePatientsDetails.Text = "          Manage Patients Details";
            this.Button_mangePatientsDetails.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_mangePatientsDetails.Textcolor = System.Drawing.Color.White;
            this.Button_mangePatientsDetails.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_mangePatientsDetails.Click += new System.EventHandler(this.Button_mangePationDetails_Click);
            // 
            // Separator3
            // 
            this.Separator3.BackColor = System.Drawing.Color.Transparent;
            this.menuTransition.SetDecoration(this.Separator3, BunifuAnimatorNS.DecorationType.None);
            this.Separator3.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.Separator3.LineThickness = 2;
            this.Separator3.Location = new System.Drawing.Point(5, 306);
            this.Separator3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Separator3.Name = "Separator3";
            this.Separator3.Size = new System.Drawing.Size(343, 10);
            this.Separator3.TabIndex = 83;
            this.Separator3.Transparency = 255;
            this.Separator3.Vertical = false;
            // 
            // Separator2
            // 
            this.Separator2.BackColor = System.Drawing.Color.Transparent;
            this.menuTransition.SetDecoration(this.Separator2, BunifuAnimatorNS.DecorationType.None);
            this.Separator2.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.Separator2.LineThickness = 2;
            this.Separator2.Location = new System.Drawing.Point(5, 114);
            this.Separator2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Separator2.Name = "Separator2";
            this.Separator2.Size = new System.Drawing.Size(343, 10);
            this.Separator2.TabIndex = 82;
            this.Separator2.Transparency = 255;
            this.Separator2.Vertical = false;
            // 
            // Separator1
            // 
            this.Separator1.BackColor = System.Drawing.Color.Transparent;
            this.menuTransition.SetDecoration(this.Separator1, BunifuAnimatorNS.DecorationType.None);
            this.Separator1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.Separator1.LineThickness = 2;
            this.Separator1.Location = new System.Drawing.Point(5, 210);
            this.Separator1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Separator1.Name = "Separator1";
            this.Separator1.Size = new System.Drawing.Size(343, 10);
            this.Separator1.TabIndex = 81;
            this.Separator1.Transparency = 255;
            this.Separator1.Vertical = false;
            // 
            // Button_Appointments
            // 
            this.Button_Appointments.Activecolor = System.Drawing.Color.Transparent;
            this.Button_Appointments.BackColor = System.Drawing.Color.Transparent;
            this.Button_Appointments.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_Appointments.BorderRadius = 0;
            this.Button_Appointments.ButtonText = "           Appointment Details";
            this.Button_Appointments.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.Button_Appointments, BunifuAnimatorNS.DecorationType.None);
            this.Button_Appointments.DisabledColor = System.Drawing.Color.Gray;
            this.Button_Appointments.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_Appointments.Iconimage = ((System.Drawing.Image)(resources.GetObject("Button_Appointments.Iconimage")));
            this.Button_Appointments.Iconimage_right = null;
            this.Button_Appointments.Iconimage_right_Selected = null;
            this.Button_Appointments.Iconimage_Selected = null;
            this.Button_Appointments.IconMarginLeft = 0;
            this.Button_Appointments.IconMarginRight = 0;
            this.Button_Appointments.IconRightVisible = true;
            this.Button_Appointments.IconRightZoom = 0D;
            this.Button_Appointments.IconVisible = true;
            this.Button_Appointments.IconZoom = 50D;
            this.Button_Appointments.IsTab = false;
            this.Button_Appointments.Location = new System.Drawing.Point(5, 320);
            this.Button_Appointments.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_Appointments.Name = "Button_Appointments";
            this.Button_Appointments.Normalcolor = System.Drawing.Color.Transparent;
            this.Button_Appointments.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.Button_Appointments.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_Appointments.selected = false;
            this.Button_Appointments.Size = new System.Drawing.Size(343, 70);
            this.Button_Appointments.TabIndex = 80;
            this.Button_Appointments.Text = "           Appointment Details";
            this.Button_Appointments.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Button_Appointments.Textcolor = System.Drawing.Color.White;
            this.Button_Appointments.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Appointments.Click += new System.EventHandler(this.Button_Appointments_Click);
            // 
            // Button_showMenu
            // 
            this.Button_showMenu.BackColor = System.Drawing.Color.Transparent;
            this.Button_showMenu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.Button_showMenu, BunifuAnimatorNS.DecorationType.None);
            this.Button_showMenu.Image = ((System.Drawing.Image)(resources.GetObject("Button_showMenu.Image")));
            this.Button_showMenu.ImageActive = null;
            this.Button_showMenu.Location = new System.Drawing.Point(18, 10);
            this.Button_showMenu.Name = "Button_showMenu";
            this.Button_showMenu.Size = new System.Drawing.Size(43, 40);
            this.Button_showMenu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Button_showMenu.TabIndex = 78;
            this.Button_showMenu.TabStop = false;
            this.Button_showMenu.Visible = false;
            this.Button_showMenu.Zoom = 10;
            this.Button_showMenu.Click += new System.EventHandler(this.Button_showMenu_Click);
            // 
            // Button_hideMenu
            // 
            this.Button_hideMenu.BackColor = System.Drawing.Color.Transparent;
            this.Button_hideMenu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.Button_hideMenu, BunifuAnimatorNS.DecorationType.None);
            this.Button_hideMenu.Image = ((System.Drawing.Image)(resources.GetObject("Button_hideMenu.Image")));
            this.Button_hideMenu.ImageActive = null;
            this.Button_hideMenu.Location = new System.Drawing.Point(299, 10);
            this.Button_hideMenu.Name = "Button_hideMenu";
            this.Button_hideMenu.Size = new System.Drawing.Size(43, 40);
            this.Button_hideMenu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Button_hideMenu.TabIndex = 77;
            this.Button_hideMenu.TabStop = false;
            this.Button_hideMenu.Zoom = 10;
            this.Button_hideMenu.Click += new System.EventHandler(this.Button_hideMenu_Click);
            // 
            // Button_home
            // 
            this.Button_home.BackColor = System.Drawing.Color.Transparent;
            this.Button_home.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.Button_home, BunifuAnimatorNS.DecorationType.None);
            this.Button_home.Image = ((System.Drawing.Image)(resources.GetObject("Button_home.Image")));
            this.Button_home.ImageActive = null;
            this.Button_home.Location = new System.Drawing.Point(238, 10);
            this.Button_home.Name = "Button_home";
            this.Button_home.Size = new System.Drawing.Size(43, 40);
            this.Button_home.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Button_home.TabIndex = 24;
            this.Button_home.TabStop = false;
            this.Button_home.Zoom = 10;
            // 
            // Button_UpdateInternal
            // 
            this.Button_UpdateInternal.Activecolor = System.Drawing.Color.Transparent;
            this.Button_UpdateInternal.BackColor = System.Drawing.Color.Transparent;
            this.Button_UpdateInternal.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_UpdateInternal.BorderRadius = 0;
            this.Button_UpdateInternal.ButtonText = "           Update Internal Details";
            this.Button_UpdateInternal.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.Button_UpdateInternal, BunifuAnimatorNS.DecorationType.None);
            this.Button_UpdateInternal.DisabledColor = System.Drawing.Color.Gray;
            this.Button_UpdateInternal.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_UpdateInternal.Iconimage = ((System.Drawing.Image)(resources.GetObject("Button_UpdateInternal.Iconimage")));
            this.Button_UpdateInternal.Iconimage_right = null;
            this.Button_UpdateInternal.Iconimage_right_Selected = null;
            this.Button_UpdateInternal.Iconimage_Selected = null;
            this.Button_UpdateInternal.IconMarginLeft = 0;
            this.Button_UpdateInternal.IconMarginRight = 0;
            this.Button_UpdateInternal.IconRightVisible = true;
            this.Button_UpdateInternal.IconRightZoom = 0D;
            this.Button_UpdateInternal.IconVisible = true;
            this.Button_UpdateInternal.IconZoom = 60D;
            this.Button_UpdateInternal.IsTab = false;
            this.Button_UpdateInternal.Location = new System.Drawing.Point(5, 612);
            this.Button_UpdateInternal.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_UpdateInternal.Name = "Button_UpdateInternal";
            this.Button_UpdateInternal.Normalcolor = System.Drawing.Color.Transparent;
            this.Button_UpdateInternal.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.Button_UpdateInternal.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_UpdateInternal.selected = false;
            this.Button_UpdateInternal.Size = new System.Drawing.Size(343, 70);
            this.Button_UpdateInternal.TabIndex = 95;
            this.Button_UpdateInternal.Text = "           Update Internal Details";
            this.Button_UpdateInternal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Button_UpdateInternal.Textcolor = System.Drawing.Color.White;
            this.Button_UpdateInternal.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_UpdateInternal.Click += new System.EventHandler(this.Button_UpdateInternal_Click);
            // 
            // Button_charts
            // 
            this.Button_charts.Activecolor = System.Drawing.Color.Transparent;
            this.Button_charts.BackColor = System.Drawing.Color.Transparent;
            this.Button_charts.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_charts.BorderRadius = 0;
            this.Button_charts.ButtonText = "           Create Chart/Reports";
            this.Button_charts.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.Button_charts, BunifuAnimatorNS.DecorationType.None);
            this.Button_charts.DisabledColor = System.Drawing.Color.Gray;
            this.Button_charts.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_charts.Iconimage = ((System.Drawing.Image)(resources.GetObject("Button_charts.Iconimage")));
            this.Button_charts.Iconimage_right = null;
            this.Button_charts.Iconimage_right_Selected = null;
            this.Button_charts.Iconimage_Selected = null;
            this.Button_charts.IconMarginLeft = 0;
            this.Button_charts.IconMarginRight = 0;
            this.Button_charts.IconRightVisible = true;
            this.Button_charts.IconRightZoom = 0D;
            this.Button_charts.IconVisible = true;
            this.Button_charts.IconZoom = 50D;
            this.Button_charts.IsTab = false;
            this.Button_charts.Location = new System.Drawing.Point(5, 320);
            this.Button_charts.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_charts.Name = "Button_charts";
            this.Button_charts.Normalcolor = System.Drawing.Color.Transparent;
            this.Button_charts.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.Button_charts.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_charts.selected = false;
            this.Button_charts.Size = new System.Drawing.Size(343, 70);
            this.Button_charts.TabIndex = 96;
            this.Button_charts.Text = "           Create Chart/Reports";
            this.Button_charts.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Button_charts.Textcolor = System.Drawing.Color.White;
            this.Button_charts.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_charts.Click += new System.EventHandler(this.Button_charts_Click);
            // 
            // Button_appointmentHistory
            // 
            this.Button_appointmentHistory.Activecolor = System.Drawing.Color.Transparent;
            this.Button_appointmentHistory.BackColor = System.Drawing.Color.Transparent;
            this.Button_appointmentHistory.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_appointmentHistory.BorderRadius = 0;
            this.Button_appointmentHistory.ButtonText = "           Crate Reports / Charts";
            this.Button_appointmentHistory.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.Button_appointmentHistory, BunifuAnimatorNS.DecorationType.None);
            this.Button_appointmentHistory.DisabledColor = System.Drawing.Color.Gray;
            this.Button_appointmentHistory.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_appointmentHistory.Iconimage = ((System.Drawing.Image)(resources.GetObject("Button_appointmentHistory.Iconimage")));
            this.Button_appointmentHistory.Iconimage_right = null;
            this.Button_appointmentHistory.Iconimage_right_Selected = null;
            this.Button_appointmentHistory.Iconimage_Selected = null;
            this.Button_appointmentHistory.IconMarginLeft = 0;
            this.Button_appointmentHistory.IconMarginRight = 0;
            this.Button_appointmentHistory.IconRightVisible = true;
            this.Button_appointmentHistory.IconRightZoom = 0D;
            this.Button_appointmentHistory.IconVisible = true;
            this.Button_appointmentHistory.IconZoom = 50D;
            this.Button_appointmentHistory.IsTab = false;
            this.Button_appointmentHistory.Location = new System.Drawing.Point(5, 420);
            this.Button_appointmentHistory.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_appointmentHistory.Name = "Button_appointmentHistory";
            this.Button_appointmentHistory.Normalcolor = System.Drawing.Color.Transparent;
            this.Button_appointmentHistory.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.Button_appointmentHistory.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_appointmentHistory.selected = false;
            this.Button_appointmentHistory.Size = new System.Drawing.Size(343, 70);
            this.Button_appointmentHistory.TabIndex = 97;
            this.Button_appointmentHistory.Text = "           Crate Reports / Charts";
            this.Button_appointmentHistory.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Button_appointmentHistory.Textcolor = System.Drawing.Color.White;
            this.Button_appointmentHistory.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_appointmentHistory.Click += new System.EventHandler(this.Button_appointmentHistory_Click);
            // 
            // menuTransition
            // 
            this.menuTransition.AnimationType = BunifuAnimatorNS.AnimationType.VertSlide;
            this.menuTransition.Cursor = null;
            animation1.AnimateOnlyDifferences = true;
            animation1.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.BlindCoeff")));
            animation1.LeafCoeff = 0F;
            animation1.MaxTime = 1F;
            animation1.MinTime = 0F;
            animation1.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.MosaicCoeff")));
            animation1.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation1.MosaicShift")));
            animation1.MosaicSize = 0;
            animation1.Padding = new System.Windows.Forms.Padding(0);
            animation1.RotateCoeff = 0F;
            animation1.RotateLimit = 0F;
            animation1.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.ScaleCoeff")));
            animation1.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.SlideCoeff")));
            animation1.TimeCoeff = 0F;
            animation1.TransparencyCoeff = 0F;
            this.menuTransition.DefaultAnimation = animation1;
            // 
            // frontControl1
            // 
            this.menuTransition.SetDecoration(this.frontControl1, BunifuAnimatorNS.DecorationType.None);
            this.frontControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.frontControl1.Location = new System.Drawing.Point(354, 54);
            this.frontControl1.Name = "frontControl1";
            this.frontControl1.Size = new System.Drawing.Size(1140, 812);
            this.frontControl1.TabIndex = 2;
            // 
            // addPatientControl1
            // 
            this.menuTransition.SetDecoration(this.addPatientControl1, BunifuAnimatorNS.DecorationType.None);
            this.addPatientControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addPatientControl1.Location = new System.Drawing.Point(0, 0);
            this.addPatientControl1.Name = "addPatientControl1";
            this.addPatientControl1.Size = new System.Drawing.Size(1494, 866);
            this.addPatientControl1.TabIndex = 3;
            // 
            // updatePatientControl1
            // 
            this.menuTransition.SetDecoration(this.updatePatientControl1, BunifuAnimatorNS.DecorationType.None);
            this.updatePatientControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.updatePatientControl1.Location = new System.Drawing.Point(0, 0);
            this.updatePatientControl1.Name = "updatePatientControl1";
            this.updatePatientControl1.Size = new System.Drawing.Size(1494, 866);
            this.updatePatientControl1.TabIndex = 4;
            // 
            // appointmentControl1
            // 
            this.menuTransition.SetDecoration(this.appointmentControl1, BunifuAnimatorNS.DecorationType.None);
            this.appointmentControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.appointmentControl1.Location = new System.Drawing.Point(0, 0);
            this.appointmentControl1.Name = "appointmentControl1";
            this.appointmentControl1.Size = new System.Drawing.Size(1494, 866);
            this.appointmentControl1.TabIndex = 5;
            // 
            // addDoctorsControl1
            // 
            this.menuTransition.SetDecoration(this.addDoctorsControl1, BunifuAnimatorNS.DecorationType.None);
            this.addDoctorsControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addDoctorsControl1.Location = new System.Drawing.Point(0, 0);
            this.addDoctorsControl1.Name = "addDoctorsControl1";
            this.addDoctorsControl1.Size = new System.Drawing.Size(1494, 866);
            this.addDoctorsControl1.TabIndex = 6;
            // 
            // updateDoctorsControl1
            // 
            this.menuTransition.SetDecoration(this.updateDoctorsControl1, BunifuAnimatorNS.DecorationType.None);
            this.updateDoctorsControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.updateDoctorsControl1.Location = new System.Drawing.Point(0, 0);
            this.updateDoctorsControl1.Name = "updateDoctorsControl1";
            this.updateDoctorsControl1.Size = new System.Drawing.Size(1494, 866);
            this.updateDoctorsControl1.TabIndex = 7;
            // 
            // paymentControl1
            // 
            this.menuTransition.SetDecoration(this.paymentControl1, BunifuAnimatorNS.DecorationType.None);
            this.paymentControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.paymentControl1.Location = new System.Drawing.Point(0, 0);
            this.paymentControl1.Name = "paymentControl1";
            this.paymentControl1.Size = new System.Drawing.Size(1494, 866);
            this.paymentControl1.TabIndex = 8;
            // 
            // caculateAmountControl1
            // 
            this.menuTransition.SetDecoration(this.caculateAmountControl1, BunifuAnimatorNS.DecorationType.None);
            this.caculateAmountControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.caculateAmountControl1.Location = new System.Drawing.Point(0, 0);
            this.caculateAmountControl1.Name = "caculateAmountControl1";
            this.caculateAmountControl1.Size = new System.Drawing.Size(1494, 866);
            this.caculateAmountControl1.TabIndex = 9;
            // 
            // patientHistoryManagementControl1
            // 
            this.menuTransition.SetDecoration(this.patientHistoryManagementControl1, BunifuAnimatorNS.DecorationType.None);
            this.patientHistoryManagementControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.patientHistoryManagementControl1.Location = new System.Drawing.Point(0, 0);
            this.patientHistoryManagementControl1.Name = "patientHistoryManagementControl1";
            this.patientHistoryManagementControl1.Size = new System.Drawing.Size(1494, 866);
            this.patientHistoryManagementControl1.TabIndex = 10;
            // 
            // viewDiagnosisDetailsControl1
            // 
            this.menuTransition.SetDecoration(this.viewDiagnosisDetailsControl1, BunifuAnimatorNS.DecorationType.None);
            this.viewDiagnosisDetailsControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.viewDiagnosisDetailsControl1.Location = new System.Drawing.Point(0, 0);
            this.viewDiagnosisDetailsControl1.Name = "viewDiagnosisDetailsControl1";
            this.viewDiagnosisDetailsControl1.Size = new System.Drawing.Size(1494, 866);
            this.viewDiagnosisDetailsControl1.TabIndex = 11;
            // 
            // calculateBillControl1
            // 
            this.menuTransition.SetDecoration(this.calculateBillControl1, BunifuAnimatorNS.DecorationType.None);
            this.calculateBillControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.calculateBillControl1.Location = new System.Drawing.Point(0, 0);
            this.calculateBillControl1.Name = "calculateBillControl1";
            this.calculateBillControl1.Size = new System.Drawing.Size(1494, 866);
            this.calculateBillControl1.TabIndex = 12;
            // 
            // internalPatientsControl1
            // 
            this.menuTransition.SetDecoration(this.internalPatientsControl1, BunifuAnimatorNS.DecorationType.None);
            this.internalPatientsControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.internalPatientsControl1.Location = new System.Drawing.Point(0, 0);
            this.internalPatientsControl1.Name = "internalPatientsControl1";
            this.internalPatientsControl1.Size = new System.Drawing.Size(1494, 866);
            this.internalPatientsControl1.TabIndex = 13;
            // 
            // updateInternalPatientsControl1
            // 
            this.menuTransition.SetDecoration(this.updateInternalPatientsControl1, BunifuAnimatorNS.DecorationType.None);
            this.updateInternalPatientsControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.updateInternalPatientsControl1.Location = new System.Drawing.Point(0, 0);
            this.updateInternalPatientsControl1.Name = "updateInternalPatientsControl1";
            this.updateInternalPatientsControl1.Size = new System.Drawing.Size(1494, 866);
            this.updateInternalPatientsControl1.TabIndex = 14;
            // 
            // chartsControl1
            // 
            this.menuTransition.SetDecoration(this.chartsControl1, BunifuAnimatorNS.DecorationType.None);
            this.chartsControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chartsControl1.Location = new System.Drawing.Point(0, 0);
            this.chartsControl1.Name = "chartsControl1";
            this.chartsControl1.Size = new System.Drawing.Size(1494, 866);
            this.chartsControl1.TabIndex = 15;
            // 
            // appointmentHistoryControl1
            // 
            this.menuTransition.SetDecoration(this.appointmentHistoryControl1, BunifuAnimatorNS.DecorationType.None);
            this.appointmentHistoryControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.appointmentHistoryControl1.Location = new System.Drawing.Point(0, 0);
            this.appointmentHistoryControl1.Name = "appointmentHistoryControl1";
            this.appointmentHistoryControl1.Size = new System.Drawing.Size(1494, 866);
            this.appointmentHistoryControl1.TabIndex = 16;
            // 
            // timer_time
            // 
            this.timer_time.Tick += new System.EventHandler(this.Timer_time_Tick);
            // 
            // timer1
            // 
            this.timer1.Interval = 1;
            this.timer1.Tick += new System.EventHandler(this.Timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Interval = 1;
            this.timer2.Tick += new System.EventHandler(this.Timer2_Tick);
            // 
            // dragControl1
            // 
            this.dragControl1.SelectControl = this.panel_left;
            // 
            // Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1494, 866);
            this.Controls.Add(this.frontControl1);
            this.Controls.Add(this.panel_left);
            this.Controls.Add(this.panel_top);
            this.Controls.Add(this.addPatientControl1);
            this.Controls.Add(this.updatePatientControl1);
            this.Controls.Add(this.appointmentControl1);
            this.Controls.Add(this.addDoctorsControl1);
            this.Controls.Add(this.updateDoctorsControl1);
            this.Controls.Add(this.paymentControl1);
            this.Controls.Add(this.caculateAmountControl1);
            this.Controls.Add(this.patientHistoryManagementControl1);
            this.Controls.Add(this.viewDiagnosisDetailsControl1);
            this.Controls.Add(this.calculateBillControl1);
            this.Controls.Add(this.internalPatientsControl1);
            this.Controls.Add(this.updateInternalPatientsControl1);
            this.Controls.Add(this.chartsControl1);
            this.Controls.Add(this.appointmentHistoryControl1);
            this.menuTransition.SetDecoration(this, BunifuAnimatorNS.DecorationType.None);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Dashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dashboard";
            this.Load += new System.EventHandler(this.Dashboard_Load);
            this.panel_top.ResumeLayout(false);
            this.panel_top.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_online)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Button_maximize)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_minimize)).EndInit();
            this.panel_left.ResumeLayout(false);
            this.panel_doctors.ResumeLayout(false);
            this.panel_Patients.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Button_showMenu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Button_hideMenu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Button_home)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private Project_SDC.DragControl dragControl1;
        private System.Windows.Forms.Panel panel_left;
        private System.Windows.Forms.Panel panel_top;
        private Bunifu.Framework.UI.BunifuImageButton Button_maximize;
        private Bunifu.Framework.UI.BunifuImageButton btn_close;
        private Bunifu.Framework.UI.BunifuImageButton btn_minimize;
        private Bunifu.Framework.UI.BunifuFlatButton Button_mangePatientsDetails;
        public Bunifu.Framework.UI.BunifuImageButton Button_showMenu;
        public Bunifu.Framework.UI.BunifuImageButton Button_hideMenu;
        private Bunifu.Framework.UI.BunifuImageButton Button_home;
        private BunifuAnimatorNS.BunifuTransition menuTransition;
        private Bunifu.Framework.UI.BunifuThinButton2 bunifuThinButton21;
        private System.Windows.Forms.Label label_time;
        private System.Windows.Forms.Label label_Date;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_timeTitle;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_dateTitle;
        private System.Windows.Forms.Timer timer_time;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton1;
        private System.Windows.Forms.PictureBox pictureBox_online;
        private Bunifu.Framework.UI.BunifuSeparator Separator2;
        private FrontControl frontControl1;
        public Bunifu.Framework.UI.BunifuFlatButton Button_add;
        public Bunifu.Framework.UI.BunifuFlatButton Button_Update;
        private System.Windows.Forms.Timer timer1;
        private addPatientControl addPatientControl1;
        private UpdatePatientControl updatePatientControl1;
        private appointmentControl appointmentControl1;
        public Bunifu.Framework.UI.BunifuCustomLabel Label_User;
        public Bunifu.Framework.UI.BunifuFlatButton btn_addDoctor;
        public Bunifu.Framework.UI.BunifuFlatButton btn_updateDoctors;
        private Bunifu.Framework.UI.BunifuFlatButton Button_ManageDoctorsDetails;
        private System.Windows.Forms.Timer timer2;
        private addDoctorsControl addDoctorsControl1;
        private UpdateDoctorsControl updateDoctorsControl1;
        private PaymentControl paymentControl1;
        private caculateAmountControl caculateAmountControl1;
        private patientHistoryManagementControl patientHistoryManagementControl1;
        private viewDiagnosisDetailsControl viewDiagnosisDetailsControl1;
        public Bunifu.Framework.UI.BunifuFlatButton Button_Appointments;
        public Bunifu.Framework.UI.BunifuSeparator Separator1;
        public Bunifu.Framework.UI.BunifuSeparator Separator3;
        public System.Windows.Forms.Panel panel_Patients;
        public System.Windows.Forms.Panel panel_doctors;
        public Bunifu.Framework.UI.BunifuSeparator Separator_app;
        public Bunifu.Framework.UI.BunifuSeparator Separator_pay;
        public Bunifu.Framework.UI.BunifuFlatButton Button_Payments;
        public Bunifu.Framework.UI.BunifuSeparator Separator_amo;
        public Bunifu.Framework.UI.BunifuFlatButton Button_amount;
        public Bunifu.Framework.UI.BunifuSeparator Separator_MH;
        public Bunifu.Framework.UI.BunifuFlatButton Button_calculateBill;
        public Bunifu.Framework.UI.BunifuSeparator Separator_IPH;
        public Bunifu.Framework.UI.BunifuFlatButton Button_addDiagnosisDetails;
        public Bunifu.Framework.UI.BunifuFlatButton Button_internalPatient;
        private calculateBillControl calculateBillControl1;
        private internalPatientsControl internalPatientsControl1;
        public Bunifu.Framework.UI.BunifuFlatButton Button_UpdateInternal;
        private UpdateInternalPatientsControl updateInternalPatientsControl1;
        public Bunifu.Framework.UI.BunifuFlatButton Button_charts;
        private chartsControl chartsControl1;
        public Bunifu.Framework.UI.BunifuFlatButton Button_appointmentHistory;
        private appointmentHistoryControl appointmentHistoryControl1;
    }
}