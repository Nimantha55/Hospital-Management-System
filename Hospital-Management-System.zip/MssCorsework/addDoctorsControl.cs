﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MssCorsework
{
    public partial class addDoctorsControl : UserControl
    {
        public bool isCollapsed;

        public addDoctorsControl()
        {
            InitializeComponent();
        }

        SQLQueries sqlq = new SQLQueries();

        private void Timer1_Tick(object sender, EventArgs e)
        {
            if (isCollapsed)
            {
                panel_Types.Height += 10;
                if (panel_Types.Size == panel_Types.MaximumSize)
                {
                    timer1.Stop();
                    isCollapsed = false;
                }
            }
            else
            {
                panel_Types.Height -= 10;
                if (panel_Types.Size == panel_Types.MinimumSize)
                {
                    timer1.Stop();
                    isCollapsed = true;
                }
            }
        }

        private void Btn_Cardiologist_Click(object sender, EventArgs e)
        {
            Button_Type.Text = "Cardiologist";
            if (label_dEType.Visible == true)
            {
                label_dEType.Visible = false;
                label_Errors.Visible = false;
            }
        }

        private void Btn_Family_Click(object sender, EventArgs e)
        {
            Button_Type.Text = "Family Physician";
            if (label_dEType.Visible == true)
            {
                label_dEType.Visible = false;
                label_Errors.Visible = false;
            }
        }

        private void Btn_Ophthalmologist_Click(object sender, EventArgs e)
        {
            Button_Type.Text = "Ophthalmologist";
            if (label_dEType.Visible == true)
            {
                label_dEType.Visible = false;
                label_Errors.Visible = false;
            }
        }

        private void Btn_Surgeon_Click(object sender, EventArgs e)
        {
            Button_Type.Text = "Surgeon";
            if (label_dEType.Visible == true)
            {
                label_dEType.Visible = false;
                label_Errors.Visible = false;
            }
        }

        private void clear()
        {
            Textbox_dName.Text = "";
            Textbox_NIC.Text = "";           
            Textbox_Address.Text = "";
            Textbox_Experience.Text = "";
            Textbox_TelephoneNum.Text = "";
            Button_Type.Text = "Doctor's Type";
        }

        private void Button_Type_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void Button_ADD_Click(object sender, EventArgs e)
        {
            if (Textbox_dName.Text == "" && Textbox_NIC.Text == "" && Textbox_Address.Text == "" && Textbox_Experience.Text == "" && Textbox_TelephoneNum.Text == "" && Button_Type.Text == "Doctor's Type")
            {
                label_Errors.Visible = true;
                label_Errors.Text = "Please Enter All Details!";
            }
            else if (Textbox_dName.Text == "")
            {
                label_dEName.Visible = true;
                label_dEName.Text = "Doctor's Name is Required!";
            }
            else if (Textbox_NIC.Text == "")
            {
                label_dENIC.Visible = true;
                label_dENIC.Text = "Doctor's NIC is Required!";
            }
            else if (Textbox_Address.Text == "")
            {
                label_dEAddress.Visible = true;
                label_dEAddress.Text = "Doctor's Address is Required!";
            }
            else if (Textbox_Experience.Text == "")
            {
                label_dEExperience.Visible = true;
                label_dEExperience.Text = "Years of Experience is Required!";
            }
            else if (Textbox_TelephoneNum.Text == "")
            {
                label_dETelephoneNum.Visible = true;
                label_dETelephoneNum.Text = "Doctor's Telephone Number is Required!";
            }
            else if (Button_Type.Text == "Doctor's Type")
            {
                label_dEType.Visible = true;
                label_dEType.Text = "Doctor's Type is Required!";
            }
            else
            {
                try
                {
                    string dname = Textbox_dName.Text;
                    string dNIC = Textbox_NIC.Text;
                    string daddress = Textbox_Address.Text;
                    int dExp = int.Parse(Textbox_Experience.Text);
                    string dTelNO = Textbox_TelephoneNum.Text;
                    string pType = Button_Type.Text;

                    //pass values for insertDoctorsDetails query which include in SQLQueries class
                    sqlq.insertDoctorsDetails(dname, dNIC, daddress, dExp, dTelNO, pType);
                    Message1 pr = new Message1();
                    pr.label1.Text = "Doctor's Details Added Successfully!";
                    pr.label1.Location = new System.Drawing.Point(41, 200);
                    pr.Show();
                    this.clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Please Check The Values" + ex, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void Textbox_dName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_dName.Text != "")
            {
                label_dEName.Visible = false;
                label_Errors.Visible = false;
            }

            //allow only characters values for textbox
            if (!char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar) && !char.IsWhiteSpace(e.KeyChar) && e.KeyChar != '.')
            {
                e.Handled = true;
            }
        }

        private void Textbox_NIC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_NIC.Text != "")
            {
                label_dENIC.Visible = false;
                label_Errors.Visible = false;
            }
        }

        private void Textbox_Address_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_Address.Text != "")
            {
                label_dEAddress.Visible = false;
                label_Errors.Visible = false;
            }
        }

        private void Textbox_Experience_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_Experience.Text != "")
            {
                label_dEExperience.Visible = false;
                label_Errors.Visible = false;
            }

            //allow only numaric values for contact number
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 32)
            {
                e.Handled = true;
            }
        }

        private void Textbox_TelephoneNum_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_TelephoneNum.Text != "")
            {
                label_dETelephoneNum.Visible = false;
                label_Errors.Visible = false;
            }

            //allow only numaric values for contact number
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 32 && e.KeyChar != '+')
            {
                e.Handled = true;
            }
        }

        private void Button_Clear_Click(object sender, EventArgs e)
        {
            this.clear();
        }
    }
}
