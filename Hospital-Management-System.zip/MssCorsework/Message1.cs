﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MssCorsework
{
    public partial class Message1 : Form
    {
        public Message1()
        {
            InitializeComponent();
        }

        private void Message1_Load(object sender, EventArgs e)
        {
            Transition1.ShowAsyc(this);
        }

        private void Transition1_TransitionEnd(object sender, EventArgs e)
        {
            timer1.Start();
            pictureBox1.Enabled = true;
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            pictureBox1.Enabled = false;
            timer1.Stop();
            label1.Visible = true;
            btn_ok.Visible = true;
        }

        private void Btn_ok_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
