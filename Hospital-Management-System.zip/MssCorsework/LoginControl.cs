﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MssCorsework
{
    public partial class LoginControl : UserControl
    {

        public LoginControl()
        {
            InitializeComponent();
        }

        SQLQueries sqlq = new SQLQueries();
        AccountControl ac = new AccountControl();

        private void Button_login_Click(object sender, EventArgs e)
        {
            string username = textBox_username.Text;
            string password = textBox_password.Text;

            if (textBox_username.Text == "")
            {
                Label_error.Visible = true;
                Label_error.Text = "Username is Required!";
            }
            else if (textBox_password.Text == "")
            {
                Label_error.Visible = true;
                Label_error.Text = "Password is Required!";
            }
            else if (textBox_username.Text == "" && textBox_password.Text == "")
            {
                Label_error.Visible = true;
                Label_error.Text = "Please Fill All Details!";
            }
            else
            {
                SqlDataReader dr = sqlq.userLogins(username, password);
                if (dr.Read())
                {
                    Label_accountSelect.Text = dr[1].ToString();
                    lab_UN.Text = dr[2].ToString();
                    ac.username = lab_UN.Text;

                    if (Label_accountSelect.Text == "               Administrator")
                    {
                        ac.Admin();
                        this.ParentForm.Hide();
                    }
                    else if (Label_accountSelect.Text == "               Front Office Clerk")
                    {
                        ac.Clerk();
                        this.ParentForm.Hide();
                    }
                    else if (Label_accountSelect.Text == "               Doctors")
                    {
                        ac.Doctor();
                        this.ParentForm.Hide();
                    }
                    else if (Label_accountSelect.Text == "               Lab Technician")
                    {
                        ac.Technician();
                        this.ParentForm.Hide();
                    }
                    else if (Label_accountSelect.Text == "               Pharmacist")
                    {
                        ac.Pharmacist();
                        this.ParentForm.Hide();
                    }
                    else if (Label_accountSelect.Text == "               Assistant")
                    {
                        ac.Assistant();
                        this.ParentForm.Hide();
                    }
                }
                else
                {
                    Message2 er = new Message2();
                    er.Show();
                    er.label1.Text = "Invalid Username Or Password!";
                    er.label1.Location = new System.Drawing.Point(70, 200);
                }
            }
        }

        private void TextBox_username_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (textBox_username.Text != "")
            {
                Label_error.Visible = false;
            }
        }

        private void TextBox_password_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (textBox_password.Text != "")
            {
                Label_error.Visible = false;
            }
        }
    }
}
