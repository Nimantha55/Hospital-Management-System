﻿namespace MssCorsework
{
    partial class RegistrationControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RegistrationControl));
            this.panel_log = new System.Windows.Forms.Panel();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Separator_confirmPassword = new Bunifu.Framework.UI.BunifuSeparator();
            this.textBox_confirmPassword = new System.Windows.Forms.TextBox();
            this.pictureBox_confirmPassword = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Label_error = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_accountSelect = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.panel_account = new System.Windows.Forms.Panel();
            this.Button_Assistant = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Button_Pharmacist = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Button_doctors = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Button_accountSelect = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Button_LabTechnician = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Button_admin = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Button_clerk = new Bunifu.Framework.UI.BunifuFlatButton();
            this.bunifuSeparator2 = new Bunifu.Framework.UI.BunifuSeparator();
            this.pictureBox_accountSelect = new System.Windows.Forms.PictureBox();
            this.Label_password = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_username = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuSeparator1 = new Bunifu.Framework.UI.BunifuSeparator();
            this.textBox_username = new System.Windows.Forms.TextBox();
            this.bunifuSeparator_password = new Bunifu.Framework.UI.BunifuSeparator();
            this.textBox_password = new System.Windows.Forms.TextBox();
            this.Button_Register = new Bunifu.Framework.UI.BunifuFlatButton();
            this.pictureBox_password = new System.Windows.Forms.PictureBox();
            this.pictureBox_username = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.bunifuGradientPanel1 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_title = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lab_UN = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_account = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.panel_log.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_confirmPassword)).BeginInit();
            this.panel_account.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_accountSelect)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_password)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_username)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.bunifuGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_log
            // 
            this.panel_log.Controls.Add(this.lab_UN);
            this.panel_log.Controls.Add(this.Label_account);
            this.panel_log.Controls.Add(this.bunifuCustomLabel2);
            this.panel_log.Controls.Add(this.Separator_confirmPassword);
            this.panel_log.Controls.Add(this.textBox_confirmPassword);
            this.panel_log.Controls.Add(this.pictureBox_confirmPassword);
            this.panel_log.Controls.Add(this.panel1);
            this.panel_log.Controls.Add(this.Label_error);
            this.panel_log.Controls.Add(this.Label_accountSelect);
            this.panel_log.Controls.Add(this.panel_account);
            this.panel_log.Controls.Add(this.bunifuSeparator2);
            this.panel_log.Controls.Add(this.pictureBox_accountSelect);
            this.panel_log.Controls.Add(this.Label_password);
            this.panel_log.Controls.Add(this.Label_username);
            this.panel_log.Controls.Add(this.bunifuSeparator1);
            this.panel_log.Controls.Add(this.textBox_username);
            this.panel_log.Controls.Add(this.bunifuSeparator_password);
            this.panel_log.Controls.Add(this.textBox_password);
            this.panel_log.Controls.Add(this.Button_Register);
            this.panel_log.Controls.Add(this.pictureBox_password);
            this.panel_log.Controls.Add(this.pictureBox_username);
            this.panel_log.Controls.Add(this.pictureBox2);
            this.panel_log.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_log.Location = new System.Drawing.Point(0, 0);
            this.panel_log.Name = "panel_log";
            this.panel_log.Size = new System.Drawing.Size(784, 660);
            this.panel_log.TabIndex = 1;
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel2.ForeColor = System.Drawing.Color.Blue;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(92, 428);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(171, 22);
            this.bunifuCustomLabel2.TabIndex = 72;
            this.bunifuCustomLabel2.Text = "Confirm Password";
            // 
            // Separator_confirmPassword
            // 
            this.Separator_confirmPassword.BackColor = System.Drawing.Color.Transparent;
            this.Separator_confirmPassword.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(105)))), ((int)(((byte)(225)))));
            this.Separator_confirmPassword.LineThickness = 3;
            this.Separator_confirmPassword.Location = new System.Drawing.Point(159, 500);
            this.Separator_confirmPassword.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Separator_confirmPassword.Name = "Separator_confirmPassword";
            this.Separator_confirmPassword.Size = new System.Drawing.Size(530, 10);
            this.Separator_confirmPassword.TabIndex = 71;
            this.Separator_confirmPassword.Transparency = 255;
            this.Separator_confirmPassword.Vertical = false;
            // 
            // textBox_confirmPassword
            // 
            this.textBox_confirmPassword.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.textBox_confirmPassword.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_confirmPassword.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_confirmPassword.ForeColor = System.Drawing.Color.White;
            this.textBox_confirmPassword.Location = new System.Drawing.Point(159, 468);
            this.textBox_confirmPassword.Name = "textBox_confirmPassword";
            this.textBox_confirmPassword.PasswordChar = '*';
            this.textBox_confirmPassword.Size = new System.Drawing.Size(530, 30);
            this.textBox_confirmPassword.TabIndex = 70;
            this.textBox_confirmPassword.UseSystemPasswordChar = true;
            this.textBox_confirmPassword.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBox_confirmPassword_KeyPress);
            // 
            // pictureBox_confirmPassword
            // 
            this.pictureBox_confirmPassword.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_confirmPassword.Image")));
            this.pictureBox_confirmPassword.Location = new System.Drawing.Point(96, 462);
            this.pictureBox_confirmPassword.Name = "pictureBox_confirmPassword";
            this.pictureBox_confirmPassword.Size = new System.Drawing.Size(51, 46);
            this.pictureBox_confirmPassword.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_confirmPassword.TabIndex = 69;
            this.pictureBox_confirmPassword.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(137)))), ((int)(((byte)(218)))));
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(784, 10);
            this.panel1.TabIndex = 68;
            // 
            // Label_error
            // 
            this.Label_error.AutoSize = true;
            this.Label_error.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_error.ForeColor = System.Drawing.Color.Red;
            this.Label_error.Location = new System.Drawing.Point(92, 525);
            this.Label_error.Name = "Label_error";
            this.Label_error.Size = new System.Drawing.Size(186, 22);
            this.Label_error.TabIndex = 67;
            this.Label_error.Text = "Please Fill All Details!";
            this.Label_error.Visible = false;
            // 
            // Label_accountSelect
            // 
            this.Label_accountSelect.AutoSize = true;
            this.Label_accountSelect.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_accountSelect.ForeColor = System.Drawing.Color.Blue;
            this.Label_accountSelect.Location = new System.Drawing.Point(92, 118);
            this.Label_accountSelect.Name = "Label_accountSelect";
            this.Label_accountSelect.Size = new System.Drawing.Size(141, 22);
            this.Label_accountSelect.TabIndex = 66;
            this.Label_accountSelect.Text = "Account Type";
            // 
            // panel_account
            // 
            this.panel_account.BackColor = System.Drawing.Color.Transparent;
            this.panel_account.Controls.Add(this.Button_Assistant);
            this.panel_account.Controls.Add(this.Button_Pharmacist);
            this.panel_account.Controls.Add(this.Button_doctors);
            this.panel_account.Controls.Add(this.Button_accountSelect);
            this.panel_account.Controls.Add(this.Button_LabTechnician);
            this.panel_account.Controls.Add(this.Button_admin);
            this.panel_account.Controls.Add(this.Button_clerk);
            this.panel_account.Location = new System.Drawing.Point(159, 154);
            this.panel_account.MaximumSize = new System.Drawing.Size(530, 317);
            this.panel_account.MinimumSize = new System.Drawing.Size(530, 45);
            this.panel_account.Name = "panel_account";
            this.panel_account.Size = new System.Drawing.Size(530, 45);
            this.panel_account.TabIndex = 65;
            // 
            // Button_Assistant
            // 
            this.Button_Assistant.Activecolor = System.Drawing.Color.SteelBlue;
            this.Button_Assistant.BackColor = System.Drawing.Color.SteelBlue;
            this.Button_Assistant.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_Assistant.BorderRadius = 0;
            this.Button_Assistant.ButtonText = "Doctor\'s Assistant";
            this.Button_Assistant.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_Assistant.DisabledColor = System.Drawing.Color.Transparent;
            this.Button_Assistant.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_Assistant.Iconimage = null;
            this.Button_Assistant.Iconimage_right = null;
            this.Button_Assistant.Iconimage_right_Selected = null;
            this.Button_Assistant.Iconimage_Selected = null;
            this.Button_Assistant.IconMarginLeft = 0;
            this.Button_Assistant.IconMarginRight = 0;
            this.Button_Assistant.IconRightVisible = true;
            this.Button_Assistant.IconRightZoom = 0D;
            this.Button_Assistant.IconVisible = true;
            this.Button_Assistant.IconZoom = 90D;
            this.Button_Assistant.IsTab = false;
            this.Button_Assistant.Location = new System.Drawing.Point(0, 273);
            this.Button_Assistant.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_Assistant.Name = "Button_Assistant";
            this.Button_Assistant.Normalcolor = System.Drawing.Color.SteelBlue;
            this.Button_Assistant.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.Button_Assistant.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_Assistant.selected = false;
            this.Button_Assistant.Size = new System.Drawing.Size(530, 44);
            this.Button_Assistant.TabIndex = 30;
            this.Button_Assistant.Text = "Doctor\'s Assistant";
            this.Button_Assistant.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_Assistant.Textcolor = System.Drawing.Color.White;
            this.Button_Assistant.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Assistant.Click += new System.EventHandler(this.Button_Assistant_Click);
            // 
            // Button_Pharmacist
            // 
            this.Button_Pharmacist.Activecolor = System.Drawing.Color.SteelBlue;
            this.Button_Pharmacist.BackColor = System.Drawing.Color.SteelBlue;
            this.Button_Pharmacist.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_Pharmacist.BorderRadius = 0;
            this.Button_Pharmacist.ButtonText = "Pharmacist";
            this.Button_Pharmacist.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_Pharmacist.DisabledColor = System.Drawing.Color.Transparent;
            this.Button_Pharmacist.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_Pharmacist.Iconimage = null;
            this.Button_Pharmacist.Iconimage_right = null;
            this.Button_Pharmacist.Iconimage_right_Selected = null;
            this.Button_Pharmacist.Iconimage_Selected = null;
            this.Button_Pharmacist.IconMarginLeft = 0;
            this.Button_Pharmacist.IconMarginRight = 0;
            this.Button_Pharmacist.IconRightVisible = true;
            this.Button_Pharmacist.IconRightZoom = 0D;
            this.Button_Pharmacist.IconVisible = true;
            this.Button_Pharmacist.IconZoom = 90D;
            this.Button_Pharmacist.IsTab = false;
            this.Button_Pharmacist.Location = new System.Drawing.Point(0, 227);
            this.Button_Pharmacist.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_Pharmacist.Name = "Button_Pharmacist";
            this.Button_Pharmacist.Normalcolor = System.Drawing.Color.SteelBlue;
            this.Button_Pharmacist.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.Button_Pharmacist.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_Pharmacist.selected = false;
            this.Button_Pharmacist.Size = new System.Drawing.Size(530, 44);
            this.Button_Pharmacist.TabIndex = 29;
            this.Button_Pharmacist.Text = "Pharmacist";
            this.Button_Pharmacist.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_Pharmacist.Textcolor = System.Drawing.Color.White;
            this.Button_Pharmacist.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Pharmacist.Click += new System.EventHandler(this.Button_Pharmacist_Click);
            // 
            // Button_doctors
            // 
            this.Button_doctors.Activecolor = System.Drawing.Color.SteelBlue;
            this.Button_doctors.BackColor = System.Drawing.Color.SteelBlue;
            this.Button_doctors.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_doctors.BorderRadius = 0;
            this.Button_doctors.ButtonText = "Doctors";
            this.Button_doctors.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_doctors.DisabledColor = System.Drawing.Color.Transparent;
            this.Button_doctors.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_doctors.Iconimage = null;
            this.Button_doctors.Iconimage_right = null;
            this.Button_doctors.Iconimage_right_Selected = null;
            this.Button_doctors.Iconimage_Selected = null;
            this.Button_doctors.IconMarginLeft = 0;
            this.Button_doctors.IconMarginRight = 0;
            this.Button_doctors.IconRightVisible = true;
            this.Button_doctors.IconRightZoom = 0D;
            this.Button_doctors.IconVisible = true;
            this.Button_doctors.IconZoom = 90D;
            this.Button_doctors.IsTab = false;
            this.Button_doctors.Location = new System.Drawing.Point(0, 180);
            this.Button_doctors.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_doctors.Name = "Button_doctors";
            this.Button_doctors.Normalcolor = System.Drawing.Color.SteelBlue;
            this.Button_doctors.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.Button_doctors.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_doctors.selected = false;
            this.Button_doctors.Size = new System.Drawing.Size(530, 44);
            this.Button_doctors.TabIndex = 28;
            this.Button_doctors.Text = "Doctors";
            this.Button_doctors.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_doctors.Textcolor = System.Drawing.Color.White;
            this.Button_doctors.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_doctors.Click += new System.EventHandler(this.Button_doctors_Click);
            // 
            // Button_accountSelect
            // 
            this.Button_accountSelect.Activecolor = System.Drawing.Color.Transparent;
            this.Button_accountSelect.BackColor = System.Drawing.Color.Transparent;
            this.Button_accountSelect.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_accountSelect.BorderRadius = 0;
            this.Button_accountSelect.ButtonText = "               Select Account Type";
            this.Button_accountSelect.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_accountSelect.DisabledColor = System.Drawing.Color.Gray;
            this.Button_accountSelect.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_accountSelect.Iconimage = ((System.Drawing.Image)(resources.GetObject("Button_accountSelect.Iconimage")));
            this.Button_accountSelect.Iconimage_right = null;
            this.Button_accountSelect.Iconimage_right_Selected = null;
            this.Button_accountSelect.Iconimage_Selected = null;
            this.Button_accountSelect.IconMarginLeft = 0;
            this.Button_accountSelect.IconMarginRight = 0;
            this.Button_accountSelect.IconRightVisible = true;
            this.Button_accountSelect.IconRightZoom = 0D;
            this.Button_accountSelect.IconVisible = true;
            this.Button_accountSelect.IconZoom = 50D;
            this.Button_accountSelect.IsTab = false;
            this.Button_accountSelect.Location = new System.Drawing.Point(0, -3);
            this.Button_accountSelect.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_accountSelect.Name = "Button_accountSelect";
            this.Button_accountSelect.Normalcolor = System.Drawing.Color.Transparent;
            this.Button_accountSelect.OnHovercolor = System.Drawing.Color.Transparent;
            this.Button_accountSelect.OnHoverTextColor = System.Drawing.Color.Transparent;
            this.Button_accountSelect.selected = false;
            this.Button_accountSelect.Size = new System.Drawing.Size(530, 48);
            this.Button_accountSelect.TabIndex = 24;
            this.Button_accountSelect.Text = "               Select Account Type";
            this.Button_accountSelect.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Button_accountSelect.Textcolor = System.Drawing.Color.White;
            this.Button_accountSelect.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_accountSelect.Click += new System.EventHandler(this.Button_accountSelect_Click);
            // 
            // Button_LabTechnician
            // 
            this.Button_LabTechnician.Activecolor = System.Drawing.Color.SteelBlue;
            this.Button_LabTechnician.BackColor = System.Drawing.Color.SteelBlue;
            this.Button_LabTechnician.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_LabTechnician.BorderRadius = 0;
            this.Button_LabTechnician.ButtonText = "Lab Technician";
            this.Button_LabTechnician.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_LabTechnician.DisabledColor = System.Drawing.Color.Gray;
            this.Button_LabTechnician.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_LabTechnician.Iconimage = null;
            this.Button_LabTechnician.Iconimage_right = null;
            this.Button_LabTechnician.Iconimage_right_Selected = null;
            this.Button_LabTechnician.Iconimage_Selected = null;
            this.Button_LabTechnician.IconMarginLeft = 0;
            this.Button_LabTechnician.IconMarginRight = 0;
            this.Button_LabTechnician.IconRightVisible = true;
            this.Button_LabTechnician.IconRightZoom = 0D;
            this.Button_LabTechnician.IconVisible = true;
            this.Button_LabTechnician.IconZoom = 90D;
            this.Button_LabTechnician.IsTab = false;
            this.Button_LabTechnician.Location = new System.Drawing.Point(0, 135);
            this.Button_LabTechnician.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_LabTechnician.Name = "Button_LabTechnician";
            this.Button_LabTechnician.Normalcolor = System.Drawing.Color.SteelBlue;
            this.Button_LabTechnician.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.Button_LabTechnician.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_LabTechnician.selected = false;
            this.Button_LabTechnician.Size = new System.Drawing.Size(530, 42);
            this.Button_LabTechnician.TabIndex = 27;
            this.Button_LabTechnician.Text = "Lab Technician";
            this.Button_LabTechnician.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_LabTechnician.Textcolor = System.Drawing.Color.White;
            this.Button_LabTechnician.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_LabTechnician.Click += new System.EventHandler(this.Button_LabTechnician_Click);
            // 
            // Button_admin
            // 
            this.Button_admin.Activecolor = System.Drawing.Color.SteelBlue;
            this.Button_admin.BackColor = System.Drawing.Color.SteelBlue;
            this.Button_admin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_admin.BorderRadius = 0;
            this.Button_admin.ButtonText = "Administrator";
            this.Button_admin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_admin.DisabledColor = System.Drawing.Color.Gray;
            this.Button_admin.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_admin.Iconimage = null;
            this.Button_admin.Iconimage_right = null;
            this.Button_admin.Iconimage_right_Selected = null;
            this.Button_admin.Iconimage_Selected = null;
            this.Button_admin.IconMarginLeft = 0;
            this.Button_admin.IconMarginRight = 0;
            this.Button_admin.IconRightVisible = true;
            this.Button_admin.IconRightZoom = 0D;
            this.Button_admin.IconVisible = true;
            this.Button_admin.IconZoom = 90D;
            this.Button_admin.IsTab = false;
            this.Button_admin.Location = new System.Drawing.Point(0, 47);
            this.Button_admin.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_admin.Name = "Button_admin";
            this.Button_admin.Normalcolor = System.Drawing.Color.SteelBlue;
            this.Button_admin.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.Button_admin.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_admin.selected = false;
            this.Button_admin.Size = new System.Drawing.Size(530, 42);
            this.Button_admin.TabIndex = 25;
            this.Button_admin.Text = "Administrator";
            this.Button_admin.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_admin.Textcolor = System.Drawing.Color.White;
            this.Button_admin.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_admin.Click += new System.EventHandler(this.Button_admin_Click);
            // 
            // Button_clerk
            // 
            this.Button_clerk.Activecolor = System.Drawing.Color.SteelBlue;
            this.Button_clerk.BackColor = System.Drawing.Color.SteelBlue;
            this.Button_clerk.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_clerk.BorderRadius = 0;
            this.Button_clerk.ButtonText = "Front office clerk";
            this.Button_clerk.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_clerk.DisabledColor = System.Drawing.Color.Gray;
            this.Button_clerk.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_clerk.Iconimage = null;
            this.Button_clerk.Iconimage_right = null;
            this.Button_clerk.Iconimage_right_Selected = null;
            this.Button_clerk.Iconimage_Selected = null;
            this.Button_clerk.IconMarginLeft = 0;
            this.Button_clerk.IconMarginRight = 0;
            this.Button_clerk.IconRightVisible = true;
            this.Button_clerk.IconRightZoom = 0D;
            this.Button_clerk.IconVisible = true;
            this.Button_clerk.IconZoom = 90D;
            this.Button_clerk.IsTab = false;
            this.Button_clerk.Location = new System.Drawing.Point(0, 91);
            this.Button_clerk.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_clerk.Name = "Button_clerk";
            this.Button_clerk.Normalcolor = System.Drawing.Color.SteelBlue;
            this.Button_clerk.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.Button_clerk.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_clerk.selected = false;
            this.Button_clerk.Size = new System.Drawing.Size(530, 42);
            this.Button_clerk.TabIndex = 26;
            this.Button_clerk.Text = "Front office clerk";
            this.Button_clerk.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_clerk.Textcolor = System.Drawing.Color.White;
            this.Button_clerk.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_clerk.Click += new System.EventHandler(this.Button_clerk_Click);
            // 
            // bunifuSeparator2
            // 
            this.bunifuSeparator2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator2.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(105)))), ((int)(((byte)(225)))));
            this.bunifuSeparator2.LineThickness = 3;
            this.bunifuSeparator2.Location = new System.Drawing.Point(159, 210);
            this.bunifuSeparator2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator2.Name = "bunifuSeparator2";
            this.bunifuSeparator2.Size = new System.Drawing.Size(530, 10);
            this.bunifuSeparator2.TabIndex = 64;
            this.bunifuSeparator2.Transparency = 255;
            this.bunifuSeparator2.Vertical = false;
            // 
            // pictureBox_accountSelect
            // 
            this.pictureBox_accountSelect.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_accountSelect.Image")));
            this.pictureBox_accountSelect.Location = new System.Drawing.Point(96, 160);
            this.pictureBox_accountSelect.Name = "pictureBox_accountSelect";
            this.pictureBox_accountSelect.Size = new System.Drawing.Size(51, 46);
            this.pictureBox_accountSelect.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_accountSelect.TabIndex = 63;
            this.pictureBox_accountSelect.TabStop = false;
            // 
            // Label_password
            // 
            this.Label_password.AutoSize = true;
            this.Label_password.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_password.ForeColor = System.Drawing.Color.Blue;
            this.Label_password.Location = new System.Drawing.Point(92, 327);
            this.Label_password.Name = "Label_password";
            this.Label_password.Size = new System.Drawing.Size(95, 22);
            this.Label_password.TabIndex = 62;
            this.Label_password.Text = "Password";
            // 
            // Label_username
            // 
            this.Label_username.AutoSize = true;
            this.Label_username.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_username.ForeColor = System.Drawing.Color.Blue;
            this.Label_username.Location = new System.Drawing.Point(92, 230);
            this.Label_username.Name = "Label_username";
            this.Label_username.Size = new System.Drawing.Size(101, 22);
            this.Label_username.TabIndex = 61;
            this.Label_username.Text = "Username";
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(105)))), ((int)(((byte)(225)))));
            this.bunifuSeparator1.LineThickness = 3;
            this.bunifuSeparator1.Location = new System.Drawing.Point(159, 303);
            this.bunifuSeparator1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Size = new System.Drawing.Size(530, 10);
            this.bunifuSeparator1.TabIndex = 60;
            this.bunifuSeparator1.Transparency = 255;
            this.bunifuSeparator1.Vertical = false;
            // 
            // textBox_username
            // 
            this.textBox_username.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.textBox_username.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_username.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_username.ForeColor = System.Drawing.Color.White;
            this.textBox_username.Location = new System.Drawing.Point(159, 271);
            this.textBox_username.Name = "textBox_username";
            this.textBox_username.Size = new System.Drawing.Size(530, 30);
            this.textBox_username.TabIndex = 59;
            this.textBox_username.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBox_username_KeyPress);
            // 
            // bunifuSeparator_password
            // 
            this.bunifuSeparator_password.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator_password.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(105)))), ((int)(((byte)(225)))));
            this.bunifuSeparator_password.LineThickness = 3;
            this.bunifuSeparator_password.Location = new System.Drawing.Point(159, 399);
            this.bunifuSeparator_password.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator_password.Name = "bunifuSeparator_password";
            this.bunifuSeparator_password.Size = new System.Drawing.Size(530, 10);
            this.bunifuSeparator_password.TabIndex = 58;
            this.bunifuSeparator_password.Transparency = 255;
            this.bunifuSeparator_password.Vertical = false;
            // 
            // textBox_password
            // 
            this.textBox_password.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.textBox_password.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_password.Font = new System.Drawing.Font("Microsoft YaHei UI", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_password.ForeColor = System.Drawing.Color.White;
            this.textBox_password.Location = new System.Drawing.Point(159, 367);
            this.textBox_password.Name = "textBox_password";
            this.textBox_password.PasswordChar = '*';
            this.textBox_password.Size = new System.Drawing.Size(530, 30);
            this.textBox_password.TabIndex = 57;
            this.textBox_password.UseSystemPasswordChar = true;
            this.textBox_password.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBox_password_KeyPress);
            // 
            // Button_Register
            // 
            this.Button_Register.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.Button_Register.BackColor = System.Drawing.Color.DarkViolet;
            this.Button_Register.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_Register.BorderRadius = 0;
            this.Button_Register.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Button_Register.ButtonText = "CREATE";
            this.Button_Register.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_Register.DisabledColor = System.Drawing.Color.Gray;
            this.Button_Register.ForeColor = System.Drawing.Color.White;
            this.Button_Register.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_Register.Iconimage = null;
            this.Button_Register.Iconimage_right = null;
            this.Button_Register.Iconimage_right_Selected = null;
            this.Button_Register.Iconimage_Selected = null;
            this.Button_Register.IconMarginLeft = 0;
            this.Button_Register.IconMarginRight = 0;
            this.Button_Register.IconRightVisible = true;
            this.Button_Register.IconRightZoom = 0D;
            this.Button_Register.IconVisible = true;
            this.Button_Register.IconZoom = 90D;
            this.Button_Register.IsTab = false;
            this.Button_Register.Location = new System.Drawing.Point(96, 560);
            this.Button_Register.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_Register.Name = "Button_Register";
            this.Button_Register.Normalcolor = System.Drawing.Color.DarkViolet;
            this.Button_Register.OnHovercolor = System.Drawing.Color.Transparent;
            this.Button_Register.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_Register.selected = false;
            this.Button_Register.Size = new System.Drawing.Size(593, 63);
            this.Button_Register.TabIndex = 56;
            this.Button_Register.Text = "CREATE";
            this.Button_Register.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_Register.Textcolor = System.Drawing.Color.White;
            this.Button_Register.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Register.Click += new System.EventHandler(this.Button_Register_Click);
            // 
            // pictureBox_password
            // 
            this.pictureBox_password.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_password.Image")));
            this.pictureBox_password.Location = new System.Drawing.Point(96, 361);
            this.pictureBox_password.Name = "pictureBox_password";
            this.pictureBox_password.Size = new System.Drawing.Size(51, 46);
            this.pictureBox_password.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_password.TabIndex = 55;
            this.pictureBox_password.TabStop = false;
            // 
            // pictureBox_username
            // 
            this.pictureBox_username.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_username.Image")));
            this.pictureBox_username.Location = new System.Drawing.Point(96, 264);
            this.pictureBox_username.Name = "pictureBox_username";
            this.pictureBox_username.Size = new System.Drawing.Size(51, 46);
            this.pictureBox_username.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_username.TabIndex = 54;
            this.pictureBox_username.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(338, -19);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(125, 116);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 53;
            this.pictureBox2.TabStop = false;
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.Controls.Add(this.label2);
            this.bunifuGradientPanel1.Controls.Add(this.label1);
            this.bunifuGradientPanel1.Controls.Add(this.pictureBox1);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuCustomLabel1);
            this.bunifuGradientPanel1.Controls.Add(this.Label_title);
            this.bunifuGradientPanel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.Black;
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.Black;
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.LightSteelBlue;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.Black;
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(783, 0);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(711, 660);
            this.bunifuGradientPanel1.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkKhaki;
            this.label2.Location = new System.Drawing.Point(7, 501);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(538, 23);
            this.label2.TabIndex = 9;
            this.label2.Text = "the cost of health care for patients in the communities we serve.\"";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkKhaki;
            this.label1.Location = new System.Drawing.Point(7, 473);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(630, 23);
            this.label1.TabIndex = 8;
            this.label1.Text = "\"Our vision is to be the unmatched leader in improving quality and reducing";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(19, 172);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(653, 264);
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Yu Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.White;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(269, 602);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(166, 22);
            this.bunifuCustomLabel1.TabIndex = 6;
            this.bunifuCustomLabel1.Text = "Design By @NSSC ";
            // 
            // Label_title
            // 
            this.Label_title.AutoSize = true;
            this.Label_title.BackColor = System.Drawing.Color.Transparent;
            this.Label_title.Font = new System.Drawing.Font("Vivaldi", 28.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_title.ForeColor = System.Drawing.Color.RoyalBlue;
            this.Label_title.Location = new System.Drawing.Point(114, 83);
            this.Label_title.Name = "Label_title";
            this.Label_title.Size = new System.Drawing.Size(483, 57);
            this.Label_title.TabIndex = 5;
            this.Label_title.Text = "Asceso Hospitals pvt Ltd ";
            // 
            // timer1
            // 
            this.timer1.Interval = 1;
            this.timer1.Tick += new System.EventHandler(this.Timer1_Tick);
            // 
            // lab_UN
            // 
            this.lab_UN.AutoSize = true;
            this.lab_UN.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lab_UN.ForeColor = System.Drawing.Color.Blue;
            this.lab_UN.Location = new System.Drawing.Point(524, 28);
            this.lab_UN.Name = "lab_UN";
            this.lab_UN.Size = new System.Drawing.Size(36, 22);
            this.lab_UN.TabIndex = 74;
            this.lab_UN.Text = "UN";
            this.lab_UN.Visible = false;
            // 
            // Label_account
            // 
            this.Label_account.AutoSize = true;
            this.Label_account.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_account.ForeColor = System.Drawing.Color.Blue;
            this.Label_account.Location = new System.Drawing.Point(524, 75);
            this.Label_account.Name = "Label_account";
            this.Label_account.Size = new System.Drawing.Size(141, 22);
            this.Label_account.TabIndex = 73;
            this.Label_account.Text = "Account Type";
            this.Label_account.Visible = false;
            // 
            // RegistrationControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.Controls.Add(this.bunifuGradientPanel1);
            this.Controls.Add(this.panel_log);
            this.Name = "RegistrationControl";
            this.Size = new System.Drawing.Size(1494, 660);
            this.panel_log.ResumeLayout(false);
            this.panel_log.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_confirmPassword)).EndInit();
            this.panel_account.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_accountSelect)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_password)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_username)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_log;
        private System.Windows.Forms.Panel panel1;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_error;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_accountSelect;
        private System.Windows.Forms.Panel panel_account;
        public Bunifu.Framework.UI.BunifuFlatButton Button_Pharmacist;
        public Bunifu.Framework.UI.BunifuFlatButton Button_doctors;
        public Bunifu.Framework.UI.BunifuFlatButton Button_LabTechnician;
        public Bunifu.Framework.UI.BunifuFlatButton Button_accountSelect;
        public Bunifu.Framework.UI.BunifuFlatButton Button_admin;
        public Bunifu.Framework.UI.BunifuFlatButton Button_clerk;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator2;
        private System.Windows.Forms.PictureBox pictureBox_accountSelect;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_password;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_username;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator1;
        public System.Windows.Forms.TextBox textBox_username;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator_password;
        public System.Windows.Forms.TextBox textBox_password;
        public Bunifu.Framework.UI.BunifuFlatButton Button_Register;
        private System.Windows.Forms.PictureBox pictureBox_password;
        private System.Windows.Forms.PictureBox pictureBox_username;
        private System.Windows.Forms.PictureBox pictureBox2;
        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_title;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private Bunifu.Framework.UI.BunifuSeparator Separator_confirmPassword;
        public System.Windows.Forms.TextBox textBox_confirmPassword;
        private System.Windows.Forms.PictureBox pictureBox_confirmPassword;
        private System.Windows.Forms.Timer timer1;
        public Bunifu.Framework.UI.BunifuFlatButton Button_Assistant;
        private Bunifu.Framework.UI.BunifuCustomLabel lab_UN;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_account;
    }
}
