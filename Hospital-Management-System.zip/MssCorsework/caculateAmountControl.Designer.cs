﻿namespace MssCorsework
{
    partial class caculateAmountControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(caculateAmountControl));
            this.bunifuGradientPanel1 = new Bunifu.Framework.UI.BunifuGradientPanel();
            this.label_vDate = new System.Windows.Forms.Label();
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Button_visa = new Bunifu.Framework.UI.BunifuImageButton();
            this.Button_masterCard = new Bunifu.Framework.UI.BunifuImageButton();
            this.Button_payPal = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuSeparator4 = new Bunifu.Framework.UI.BunifuSeparator();
            this.Textbox_dAmount = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Textbox_hCharge = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.Button_result = new Bunifu.Framework.UI.BunifuFlatButton();
            this.label_eAF = new System.Windows.Forms.Label();
            this.label_eEa = new System.Windows.Forms.Label();
            this.Textbox_charge = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.lbl_totalCharge = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.lbl_hCharge = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_dFee = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.dateTimePicker_eDate = new System.Windows.Forms.DateTimePicker();
            this.bunifuSeparator3 = new Bunifu.Framework.UI.BunifuSeparator();
            this.label1 = new System.Windows.Forms.Label();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.label_eDC = new System.Windows.Forms.Label();
            this.Datepicker_aDate = new System.Windows.Forms.DateTimePicker();
            this.label_ID = new System.Windows.Forms.Label();
            this.bunifuSeparator2 = new Bunifu.Framework.UI.BunifuSeparator();
            this.label_ESearchNIC = new System.Windows.Forms.Label();
            this.bunifuSeparator1 = new Bunifu.Framework.UI.BunifuSeparator();
            this.Button_Search = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Label_SearchNIC = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Textbox_SearchNIC = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label_EDate = new System.Windows.Forms.Label();
            this.Button_SaveDetails = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Label_Date = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_Title = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel3 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Checkbox1 = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuGradientPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Button_visa)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Button_masterCard)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Button_payPal)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuGradientPanel1
            // 
            this.bunifuGradientPanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuGradientPanel1.BackgroundImage")));
            this.bunifuGradientPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuGradientPanel1.Controls.Add(this.bunifuCustomLabel3);
            this.bunifuGradientPanel1.Controls.Add(this.Checkbox1);
            this.bunifuGradientPanel1.Controls.Add(this.label_vDate);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuCustomLabel2);
            this.bunifuGradientPanel1.Controls.Add(this.Button_visa);
            this.bunifuGradientPanel1.Controls.Add(this.Button_masterCard);
            this.bunifuGradientPanel1.Controls.Add(this.Button_payPal);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuSeparator4);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_dAmount);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_hCharge);
            this.bunifuGradientPanel1.Controls.Add(this.Button_result);
            this.bunifuGradientPanel1.Controls.Add(this.label_eAF);
            this.bunifuGradientPanel1.Controls.Add(this.label_eEa);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_charge);
            this.bunifuGradientPanel1.Controls.Add(this.lbl_totalCharge);
            this.bunifuGradientPanel1.Controls.Add(this.lbl_hCharge);
            this.bunifuGradientPanel1.Controls.Add(this.Label_dFee);
            this.bunifuGradientPanel1.Controls.Add(this.dateTimePicker_eDate);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuSeparator3);
            this.bunifuGradientPanel1.Controls.Add(this.label1);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuCustomLabel1);
            this.bunifuGradientPanel1.Controls.Add(this.label_eDC);
            this.bunifuGradientPanel1.Controls.Add(this.Datepicker_aDate);
            this.bunifuGradientPanel1.Controls.Add(this.label_ID);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuSeparator2);
            this.bunifuGradientPanel1.Controls.Add(this.label_ESearchNIC);
            this.bunifuGradientPanel1.Controls.Add(this.bunifuSeparator1);
            this.bunifuGradientPanel1.Controls.Add(this.Button_Search);
            this.bunifuGradientPanel1.Controls.Add(this.Label_SearchNIC);
            this.bunifuGradientPanel1.Controls.Add(this.Textbox_SearchNIC);
            this.bunifuGradientPanel1.Controls.Add(this.label_EDate);
            this.bunifuGradientPanel1.Controls.Add(this.Button_SaveDetails);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Date);
            this.bunifuGradientPanel1.Controls.Add(this.Label_Title);
            this.bunifuGradientPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bunifuGradientPanel1.GradientBottomLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientBottomRight = System.Drawing.Color.Black;
            this.bunifuGradientPanel1.GradientTopLeft = System.Drawing.Color.White;
            this.bunifuGradientPanel1.GradientTopRight = System.Drawing.Color.Gray;
            this.bunifuGradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.bunifuGradientPanel1.Name = "bunifuGradientPanel1";
            this.bunifuGradientPanel1.Quality = 10;
            this.bunifuGradientPanel1.Size = new System.Drawing.Size(1140, 816);
            this.bunifuGradientPanel1.TabIndex = 3;
            // 
            // label_vDate
            // 
            this.label_vDate.AutoSize = true;
            this.label_vDate.BackColor = System.Drawing.Color.Transparent;
            this.label_vDate.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_vDate.ForeColor = System.Drawing.Color.Black;
            this.label_vDate.Location = new System.Drawing.Point(1053, 71);
            this.label_vDate.Name = "label_vDate";
            this.label_vDate.Size = new System.Drawing.Size(47, 19);
            this.label_vDate.TabIndex = 140;
            this.label_vDate.Text = "Date";
            this.label_vDate.Visible = false;
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel2.ForeColor = System.Drawing.Color.Black;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(62, 603);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(230, 32);
            this.bunifuCustomLabel2.TabIndex = 139;
            this.bunifuCustomLabel2.Text = "Payment Gateways";
            // 
            // Button_visa
            // 
            this.Button_visa.BackColor = System.Drawing.Color.Transparent;
            this.Button_visa.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Button_visa.Image = ((System.Drawing.Image)(resources.GetObject("Button_visa.Image")));
            this.Button_visa.ImageActive = null;
            this.Button_visa.Location = new System.Drawing.Point(539, 651);
            this.Button_visa.Name = "Button_visa";
            this.Button_visa.Size = new System.Drawing.Size(200, 80);
            this.Button_visa.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Button_visa.TabIndex = 138;
            this.Button_visa.TabStop = false;
            this.Button_visa.Zoom = 10;
            this.Button_visa.Click += new System.EventHandler(this.Button_visa_Click);
            // 
            // Button_masterCard
            // 
            this.Button_masterCard.BackColor = System.Drawing.Color.Transparent;
            this.Button_masterCard.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Button_masterCard.Image = ((System.Drawing.Image)(resources.GetObject("Button_masterCard.Image")));
            this.Button_masterCard.ImageActive = null;
            this.Button_masterCard.Location = new System.Drawing.Point(304, 651);
            this.Button_masterCard.Name = "Button_masterCard";
            this.Button_masterCard.Size = new System.Drawing.Size(200, 80);
            this.Button_masterCard.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Button_masterCard.TabIndex = 137;
            this.Button_masterCard.TabStop = false;
            this.Button_masterCard.Zoom = 10;
            this.Button_masterCard.Click += new System.EventHandler(this.Button_masterCard_Click);
            // 
            // Button_payPal
            // 
            this.Button_payPal.BackColor = System.Drawing.Color.Transparent;
            this.Button_payPal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Button_payPal.Image = ((System.Drawing.Image)(resources.GetObject("Button_payPal.Image")));
            this.Button_payPal.ImageActive = null;
            this.Button_payPal.Location = new System.Drawing.Point(68, 651);
            this.Button_payPal.Name = "Button_payPal";
            this.Button_payPal.Size = new System.Drawing.Size(200, 80);
            this.Button_payPal.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Button_payPal.TabIndex = 136;
            this.Button_payPal.TabStop = false;
            this.Button_payPal.Zoom = 10;
            this.Button_payPal.Click += new System.EventHandler(this.Button_payPal_Click);
            // 
            // bunifuSeparator4
            // 
            this.bunifuSeparator4.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator4.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator4.LineThickness = 2;
            this.bunifuSeparator4.Location = new System.Drawing.Point(66, 573);
            this.bunifuSeparator4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator4.Name = "bunifuSeparator4";
            this.bunifuSeparator4.Size = new System.Drawing.Size(1012, 10);
            this.bunifuSeparator4.TabIndex = 135;
            this.bunifuSeparator4.Transparency = 255;
            this.bunifuSeparator4.Vertical = false;
            // 
            // Textbox_dAmount
            // 
            this.Textbox_dAmount.BackColor = System.Drawing.Color.Silver;
            this.Textbox_dAmount.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_dAmount.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_dAmount.ForeColor = System.Drawing.Color.Black;
            this.Textbox_dAmount.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_dAmount.HintText = "Earned Amount ";
            this.Textbox_dAmount.isPassword = false;
            this.Textbox_dAmount.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_dAmount.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_dAmount.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_dAmount.LineThickness = 3;
            this.Textbox_dAmount.Location = new System.Drawing.Point(66, 476);
            this.Textbox_dAmount.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_dAmount.Name = "Textbox_dAmount";
            this.Textbox_dAmount.Size = new System.Drawing.Size(247, 58);
            this.Textbox_dAmount.TabIndex = 134;
            this.Textbox_dAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Textbox_dAmount.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_dAmount_KeyPress);
            // 
            // Textbox_hCharge
            // 
            this.Textbox_hCharge.BackColor = System.Drawing.Color.Silver;
            this.Textbox_hCharge.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_hCharge.Enabled = false;
            this.Textbox_hCharge.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_hCharge.ForeColor = System.Drawing.Color.Black;
            this.Textbox_hCharge.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_hCharge.HintText = "";
            this.Textbox_hCharge.isPassword = false;
            this.Textbox_hCharge.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_hCharge.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_hCharge.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_hCharge.LineThickness = 3;
            this.Textbox_hCharge.Location = new System.Drawing.Point(336, 477);
            this.Textbox_hCharge.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_hCharge.Name = "Textbox_hCharge";
            this.Textbox_hCharge.Size = new System.Drawing.Size(191, 57);
            this.Textbox_hCharge.TabIndex = 133;
            this.Textbox_hCharge.Text = "20 ";
            this.Textbox_hCharge.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Textbox_hCharge.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_hCharge_KeyPress);
            // 
            // Button_result
            // 
            this.Button_result.Activecolor = System.Drawing.Color.RoyalBlue;
            this.Button_result.BackColor = System.Drawing.Color.RoyalBlue;
            this.Button_result.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_result.BorderRadius = 0;
            this.Button_result.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Button_result.ButtonText = "RESULT";
            this.Button_result.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_result.DisabledColor = System.Drawing.Color.Gray;
            this.Button_result.ForeColor = System.Drawing.Color.White;
            this.Button_result.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_result.Iconimage = null;
            this.Button_result.Iconimage_right = null;
            this.Button_result.Iconimage_right_Selected = null;
            this.Button_result.Iconimage_Selected = null;
            this.Button_result.IconMarginLeft = 0;
            this.Button_result.IconMarginRight = 0;
            this.Button_result.IconRightVisible = true;
            this.Button_result.IconRightZoom = 0D;
            this.Button_result.IconVisible = true;
            this.Button_result.IconZoom = 90D;
            this.Button_result.IsTab = false;
            this.Button_result.Location = new System.Drawing.Point(549, 477);
            this.Button_result.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_result.Name = "Button_result";
            this.Button_result.Normalcolor = System.Drawing.Color.RoyalBlue;
            this.Button_result.OnHovercolor = System.Drawing.Color.Transparent;
            this.Button_result.OnHoverTextColor = System.Drawing.Color.Black;
            this.Button_result.selected = false;
            this.Button_result.Size = new System.Drawing.Size(192, 58);
            this.Button_result.TabIndex = 131;
            this.Button_result.Text = "RESULT";
            this.Button_result.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_result.Textcolor = System.Drawing.Color.White;
            this.Button_result.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_result.Click += new System.EventHandler(this.Button_result_Click);
            // 
            // label_eAF
            // 
            this.label_eAF.AutoSize = true;
            this.label_eAF.BackColor = System.Drawing.Color.Transparent;
            this.label_eAF.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_eAF.ForeColor = System.Drawing.Color.Red;
            this.label_eAF.Location = new System.Drawing.Point(332, 547);
            this.label_eAF.Name = "label_eAF";
            this.label_eAF.Size = new System.Drawing.Size(60, 19);
            this.label_eAF.TabIndex = 129;
            this.label_eAF.Text = "label5";
            this.label_eAF.Visible = false;
            // 
            // label_eEa
            // 
            this.label_eEa.AutoSize = true;
            this.label_eEa.BackColor = System.Drawing.Color.Transparent;
            this.label_eEa.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_eEa.ForeColor = System.Drawing.Color.Red;
            this.label_eEa.Location = new System.Drawing.Point(64, 547);
            this.label_eEa.Name = "label_eEa";
            this.label_eEa.Size = new System.Drawing.Size(60, 19);
            this.label_eEa.TabIndex = 128;
            this.label_eEa.Text = "label5";
            this.label_eEa.Visible = false;
            // 
            // Textbox_charge
            // 
            this.Textbox_charge.BackColor = System.Drawing.Color.Silver;
            this.Textbox_charge.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_charge.Enabled = false;
            this.Textbox_charge.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_charge.ForeColor = System.Drawing.Color.Black;
            this.Textbox_charge.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_charge.HintText = "Doctor\'s Charge";
            this.Textbox_charge.isPassword = false;
            this.Textbox_charge.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_charge.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_charge.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_charge.LineThickness = 3;
            this.Textbox_charge.Location = new System.Drawing.Point(761, 476);
            this.Textbox_charge.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_charge.Name = "Textbox_charge";
            this.Textbox_charge.Size = new System.Drawing.Size(315, 58);
            this.Textbox_charge.TabIndex = 127;
            this.Textbox_charge.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Textbox_charge.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_charge_KeyPress);
            // 
            // lbl_totalCharge
            // 
            this.lbl_totalCharge.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_totalCharge.AutoSize = true;
            this.lbl_totalCharge.BackColor = System.Drawing.Color.Transparent;
            this.lbl_totalCharge.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_totalCharge.ForeColor = System.Drawing.Color.Black;
            this.lbl_totalCharge.Location = new System.Drawing.Point(755, 428);
            this.lbl_totalCharge.Name = "lbl_totalCharge";
            this.lbl_totalCharge.Size = new System.Drawing.Size(268, 32);
            this.lbl_totalCharge.TabIndex = 126;
            this.lbl_totalCharge.Text = "Doctor\'s Charge (LKR)";
            // 
            // lbl_hCharge
            // 
            this.lbl_hCharge.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbl_hCharge.AutoSize = true;
            this.lbl_hCharge.BackColor = System.Drawing.Color.Transparent;
            this.lbl_hCharge.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_hCharge.ForeColor = System.Drawing.Color.Black;
            this.lbl_hCharge.Location = new System.Drawing.Point(330, 428);
            this.lbl_hCharge.Name = "lbl_hCharge";
            this.lbl_hCharge.Size = new System.Drawing.Size(278, 32);
            this.lbl_hCharge.TabIndex = 124;
            this.lbl_hCharge.Text = "Administration Fee (%)";
            // 
            // Label_dFee
            // 
            this.Label_dFee.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_dFee.AutoSize = true;
            this.Label_dFee.BackColor = System.Drawing.Color.Transparent;
            this.Label_dFee.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_dFee.ForeColor = System.Drawing.Color.Black;
            this.Label_dFee.Location = new System.Drawing.Point(60, 427);
            this.Label_dFee.Name = "Label_dFee";
            this.Label_dFee.Size = new System.Drawing.Size(263, 32);
            this.Label_dFee.TabIndex = 123;
            this.Label_dFee.Text = "Earned Amount (LKR)";
            // 
            // dateTimePicker_eDate
            // 
            this.dateTimePicker_eDate.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker_eDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker_eDate.Location = new System.Drawing.Point(66, 301);
            this.dateTimePicker_eDate.MinimumSize = new System.Drawing.Size(4, 44);
            this.dateTimePicker_eDate.Name = "dateTimePicker_eDate";
            this.dateTimePicker_eDate.Size = new System.Drawing.Size(480, 44);
            this.dateTimePicker_eDate.TabIndex = 122;
            this.dateTimePicker_eDate.MouseDown += new System.Windows.Forms.MouseEventHandler(this.DateTimePicker_eDate_MouseDown);
            // 
            // bunifuSeparator3
            // 
            this.bunifuSeparator3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator3.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuSeparator3.LineThickness = 3;
            this.bunifuSeparator3.Location = new System.Drawing.Point(66, 342);
            this.bunifuSeparator3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator3.Name = "bunifuSeparator3";
            this.bunifuSeparator3.Size = new System.Drawing.Size(480, 10);
            this.bunifuSeparator3.TabIndex = 121;
            this.bunifuSeparator3.Transparency = 255;
            this.bunifuSeparator3.Vertical = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(62, 359);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 19);
            this.label1.TabIndex = 120;
            this.label1.Text = "label3";
            this.label1.Visible = false;
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.ForeColor = System.Drawing.Color.Black;
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(60, 263);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(118, 32);
            this.bunifuCustomLabel1.TabIndex = 119;
            this.bunifuCustomLabel1.Text = "End Date";
            // 
            // label_eDC
            // 
            this.label_eDC.AutoSize = true;
            this.label_eDC.BackColor = System.Drawing.Color.Transparent;
            this.label_eDC.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_eDC.ForeColor = System.Drawing.Color.Red;
            this.label_eDC.Location = new System.Drawing.Point(757, 547);
            this.label_eDC.Name = "label_eDC";
            this.label_eDC.Size = new System.Drawing.Size(60, 19);
            this.label_eDC.TabIndex = 116;
            this.label_eDC.Text = "label5";
            this.label_eDC.Visible = false;
            // 
            // Datepicker_aDate
            // 
            this.Datepicker_aDate.Font = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Datepicker_aDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.Datepicker_aDate.Location = new System.Drawing.Point(66, 168);
            this.Datepicker_aDate.MinimumSize = new System.Drawing.Size(4, 44);
            this.Datepicker_aDate.Name = "Datepicker_aDate";
            this.Datepicker_aDate.Size = new System.Drawing.Size(480, 44);
            this.Datepicker_aDate.TabIndex = 97;
            this.Datepicker_aDate.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Datepicker_aDate_MouseDown);
            // 
            // label_ID
            // 
            this.label_ID.AutoSize = true;
            this.label_ID.BackColor = System.Drawing.Color.Transparent;
            this.label_ID.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ID.ForeColor = System.Drawing.Color.Black;
            this.label_ID.Location = new System.Drawing.Point(1053, 27);
            this.label_ID.Name = "label_ID";
            this.label_ID.Size = new System.Drawing.Size(26, 19);
            this.label_ID.TabIndex = 95;
            this.label_ID.Text = "ID";
            this.label_ID.Visible = false;
            // 
            // bunifuSeparator2
            // 
            this.bunifuSeparator2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator2.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bunifuSeparator2.LineThickness = 3;
            this.bunifuSeparator2.Location = new System.Drawing.Point(66, 209);
            this.bunifuSeparator2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator2.Name = "bunifuSeparator2";
            this.bunifuSeparator2.Size = new System.Drawing.Size(480, 10);
            this.bunifuSeparator2.TabIndex = 92;
            this.bunifuSeparator2.Transparency = 255;
            this.bunifuSeparator2.Vertical = false;
            // 
            // label_ESearchNIC
            // 
            this.label_ESearchNIC.AutoSize = true;
            this.label_ESearchNIC.BackColor = System.Drawing.Color.Transparent;
            this.label_ESearchNIC.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_ESearchNIC.ForeColor = System.Drawing.Color.Red;
            this.label_ESearchNIC.Location = new System.Drawing.Point(592, 224);
            this.label_ESearchNIC.Name = "label_ESearchNIC";
            this.label_ESearchNIC.Size = new System.Drawing.Size(60, 19);
            this.label_ESearchNIC.TabIndex = 85;
            this.label_ESearchNIC.Text = "label5";
            this.label_ESearchNIC.Visible = false;
            // 
            // bunifuSeparator1
            // 
            this.bunifuSeparator1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.bunifuSeparator1.LineThickness = 2;
            this.bunifuSeparator1.Location = new System.Drawing.Point(64, 390);
            this.bunifuSeparator1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuSeparator1.Name = "bunifuSeparator1";
            this.bunifuSeparator1.Size = new System.Drawing.Size(1015, 10);
            this.bunifuSeparator1.TabIndex = 84;
            this.bunifuSeparator1.Transparency = 255;
            this.bunifuSeparator1.Vertical = false;
            // 
            // Button_Search
            // 
            this.Button_Search.Activecolor = System.Drawing.Color.DarkViolet;
            this.Button_Search.BackColor = System.Drawing.Color.DarkViolet;
            this.Button_Search.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_Search.BorderRadius = 0;
            this.Button_Search.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Button_Search.ButtonText = "SEARCH";
            this.Button_Search.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_Search.DisabledColor = System.Drawing.Color.Gray;
            this.Button_Search.ForeColor = System.Drawing.Color.White;
            this.Button_Search.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_Search.Iconimage = null;
            this.Button_Search.Iconimage_right = null;
            this.Button_Search.Iconimage_right_Selected = null;
            this.Button_Search.Iconimage_Selected = null;
            this.Button_Search.IconMarginLeft = 0;
            this.Button_Search.IconMarginRight = 0;
            this.Button_Search.IconRightVisible = true;
            this.Button_Search.IconRightZoom = 0D;
            this.Button_Search.IconVisible = true;
            this.Button_Search.IconZoom = 90D;
            this.Button_Search.IsTab = false;
            this.Button_Search.Location = new System.Drawing.Point(596, 301);
            this.Button_Search.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_Search.Name = "Button_Search";
            this.Button_Search.Normalcolor = System.Drawing.Color.DarkViolet;
            this.Button_Search.OnHovercolor = System.Drawing.Color.Transparent;
            this.Button_Search.OnHoverTextColor = System.Drawing.Color.Black;
            this.Button_Search.selected = false;
            this.Button_Search.Size = new System.Drawing.Size(480, 51);
            this.Button_Search.TabIndex = 83;
            this.Button_Search.Text = "SEARCH";
            this.Button_Search.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_Search.Textcolor = System.Drawing.Color.White;
            this.Button_Search.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Search.Click += new System.EventHandler(this.Button_Search_Click);
            // 
            // Label_SearchNIC
            // 
            this.Label_SearchNIC.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_SearchNIC.AutoSize = true;
            this.Label_SearchNIC.BackColor = System.Drawing.Color.Transparent;
            this.Label_SearchNIC.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_SearchNIC.ForeColor = System.Drawing.Color.Black;
            this.Label_SearchNIC.Location = new System.Drawing.Point(590, 128);
            this.Label_SearchNIC.Name = "Label_SearchNIC";
            this.Label_SearchNIC.Size = new System.Drawing.Size(161, 32);
            this.Label_SearchNIC.TabIndex = 82;
            this.Label_SearchNIC.Text = "Doctor\'s NIC";
            // 
            // Textbox_SearchNIC
            // 
            this.Textbox_SearchNIC.BackColor = System.Drawing.Color.Silver;
            this.Textbox_SearchNIC.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Textbox_SearchNIC.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Textbox_SearchNIC.ForeColor = System.Drawing.Color.Black;
            this.Textbox_SearchNIC.HintForeColor = System.Drawing.Color.Black;
            this.Textbox_SearchNIC.HintText = "Doctor\'s NIC";
            this.Textbox_SearchNIC.isPassword = false;
            this.Textbox_SearchNIC.LineFocusedColor = System.Drawing.Color.Blue;
            this.Textbox_SearchNIC.LineIdleColor = System.Drawing.Color.Black;
            this.Textbox_SearchNIC.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.Textbox_SearchNIC.LineThickness = 3;
            this.Textbox_SearchNIC.Location = new System.Drawing.Point(596, 168);
            this.Textbox_SearchNIC.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Textbox_SearchNIC.Name = "Textbox_SearchNIC";
            this.Textbox_SearchNIC.Size = new System.Drawing.Size(480, 45);
            this.Textbox_SearchNIC.TabIndex = 81;
            this.Textbox_SearchNIC.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.Textbox_SearchNIC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Textbox_SearchNIC_KeyPress);
            // 
            // label_EDate
            // 
            this.label_EDate.AutoSize = true;
            this.label_EDate.BackColor = System.Drawing.Color.Transparent;
            this.label_EDate.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_EDate.ForeColor = System.Drawing.Color.Red;
            this.label_EDate.Location = new System.Drawing.Point(62, 226);
            this.label_EDate.Name = "label_EDate";
            this.label_EDate.Size = new System.Drawing.Size(60, 19);
            this.label_EDate.TabIndex = 71;
            this.label_EDate.Text = "label3";
            this.label_EDate.Visible = false;
            // 
            // Button_SaveDetails
            // 
            this.Button_SaveDetails.Activecolor = System.Drawing.Color.ForestGreen;
            this.Button_SaveDetails.BackColor = System.Drawing.Color.ForestGreen;
            this.Button_SaveDetails.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_SaveDetails.BorderRadius = 0;
            this.Button_SaveDetails.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Button_SaveDetails.ButtonText = "SAVE DETAILS";
            this.Button_SaveDetails.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Button_SaveDetails.DisabledColor = System.Drawing.Color.Gray;
            this.Button_SaveDetails.ForeColor = System.Drawing.Color.White;
            this.Button_SaveDetails.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_SaveDetails.Iconimage = null;
            this.Button_SaveDetails.Iconimage_right = null;
            this.Button_SaveDetails.Iconimage_right_Selected = null;
            this.Button_SaveDetails.Iconimage_Selected = null;
            this.Button_SaveDetails.IconMarginLeft = 0;
            this.Button_SaveDetails.IconMarginRight = 0;
            this.Button_SaveDetails.IconRightVisible = true;
            this.Button_SaveDetails.IconRightZoom = 0D;
            this.Button_SaveDetails.IconVisible = true;
            this.Button_SaveDetails.IconZoom = 90D;
            this.Button_SaveDetails.IsTab = false;
            this.Button_SaveDetails.Location = new System.Drawing.Point(761, 651);
            this.Button_SaveDetails.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_SaveDetails.Name = "Button_SaveDetails";
            this.Button_SaveDetails.Normalcolor = System.Drawing.Color.ForestGreen;
            this.Button_SaveDetails.OnHovercolor = System.Drawing.Color.Transparent;
            this.Button_SaveDetails.OnHoverTextColor = System.Drawing.Color.Black;
            this.Button_SaveDetails.selected = false;
            this.Button_SaveDetails.Size = new System.Drawing.Size(315, 80);
            this.Button_SaveDetails.TabIndex = 57;
            this.Button_SaveDetails.Text = "SAVE DETAILS";
            this.Button_SaveDetails.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_SaveDetails.Textcolor = System.Drawing.Color.White;
            this.Button_SaveDetails.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_SaveDetails.Click += new System.EventHandler(this.Button_SaveDetails_Click);
            // 
            // Label_Date
            // 
            this.Label_Date.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Date.AutoSize = true;
            this.Label_Date.BackColor = System.Drawing.Color.Transparent;
            this.Label_Date.Font = new System.Drawing.Font("Ebrima", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Date.ForeColor = System.Drawing.Color.Black;
            this.Label_Date.Location = new System.Drawing.Point(60, 130);
            this.Label_Date.Name = "Label_Date";
            this.Label_Date.Size = new System.Drawing.Size(129, 32);
            this.Label_Date.TabIndex = 25;
            this.Label_Date.Text = "Start Date";
            // 
            // Label_Title
            // 
            this.Label_Title.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_Title.AutoSize = true;
            this.Label_Title.BackColor = System.Drawing.Color.Transparent;
            this.Label_Title.Font = new System.Drawing.Font("Felix Titling", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Title.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.Label_Title.Location = new System.Drawing.Point(244, 30);
            this.Label_Title.Name = "Label_Title";
            this.Label_Title.Size = new System.Drawing.Size(690, 35);
            this.Label_Title.TabIndex = 18;
            this.Label_Title.Text = "Calculate doctors earning amount ";
            // 
            // bunifuCustomLabel3
            // 
            this.bunifuCustomLabel3.AutoSize = true;
            this.bunifuCustomLabel3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuCustomLabel3.Font = new System.Drawing.Font("Yu Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel3.ForeColor = System.Drawing.Color.Black;
            this.bunifuCustomLabel3.Location = new System.Drawing.Point(612, 438);
            this.bunifuCustomLabel3.Name = "bunifuCustomLabel3";
            this.bunifuCustomLabel3.Size = new System.Drawing.Size(65, 19);
            this.bunifuCustomLabel3.TabIndex = 142;
            this.bunifuCustomLabel3.Text = "Change";
            // 
            // Checkbox1
            // 
            this.Checkbox1.BackColor = System.Drawing.Color.Silver;
            this.Checkbox1.ChechedOffColor = System.Drawing.Color.Silver;
            this.Checkbox1.Checked = false;
            this.Checkbox1.CheckedOnColor = System.Drawing.Color.DeepSkyBlue;
            this.Checkbox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Checkbox1.ForeColor = System.Drawing.Color.Black;
            this.Checkbox1.Location = new System.Drawing.Point(682, 437);
            this.Checkbox1.Margin = new System.Windows.Forms.Padding(5, 5, 5, 5);
            this.Checkbox1.Name = "Checkbox1";
            this.Checkbox1.Size = new System.Drawing.Size(20, 20);
            this.Checkbox1.TabIndex = 141;
            this.Checkbox1.OnChange += new System.EventHandler(this.Checkbox1_OnChange);
            // 
            // caculateAmountControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.bunifuGradientPanel1);
            this.Name = "caculateAmountControl";
            this.Size = new System.Drawing.Size(1140, 816);
            this.bunifuGradientPanel1.ResumeLayout(false);
            this.bunifuGradientPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Button_visa)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Button_masterCard)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Button_payPal)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuGradientPanel bunifuGradientPanel1;
        private System.Windows.Forms.Label label_eDC;
        private System.Windows.Forms.DateTimePicker Datepicker_aDate;
        private System.Windows.Forms.Label label_ID;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator2;
        private System.Windows.Forms.Label label_ESearchNIC;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator1;
        public Bunifu.Framework.UI.BunifuFlatButton Button_Search;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_SearchNIC;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_SearchNIC;
        private System.Windows.Forms.Label label_EDate;
        public Bunifu.Framework.UI.BunifuFlatButton Button_SaveDetails;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Date;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_Title;
        private System.Windows.Forms.DateTimePicker dateTimePicker_eDate;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator3;
        private System.Windows.Forms.Label label1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private Bunifu.Framework.UI.BunifuImageButton Button_visa;
        private Bunifu.Framework.UI.BunifuImageButton Button_masterCard;
        private Bunifu.Framework.UI.BunifuImageButton Button_payPal;
        private Bunifu.Framework.UI.BunifuSeparator bunifuSeparator4;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_dAmount;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_hCharge;
        public Bunifu.Framework.UI.BunifuFlatButton Button_result;
        private System.Windows.Forms.Label label_eAF;
        private System.Windows.Forms.Label label_eEa;
        public Bunifu.Framework.UI.BunifuMaterialTextbox Textbox_charge;
        private Bunifu.Framework.UI.BunifuCustomLabel lbl_totalCharge;
        private Bunifu.Framework.UI.BunifuCustomLabel lbl_hCharge;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_dFee;
        private System.Windows.Forms.Label label_vDate;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel3;
        private Bunifu.Framework.UI.BunifuCheckbox Checkbox1;
    }
}
