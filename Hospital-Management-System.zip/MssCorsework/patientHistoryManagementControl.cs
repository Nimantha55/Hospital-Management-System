﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MssCorsework
{
    public partial class patientHistoryManagementControl : UserControl
    {
        public patientHistoryManagementControl()
        {
            InitializeComponent();
        }

        SQLQueries sqlq = new SQLQueries();

        private void clear()
        {
            Textbox_pName.Text = "";
            Textbox_NIC.Text = "";
            Textbox_Dia.Text = "";
            Textbox_Sym.Text = "";
            Textbox_changeDetails.Text = "";
            Textbox_remarks.Text = "";
            Textbox_prescription.Text = "";
            Textbox_labReports.Text = "";
        }

        private void Button_ADD_Click(object sender, EventArgs e)
        {
            if (Textbox_pName.Text == "" && Textbox_NIC.Text == "" && Textbox_Dia.Text == "" && Textbox_Sym.Text == "" && Textbox_changeDetails.Text == "" && Textbox_remarks.Text == "" && Textbox_prescription.Text == "" && Textbox_labReports.Text == "")
            {
                label_Errors.Visible = true;
                label_Errors.Text = "Please Enter All Details!";
            }
            else if (Textbox_pName.Text == "")
            {
                label_pEName.Visible = true;
                label_pEName.Text = "Patient's Name is Required!";
            }
            else if (Textbox_NIC.Text == "")
            {
                label_pENIC.Visible = true;
                label_pENIC.Text = "Patient's NIC is Required!";
            }
            else if (Textbox_Dia.Text == "")
            {
                label_pEDia.Visible = true;
                label_pEDia.Text = "Diagnosis details is Required!";
            }
            else if (Textbox_Sym.Text == "")
            {
                label_pESym.Visible = true;
                label_pESym.Text = "Symptoms details is Required!";
            }
            else if (Textbox_changeDetails.Text == "")
            {
                label_pEchange.Visible = true;
                label_pEchange.Text = "Change Details is Required!";
            }
            else if (Textbox_remarks.Text == "")
            {
                label_pERemarks.Visible = true;
                label_pERemarks.Text = "Remarks is Required!";
            }
            else if (Textbox_prescription.Text == "")
            {
                label_pEPrescription.Visible = true;
                label_pEPrescription.Text = "Prescription is Required!";
            }
            else if (Textbox_labReports.Text == "")
            {
                label_labReport.Visible = true;
                label_labReport.Text = "Lab Report is Required!";
            }
            else
            {
                try
                {
                    string pName = Textbox_pName.Text;
                    string pNIC = Textbox_NIC.Text;
                    string pDia = Textbox_Dia.Text;
                    string pSymp = Textbox_Sym.Text;
                    string pChange = Textbox_changeDetails.Text;
                    string pRemarks = Textbox_remarks.Text;
                    string pPres = Textbox_prescription.Text;
                    string pLabReport = Textbox_labReports.Text;

                    //pass values for insertDoctorsDetails query which include in SQLQueries class
                    sqlq.patientHistory(pName, pNIC, pDia, pSymp, pChange, pRemarks, pPres, pLabReport);
                    Message1 pr = new Message1();
                    pr.label1.Text = "Diagnosis Details Added Successfully!";
                    pr.label1.Location = new System.Drawing.Point(32, 200);
                    pr.Show();
                    this.clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Please Check The Values" + ex, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void Button_Clear_Click(object sender, EventArgs e)
        {
            this.clear();
        }

        private void Textbox_pName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_pName.Text != "")
            {
                label_pEName.Visible = false;
                label_Errors.Visible = false;
            }
        }

        private void Textbox_NIC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_NIC.Text != "")
            {
                label_pENIC.Visible = false;
                label_Errors.Visible = false;
            }
        }

        private void Textbox_Dia_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_Dia.Text != "")
            {
                label_pEDia.Visible = false;
                label_Errors.Visible = false;
            }
        }

        private void Textbox_Sym_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_Sym.Text != "")
            {
                label_pESym.Visible = false;
                label_Errors.Visible = false;
            }
        }

        private void Textbox_changeDetails_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_changeDetails.Text != "")
            {
                label_pEchange.Visible = false;
                label_Errors.Visible = false;
            }
        }

        private void Textbox_remarks_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_remarks.Text != "")
            {
                label_pERemarks.Visible = false;
                label_Errors.Visible = false;
            }
        }

        private void Textbox_prescription_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_prescription.Text != "")
            {
                label_pEPrescription.Visible = false;
                label_Errors.Visible = false;
            }
        }

        private void Textbox_labReports_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_labReports.Text != "")
            {
                label_labReport.Visible = false;
                label_Errors.Visible = false;
            }
        }

        private void Textbox_NIC_Leave(object sender, EventArgs e)
        {
            string searchNIC = Textbox_NIC.Text;

            SqlDataReader dr = sqlq.patientDetails(searchNIC);
            if (dr.Read())
            {
                Textbox_pName.Text = dr[1].ToString();
            }
            else
            {
                MessageBox.Show("Invalid Patient's or Guardian's NIC", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
