﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MssCorsework
{
    public partial class pharmacyControl : UserControl
    {
        public bool isCollapsed;

        public pharmacyControl()
        {
            InitializeComponent();
        }

        SQLQueries sqlq = new SQLQueries();

        private void Button_prescriptions_Click(object sender, EventArgs e)
        {
            timer1.Start();
            panel_PresType.BringToFront();

            try
            {
                this.tablePrescriptionTableAdapter.pre(this.mSSDBDataSet2.TablePrescription, Button_prescriptions.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
        }

        private void Btn_Type1_Click(object sender, EventArgs e)
        {
            Button_prescriptions.Text = "Antipyretics";
            Button_prescriptions.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
        }

        private void Btn_Type2_Click(object sender, EventArgs e)
        {
            Button_prescriptions.Text = "Analgesics";
            Button_prescriptions.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
        }

        private void Btn_Type3_Click(object sender, EventArgs e)
        {
            Button_prescriptions.Text = "Antiseptics";
            Button_prescriptions.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
        }

        private void Btn_Type4_Click(object sender, EventArgs e)
        {
            Button_prescriptions.Text = "Antibiotics";
            Button_prescriptions.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            if (isCollapsed)
            {
                panel_PresType.Height += 10;
                if (panel_PresType.Size == panel_PresType.MaximumSize)
                {
                    timer1.Stop();
                    isCollapsed = false;
                }
            }
            else
            {
                panel_PresType.Height -= 10;
                if (panel_PresType.Size == panel_PresType.MinimumSize)
                {
                    timer1.Stop();
                    isCollapsed = true;
                }
            }
        }

        private void PharmacyControl_Load(object sender, EventArgs e)
        {

        }

        private void PreToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.tablePrescriptionTableAdapter.pre(this.mSSDBDataSet2.TablePrescription, categoryToolStripTextBox.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
        }

        private void Button_Search_Click(object sender, EventArgs e)
        {
            string pNIC = Textbox_SearchNIC.Text;

            if (Textbox_SearchNIC.Text == "")
            {
                label_ESearchNIC.Visible = false;
                label_ESearchNIC.Text = "Patient's NIC or Guardian's NIC is required!";
            }
            else
            {
                SqlDataReader dr = sqlq.getTablePatientsHistory(pNIC);
                if (dr.Read())
                {
                    label_ID.Text = dr[0].ToString();
                    Textbox_diagnosis.Text = dr[3].ToString();
                    Textbox_prescriptions.Text = dr[7].ToString();
                }
                else
                {
                    MessageBox.Show("Invalid Patient's or Guardian's NIC", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void DataGrid1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.DataGrid1.Rows[e.RowIndex];
                Textbox_preName.Text = row.Cells["preName"].Value.ToString();
                label_cost.Text = row.Cells["costPrice"].Value.ToString();
                Textbox_salesPrice.Text = row.Cells["salesPrice"].Value.ToString();
                label_stocks.Text = row.Cells["stocks"].Value.ToString();
                label_relevel.Text = row.Cells["reorderLevel"].Value.ToString();
                label_cate.Text = row.Cells["category"].Value.ToString();
            }
        }

        private void Btn_result_Click(object sender, EventArgs e)
        {
            int sale = int.Parse(Textbox_salesPrice.Text);
            decimal quent = app_Number.Value;
            int qun;
            int result;

            if (Textbox_salesPrice.Text == "")
            {
                label_saleP.Visible = true;
                label_saleP.Text = "Sales Price is required!";
            }
            else if (app_Number.Value == 0)
            {
                label_qun.Visible = true;
                label_qun.Text = "Quantity is required!";
            }
            else
            { 
                qun = Decimal.ToInt32(quent);
                result = sale * qun;
                Textbox_cost.Text = result.ToString();
            }
        }

        private void DataGrid1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.DataGrid1.Rows[e.RowIndex];
                Textbox_preName.Text = row.Cells["preName"].Value.ToString();
                label_cost.Text = row.Cells["costPrice"].Value.ToString();
                Textbox_salesPrice.Text = row.Cells["salesPrice"].Value.ToString();
                label_stocks.Text = row.Cells["stocks"].Value.ToString();
                label_relevel.Text = row.Cells["reorderLevel"].Value.ToString();
                label_cate.Text = row.Cells["category"].Value.ToString();
            }
        }

        private void Button_SavePayment_Click(object sender, EventArgs e)
        {
            if (Textbox_salesPrice.Text == "")
            {
                label_saleP.Visible = true;
                label_saleP.Text = "Sales Price is required!";
            }
            else if (app_Number.Value == 0)
            {
                label_qun.Visible = true;
                label_qun.Text = "Quantity is required!";
            }
            else
            {
                try
                {
                    DateTime date = DateTime.Now.Date;
                    string preName = Textbox_prescriptions.Text;
                    int costP = int.Parse(label_cost.Text);
                    int salesP = int.Parse(Textbox_salesPrice.Text);
                    int stock = int.Parse(label_stocks.Text);
                    int relevel = int.Parse(label_relevel.Text);
                    int quentity = int.Parse(app_Number.Text);
                    int total = int.Parse(Textbox_cost.Text);
                    string pNIC = Textbox_SearchNIC.Text;

                    //pass values for inventoryDetails query which include in SQLQueries class
                    sqlq.inventoryDetails(date, preName, costP, salesP, stock, relevel, quentity, total, pNIC);
                    Message1 pr = new Message1();
                    pr.label1.Text = "Details Added Successfully!";
                    pr.label1.Location = new System.Drawing.Point(60, 200);
                    pr.Show();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Please Check The Values" + ex, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
