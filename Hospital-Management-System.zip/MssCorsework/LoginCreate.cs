﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MssCorsework
{
    public partial class LoginCreate : Form
    {
        public LoginCreate()
        {
            InitializeComponent();
        }

        private void Btn_close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Btn_minimize_Click(object sender, EventArgs e)
        {
            //Minimize button
            this.WindowState = FormWindowState.Minimized;
        }

        private void Btn_Start_Click(object sender, EventArgs e)
        {
            loginControl1.BringToFront();
        }

        private void BunifuImageButton1_Click(object sender, EventArgs e)
        {
            introControl1.BringToFront();
        }

        private void Btn_CreateAccount_Click(object sender, EventArgs e)
        {
            registrationControl1.BringToFront();
        }
    }
}
