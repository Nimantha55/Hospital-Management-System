﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MssCorsework
{
    public partial class RegistrationControl : UserControl
    {
        public bool isCollapsed;

        public RegistrationControl()
        {
            InitializeComponent();
        }

        SQLQueries sqlq = new SQLQueries();
        AccountControl ac = new AccountControl();

        private void Timer1_Tick(object sender, EventArgs e)
        {
            if (isCollapsed)
            {
                panel_account.Height += 10;
                if (panel_account.Size == panel_account.MaximumSize)
                {
                    timer1.Stop();
                    isCollapsed = false;
                }
            }
            else
            {
                panel_account.Height -= 10;
                if (panel_account.Size == panel_account.MinimumSize)
                {
                    timer1.Stop();
                    isCollapsed = true;
                }
            }
        }

        private void clear()
        {
            Button_accountSelect.Text = "               Select Account Type";
            textBox_username.Text = "";
            textBox_password.Text = "";
        }

        private void Button_Register_Click(object sender, EventArgs e)
        {
            if (Button_accountSelect.Text == "               Select Account Type")
            {
                Label_error.Visible = true;
                Label_error.Text = "Account Type is Required!";
            }
            else if (textBox_username.Text == "")
            {
                Label_error.Visible = true;
                Label_error.Text = "Username is Required!";
            }
            else if (textBox_password.Text == "")
            {
                Label_error.Visible = true;
                Label_error.Text = "Password is Required!";
            }
            else if (textBox_confirmPassword.Text == "")
            {
                Label_error.Visible = true;
                Label_error.Text = "Conform Password is Required!";
            }
            else if (textBox_username.Text == "" && textBox_password.Text == "" && textBox_confirmPassword.Text == "")
            {
                Label_error.Visible = true;
                Label_error.Text = "Please Fill All Details!";
            }
            else if (textBox_password.Text != textBox_confirmPassword.Text)
            {
                Label_error.Visible = true;
                Label_error.Text = "Password and Confirm Password do not match!";
            }
            else
            {
                try
                {
                    string accountType = Button_accountSelect.Text;
                    string username = textBox_username.Text;
                    string password = textBox_password.Text;

                    //pass values for userRegistration query which include in SQLQueries class
                    sqlq.userRegistration(accountType, username, password);
                    this.clear();

                    SqlDataReader dr = sqlq.userLogins(username, password);
                    if (dr.Read())
                    {
                        Label_account.Text = dr[1].ToString();
                        lab_UN.Text = dr[2].ToString();
                        ac.username = lab_UN.Text;

                        if (Label_account.Text == "               Administrator")
                        {
                            ac.Admin();
                            this.ParentForm.Hide();
                        }
                        else if (Label_account.Text == "               Front Office Clerk")
                        {
                            ac.Clerk();
                            this.ParentForm.Hide();
                        }
                        else if (Label_account.Text == "               Doctors")
                        {
                            ac.Doctor();
                            this.ParentForm.Hide();
                        }
                        else if (Label_account.Text == "               Lab Technician")
                        {
                            ac.Technician();
                            this.ParentForm.Hide();
                        }
                        else if (Label_account.Text == "               Pharmacist")
                        {
                            ac.Pharmacist();
                            this.ParentForm.Hide();
                        }
                        else if (Label_account.Text == "               Assistant")
                        {
                            ac.Assistant();
                            this.ParentForm.Hide();
                        }
                    }
                }
                catch(Exception ex)
                {
                    MessageBox.Show("Please Check The Values" + ex, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                } 
            }
        }

        private void Button_admin_Click(object sender, EventArgs e)
        {
            Button_accountSelect.Text = "               Administrator";
            Button_accountSelect.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            Label_error.Visible = false;
        }

        private void Button_clerk_Click(object sender, EventArgs e)
        {
            Button_accountSelect.Text = "               Front Office Clerk";
            Button_accountSelect.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            Label_error.Visible = false;
        }

        private void Button_doctors_Click(object sender, EventArgs e)
        {
            Button_accountSelect.Text = "               Doctors";
            Button_accountSelect.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            Label_error.Visible = false;
        }

        private void Button_LabTechnician_Click(object sender, EventArgs e)
        {
            Button_accountSelect.Text = "               Lab Technician";
            Button_accountSelect.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            Label_error.Visible = false;
        }

        private void Button_Pharmacist_Click(object sender, EventArgs e)
        {
            Button_accountSelect.Text = "               Pharmacist";
            Button_accountSelect.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            Label_error.Visible = false;
        }

        private void Button_accountSelect_Click(object sender, EventArgs e)
        {
            timer1.Start();
            panel_account.BringToFront();
        }

        private void TextBox_username_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (textBox_username.Text != "")
            {
                Label_error.Visible = false;
            }
        }

        private void TextBox_password_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (textBox_password.Text != "")
            {
                Label_error.Visible = false;
            }
        }

        private void TextBox_confirmPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (textBox_confirmPassword.Text != "")
            {
                Label_error.Visible = false;
            }
        }

        private void Button_Assistant_Click(object sender, EventArgs e)
        {
            Button_accountSelect.Text = "               Assistant";
            Button_accountSelect.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            Label_error.Visible = false;
        }
    }
}
