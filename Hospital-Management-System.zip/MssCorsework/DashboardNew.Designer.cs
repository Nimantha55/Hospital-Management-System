﻿namespace MssCorsework
{
    partial class DashboardNew
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            BunifuAnimatorNS.Animation animation1 = new BunifuAnimatorNS.Animation();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DashboardNew));
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.panel_top = new System.Windows.Forms.Panel();
            this.pictureBox_online = new System.Windows.Forms.PictureBox();
            this.Label_User = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuImageButton1 = new Bunifu.Framework.UI.BunifuImageButton();
            this.label_time = new System.Windows.Forms.Label();
            this.label_Date = new System.Windows.Forms.Label();
            this.Label_timeTitle = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Label_dateTitle = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.Button_logOut = new Bunifu.Framework.UI.BunifuThinButton2();
            this.Button_maximize = new Bunifu.Framework.UI.BunifuImageButton();
            this.btn_close = new Bunifu.Framework.UI.BunifuImageButton();
            this.btn_minimize = new Bunifu.Framework.UI.BunifuImageButton();
            this.panel_left = new System.Windows.Forms.Panel();
            this.Separator_VDD = new Bunifu.Framework.UI.BunifuSeparator();
            this.Button_viewDiagnosisDetails = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Separator_RDD = new Bunifu.Framework.UI.BunifuSeparator();
            this.Button_addDiagnosisDetails = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Separator_UIP = new Bunifu.Framework.UI.BunifuSeparator();
            this.Button_updateInternalPatients = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Separator_PD = new Bunifu.Framework.UI.BunifuSeparator();
            this.Button_Payments = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Button_Inventory = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Separator_CRI = new Bunifu.Framework.UI.BunifuSeparator();
            this.panel_labReports = new System.Windows.Forms.Panel();
            this.Button_add = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Button_View = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Button_mangeLabReportDetails = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Separator_ID = new Bunifu.Framework.UI.BunifuSeparator();
            this.Separator2 = new Bunifu.Framework.UI.BunifuSeparator();
            this.Separator1 = new Bunifu.Framework.UI.BunifuSeparator();
            this.Button_createInventory = new Bunifu.Framework.UI.BunifuFlatButton();
            this.Button_showMenu = new Bunifu.Framework.UI.BunifuImageButton();
            this.Button_hideMenu = new Bunifu.Framework.UI.BunifuImageButton();
            this.Button_home = new Bunifu.Framework.UI.BunifuImageButton();
            this.Button_inventoryReport = new Bunifu.Framework.UI.BunifuFlatButton();
            this.timer_time = new System.Windows.Forms.Timer(this.components);
            this.menuTransition = new BunifuAnimatorNS.BunifuTransition(this.components);
            this.frontControl1 = new MssCorsework.FrontControl();
            this.addLabReportDetailsControl1 = new MssCorsework.addLabReportDetailsControl();
            this.viewLabReportsControl1 = new MssCorsework.viewLabReportsControl();
            this.pharmacyControl1 = new MssCorsework.pharmacyControl();
            this.displayInventoryControl1 = new MssCorsework.displayInventoryControl();
            this.internalPatientsControl1 = new MssCorsework.internalPatientsControl();
            this.updateInternalPatientsControl1 = new MssCorsework.UpdateInternalPatientsControl();
            this.patientHistoryManagementControl1 = new MssCorsework.patientHistoryManagementControl();
            this.viewDiagnosisDetailsControl1 = new MssCorsework.viewDiagnosisDetailsControl();
            this.viewInventoryControl1 = new MssCorsework.viewInventoryControl();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.dragControl1 = new Project_SDC.DragControl();
            this.panel_top.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_online)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Button_maximize)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_minimize)).BeginInit();
            this.panel_left.SuspendLayout();
            this.panel_labReports.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Button_showMenu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Button_hideMenu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Button_home)).BeginInit();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 5;
            this.bunifuElipse1.TargetControl = this;
            // 
            // panel_top
            // 
            this.panel_top.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.panel_top.Controls.Add(this.pictureBox_online);
            this.panel_top.Controls.Add(this.Label_User);
            this.panel_top.Controls.Add(this.bunifuImageButton1);
            this.panel_top.Controls.Add(this.label_time);
            this.panel_top.Controls.Add(this.label_Date);
            this.panel_top.Controls.Add(this.Label_timeTitle);
            this.panel_top.Controls.Add(this.Label_dateTitle);
            this.panel_top.Controls.Add(this.Button_logOut);
            this.panel_top.Controls.Add(this.Button_maximize);
            this.panel_top.Controls.Add(this.btn_close);
            this.panel_top.Controls.Add(this.btn_minimize);
            this.menuTransition.SetDecoration(this.panel_top, BunifuAnimatorNS.DecorationType.None);
            this.panel_top.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_top.Location = new System.Drawing.Point(0, 0);
            this.panel_top.Name = "panel_top";
            this.panel_top.Size = new System.Drawing.Size(1494, 54);
            this.panel_top.TabIndex = 1;
            // 
            // pictureBox_online
            // 
            this.pictureBox_online.BackColor = System.Drawing.Color.Transparent;
            this.menuTransition.SetDecoration(this.pictureBox_online, BunifuAnimatorNS.DecorationType.None);
            this.pictureBox_online.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox_online.Image")));
            this.pictureBox_online.Location = new System.Drawing.Point(64, 19);
            this.pictureBox_online.Name = "pictureBox_online";
            this.pictureBox_online.Size = new System.Drawing.Size(20, 20);
            this.pictureBox_online.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_online.TabIndex = 18;
            this.pictureBox_online.TabStop = false;
            // 
            // Label_User
            // 
            this.Label_User.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_User.AutoSize = true;
            this.Label_User.BackColor = System.Drawing.Color.Transparent;
            this.menuTransition.SetDecoration(this.Label_User, BunifuAnimatorNS.DecorationType.None);
            this.Label_User.Font = new System.Drawing.Font("Franklin Gothic Demi", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_User.ForeColor = System.Drawing.Color.White;
            this.Label_User.Location = new System.Drawing.Point(90, 18);
            this.Label_User.Name = "Label_User";
            this.Label_User.Size = new System.Drawing.Size(63, 24);
            this.Label_User.TabIndex = 17;
            this.Label_User.Text = "Admin";
            // 
            // bunifuImageButton1
            // 
            this.bunifuImageButton1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.bunifuImageButton1, BunifuAnimatorNS.DecorationType.None);
            this.bunifuImageButton1.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton1.Image")));
            this.bunifuImageButton1.ImageActive = null;
            this.bunifuImageButton1.Location = new System.Drawing.Point(18, 6);
            this.bunifuImageButton1.Name = "bunifuImageButton1";
            this.bunifuImageButton1.Size = new System.Drawing.Size(40, 40);
            this.bunifuImageButton1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bunifuImageButton1.TabIndex = 16;
            this.bunifuImageButton1.TabStop = false;
            this.bunifuImageButton1.Zoom = 10;
            // 
            // label_time
            // 
            this.label_time.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label_time.AutoSize = true;
            this.label_time.BackColor = System.Drawing.Color.Transparent;
            this.menuTransition.SetDecoration(this.label_time, BunifuAnimatorNS.DecorationType.None);
            this.label_time.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_time.ForeColor = System.Drawing.Color.White;
            this.label_time.Location = new System.Drawing.Point(887, 16);
            this.label_time.Name = "label_time";
            this.label_time.Size = new System.Drawing.Size(0, 24);
            this.label_time.TabIndex = 15;
            // 
            // label_Date
            // 
            this.label_Date.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label_Date.AutoSize = true;
            this.label_Date.BackColor = System.Drawing.Color.Transparent;
            this.menuTransition.SetDecoration(this.label_Date, BunifuAnimatorNS.DecorationType.None);
            this.label_Date.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_Date.ForeColor = System.Drawing.Color.White;
            this.label_Date.Location = new System.Drawing.Point(681, 16);
            this.label_Date.Name = "label_Date";
            this.label_Date.Size = new System.Drawing.Size(0, 24);
            this.label_Date.TabIndex = 14;
            // 
            // Label_timeTitle
            // 
            this.Label_timeTitle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_timeTitle.AutoSize = true;
            this.Label_timeTitle.BackColor = System.Drawing.Color.Transparent;
            this.menuTransition.SetDecoration(this.Label_timeTitle, BunifuAnimatorNS.DecorationType.None);
            this.Label_timeTitle.Font = new System.Drawing.Font("Franklin Gothic Demi", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_timeTitle.ForeColor = System.Drawing.Color.White;
            this.Label_timeTitle.Location = new System.Drawing.Point(610, 16);
            this.Label_timeTitle.Name = "Label_timeTitle";
            this.Label_timeTitle.Size = new System.Drawing.Size(65, 24);
            this.Label_timeTitle.TabIndex = 13;
            this.Label_timeTitle.Text = "Time : ";
            // 
            // Label_dateTitle
            // 
            this.Label_dateTitle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Label_dateTitle.AutoSize = true;
            this.Label_dateTitle.BackColor = System.Drawing.Color.Transparent;
            this.menuTransition.SetDecoration(this.Label_dateTitle, BunifuAnimatorNS.DecorationType.None);
            this.Label_dateTitle.Font = new System.Drawing.Font("Franklin Gothic Demi", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_dateTitle.ForeColor = System.Drawing.Color.White;
            this.Label_dateTitle.Location = new System.Drawing.Point(809, 16);
            this.Label_dateTitle.Name = "Label_dateTitle";
            this.Label_dateTitle.Size = new System.Drawing.Size(72, 24);
            this.Label_dateTitle.TabIndex = 12;
            this.Label_dateTitle.Text = "Today : ";
            // 
            // Button_logOut
            // 
            this.Button_logOut.ActiveBorderThickness = 1;
            this.Button_logOut.ActiveCornerRadius = 20;
            this.Button_logOut.ActiveFillColor = System.Drawing.Color.Transparent;
            this.Button_logOut.ActiveForecolor = System.Drawing.Color.Firebrick;
            this.Button_logOut.ActiveLineColor = System.Drawing.Color.Firebrick;
            this.Button_logOut.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.Button_logOut.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Button_logOut.BackgroundImage")));
            this.Button_logOut.ButtonText = "Log Out";
            this.Button_logOut.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.Button_logOut, BunifuAnimatorNS.DecorationType.None);
            this.Button_logOut.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_logOut.ForeColor = System.Drawing.Color.SeaGreen;
            this.Button_logOut.IdleBorderThickness = 1;
            this.Button_logOut.IdleCornerRadius = 20;
            this.Button_logOut.IdleFillColor = System.Drawing.Color.Transparent;
            this.Button_logOut.IdleForecolor = System.Drawing.Color.Teal;
            this.Button_logOut.IdleLineColor = System.Drawing.Color.Teal;
            this.Button_logOut.Location = new System.Drawing.Point(1244, 2);
            this.Button_logOut.Margin = new System.Windows.Forms.Padding(5);
            this.Button_logOut.Name = "Button_logOut";
            this.Button_logOut.Size = new System.Drawing.Size(110, 48);
            this.Button_logOut.TabIndex = 2;
            this.Button_logOut.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_logOut.Click += new System.EventHandler(this.Button_logOut_Click);
            // 
            // Button_maximize
            // 
            this.Button_maximize.BackColor = System.Drawing.Color.Transparent;
            this.Button_maximize.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.Button_maximize, BunifuAnimatorNS.DecorationType.None);
            this.Button_maximize.Image = ((System.Drawing.Image)(resources.GetObject("Button_maximize.Image")));
            this.Button_maximize.ImageActive = null;
            this.Button_maximize.Location = new System.Drawing.Point(1408, 6);
            this.Button_maximize.Name = "Button_maximize";
            this.Button_maximize.Size = new System.Drawing.Size(40, 40);
            this.Button_maximize.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Button_maximize.TabIndex = 4;
            this.Button_maximize.TabStop = false;
            this.Button_maximize.Zoom = 10;
            // 
            // btn_close
            // 
            this.btn_close.BackColor = System.Drawing.Color.Transparent;
            this.btn_close.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.btn_close, BunifuAnimatorNS.DecorationType.None);
            this.btn_close.Image = ((System.Drawing.Image)(resources.GetObject("btn_close.Image")));
            this.btn_close.ImageActive = null;
            this.btn_close.Location = new System.Drawing.Point(1449, 6);
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(40, 40);
            this.btn_close.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btn_close.TabIndex = 2;
            this.btn_close.TabStop = false;
            this.btn_close.Zoom = 10;
            this.btn_close.Click += new System.EventHandler(this.Btn_close_Click);
            // 
            // btn_minimize
            // 
            this.btn_minimize.BackColor = System.Drawing.Color.Transparent;
            this.btn_minimize.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.btn_minimize, BunifuAnimatorNS.DecorationType.None);
            this.btn_minimize.Image = ((System.Drawing.Image)(resources.GetObject("btn_minimize.Image")));
            this.btn_minimize.ImageActive = null;
            this.btn_minimize.Location = new System.Drawing.Point(1367, 6);
            this.btn_minimize.Name = "btn_minimize";
            this.btn_minimize.Size = new System.Drawing.Size(40, 40);
            this.btn_minimize.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btn_minimize.TabIndex = 3;
            this.btn_minimize.TabStop = false;
            this.btn_minimize.Zoom = 10;
            this.btn_minimize.Click += new System.EventHandler(this.Btn_minimize_Click);
            // 
            // panel_left
            // 
            this.panel_left.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.panel_left.Controls.Add(this.Separator_VDD);
            this.panel_left.Controls.Add(this.Button_viewDiagnosisDetails);
            this.panel_left.Controls.Add(this.Separator_RDD);
            this.panel_left.Controls.Add(this.Button_addDiagnosisDetails);
            this.panel_left.Controls.Add(this.Separator_UIP);
            this.panel_left.Controls.Add(this.Button_updateInternalPatients);
            this.panel_left.Controls.Add(this.Separator_PD);
            this.panel_left.Controls.Add(this.Button_Payments);
            this.panel_left.Controls.Add(this.Button_Inventory);
            this.panel_left.Controls.Add(this.Separator_CRI);
            this.panel_left.Controls.Add(this.panel_labReports);
            this.panel_left.Controls.Add(this.Separator_ID);
            this.panel_left.Controls.Add(this.Separator2);
            this.panel_left.Controls.Add(this.Separator1);
            this.panel_left.Controls.Add(this.Button_createInventory);
            this.panel_left.Controls.Add(this.Button_showMenu);
            this.panel_left.Controls.Add(this.Button_hideMenu);
            this.panel_left.Controls.Add(this.Button_home);
            this.panel_left.Controls.Add(this.Button_inventoryReport);
            this.menuTransition.SetDecoration(this.panel_left, BunifuAnimatorNS.DecorationType.None);
            this.panel_left.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_left.Location = new System.Drawing.Point(0, 54);
            this.panel_left.Name = "panel_left";
            this.panel_left.Size = new System.Drawing.Size(354, 812);
            this.panel_left.TabIndex = 2;
            // 
            // Separator_VDD
            // 
            this.Separator_VDD.BackColor = System.Drawing.Color.Transparent;
            this.menuTransition.SetDecoration(this.Separator_VDD, BunifuAnimatorNS.DecorationType.None);
            this.Separator_VDD.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.Separator_VDD.LineThickness = 2;
            this.Separator_VDD.Location = new System.Drawing.Point(5, 786);
            this.Separator_VDD.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Separator_VDD.Name = "Separator_VDD";
            this.Separator_VDD.Size = new System.Drawing.Size(343, 10);
            this.Separator_VDD.TabIndex = 96;
            this.Separator_VDD.Transparency = 255;
            this.Separator_VDD.Vertical = false;
            // 
            // Button_viewDiagnosisDetails
            // 
            this.Button_viewDiagnosisDetails.Activecolor = System.Drawing.Color.Transparent;
            this.Button_viewDiagnosisDetails.BackColor = System.Drawing.Color.Transparent;
            this.Button_viewDiagnosisDetails.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_viewDiagnosisDetails.BorderRadius = 0;
            this.Button_viewDiagnosisDetails.ButtonText = "           View Diagnosis Details";
            this.Button_viewDiagnosisDetails.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.Button_viewDiagnosisDetails, BunifuAnimatorNS.DecorationType.None);
            this.Button_viewDiagnosisDetails.DisabledColor = System.Drawing.Color.Gray;
            this.Button_viewDiagnosisDetails.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_viewDiagnosisDetails.Iconimage = ((System.Drawing.Image)(resources.GetObject("Button_viewDiagnosisDetails.Iconimage")));
            this.Button_viewDiagnosisDetails.Iconimage_right = null;
            this.Button_viewDiagnosisDetails.Iconimage_right_Selected = null;
            this.Button_viewDiagnosisDetails.Iconimage_Selected = null;
            this.Button_viewDiagnosisDetails.IconMarginLeft = 0;
            this.Button_viewDiagnosisDetails.IconMarginRight = 0;
            this.Button_viewDiagnosisDetails.IconRightVisible = true;
            this.Button_viewDiagnosisDetails.IconRightZoom = 0D;
            this.Button_viewDiagnosisDetails.IconVisible = true;
            this.Button_viewDiagnosisDetails.IconZoom = 60D;
            this.Button_viewDiagnosisDetails.IsTab = false;
            this.Button_viewDiagnosisDetails.Location = new System.Drawing.Point(5, 708);
            this.Button_viewDiagnosisDetails.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_viewDiagnosisDetails.Name = "Button_viewDiagnosisDetails";
            this.Button_viewDiagnosisDetails.Normalcolor = System.Drawing.Color.Transparent;
            this.Button_viewDiagnosisDetails.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.Button_viewDiagnosisDetails.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_viewDiagnosisDetails.selected = false;
            this.Button_viewDiagnosisDetails.Size = new System.Drawing.Size(343, 70);
            this.Button_viewDiagnosisDetails.TabIndex = 95;
            this.Button_viewDiagnosisDetails.Text = "           View Diagnosis Details";
            this.Button_viewDiagnosisDetails.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Button_viewDiagnosisDetails.Textcolor = System.Drawing.Color.White;
            this.Button_viewDiagnosisDetails.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_viewDiagnosisDetails.Click += new System.EventHandler(this.Button_viewDiagnosisDetails_Click);
            // 
            // Separator_RDD
            // 
            this.Separator_RDD.BackColor = System.Drawing.Color.Transparent;
            this.menuTransition.SetDecoration(this.Separator_RDD, BunifuAnimatorNS.DecorationType.None);
            this.Separator_RDD.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.Separator_RDD.LineThickness = 2;
            this.Separator_RDD.Location = new System.Drawing.Point(5, 690);
            this.Separator_RDD.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Separator_RDD.Name = "Separator_RDD";
            this.Separator_RDD.Size = new System.Drawing.Size(343, 10);
            this.Separator_RDD.TabIndex = 94;
            this.Separator_RDD.Transparency = 255;
            this.Separator_RDD.Vertical = false;
            // 
            // Button_addDiagnosisDetails
            // 
            this.Button_addDiagnosisDetails.Activecolor = System.Drawing.Color.Transparent;
            this.Button_addDiagnosisDetails.BackColor = System.Drawing.Color.Transparent;
            this.Button_addDiagnosisDetails.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_addDiagnosisDetails.BorderRadius = 0;
            this.Button_addDiagnosisDetails.ButtonText = "           Record Diagnosis Details";
            this.Button_addDiagnosisDetails.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.Button_addDiagnosisDetails, BunifuAnimatorNS.DecorationType.None);
            this.Button_addDiagnosisDetails.DisabledColor = System.Drawing.Color.Gray;
            this.Button_addDiagnosisDetails.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_addDiagnosisDetails.Iconimage = ((System.Drawing.Image)(resources.GetObject("Button_addDiagnosisDetails.Iconimage")));
            this.Button_addDiagnosisDetails.Iconimage_right = null;
            this.Button_addDiagnosisDetails.Iconimage_right_Selected = null;
            this.Button_addDiagnosisDetails.Iconimage_Selected = null;
            this.Button_addDiagnosisDetails.IconMarginLeft = 0;
            this.Button_addDiagnosisDetails.IconMarginRight = 0;
            this.Button_addDiagnosisDetails.IconRightVisible = true;
            this.Button_addDiagnosisDetails.IconRightZoom = 0D;
            this.Button_addDiagnosisDetails.IconVisible = true;
            this.Button_addDiagnosisDetails.IconZoom = 60D;
            this.Button_addDiagnosisDetails.IsTab = false;
            this.Button_addDiagnosisDetails.Location = new System.Drawing.Point(5, 612);
            this.Button_addDiagnosisDetails.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_addDiagnosisDetails.Name = "Button_addDiagnosisDetails";
            this.Button_addDiagnosisDetails.Normalcolor = System.Drawing.Color.Transparent;
            this.Button_addDiagnosisDetails.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.Button_addDiagnosisDetails.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_addDiagnosisDetails.selected = false;
            this.Button_addDiagnosisDetails.Size = new System.Drawing.Size(343, 70);
            this.Button_addDiagnosisDetails.TabIndex = 93;
            this.Button_addDiagnosisDetails.Text = "           Record Diagnosis Details";
            this.Button_addDiagnosisDetails.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Button_addDiagnosisDetails.Textcolor = System.Drawing.Color.White;
            this.Button_addDiagnosisDetails.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_addDiagnosisDetails.Click += new System.EventHandler(this.Button_addDiagnosisDetails_Click);
            // 
            // Separator_UIP
            // 
            this.Separator_UIP.BackColor = System.Drawing.Color.Transparent;
            this.menuTransition.SetDecoration(this.Separator_UIP, BunifuAnimatorNS.DecorationType.None);
            this.Separator_UIP.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.Separator_UIP.LineThickness = 2;
            this.Separator_UIP.Location = new System.Drawing.Point(5, 594);
            this.Separator_UIP.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Separator_UIP.Name = "Separator_UIP";
            this.Separator_UIP.Size = new System.Drawing.Size(343, 10);
            this.Separator_UIP.TabIndex = 89;
            this.Separator_UIP.Transparency = 255;
            this.Separator_UIP.Vertical = false;
            // 
            // Button_updateInternalPatients
            // 
            this.Button_updateInternalPatients.Activecolor = System.Drawing.Color.Transparent;
            this.Button_updateInternalPatients.BackColor = System.Drawing.Color.Transparent;
            this.Button_updateInternalPatients.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_updateInternalPatients.BorderRadius = 0;
            this.Button_updateInternalPatients.ButtonText = "           Payment Details";
            this.Button_updateInternalPatients.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.Button_updateInternalPatients, BunifuAnimatorNS.DecorationType.None);
            this.Button_updateInternalPatients.DisabledColor = System.Drawing.Color.Gray;
            this.Button_updateInternalPatients.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_updateInternalPatients.Iconimage = ((System.Drawing.Image)(resources.GetObject("Button_updateInternalPatients.Iconimage")));
            this.Button_updateInternalPatients.Iconimage_right = null;
            this.Button_updateInternalPatients.Iconimage_right_Selected = null;
            this.Button_updateInternalPatients.Iconimage_Selected = null;
            this.Button_updateInternalPatients.IconMarginLeft = 0;
            this.Button_updateInternalPatients.IconMarginRight = 0;
            this.Button_updateInternalPatients.IconRightVisible = true;
            this.Button_updateInternalPatients.IconRightZoom = 0D;
            this.Button_updateInternalPatients.IconVisible = true;
            this.Button_updateInternalPatients.IconZoom = 50D;
            this.Button_updateInternalPatients.IsTab = false;
            this.Button_updateInternalPatients.Location = new System.Drawing.Point(5, 516);
            this.Button_updateInternalPatients.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_updateInternalPatients.Name = "Button_updateInternalPatients";
            this.Button_updateInternalPatients.Normalcolor = System.Drawing.Color.Transparent;
            this.Button_updateInternalPatients.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.Button_updateInternalPatients.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_updateInternalPatients.selected = false;
            this.Button_updateInternalPatients.Size = new System.Drawing.Size(343, 70);
            this.Button_updateInternalPatients.TabIndex = 88;
            this.Button_updateInternalPatients.Text = "           Payment Details";
            this.Button_updateInternalPatients.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Button_updateInternalPatients.Textcolor = System.Drawing.Color.White;
            this.Button_updateInternalPatients.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_updateInternalPatients.Click += new System.EventHandler(this.Button_updateInternalPatients_Click);
            // 
            // Separator_PD
            // 
            this.Separator_PD.BackColor = System.Drawing.Color.Transparent;
            this.menuTransition.SetDecoration(this.Separator_PD, BunifuAnimatorNS.DecorationType.None);
            this.Separator_PD.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.Separator_PD.LineThickness = 2;
            this.Separator_PD.Location = new System.Drawing.Point(5, 498);
            this.Separator_PD.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Separator_PD.Name = "Separator_PD";
            this.Separator_PD.Size = new System.Drawing.Size(343, 10);
            this.Separator_PD.TabIndex = 87;
            this.Separator_PD.Transparency = 255;
            this.Separator_PD.Vertical = false;
            // 
            // Button_Payments
            // 
            this.Button_Payments.Activecolor = System.Drawing.Color.Transparent;
            this.Button_Payments.BackColor = System.Drawing.Color.Transparent;
            this.Button_Payments.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_Payments.BorderRadius = 0;
            this.Button_Payments.ButtonText = "           Payment Details";
            this.Button_Payments.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.Button_Payments, BunifuAnimatorNS.DecorationType.None);
            this.Button_Payments.DisabledColor = System.Drawing.Color.Gray;
            this.Button_Payments.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_Payments.Iconimage = ((System.Drawing.Image)(resources.GetObject("Button_Payments.Iconimage")));
            this.Button_Payments.Iconimage_right = null;
            this.Button_Payments.Iconimage_right_Selected = null;
            this.Button_Payments.Iconimage_Selected = null;
            this.Button_Payments.IconMarginLeft = 0;
            this.Button_Payments.IconMarginRight = 0;
            this.Button_Payments.IconRightVisible = true;
            this.Button_Payments.IconRightZoom = 0D;
            this.Button_Payments.IconVisible = true;
            this.Button_Payments.IconZoom = 50D;
            this.Button_Payments.IsTab = false;
            this.Button_Payments.Location = new System.Drawing.Point(5, 420);
            this.Button_Payments.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_Payments.Name = "Button_Payments";
            this.Button_Payments.Normalcolor = System.Drawing.Color.Transparent;
            this.Button_Payments.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.Button_Payments.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_Payments.selected = false;
            this.Button_Payments.Size = new System.Drawing.Size(343, 70);
            this.Button_Payments.TabIndex = 86;
            this.Button_Payments.Text = "           Payment Details";
            this.Button_Payments.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Button_Payments.Textcolor = System.Drawing.Color.White;
            this.Button_Payments.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Payments.Click += new System.EventHandler(this.Button_Payments_Click);
            // 
            // Button_Inventory
            // 
            this.Button_Inventory.Activecolor = System.Drawing.Color.Transparent;
            this.Button_Inventory.BackColor = System.Drawing.Color.Transparent;
            this.Button_Inventory.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_Inventory.BorderRadius = 0;
            this.Button_Inventory.ButtonText = "Inventory Details";
            this.Button_Inventory.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.Button_Inventory, BunifuAnimatorNS.DecorationType.None);
            this.Button_Inventory.DisabledColor = System.Drawing.Color.Gray;
            this.Button_Inventory.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_Inventory.Iconimage = ((System.Drawing.Image)(resources.GetObject("Button_Inventory.Iconimage")));
            this.Button_Inventory.Iconimage_right = null;
            this.Button_Inventory.Iconimage_right_Selected = null;
            this.Button_Inventory.Iconimage_Selected = null;
            this.Button_Inventory.IconMarginLeft = 0;
            this.Button_Inventory.IconMarginRight = 0;
            this.Button_Inventory.IconRightVisible = true;
            this.Button_Inventory.IconRightZoom = 0D;
            this.Button_Inventory.IconVisible = true;
            this.Button_Inventory.IconZoom = 60D;
            this.Button_Inventory.IsTab = false;
            this.Button_Inventory.Location = new System.Drawing.Point(8, 228);
            this.Button_Inventory.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_Inventory.Name = "Button_Inventory";
            this.Button_Inventory.Normalcolor = System.Drawing.Color.Transparent;
            this.Button_Inventory.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.Button_Inventory.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_Inventory.selected = false;
            this.Button_Inventory.Size = new System.Drawing.Size(339, 70);
            this.Button_Inventory.TabIndex = 79;
            this.Button_Inventory.Text = "Inventory Details";
            this.Button_Inventory.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_Inventory.Textcolor = System.Drawing.Color.White;
            this.Button_Inventory.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Inventory.Click += new System.EventHandler(this.Button_Inventory_Click);
            // 
            // Separator_CRI
            // 
            this.Separator_CRI.BackColor = System.Drawing.Color.Transparent;
            this.menuTransition.SetDecoration(this.Separator_CRI, BunifuAnimatorNS.DecorationType.None);
            this.Separator_CRI.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.Separator_CRI.LineThickness = 2;
            this.Separator_CRI.Location = new System.Drawing.Point(5, 402);
            this.Separator_CRI.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Separator_CRI.Name = "Separator_CRI";
            this.Separator_CRI.Size = new System.Drawing.Size(343, 10);
            this.Separator_CRI.TabIndex = 85;
            this.Separator_CRI.Transparency = 255;
            this.Separator_CRI.Vertical = false;
            // 
            // panel_labReports
            // 
            this.panel_labReports.BackColor = System.Drawing.Color.Transparent;
            this.panel_labReports.Controls.Add(this.Button_add);
            this.panel_labReports.Controls.Add(this.Button_View);
            this.panel_labReports.Controls.Add(this.Button_mangeLabReportDetails);
            this.menuTransition.SetDecoration(this.panel_labReports, BunifuAnimatorNS.DecorationType.None);
            this.panel_labReports.Location = new System.Drawing.Point(5, 131);
            this.panel_labReports.MaximumSize = new System.Drawing.Size(343, 167);
            this.panel_labReports.MinimumSize = new System.Drawing.Size(343, 72);
            this.panel_labReports.Name = "panel_labReports";
            this.panel_labReports.Size = new System.Drawing.Size(343, 72);
            this.panel_labReports.TabIndex = 66;
            // 
            // Button_add
            // 
            this.Button_add.Activecolor = System.Drawing.Color.SteelBlue;
            this.Button_add.BackColor = System.Drawing.Color.SteelBlue;
            this.Button_add.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_add.BorderRadius = 0;
            this.Button_add.ButtonText = "Add New Lab Report Details";
            this.Button_add.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.Button_add, BunifuAnimatorNS.DecorationType.None);
            this.Button_add.DisabledColor = System.Drawing.Color.Gray;
            this.Button_add.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_add.Iconimage = null;
            this.Button_add.Iconimage_right = null;
            this.Button_add.Iconimage_right_Selected = null;
            this.Button_add.Iconimage_Selected = null;
            this.Button_add.IconMarginLeft = 0;
            this.Button_add.IconMarginRight = 0;
            this.Button_add.IconRightVisible = true;
            this.Button_add.IconRightZoom = 0D;
            this.Button_add.IconVisible = true;
            this.Button_add.IconZoom = 90D;
            this.Button_add.IsTab = false;
            this.Button_add.Location = new System.Drawing.Point(0, 76);
            this.Button_add.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_add.Name = "Button_add";
            this.Button_add.Normalcolor = System.Drawing.Color.SteelBlue;
            this.Button_add.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.Button_add.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_add.selected = false;
            this.Button_add.Size = new System.Drawing.Size(343, 42);
            this.Button_add.TabIndex = 25;
            this.Button_add.Text = "Add New Lab Report Details";
            this.Button_add.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_add.Textcolor = System.Drawing.Color.White;
            this.Button_add.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_add.Click += new System.EventHandler(this.Button_add_Click);
            // 
            // Button_View
            // 
            this.Button_View.Activecolor = System.Drawing.Color.SteelBlue;
            this.Button_View.BackColor = System.Drawing.Color.SteelBlue;
            this.Button_View.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_View.BorderRadius = 0;
            this.Button_View.ButtonText = "View Lab Report Details";
            this.Button_View.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.Button_View, BunifuAnimatorNS.DecorationType.None);
            this.Button_View.DisabledColor = System.Drawing.Color.Gray;
            this.Button_View.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_View.Iconimage = null;
            this.Button_View.Iconimage_right = null;
            this.Button_View.Iconimage_right_Selected = null;
            this.Button_View.Iconimage_Selected = null;
            this.Button_View.IconMarginLeft = 0;
            this.Button_View.IconMarginRight = 0;
            this.Button_View.IconRightVisible = true;
            this.Button_View.IconRightZoom = 0D;
            this.Button_View.IconVisible = true;
            this.Button_View.IconZoom = 90D;
            this.Button_View.IsTab = false;
            this.Button_View.Location = new System.Drawing.Point(0, 121);
            this.Button_View.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_View.Name = "Button_View";
            this.Button_View.Normalcolor = System.Drawing.Color.SteelBlue;
            this.Button_View.OnHovercolor = System.Drawing.Color.SlateBlue;
            this.Button_View.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_View.selected = false;
            this.Button_View.Size = new System.Drawing.Size(343, 42);
            this.Button_View.TabIndex = 26;
            this.Button_View.Text = "View Lab Report Details";
            this.Button_View.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_View.Textcolor = System.Drawing.Color.White;
            this.Button_View.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_View.Click += new System.EventHandler(this.Button_View_Click);
            // 
            // Button_mangeLabReportDetails
            // 
            this.Button_mangeLabReportDetails.Activecolor = System.Drawing.Color.Transparent;
            this.Button_mangeLabReportDetails.BackColor = System.Drawing.Color.Transparent;
            this.Button_mangeLabReportDetails.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_mangeLabReportDetails.BorderRadius = 0;
            this.Button_mangeLabReportDetails.ButtonText = "         Manage Report Details";
            this.Button_mangeLabReportDetails.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.Button_mangeLabReportDetails, BunifuAnimatorNS.DecorationType.None);
            this.Button_mangeLabReportDetails.DisabledColor = System.Drawing.Color.Gray;
            this.Button_mangeLabReportDetails.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_mangeLabReportDetails.Iconimage = ((System.Drawing.Image)(resources.GetObject("Button_mangeLabReportDetails.Iconimage")));
            this.Button_mangeLabReportDetails.Iconimage_right = null;
            this.Button_mangeLabReportDetails.Iconimage_right_Selected = null;
            this.Button_mangeLabReportDetails.Iconimage_Selected = null;
            this.Button_mangeLabReportDetails.IconMarginLeft = 0;
            this.Button_mangeLabReportDetails.IconMarginRight = 0;
            this.Button_mangeLabReportDetails.IconRightVisible = true;
            this.Button_mangeLabReportDetails.IconRightZoom = 0D;
            this.Button_mangeLabReportDetails.IconVisible = true;
            this.Button_mangeLabReportDetails.IconZoom = 60D;
            this.Button_mangeLabReportDetails.IsTab = false;
            this.Button_mangeLabReportDetails.Location = new System.Drawing.Point(3, 1);
            this.Button_mangeLabReportDetails.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_mangeLabReportDetails.Name = "Button_mangeLabReportDetails";
            this.Button_mangeLabReportDetails.Normalcolor = System.Drawing.Color.Transparent;
            this.Button_mangeLabReportDetails.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.Button_mangeLabReportDetails.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_mangeLabReportDetails.selected = false;
            this.Button_mangeLabReportDetails.Size = new System.Drawing.Size(339, 70);
            this.Button_mangeLabReportDetails.TabIndex = 79;
            this.Button_mangeLabReportDetails.Text = "         Manage Report Details";
            this.Button_mangeLabReportDetails.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.Button_mangeLabReportDetails.Textcolor = System.Drawing.Color.White;
            this.Button_mangeLabReportDetails.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_mangeLabReportDetails.Click += new System.EventHandler(this.Button_mangeLabReportDetails_Click);
            // 
            // Separator_ID
            // 
            this.Separator_ID.BackColor = System.Drawing.Color.Transparent;
            this.menuTransition.SetDecoration(this.Separator_ID, BunifuAnimatorNS.DecorationType.None);
            this.Separator_ID.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.Separator_ID.LineThickness = 2;
            this.Separator_ID.Location = new System.Drawing.Point(5, 306);
            this.Separator_ID.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Separator_ID.Name = "Separator_ID";
            this.Separator_ID.Size = new System.Drawing.Size(343, 10);
            this.Separator_ID.TabIndex = 83;
            this.Separator_ID.Transparency = 255;
            this.Separator_ID.Vertical = false;
            // 
            // Separator2
            // 
            this.Separator2.BackColor = System.Drawing.Color.Transparent;
            this.menuTransition.SetDecoration(this.Separator2, BunifuAnimatorNS.DecorationType.None);
            this.Separator2.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.Separator2.LineThickness = 2;
            this.Separator2.Location = new System.Drawing.Point(5, 114);
            this.Separator2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Separator2.Name = "Separator2";
            this.Separator2.Size = new System.Drawing.Size(343, 10);
            this.Separator2.TabIndex = 82;
            this.Separator2.Transparency = 255;
            this.Separator2.Vertical = false;
            // 
            // Separator1
            // 
            this.Separator1.BackColor = System.Drawing.Color.Transparent;
            this.menuTransition.SetDecoration(this.Separator1, BunifuAnimatorNS.DecorationType.None);
            this.Separator1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(105)))), ((int)(((byte)(105)))));
            this.Separator1.LineThickness = 2;
            this.Separator1.Location = new System.Drawing.Point(5, 210);
            this.Separator1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Separator1.Name = "Separator1";
            this.Separator1.Size = new System.Drawing.Size(343, 10);
            this.Separator1.TabIndex = 81;
            this.Separator1.Transparency = 255;
            this.Separator1.Vertical = false;
            // 
            // Button_createInventory
            // 
            this.Button_createInventory.Activecolor = System.Drawing.Color.Transparent;
            this.Button_createInventory.BackColor = System.Drawing.Color.Transparent;
            this.Button_createInventory.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_createInventory.BorderRadius = 0;
            this.Button_createInventory.ButtonText = "           Create Receipt Inventory";
            this.Button_createInventory.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.Button_createInventory, BunifuAnimatorNS.DecorationType.None);
            this.Button_createInventory.DisabledColor = System.Drawing.Color.Gray;
            this.Button_createInventory.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_createInventory.Iconimage = ((System.Drawing.Image)(resources.GetObject("Button_createInventory.Iconimage")));
            this.Button_createInventory.Iconimage_right = null;
            this.Button_createInventory.Iconimage_right_Selected = null;
            this.Button_createInventory.Iconimage_Selected = null;
            this.Button_createInventory.IconMarginLeft = 0;
            this.Button_createInventory.IconMarginRight = 0;
            this.Button_createInventory.IconRightVisible = true;
            this.Button_createInventory.IconRightZoom = 0D;
            this.Button_createInventory.IconVisible = true;
            this.Button_createInventory.IconZoom = 50D;
            this.Button_createInventory.IsTab = false;
            this.Button_createInventory.Location = new System.Drawing.Point(5, 324);
            this.Button_createInventory.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_createInventory.Name = "Button_createInventory";
            this.Button_createInventory.Normalcolor = System.Drawing.Color.Transparent;
            this.Button_createInventory.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.Button_createInventory.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_createInventory.selected = false;
            this.Button_createInventory.Size = new System.Drawing.Size(343, 70);
            this.Button_createInventory.TabIndex = 80;
            this.Button_createInventory.Text = "           Create Receipt Inventory";
            this.Button_createInventory.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Button_createInventory.Textcolor = System.Drawing.Color.White;
            this.Button_createInventory.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_createInventory.Click += new System.EventHandler(this.Button_Appointments_Click);
            // 
            // Button_showMenu
            // 
            this.Button_showMenu.BackColor = System.Drawing.Color.Transparent;
            this.Button_showMenu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.Button_showMenu, BunifuAnimatorNS.DecorationType.None);
            this.Button_showMenu.Image = ((System.Drawing.Image)(resources.GetObject("Button_showMenu.Image")));
            this.Button_showMenu.ImageActive = null;
            this.Button_showMenu.Location = new System.Drawing.Point(18, 10);
            this.Button_showMenu.Name = "Button_showMenu";
            this.Button_showMenu.Size = new System.Drawing.Size(43, 40);
            this.Button_showMenu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Button_showMenu.TabIndex = 78;
            this.Button_showMenu.TabStop = false;
            this.Button_showMenu.Visible = false;
            this.Button_showMenu.Zoom = 10;
            this.Button_showMenu.Click += new System.EventHandler(this.Button_showMenu_Click);
            // 
            // Button_hideMenu
            // 
            this.Button_hideMenu.BackColor = System.Drawing.Color.Transparent;
            this.Button_hideMenu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.Button_hideMenu, BunifuAnimatorNS.DecorationType.None);
            this.Button_hideMenu.Image = ((System.Drawing.Image)(resources.GetObject("Button_hideMenu.Image")));
            this.Button_hideMenu.ImageActive = null;
            this.Button_hideMenu.Location = new System.Drawing.Point(299, 10);
            this.Button_hideMenu.Name = "Button_hideMenu";
            this.Button_hideMenu.Size = new System.Drawing.Size(43, 40);
            this.Button_hideMenu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Button_hideMenu.TabIndex = 77;
            this.Button_hideMenu.TabStop = false;
            this.Button_hideMenu.Zoom = 10;
            this.Button_hideMenu.Click += new System.EventHandler(this.Button_hideMenu_Click);
            // 
            // Button_home
            // 
            this.Button_home.BackColor = System.Drawing.Color.Transparent;
            this.Button_home.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.Button_home, BunifuAnimatorNS.DecorationType.None);
            this.Button_home.Image = ((System.Drawing.Image)(resources.GetObject("Button_home.Image")));
            this.Button_home.ImageActive = null;
            this.Button_home.Location = new System.Drawing.Point(238, 10);
            this.Button_home.Name = "Button_home";
            this.Button_home.Size = new System.Drawing.Size(43, 40);
            this.Button_home.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Button_home.TabIndex = 24;
            this.Button_home.TabStop = false;
            this.Button_home.Zoom = 10;
            // 
            // Button_inventoryReport
            // 
            this.Button_inventoryReport.Activecolor = System.Drawing.Color.Transparent;
            this.Button_inventoryReport.BackColor = System.Drawing.Color.Transparent;
            this.Button_inventoryReport.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Button_inventoryReport.BorderRadius = 0;
            this.Button_inventoryReport.ButtonText = "           Create Receipt Inventory ";
            this.Button_inventoryReport.Cursor = System.Windows.Forms.Cursors.Hand;
            this.menuTransition.SetDecoration(this.Button_inventoryReport, BunifuAnimatorNS.DecorationType.None);
            this.Button_inventoryReport.DisabledColor = System.Drawing.Color.Gray;
            this.Button_inventoryReport.Iconcolor = System.Drawing.Color.Transparent;
            this.Button_inventoryReport.Iconimage = ((System.Drawing.Image)(resources.GetObject("Button_inventoryReport.Iconimage")));
            this.Button_inventoryReport.Iconimage_right = null;
            this.Button_inventoryReport.Iconimage_right_Selected = null;
            this.Button_inventoryReport.Iconimage_Selected = null;
            this.Button_inventoryReport.IconMarginLeft = 0;
            this.Button_inventoryReport.IconMarginRight = 0;
            this.Button_inventoryReport.IconRightVisible = true;
            this.Button_inventoryReport.IconRightZoom = 0D;
            this.Button_inventoryReport.IconVisible = true;
            this.Button_inventoryReport.IconZoom = 60D;
            this.Button_inventoryReport.IsTab = false;
            this.Button_inventoryReport.Location = new System.Drawing.Point(5, 708);
            this.Button_inventoryReport.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_inventoryReport.Name = "Button_inventoryReport";
            this.Button_inventoryReport.Normalcolor = System.Drawing.Color.Transparent;
            this.Button_inventoryReport.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(17)))), ((int)(((byte)(17)))), ((int)(((byte)(17)))));
            this.Button_inventoryReport.OnHoverTextColor = System.Drawing.Color.White;
            this.Button_inventoryReport.selected = false;
            this.Button_inventoryReport.Size = new System.Drawing.Size(343, 70);
            this.Button_inventoryReport.TabIndex = 97;
            this.Button_inventoryReport.Text = "           Create Receipt Inventory ";
            this.Button_inventoryReport.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Button_inventoryReport.Textcolor = System.Drawing.Color.White;
            this.Button_inventoryReport.TextFont = new System.Drawing.Font("Microsoft YaHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_inventoryReport.Click += new System.EventHandler(this.Button_inventoryReport_Click);
            // 
            // timer_time
            // 
            this.timer_time.Tick += new System.EventHandler(this.Timer_time_Tick);
            // 
            // menuTransition
            // 
            this.menuTransition.AnimationType = BunifuAnimatorNS.AnimationType.VertSlide;
            this.menuTransition.Cursor = null;
            animation1.AnimateOnlyDifferences = true;
            animation1.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.BlindCoeff")));
            animation1.LeafCoeff = 0F;
            animation1.MaxTime = 1F;
            animation1.MinTime = 0F;
            animation1.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.MosaicCoeff")));
            animation1.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation1.MosaicShift")));
            animation1.MosaicSize = 0;
            animation1.Padding = new System.Windows.Forms.Padding(0);
            animation1.RotateCoeff = 0F;
            animation1.RotateLimit = 0F;
            animation1.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.ScaleCoeff")));
            animation1.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation1.SlideCoeff")));
            animation1.TimeCoeff = 0F;
            animation1.TransparencyCoeff = 0F;
            this.menuTransition.DefaultAnimation = animation1;
            // 
            // frontControl1
            // 
            this.menuTransition.SetDecoration(this.frontControl1, BunifuAnimatorNS.DecorationType.None);
            this.frontControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.frontControl1.Location = new System.Drawing.Point(354, 54);
            this.frontControl1.Name = "frontControl1";
            this.frontControl1.Size = new System.Drawing.Size(1140, 812);
            this.frontControl1.TabIndex = 3;
            // 
            // addLabReportDetailsControl1
            // 
            this.menuTransition.SetDecoration(this.addLabReportDetailsControl1, BunifuAnimatorNS.DecorationType.None);
            this.addLabReportDetailsControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.addLabReportDetailsControl1.Location = new System.Drawing.Point(0, 0);
            this.addLabReportDetailsControl1.Name = "addLabReportDetailsControl1";
            this.addLabReportDetailsControl1.Size = new System.Drawing.Size(1494, 866);
            this.addLabReportDetailsControl1.TabIndex = 4;
            // 
            // viewLabReportsControl1
            // 
            this.menuTransition.SetDecoration(this.viewLabReportsControl1, BunifuAnimatorNS.DecorationType.None);
            this.viewLabReportsControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.viewLabReportsControl1.Location = new System.Drawing.Point(0, 0);
            this.viewLabReportsControl1.Name = "viewLabReportsControl1";
            this.viewLabReportsControl1.Size = new System.Drawing.Size(1494, 866);
            this.viewLabReportsControl1.TabIndex = 5;
            // 
            // pharmacyControl1
            // 
            this.menuTransition.SetDecoration(this.pharmacyControl1, BunifuAnimatorNS.DecorationType.None);
            this.pharmacyControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pharmacyControl1.Location = new System.Drawing.Point(0, 0);
            this.pharmacyControl1.Name = "pharmacyControl1";
            this.pharmacyControl1.Size = new System.Drawing.Size(1494, 866);
            this.pharmacyControl1.TabIndex = 6;
            // 
            // displayInventoryControl1
            // 
            this.menuTransition.SetDecoration(this.displayInventoryControl1, BunifuAnimatorNS.DecorationType.None);
            this.displayInventoryControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.displayInventoryControl1.Location = new System.Drawing.Point(0, 0);
            this.displayInventoryControl1.Name = "displayInventoryControl1";
            this.displayInventoryControl1.Size = new System.Drawing.Size(1494, 866);
            this.displayInventoryControl1.TabIndex = 7;
            // 
            // internalPatientsControl1
            // 
            this.menuTransition.SetDecoration(this.internalPatientsControl1, BunifuAnimatorNS.DecorationType.None);
            this.internalPatientsControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.internalPatientsControl1.Location = new System.Drawing.Point(0, 0);
            this.internalPatientsControl1.Name = "internalPatientsControl1";
            this.internalPatientsControl1.Size = new System.Drawing.Size(1494, 866);
            this.internalPatientsControl1.TabIndex = 8;
            // 
            // updateInternalPatientsControl1
            // 
            this.menuTransition.SetDecoration(this.updateInternalPatientsControl1, BunifuAnimatorNS.DecorationType.None);
            this.updateInternalPatientsControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.updateInternalPatientsControl1.Location = new System.Drawing.Point(0, 0);
            this.updateInternalPatientsControl1.Name = "updateInternalPatientsControl1";
            this.updateInternalPatientsControl1.Size = new System.Drawing.Size(1494, 866);
            this.updateInternalPatientsControl1.TabIndex = 9;
            // 
            // patientHistoryManagementControl1
            // 
            this.menuTransition.SetDecoration(this.patientHistoryManagementControl1, BunifuAnimatorNS.DecorationType.None);
            this.patientHistoryManagementControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.patientHistoryManagementControl1.Location = new System.Drawing.Point(0, 0);
            this.patientHistoryManagementControl1.Name = "patientHistoryManagementControl1";
            this.patientHistoryManagementControl1.Size = new System.Drawing.Size(1494, 866);
            this.patientHistoryManagementControl1.TabIndex = 10;
            // 
            // viewDiagnosisDetailsControl1
            // 
            this.menuTransition.SetDecoration(this.viewDiagnosisDetailsControl1, BunifuAnimatorNS.DecorationType.None);
            this.viewDiagnosisDetailsControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.viewDiagnosisDetailsControl1.Location = new System.Drawing.Point(0, 0);
            this.viewDiagnosisDetailsControl1.Name = "viewDiagnosisDetailsControl1";
            this.viewDiagnosisDetailsControl1.Size = new System.Drawing.Size(1494, 866);
            this.viewDiagnosisDetailsControl1.TabIndex = 11;
            // 
            // viewInventoryControl1
            // 
            this.menuTransition.SetDecoration(this.viewInventoryControl1, BunifuAnimatorNS.DecorationType.None);
            this.viewInventoryControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.viewInventoryControl1.Location = new System.Drawing.Point(0, 0);
            this.viewInventoryControl1.Name = "viewInventoryControl1";
            this.viewInventoryControl1.Size = new System.Drawing.Size(1494, 866);
            this.viewInventoryControl1.TabIndex = 12;
            // 
            // timer1
            // 
            this.timer1.Interval = 1;
            this.timer1.Tick += new System.EventHandler(this.Timer1_Tick);
            // 
            // dragControl1
            // 
            this.dragControl1.SelectControl = null;
            // 
            // DashboardNew
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1494, 866);
            this.Controls.Add(this.frontControl1);
            this.Controls.Add(this.panel_left);
            this.Controls.Add(this.panel_top);
            this.Controls.Add(this.addLabReportDetailsControl1);
            this.Controls.Add(this.viewLabReportsControl1);
            this.Controls.Add(this.pharmacyControl1);
            this.Controls.Add(this.displayInventoryControl1);
            this.Controls.Add(this.internalPatientsControl1);
            this.Controls.Add(this.updateInternalPatientsControl1);
            this.Controls.Add(this.patientHistoryManagementControl1);
            this.Controls.Add(this.viewDiagnosisDetailsControl1);
            this.Controls.Add(this.viewInventoryControl1);
            this.menuTransition.SetDecoration(this, BunifuAnimatorNS.DecorationType.None);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "DashboardNew";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DashboardNew";
            this.Load += new System.EventHandler(this.DashboardNew_Load);
            this.panel_top.ResumeLayout(false);
            this.panel_top.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_online)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Button_maximize)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_minimize)).EndInit();
            this.panel_left.ResumeLayout(false);
            this.panel_labReports.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Button_showMenu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Button_hideMenu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Button_home)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private Project_SDC.DragControl dragControl1;
        private System.Windows.Forms.Panel panel_top;
        private System.Windows.Forms.PictureBox pictureBox_online;
        public Bunifu.Framework.UI.BunifuCustomLabel Label_User;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton1;
        private System.Windows.Forms.Label label_time;
        private System.Windows.Forms.Label label_Date;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_timeTitle;
        private Bunifu.Framework.UI.BunifuCustomLabel Label_dateTitle;
        private Bunifu.Framework.UI.BunifuThinButton2 Button_logOut;
        private Bunifu.Framework.UI.BunifuImageButton Button_maximize;
        private Bunifu.Framework.UI.BunifuImageButton btn_close;
        private Bunifu.Framework.UI.BunifuImageButton btn_minimize;
        private System.Windows.Forms.Panel panel_left;
        public Bunifu.Framework.UI.BunifuFlatButton Button_add;
        public Bunifu.Framework.UI.BunifuFlatButton Button_View;
        private Bunifu.Framework.UI.BunifuFlatButton Button_mangeLabReportDetails;
        private Bunifu.Framework.UI.BunifuSeparator Separator2;
        public Bunifu.Framework.UI.BunifuImageButton Button_showMenu;
        public Bunifu.Framework.UI.BunifuImageButton Button_hideMenu;
        private Bunifu.Framework.UI.BunifuImageButton Button_home;
        private FrontControl frontControl1;
        private System.Windows.Forms.Timer timer_time;
        private BunifuAnimatorNS.BunifuTransition menuTransition;
        private System.Windows.Forms.Timer timer1;
        private addLabReportDetailsControl addLabReportDetailsControl1;
        private viewLabReportsControl viewLabReportsControl1;
        private pharmacyControl pharmacyControl1;
        private displayInventoryControl displayInventoryControl1;
        private internalPatientsControl internalPatientsControl1;
        private UpdateInternalPatientsControl updateInternalPatientsControl1;
        public Bunifu.Framework.UI.BunifuFlatButton Button_addDiagnosisDetails;
        private patientHistoryManagementControl patientHistoryManagementControl1;
        public Bunifu.Framework.UI.BunifuFlatButton Button_viewDiagnosisDetails;
        private viewDiagnosisDetailsControl viewDiagnosisDetailsControl1;
        public Bunifu.Framework.UI.BunifuSeparator Separator_PD;
        public Bunifu.Framework.UI.BunifuFlatButton Button_Payments;
        public Bunifu.Framework.UI.BunifuFlatButton Button_Inventory;
        public Bunifu.Framework.UI.BunifuSeparator Separator_CRI;
        public System.Windows.Forms.Panel panel_labReports;
        public Bunifu.Framework.UI.BunifuSeparator Separator_ID;
        public Bunifu.Framework.UI.BunifuSeparator Separator1;
        public Bunifu.Framework.UI.BunifuFlatButton Button_createInventory;
        public Bunifu.Framework.UI.BunifuSeparator Separator_UIP;
        public Bunifu.Framework.UI.BunifuFlatButton Button_updateInternalPatients;
        public Bunifu.Framework.UI.BunifuSeparator Separator_RDD;
        public Bunifu.Framework.UI.BunifuSeparator Separator_VDD;
        public Bunifu.Framework.UI.BunifuFlatButton Button_inventoryReport;
        private viewInventoryControl viewInventoryControl1;
    }
}