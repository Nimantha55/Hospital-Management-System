﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MssCorsework
{
    public partial class viewLabReportsControl : UserControl
    {
        public viewLabReportsControl()
        {
            InitializeComponent();
        }

        SQLQueries sqlq = new SQLQueries();
        labReportViewer lrv = new labReportViewer();

        private void Button_Search_Click(object sender, EventArgs e)
        {
            try
            {
                this.tableLabReportsTableAdapter.report(this.mSSDBDataSet1.TableLabReports, Textbox_SearchNo.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

            
            
        }

        private void Textbox_SearchID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Textbox_SearchNo.Text != "")
            {
                label_ESearchID.Visible = false;
            }

            //allow only numaric values for contact number
            char ch = e.KeyChar;
            if (!Char.IsDigit(ch) && ch != 8 && ch != 32)
            {
                e.Handled = true;
            }
        }


        private void Button_Clear_Click(object sender, EventArgs e)
        {
            string ID = Textbox_SearchNo.Text;

            labReport1 lr = new labReport1();
            SqlConnection con = new SqlConnection();
            con = MSSDBConnection.MSSConnection();
            string labReport = "SELECT * FROM TableLabReports WHERE repNo = " + ID + "";
            DataSet ds = new DataSet();
            SqlDataAdapter sda = new SqlDataAdapter(labReport, con);
            sda.Fill(ds, "TableLabReports");

            lr.SetDataSource(ds.Tables["TableLabReports"]);
            lrv.crystalReportViewer1.ReportSource = lr;
            lrv.crystalReportViewer1.Refresh();
            lrv.Show();
        }

        private void ReportToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.tableLabReportsTableAdapter.report(this.mSSDBDataSet1.TableLabReports, repNoToolStripTextBox.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}
